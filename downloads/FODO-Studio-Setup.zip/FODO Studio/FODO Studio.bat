@echo off
cd /d "%~dp0"
title FODO Studio
if not exist ".setup_done" (
  echo FODO Studio is not set up yet on this computer. Running setup first...
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
  if not exist ".setup_done" ( echo Setup did not finish. See setup_log.txt & pause & exit /b 1 )
)
set "LOG=%~dp0run_log.txt"
(echo ==== %date% %time% ====) > "%LOG%" 2>nul || set "LOG=%~dp0run_log_%RANDOM%.txt"
set "PATH=%PATH%;%LOCALAPPDATA%\Microsoft\WinGet\Links"
where ffmpeg >nul 2>&1 || for /d %%D in ("%LOCALAPPDATA%\Microsoft\WinGet\Packages\Gyan.FFmpeg*") do for /d %%E in ("%%D\ffmpeg-*") do set "PATH=%PATH%;%%E\bin"
where ffmpeg >nul 2>&1 || (echo FFmpeg is missing. Run setup.ps1 again. & pause & exit /b 1)
rem Already running? Just open it.
powershell -NoProfile -Command "try{ Invoke-RestMethod http://127.0.0.1:8777/health -TimeoutSec 2 | Out-Null; exit 0 }catch{ exit 1 }"
if %errorlevel%==0 ( start "" http://127.0.0.1:8777 & exit /b 0 )
powershell -NoProfile -Command "$o=Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'; if(Test-Path $o){ try{Invoke-RestMethod http://127.0.0.1:11434/api/tags -TimeoutSec 2 | Out-Null}catch{Start-Process $o -ArgumentList serve -WindowStyle Hidden} }"
echo FODO Studio is running at http://127.0.0.1:8777
echo Keep this window open (you can minimise it). Close it to stop FODO Studio.
start "" cmd /c "timeout /t 6 >nul & start http://127.0.0.1:8777"
".venv\Scripts\python.exe" -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8777 >> "%LOG%" 2>&1
echo FODO Studio stopped. See run_log.txt
pause
