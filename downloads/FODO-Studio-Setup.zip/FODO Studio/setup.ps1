# FODO Studio - one-time setup for this computer (run by the installer, safe to run again).
# Installs what this PC needs, sized to its hardware:
#   Python 3.12 + FFmpeg (+ Deno for link import) via winget, the app's Python packages,
#   CUDA libraries only when an NVIDIA GPU exists, and a local AI model sized to the RAM.
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot
Start-Transcript -Path (Join-Path $PSScriptRoot "setup_log.txt") -Force | Out-Null
$Host.UI.RawUI.WindowTitle = "FODO Studio setup"
function Refresh-Path {
  $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User")
}
function Has($cmd) { return [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function Step($t) { Write-Host ""; Write-Host "==> $t" -ForegroundColor DarkYellow }

Write-Host "FODO Studio setup" -ForegroundColor DarkYellow
Write-Host "This takes 5-15 minutes the first time (downloads ~1-3 GB). Keep this window open."

# Stop FODO Studio from THIS folder if it is running, so its files can be updated.
$here = [Regex]::Escape($PSScriptRoot)
Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object { $_.CommandLine -match 'uvicorn backend.app.main' -and $_.ExecutablePath -match $here } |
  ForEach-Object { Stop-Process -Id $_.ProcessId -Force }

# --- This PC ---
$ramGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 1)
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$gpus = (Get-CimInstance Win32_VideoController | ForEach-Object { $_.Name }) -join ", "
Write-Host ("This PC: {0} ({1} threads), {2} GB RAM, {3}" -f $cpu.Name.Trim(), $cpu.NumberOfLogicalProcessors, $ramGB, $gpus)

if (-not (Has "winget")) {
  Write-Host ""
  Write-Host "Windows Package Manager (winget) is missing. Install 'App Installer' from the Microsoft Store, then run this setup again." -ForegroundColor Red
  Start-Process "ms-windows-store://pdp/?productid=9NBLGGH4NNS1"
  throw "winget missing"
}

# --- Python ---
Step "Python"
$py = $null
foreach ($c in @("py -3.12", "py -3.11", "python")) {
  try { $v = & cmd /c "$c --version 2>&1"; if ($v -match "Python 3\.(1[1-3])") { $py = $c; break } } catch {}
}
if (-not $py) {
  Write-Host "Installing Python 3.12..." -ForegroundColor Yellow
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements --silent
  Refresh-Path
  $py = "py -3.12"
  try { & cmd /c "$py --version" | Out-Null } catch { $py = "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe" }
}
Write-Host "Python: $py"

# --- FFmpeg ---
Step "FFmpeg (video engine)"
if (-not (Has "ffmpeg")) {
  winget install -e --id Gyan.FFmpeg --accept-package-agreements --accept-source-agreements --silent
  Refresh-Path
}
if (-not (Has "ffmpeg")) {
  $links = Join-Path $env:LOCALAPPDATA "Microsoft\WinGet\Links"
  if (Test-Path (Join-Path $links "ffmpeg.exe")) { $env:Path += ";$links" }
}
if (-not (Has "ffmpeg")) { throw "FFmpeg not found after install. Run this setup again, or install FFmpeg from https://www.gyan.dev/ffmpeg/builds/" }
& ffmpeg -version | Select-Object -First 1

# --- Deno (yt-dlp needs it for YouTube link import) ---
if (-not (Has "deno")) {
  Step "Deno (for importing YouTube links)"
  winget install -e --id DenoLand.Deno --accept-package-agreements --accept-source-agreements --silent 2>&1 | Out-Null
  Refresh-Path
}

# --- Python packages ---
Step "App packages (first time 3-6 minutes)"
if (-not (Test-Path ".venv\Scripts\python.exe")) { & cmd /c "$py -m venv .venv" }
$ErrorActionPreference = "Continue"
& .\.venv\Scripts\python.exe -m pip install --upgrade pip --quiet 2>&1 | Out-Null
& .\.venv\Scripts\python.exe -m pip install --prefer-binary -r requirements.txt --quiet 2>&1 | Where-Object { $_ -notmatch "WARNING" }
if ($LASTEXITCODE -ne 0) { $ErrorActionPreference = "Stop"; throw "Installing Python packages failed (check the internet connection and run setup again)" }
& .\.venv\Scripts\python.exe -m pip install --force-reinstall --no-deps --quiet opencv-contrib-python-headless 2>&1 | Out-Null

# --- NVIDIA: GPU speech AI (only when this PC has an NVIDIA card) ---
if (Has "nvidia-smi") {
  Step "NVIDIA GPU found: installing CUDA libraries for fast speech AI (~1 GB)"
  & .\.venv\Scripts\python.exe -m pip install --quiet "nvidia-cublas-cu12" "nvidia-cudnn-cu12>=9,<10" 2>&1 | Where-Object { $_ -notmatch "WARNING" }
}

# --- Local AI for titles / ideas / replies, sized to this PC's memory ---
New-Item -ItemType Directory -Force -Path "storage" | Out-Null
$settingsPath = "storage\settings.json"
$settings = [ordered]@{}
if (Test-Path $settingsPath) {   # Windows PowerShell 5.1 has no -AsHashtable
  try { (Get-Content $settingsPath -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $settings[$_.Name] = $_.Value } } catch {}
}
if ($ramGB -ge 16) { $llm = "qwen2.5:3b" } elseif ($ramGB -ge 8) { $llm = "qwen2.5:1.5b" } else { $llm = $null }
if ($llm) {
  Step "Local AI model $llm (one time download)"
  $ollama = Join-Path $env:LOCALAPPDATA "Programs\Ollama\ollama.exe"
  if (-not (Test-Path $ollama) -and -not (Has "ollama")) {
    winget install -e --id Ollama.Ollama --accept-package-agreements --accept-source-agreements --silent 2>&1 | Out-Null
    Refresh-Path
  }
  if (Has "ollama") { $ollama = (Get-Command ollama).Source }
  if (Test-Path $ollama) {
    try { Invoke-RestMethod -Uri "http://127.0.0.1:11434/api/tags" -TimeoutSec 3 | Out-Null } catch {
      Start-Process -FilePath $ollama -ArgumentList "serve" -WindowStyle Hidden; Start-Sleep -Seconds 5 }
    & $ollama pull $llm 2>&1 | Select-Object -Last 2
    $settings["llm_model"] = $llm; $settings["use_llm"] = $true
  } else { $settings["use_llm"] = $false }
} else {
  Write-Host "Less than 8 GB RAM: local AI titles are switched off so clipping stays smooth." -ForegroundColor DarkYellow
  $settings["use_llm"] = $false
}
[IO.File]::WriteAllText((Join-Path $PSScriptRoot $settingsPath), ($settings | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))   # no BOM

$ErrorActionPreference = "Stop"
Step "Checking"
& .\.venv\Scripts\python.exe -c "import fastapi, faster_whisper, cv2, scenedetect, yt_dlp; print('All parts OK')"
New-Item -ItemType File -Force -Path ".setup_done" | Out-Null
Write-Host ""
Write-Host "FODO Studio is ready. Open it from the 'FODO Studio' icon on your desktop." -ForegroundColor Green
Write-Host "It checks this PC's processor, memory and graphics card on first start and sets its power to match."
Stop-Transcript | Out-Null
