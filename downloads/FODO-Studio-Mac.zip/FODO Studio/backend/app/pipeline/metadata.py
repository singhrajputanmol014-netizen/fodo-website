"""FFprobe metadata extraction + output verification."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path


def ffprobe(path: str | Path) -> dict:
    out = subprocess.run(
        [
            "ffprobe", "-v", "error", "-print_format", "json",
            "-show_format", "-show_streams", str(path),
        ],
        capture_output=True, text=True, check=True,
    ).stdout
    return json.loads(out)


def extract_metadata(path: str | Path) -> dict:
    raw = ffprobe(path)
    fmt = raw.get("format", {})
    v = next((s for s in raw.get("streams", []) if s.get("codec_type") == "video"), None)
    a = next((s for s in raw.get("streams", []) if s.get("codec_type") == "audio"), None)
    if v is None:
        raise ValueError("No video stream found")

    def _fps(s: dict) -> float:
        fr = s.get("avg_frame_rate") or s.get("r_frame_rate") or "0/1"
        num, _, den = fr.partition("/")
        try:
            return round(float(num) / float(den or 1), 3)
        except (ValueError, ZeroDivisionError):
            return 0.0

    w, h = int(v.get("width", 0)), int(v.get("height", 0))
    return {
        "duration": float(fmt.get("duration", 0)),
        "size_bytes": int(fmt.get("size", 0)),
        "container": fmt.get("format_name", ""),
        "width": w,
        "height": h,
        "fps": _fps(v),
        "video_codec": v.get("codec_name", ""),
        "audio_codec": a.get("codec_name") if a else None,
        "audio_channels": a.get("channels") if a else 0,
        "aspect_ratio": f"{w}:{h}",
        "has_audio": a is not None,
    }


def verify_output(path: str | Path, expected_duration: float | None = None) -> dict:
    """Verify a rendered file is a real playable video. Returns verification dict."""
    p = Path(path)
    result: dict = {"ok": False, "checks": {}}
    if not p.exists() or p.stat().st_size < 1024:
        result["checks"]["file_exists_nonempty"] = False
        return result
    result["checks"]["file_exists_nonempty"] = True
    try:
        meta = extract_metadata(p)
    except Exception as e:  # noqa: BLE001
        result["checks"]["ffprobe_readable"] = False
        result["error"] = str(e)
        return result
    result["checks"]["ffprobe_readable"] = True
    result["meta"] = meta
    result["checks"]["has_video_frames"] = meta["width"] > 0 and meta["height"] > 0
    result["checks"]["has_audio"] = meta["has_audio"]
    if expected_duration is not None:
        drift = abs(meta["duration"] - expected_duration)
        result["checks"]["duration_within_1s"] = drift <= 1.0
        result["duration_drift"] = round(drift, 3)
    result["ok"] = all(v for k, v in result["checks"].items() if k != "has_audio")
    return result
