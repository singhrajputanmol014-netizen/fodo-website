"""Creative template engine: original presets (no third-party assets).

A template bundles caption style, aspect, framing, audio treatment, quality
profile and placement. Users can save custom templates (stored in DB).
"""
from __future__ import annotations

BUILTIN_TEMPLATES: dict[str, dict] = {
    "luxury_brand":     {"label": "Luxury Brand", "caption_style": "luxury", "aspect": "4:5", "profile": "quality", "placement": "lower", "audio_normalize": True, "category": "Brand"},
    "real_estate":      {"label": "Real Estate", "caption_style": "modern_editorial", "aspect": "9:16", "profile": "quality", "placement": "lower", "audio_normalize": True, "category": "Business"},
    "podcast":          {"label": "Podcast", "caption_style": "podcast", "aspect": "9:16", "profile": "balanced", "placement": "lower", "audio_normalize": True, "category": "Talk"},
    "tech_startup":     {"label": "Tech Startup", "caption_style": "kinetic", "aspect": "9:16", "profile": "balanced", "placement": "lower", "audio_normalize": True, "category": "Business"},
    "finance":          {"label": "Finance", "caption_style": "corporate", "aspect": "9:16", "profile": "balanced", "placement": "lower", "audio_normalize": True, "category": "Business"},
    "educational":      {"label": "Educational", "caption_style": "educational", "aspect": "9:16", "profile": "balanced", "placement": "lower", "audio_normalize": True, "category": "Education"},
    "gaming":           {"label": "Gaming", "caption_style": "gaming", "aspect": "9:16", "profile": "balanced", "placement": "middle", "audio_normalize": True, "category": "Entertainment"},
    "comedy":           {"label": "Comedy", "caption_style": "comedy", "aspect": "9:16", "profile": "economy", "placement": "middle", "audio_normalize": True, "category": "Entertainment"},
    "interview":        {"label": "Interview", "caption_style": "documentary", "aspect": "9:16", "profile": "balanced", "placement": "lower", "audio_normalize": True, "category": "Talk"},
    "documentary":      {"label": "Documentary", "caption_style": "documentary", "aspect": "16:9", "profile": "quality", "placement": "lower", "audio_normalize": True, "category": "Film"},
    "motivational":     {"label": "Motivational", "caption_style": "motivational", "aspect": "9:16", "profile": "balanced", "placement": "middle", "audio_normalize": True, "category": "Inspiration"},
    "product_marketing":{"label": "Product Marketing", "caption_style": "premium_social", "aspect": "1:1", "profile": "quality", "placement": "lower", "audio_normalize": True, "category": "Brand"},
    "business_explainer":{"label": "Business Explainer", "caption_style": "corporate", "aspect": "16:9", "profile": "balanced", "placement": "lower", "audio_normalize": True, "category": "Business"},
    "film_trailer":     {"label": "Film Trailer", "caption_style": "cinematic", "aspect": "21:9", "profile": "quality", "placement": "lower", "audio_normalize": True, "category": "Film"},
    "talking_head":     {"label": "Talking Head", "caption_style": "bold_creator", "aspect": "9:16", "profile": "balanced", "placement": "lower", "audio_normalize": True, "category": "Talk"},
    "reaction":         {"label": "Reaction", "caption_style": "bold_creator", "aspect": "9:16", "profile": "economy", "placement": "middle", "audio_normalize": True, "category": "Entertainment"},
    "storytelling":     {"label": "Storytelling", "caption_style": "storytelling", "aspect": "9:16", "profile": "balanced", "placement": "lower", "audio_normalize": True, "category": "Inspiration"},
    "fodo_signature":   {"label": "FODO Signature", "caption_style": "fodo_orange", "aspect": "9:16", "profile": "quality", "placement": "lower", "audio_normalize": True, "category": "Brand"},
}

TEMPLATE_KEYS = ("caption_style", "aspect", "profile", "placement", "audio_normalize")
