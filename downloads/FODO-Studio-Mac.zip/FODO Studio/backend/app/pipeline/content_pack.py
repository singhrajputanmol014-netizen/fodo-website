"""AI content pack for a clip: titles, descriptions, hashtags, hook text, thumbnail ideas,
summary, keywords, audience, platform copy, category.

Written by the local LLM (Ollama) when it is running; otherwise a deterministic fallback built
from the clip's own words. Everything is a suggestion and editable - no platform analytics are
invented (no "this will get 1M views")."""
from __future__ import annotations

import re
from collections import Counter

from . import llm

_STOP = set("""a an the and or but so if then than that this is are was were be been am i you he she it we they me
him her us them my your his its our their to of in on at by for with from up as just very not no do does did have
has had will would can could should what who when where why how all some more like get got go yeah okay ok um uh
really thing things know think going gonna want say said one two people because about there here also only even
every single day today always never much many make made lot thats it's that's dont don't im i'm
hai ka ki ke ko se me mein aur bhi toh to ye yeh woh wo na nahi kya ho tha thi hum main tum aap""".split())

CATEGORIES = ["Business & money", "Self-improvement", "Comedy", "Entertainment", "Education", "Gaming",
              "Sports", "Tech", "Health & fitness", "Relationships", "News & current affairs", "Lifestyle"]


def _keywords(text: str, n: int = 8) -> list[str]:
    ws = [w for w in re.findall(r"[A-Za-zऀ-ॿ']{3,}", text.lower()) if w not in _STOP]
    return [w for w, _ in Counter(ws).most_common(n)]


def fallback(title: str, text: str, channel: str = "") -> dict:
    kw = _keywords(text)
    first = re.split(r"(?<=[.!?])\s+", text.strip())[0][:120] if text.strip() else title
    tag = lambda w: "#" + re.sub(r"[^A-Za-z0-9ऀ-ॿ]", "", w.title())       # noqa: E731
    hashtags = [tag(w) for w in kw[:6]] + ["#shorts", "#reels", "#podcast"]
    return {
        "titles": [title, f"{title} 🤯", f"Nobody talks about this: {title.lower()}",
                   f"The truth about {kw[0] if kw else title.lower()}", f"Watch till the end - {title.lower()}"],
        "descriptions": [f"{first}\n\n{('From ' + channel + '. ') if channel else ''}Full conversation linked.",
                         f"{title}. {first}", f"Key moment: {first}"],
        "hashtags": hashtags,
        "hook_text": [title.upper()[:40], (first[:38] + "…") if len(first) > 40 else first],
        "thumbnail": [f"Close-up of the speaker mid-sentence + 3-word text: \"{' '.join(kw[:3]).upper()}\"",
                      "High-contrast frame at the strongest reaction, face on the left third, text on the right"],
        "summary": first,
        "keywords": kw,
        "audience": "Viewers interested in " + (", ".join(kw[:3]) if kw else "this topic"),
        "platform_copy": {"instagram": f"{title} 👇\n\n{first}\n\n" + " ".join(hashtags[:8]),
                          "youtube_shorts": f"{title} #shorts", "linkedin": f"{first}\n\nWhat do you think?"},
        "category": "Entertainment",
        "source": "fallback (local LLM not running) - built from the clip's own words",
    }


def build(title: str, text: str, channel: str = "", lang_hint: str = "") -> dict:
    text = (text or "")[:3500]
    prompt = f"""You write social media copy for a short video clip. Use ONLY facts in the transcript.
Do not invent numbers, views or claims. If the transcript is Hindi/Hinglish, write Hinglish (Roman script).
Clip title: {title}
Channel/source: {channel}
Transcript: {text}

Return JSON with exactly these keys:
"titles": 5 short catchy titles (max 60 chars),
"descriptions": 3 descriptions (2-3 sentences),
"hashtags": 10 relevant hashtags,
"hook_text": 2 on-screen hook lines (max 6 words),
"thumbnail": 2 thumbnail ideas,
"summary": one sentence,
"keywords": 8 keywords,
"audience": who this is for (one sentence),
"platform_copy": {{"instagram": caption, "youtube_shorts": title, "linkedin": post}},
"category": one of {CATEGORIES}"""
    out = llm.generate_json(prompt, timeout=120)
    base = fallback(title, text, channel)
    if not isinstance(out, dict):
        return base
    res = {}
    for k, v in base.items():
        got = out.get(k)
        if k == "platform_copy":
            res[k] = {**v, **{kk: str(vv)[:2200] for kk, vv in (got or {}).items() if isinstance(got, dict)}}
        elif isinstance(v, list):
            res[k] = [str(x)[:300] for x in got][:10] if isinstance(got, list) and got else v
        elif k == "source":
            continue
        else:
            res[k] = str(got)[:600] if got else v
    hs = []
    for h in res["hashtags"]:
        h = "#" + re.sub(r"[^A-Za-z0-9_ऀ-ॿ]", "", h.lstrip("#"))
        if len(h) > 2 and h.lower() not in {x.lower() for x in hs}:
            hs.append(h)
    res["hashtags"] = hs[:12]
    res["source"] = f"local LLM ({llm.model_name()})"
    return res
