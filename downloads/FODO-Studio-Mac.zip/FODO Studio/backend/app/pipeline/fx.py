"""Filters (colour looks), CapCut-style adjustments, video effects and the watermark overlay.

Everything is a plain FFmpeg filter, so a preview frame and the exported video look the same.
`graph(src, dst, fx)` returns a filter-graph fragment from label [src] to label [dst].

fx = {"filter": "teal_orange", "intensity": 80,
      "adjust": {"brightness": 0, "contrast": 0, "saturation": 0, "exposure": 0, "temperature": 0,
                 "tint": 0, "vibrance": 0, "highlights": 0, "shadows": 0, "fade": 0, "sharpen": 0,
                 "vignette": 0, "grain": 0, "hue": 0},          # each -100..100 (sharpen/vignette/grain/fade 0..100)
      "effects": ["glow", "letterbox", ...]}
"""
from __future__ import annotations

FILTERS: dict[str, dict] = {
    "none":        {"label": "Original", "group": "Basic", "vf": ""},
    # --- portrait / everyday
    "vivid":       {"label": "Vivid", "group": "Basic", "vf": "eq=contrast=1.08:saturation=1.35,unsharp=5:5:0.4"},
    "natural":     {"label": "Natural", "group": "Basic", "vf": "eq=contrast=1.04:saturation=1.08:gamma=1.02"},
    "bright_air":  {"label": "Bright air", "group": "Basic", "vf": "eq=brightness=0.05:contrast=0.97:saturation=1.05,curves=all='0/0.04 1/1'"},
    "crisp":       {"label": "Crisp", "group": "Basic", "vf": "eq=contrast=1.12:saturation=1.05,unsharp=7:7:0.8"},
    "soft_skin":   {"label": "Soft skin", "group": "Portrait", "vf": "smartblur=lr=1.5:ls=-0.4:lt=-3,eq=brightness=0.02:saturation=1.05,colorbalance=rm=0.02:gm=0.0:bm=-0.02"},
    "glow_skin":   {"label": "Warm glow", "group": "Portrait", "vf": "colorbalance=rs=0.03:rm=0.04:bm=-0.03,eq=brightness=0.03:saturation=1.08:gamma=1.04"},
    "peach":       {"label": "Peach", "group": "Portrait", "vf": "colorbalance=rm=0.05:gm=0.01:bm=-0.02:rh=0.03,eq=saturation=0.95:brightness=0.03"},
    # --- cinematic
    "teal_orange": {"label": "Teal & orange", "group": "Cinematic", "vf": "colorbalance=rs=-0.08:gs=-0.02:bs=0.1:rm=0.05:bm=-0.05:rh=0.08:bh=-0.08,eq=contrast=1.1:saturation=1.15"},
    "blockbuster": {"label": "Blockbuster", "group": "Cinematic", "vf": "colorbalance=rs=-0.05:bs=0.08:rh=0.06:bh=-0.05,eq=contrast=1.18:saturation=1.05,vignette=PI/5"},
    "bleach":      {"label": "Bleach bypass", "group": "Cinematic", "vf": "eq=contrast=1.25:saturation=0.55:gamma=0.95"},
    "noir_film":   {"label": "Film noir", "group": "Cinematic", "vf": "hue=s=0,eq=contrast=1.35:gamma=0.9,vignette=PI/4"},
    "moonlight":   {"label": "Moonlight", "group": "Cinematic", "vf": "colorbalance=rs=-0.08:bs=0.12:rm=-0.05:bm=0.08,eq=brightness=-0.03:saturation=0.7:contrast=1.1"},
    "golden_hour": {"label": "Golden hour", "group": "Cinematic", "vf": "colorbalance=rs=0.06:gs=0.02:bs=-0.08:rm=0.07:bm=-0.07:rh=0.05,eq=saturation=1.15:contrast=1.05"},
    "desert":      {"label": "Desert", "group": "Cinematic", "vf": "colorbalance=rs=0.06:rm=0.06:bm=-0.08:bh=-0.06,eq=saturation=0.85:contrast=1.08,curves=all='0/0.05 1/0.97'"},
    "arctic":      {"label": "Arctic", "group": "Cinematic", "vf": "colorbalance=bs=0.08:bm=0.06:bh=0.04:rh=-0.03,eq=brightness=0.03:saturation=0.8"},
    # --- film / retro
    "kodak_warm":  {"label": "Warm film", "group": "Film", "vf": "curves=r='0/0.03 0.5/0.55 1/1':g='0/0.02 0.5/0.5 1/0.96':b='0/0.05 0.5/0.45 1/0.9',eq=saturation=1.08"},
    "fuji_fresh":  {"label": "Fresh film", "group": "Film", "vf": "curves=r='0/0 0.5/0.48 1/0.97':g='0/0.02 0.5/0.53 1/1':b='0/0.06 0.5/0.52 1/0.98',eq=saturation=1.05"},
    "faded":       {"label": "Faded", "group": "Film", "vf": "curves=all='0/0.12 0.5/0.52 1/0.9',eq=saturation=0.8"},
    "matte":       {"label": "Matte", "group": "Film", "vf": "curves=all='0/0.08 0.25/0.24 0.75/0.78 1/0.94',eq=contrast=1.02:saturation=0.9"},
    "sepia":       {"label": "Sepia", "group": "Film", "vf": "colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131"},
    "retro70":     {"label": "70s retro", "group": "Film", "vf": "colorbalance=rs=0.08:gs=0.04:bs=-0.08:rh=0.06,curves=all='0/0.07 1/0.93',eq=saturation=1.2"},
    "polaroid":    {"label": "Instant photo", "group": "Film", "vf": "curves=all='0/0.1 0.5/0.55 1/0.95',colorbalance=bs=0.05:rh=0.04,eq=saturation=0.9"},
    "bw_soft":     {"label": "B&W soft", "group": "Film", "vf": "hue=s=0,curves=all='0/0.06 1/0.95'"},
    "bw_hard":     {"label": "B&W high contrast", "group": "Film", "vf": "hue=s=0,eq=contrast=1.4"},
    # --- vibe / creative
    "cyberpunk":   {"label": "Cyberpunk", "group": "Vibe", "vf": "colorbalance=rs=0.08:bs=0.12:gs=-0.06:rh=0.05:bh=0.08:gh=-0.05,eq=contrast=1.15:saturation=1.4"},
    "pastel":      {"label": "Pastel", "group": "Vibe", "vf": "curves=all='0/0.15 1/0.95',eq=saturation=0.8:brightness=0.04,colorbalance=rh=0.02:bh=0.03"},
    "dreamy":      {"label": "Dreamy", "group": "Vibe", "vf": "curves=all='0/0.08 1/1',eq=brightness=0.04:saturation=0.9,colorbalance=rh=0.03:bh=0.03"},
    "sunset":      {"label": "Sunset", "group": "Vibe", "vf": "colorbalance=rs=0.1:gs=-0.02:bs=-0.05:rm=0.08:bm=0.02:rh=0.06:bh=0.04,eq=saturation=1.2"},
    "forest":      {"label": "Forest", "group": "Vibe", "vf": "colorbalance=gs=0.05:gm=0.04:rm=-0.02:bh=-0.03,eq=saturation=1.08:contrast=1.06"},
    "food":        {"label": "Food fresh", "group": "Vibe", "vf": "eq=brightness=0.03:contrast=1.06:saturation=1.3,colorbalance=rm=0.03:bm=-0.02,unsharp=5:5:0.5"},
    "lofi":        {"label": "Lo-fi", "group": "Vibe", "vf": "curves=all='0/0.1 1/0.88',eq=saturation=0.75,noise=alls=8:allf=t"},
    "night_neon":  {"label": "Neon night", "group": "Vibe", "vf": "eq=contrast=1.15:saturation=1.45,colorbalance=bs=0.1:rs=0.04:gs=-0.05"},
    "invert":      {"label": "Negative", "group": "Vibe", "vf": "negate"},
}

EFFECTS: dict[str, dict] = {
    "vignette":   {"label": "Vignette", "group": "Look", "vf": "vignette=PI/4"},
    "grain":      {"label": "Film grain", "group": "Look", "vf": "noise=alls=9:allf=t"},
    "glow":       {"label": "Soft glow", "group": "Look", "graph": "split[a{n}][b{n}];[b{n}]gblur=sigma=14,eq=brightness=0.04[c{n}];[a{n}][c{n}]blend=all_mode=screen:all_opacity=0.35"},
    "bloom":      {"label": "Highlight bloom", "group": "Look", "graph": "split[a{n}][b{n}];[b{n}]curves=all='0/0 0.6/0 1/1',gblur=sigma=20[c{n}];[a{n}][c{n}]blend=all_mode=screen:all_opacity=0.6"},
    "letterbox":  {"label": "Cinema bars", "group": "Frame", "vf": "drawbox=x=0:y=0:w=iw:h=ih*0.07:color=black:t=fill,drawbox=x=0:y=ih*0.93:w=iw:h=ih*0.07:color=black:t=fill"},
    "border":     {"label": "White border", "group": "Frame", "vf": "drawbox=x=0:y=0:w=iw:h=ih:color=white@0.95:t=18"},
    "mirror":     {"label": "Mirror (flip)", "group": "Frame", "vf": "hflip"},
    "sharpen":    {"label": "Sharpen HD", "group": "Clarity", "vf": "unsharp=7:7:0.9:5:5:0.0"},
    "denoise":    {"label": "Clean noise", "group": "Clarity", "vf": "hqdn3d=3:3:6:6"},
    "glitch":     {"label": "Glitch", "group": "Retro", "vf": "rgbashift=rh=6:bh=-6:gv=2,noise=alls=12:allf=t"},
    "chroma":     {"label": "RGB split", "group": "Retro", "vf": "rgbashift=rh=4:bh=-4"},
    "vhs":        {"label": "VHS tape", "group": "Retro", "vf": "rgbashift=rh=3:bh=-3,gblur=sigma=0.7,noise=alls=12:allf=t,eq=saturation=1.2"},
    "old_film":   {"label": "Old film", "group": "Retro", "vf": "colorchannelmixer=.393:.769:.189:0:.349:.686:.168:0:.272:.534:.131,noise=alls=14:allf=t,vignette=PI/3.5,eq=brightness='0.02*sin(t*23)':eval=frame"},
    "flicker":    {"label": "Light flicker", "group": "Motion", "vf": "eq=brightness='0.035*sin(t*31)':eval=frame"},
    "shake":      {"label": "Camera shake", "group": "Motion", "vf": "scale=iw*1.05:ih*1.05,crop=iw/1.05:ih/1.05:x='(iw-ow)/2+((iw-ow)/2)*sin(t*17)*0.6':y='(ih-oh)/2+((ih-oh)/2)*sin(t*13)*0.6'"},
    "echo":       {"label": "Motion trail", "group": "Motion", "vf": "tmix=frames=4:weights='1 0.6 0.35 0.2'"},
    "dream_trail": {"label": "Dream trail", "group": "Motion", "vf": "lagfun=decay=0.93"},
    "pixel":      {"label": "Pixelate", "group": "Creative", "vf": "scale=iw/14:ih/14:flags=neighbor,scale=iw*14:ih*14:flags=neighbor"},
    "sketch":     {"label": "Sketch", "group": "Creative", "vf": "edgedetect=low=0.08:high=0.3,negate"},
    "posterize":  {"label": "Posterize", "group": "Creative", "vf": "lutyuv=y='bitand(val,224)'"},
}

ADJUST_KEYS = ("brightness", "contrast", "saturation", "exposure", "temperature", "tint", "vibrance",
               "highlights", "shadows", "fade", "sharpen", "vignette", "grain", "hue")


def _num(v, lo=-100.0, hi=100.0) -> float:
    try:
        return max(lo, min(hi, float(v)))
    except (TypeError, ValueError):
        return 0.0


def clean(fx: dict | None) -> dict | None:
    """Validate user input into a safe fx dict (or None when nothing is set)."""
    if not isinstance(fx, dict):
        return None
    f = fx.get("filter") if fx.get("filter") in FILTERS else "none"
    inten = _num(fx.get("intensity", 100), 0, 100)
    adj = {k: _num((fx.get("adjust") or {}).get(k, 0)) for k in ADJUST_KEYS}
    adj = {k: v for k, v in adj.items() if abs(v) >= 1}
    eff = [e for e in dict.fromkeys(fx.get("effects") or []) if e in EFFECTS][:8]
    if f == "none" and not adj and not eff:
        return None
    return {"filter": f, "intensity": inten, "adjust": adj, "effects": eff}


def adjust_vf(a: dict) -> str:
    g = lambda k: a.get(k, 0.0) / 100.0                       # noqa: E731
    out = []
    eq = []
    if g("brightness"):
        eq.append(f"brightness={0.15 * g('brightness'):.3f}")
    if g("contrast"):
        eq.append(f"contrast={1 + 0.35 * g('contrast'):.3f}")
    if g("saturation"):
        eq.append(f"saturation={max(0.0, 1 + g('saturation')):.3f}")
    if eq:
        out.append("eq=" + ":".join(eq))
    if g("exposure"):
        out.append(f"exposure=exposure={1.2 * g('exposure'):.3f}")
    if g("temperature"):
        out.append(f"colortemperature=temperature={6500 - 3000 * g('temperature'):.0f}:mix=0.8")
    if g("tint"):
        t = 0.12 * g("tint")
        out.append(f"colorbalance=gs={-t:.3f}:gm={-t:.3f}:gh={-t * 0.6:.3f}:rs={t / 2:.3f}:bs={t / 2:.3f}")
    if g("vibrance"):
        out.append(f"vibrance=intensity={0.8 * g('vibrance'):.3f}")
    if g("highlights") or g("shadows"):
        h, s = 0.15 * g("highlights"), 0.15 * g("shadows")
        out.append(f"curves=all='0/0 0.25/{max(0.0, min(1.0, 0.25 + s)):.3f} 0.75/{max(0.0, min(1.0, 0.75 + h)):.3f} 1/1'")
    if g("fade") > 0:
        out.append(f"curves=all='0/{0.18 * g('fade'):.3f} 1/{1 - 0.06 * g('fade'):.3f}'")
    if g("hue"):
        out.append(f"hue=h={180 * g('hue'):.1f}")
    if g("sharpen") > 0:
        out.append(f"unsharp=7:7:{1.4 * g('sharpen'):.2f}")
    if g("vignette") > 0:
        out.append(f"vignette=angle={0.15 + 0.6 * g('vignette'):.3f}")
    if g("grain") > 0:
        out.append(f"noise=alls={int(4 + 20 * g('grain'))}:allf=t")
    return ",".join(out)


def graph(src: str, dst: str, fx: dict | None, tag: str = "x") -> str:
    """Filter-graph fragment [src] -> [dst] for filter + intensity + adjustments + effects."""
    fx = clean(fx)
    if not fx:
        return f"[{src}]null[{dst}]"
    parts, cur, n = [], src, 0

    def step(chain: str):
        nonlocal cur, n
        n += 1
        nxt = f"{tag}{n}"
        parts.append(f"[{cur}]{chain}[{nxt}]")
        cur = nxt

    flt = FILTERS[fx["filter"]]["vf"]
    if flt:
        k = fx.get("intensity", 100) / 100.0
        if k >= 0.99:
            step(flt)
        elif k > 0.01:
            n += 1
            a, b, c, o = f"{tag}a{n}", f"{tag}b{n}", f"{tag}c{n}", f"{tag}{n}"
            parts.append(f"[{cur}]format=yuv420p,split[{a}][{b}];[{b}]{flt},format=yuv420p[{c}];"
                         f"[{a}][{c}]blend=all_mode=normal:all_opacity={k:.2f}[{o}]")
            cur = o
    adj = adjust_vf(fx.get("adjust") or {})
    if adj:
        step(adj)
    for e in fx.get("effects") or []:
        d = EFFECTS[e]
        if "graph" in d:
            n += 1
            g = d["graph"].replace("{n}", f"{tag}{n}")
            o = f"{tag}{n}"
            parts.append(f"[{cur}]format=yuv420p,{g},format=yuv420p[{o}]")
            cur = o
        else:
            step(d["vf"])
    parts.append(f"[{cur}]null[{dst}]")
    return ";".join(parts)


# ------------------------------------------------------------------ watermark ----
POSITIONS = {"tl": ("M", "M"), "tc": ("(W-w)/2", "M"), "tr": ("W-w-M", "M"),
             "ml": ("M", "(H-h)/2"), "c": ("(W-w)/2", "(H-h)/2"), "mr": ("W-w-M", "(H-h)/2"),
             "bl": ("M", "H-h-M"), "bc": ("(W-w)/2", "H-h-M"), "br": ("W-w-M", "H-h-M")}


def clean_watermark(w: dict | None) -> dict | None:
    if not isinstance(w, dict) or not w.get("id"):
        return None
    import re
    if not re.fullmatch(r"[0-9a-f]{12}", str(w["id"])):
        return None
    pos = w.get("position") if w.get("position") in POSITIONS or w.get("position") == "custom" else "tr"
    return {"id": w["id"], "position": pos, "size": _num(w.get("size", 18), 3, 60),
            "opacity": _num(w.get("opacity", 85), 5, 100), "margin": _num(w.get("margin", 4), 0, 20),
            "x": _num(w.get("x", 0.8), 0, 1), "y": _num(w.get("y", 0.05), 0, 1)}


def watermark_graph(src: str, wm_in: str, dst: str, w: dict, out_w: int, out_h: int) -> str:
    size = int(out_w * w["size"] / 100) // 2 * 2
    m = int(out_w * w["margin"] / 100)
    op = w["opacity"] / 100
    if w["position"] == "custom":
        x, y = f"(W-w)*{w['x']:.3f}", f"(H-h)*{w['y']:.3f}"
    else:
        x, y = (s.replace("M", str(m)) for s in POSITIONS[w["position"]])
    return (f"[{wm_in}]scale={size}:-1,format=rgba,colorchannelmixer=aa={op:.2f}[wmk];"
            f"[{src}][wmk]overlay=x={x}:y={y}:format=auto[{dst}]")
