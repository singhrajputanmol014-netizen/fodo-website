"""Publish desk: post finished clips to social platforms, track campaigns, views and estimates.

Ported from the standalone "FODO Clip Desk" (Node) into ClipForge, so a clip goes from render to
post in one app. Everything stays on this PC: no tunnel, no public URL.

Platform facts this is built on (checked 19 Nov 2026):
  Instagram  Reels via the resumable upload protocol: the file bytes go straight to
             rupload.facebook.com, so no public URL is needed. 100 API posts / 24 h per
             account (the limit field still reports 50, we warn at 50).
  Facebook   Page Reels API (video_reels start -> rupload -> finish). 30 API reels / 24 h.
  YouTube    videos.insert, resumable. 100 uploads/day per project; unverified projects are no
             longer forced to private (docs updated 12 Nov 2026).
  TikTok     Content Posting API, FILE_UPLOAD in chunks. Until the TikTok app passes its audit,
             every post is private (SELF_ONLY). Desktop app type allows a localhost redirect.
  X          Pay per use ($0.015 per post), so not automated here (no paid APIs). Manual mode.
  LinkedIn   Needs a reviewed app. Manual mode.

Never re-posts something on its own after a crash: a post that was mid-upload when the server
stopped is marked "check" so a human looks first (it may already be live)."""
from __future__ import annotations

import base64
import contextlib
import re
import contextvars
import datetime as dt
import hashlib
import json
import logging
import os
import secrets as _secrets
import threading
import time
import urllib.parse
import uuid
from pathlib import Path

from .config import STORAGE_DIR

log = logging.getLogger("clipforge.publish")

DIR = STORAGE_DIR / "publish"
DATA = DIR / "data.json"
SECRETS = DIR / "secrets.json"
UPLOADS = DIR / "uploads"
GRAPH_V = "v25.0"
GRAPH = f"https://graph.facebook.com/{GRAPH_V}"
_lock = threading.RLock()

# ------------------------------------------------------------------ client projects (workspaces)
# Every client project has its own set of connected accounts. "main" = your own accounts (the
# original single set in secrets["accounts"]); other projects keep theirs in secrets["workspaces"][id].
MAIN = "main"
_WS: contextvars.ContextVar = contextvars.ContextVar("cf_ws", default=MAIN)


def _wsid(ws: str | None) -> str:
    return ws if ws and ws != MAIN else MAIN


@contextlib.contextmanager
def in_ws(ws: str | None):
    tok = _WS.set(_wsid(ws))
    try:
        yield
    finally:
        _WS.reset(tok)


def _acc(s: dict) -> dict:
    """The connected-accounts dict of the current project (inside `with in_ws(...)`)."""
    ws = _WS.get()
    if ws == MAIN:
        return s.setdefault("accounts", {})
    return s.setdefault("workspaces", {}).setdefault(ws, {}).setdefault("accounts", {})


def _post_ws(p: dict) -> str:
    return _wsid(p.get("workspace"))


def _lkey(plat: str, ws: str | None = None) -> str:
    ws = _wsid(ws or _WS.get())
    return plat if ws == MAIN else f"{plat}@{ws}"

# ------------------------------------------------------------------ platforms
PLATFORMS = {
    "instagram": {"label": "Instagram", "icon": "📸", "auth": "meta", "auto": True},
    "facebook": {"label": "Facebook", "icon": "📘", "auth": "meta", "auto": True},
    "youtube": {"label": "YouTube", "icon": "▶️", "auth": "google", "auto": True},
    "tiktok": {"label": "TikTok", "icon": "🎵", "auth": "tiktok", "auto": True},
    "x": {"label": "X", "icon": "𝕏", "auth": None, "auto": False},
    "linkedin": {"label": "LinkedIn", "icon": "💼", "auth": None, "auto": False},
}
# what each platform accepts through its API, and how many API posts a rolling 24 h allows
SPECS = {
    "instagram": {"min_s": 3, "max_s": 900, "max_mb": 1000, "cap24": 50,
                  "note": "Reels 3 s–15 min. Instagram re-compresses on its side."},
    "facebook": {"min_s": 3, "max_s": 90, "max_mb": 1000, "cap24": 30,
                 "note": "Page Reels via API: 3–90 s, at least 540p."},
    "youtube": {"min_s": 1, "max_s": 43200, "max_mb": 256000, "cap24": 100,
                "note": "Up to 3 min and vertical counts as a Short. 100 uploads a day per Google project."},
    "tiktok": {"min_s": 3, "max_s": 600, "max_mb": 4000, "cap24": 15,
               "note": "Private until your TikTok app passes its audit. Around 15 posts a day per account."},
    "x": {"min_s": 0.5, "max_s": 140, "max_mb": 512, "cap24": 0, "note": "Standard accounts: 2:20 max."},
    "linkedin": {"min_s": 3, "max_s": 600, "max_mb": 500, "cap24": 0, "note": ""},
}

# ------------------------------------------------------------------ campaigns
# Seeded from the 9 Content Rewards campaigns (read 19 Nov 2026). Editable in the UI.
SEED_CAMPAIGNS = [
    {"id": "dylan-page", "name": "Dylan Page — GTA VI Marathon", "owner": "NewsDaddy", "network": "Content Rewards",
     "model": "cpm", "cpm": 1.0, "cap_per_clip": 250, "min_payout": 10, "budget": 5000, "spent": 0,
     "status": "active", "priority": 1, "platforms": ["tiktok", "instagram", "youtube", "x"],
     "required_tags": ["#DylanPage"], "source": "https://www.youtube.com/@dylan.page./live",
     "rules": "Marathon footage from 19 Nov 2026 only. 9:16 vertical. Dylan must be the main focus throughout — "
              "intro-only is rejected. English captions. No added watermarks. Do not reuse a thumbnail. No collab "
              "posts. AI footage or fabricated reactions = permanent ban.", "submit_window_min": None},
    {"id": "dasgasd3m", "name": "Dasgasd3m (Dom) x RUCKUS | GTA 6", "owner": "Ruckus", "network": "Content Rewards",
     "model": "cpm", "cpm": 1.0, "cap_per_clip": 100, "min_payout": 10, "budget": 1000, "spent": 0,
     "status": "active", "priority": 2, "platforms": ["tiktok", "youtube"], "required_tags": ["#dasgasdom3"],
     "source": "https://kick.com/dasgasd3m",
     "rules": "ONLY Dom's 18 Nov 2026 Kick stream, live or its VOD. Old clips are style references, not eligible. "
              "Needs a GTA 6-specific account. Credit kick.com/dasgasd3m. Disclose paid content. Submit within 30 "
              "minutes of posting. Deadline 19 Dec 2026.", "submit_window_min": 30},
    {"id": "sypherpk", "name": "SypherPK $7,500 (Fortnite)", "owner": "Reach", "network": "Content Rewards",
     "model": "cpm", "cpm": 2.0, "cap_per_clip": 500, "min_payout": 20, "budget": 7500, "spent": 73,
     "status": "active", "priority": 3, "platforms": ["tiktok", "instagram", "youtube", "x"],
     "required_tags": ["#fortnitecreative", "#uefn"], "source": "https://www.twitch.tv/videos/2929935152?t=00h45m52s",
     "rules": "15 Nov VODs only, within the listed timestamps. Sypher, Replays and Maddynf together must be the "
              "focus. Payout starts only past 10,000 views. Audience at least 50% USA/CA/AU/UK/NZ. English "
              "captions. No AI video, no logos, no botting.", "submit_window_min": None, "min_views": 10000},
    {"id": "tomo", "name": "TOMO GTA VI Clipping", "owner": "Clipping Nation", "network": "Content Rewards",
     "model": "cpm", "cpm": 1.5, "cap_per_clip": 150, "min_payout": 3.5, "budget": 1000, "spent": 390,
     "status": "active", "priority": 4, "platforms": ["tiktok", "instagram", "youtube"], "required_tags": [],
     "source": "https://www.youtube.com/@Tomovids/streams",
     "rules": "Any GTA VI video or stream featuring Tomo. Drive subscribers to his YouTube. Joining their Discord "
              "is required for payout.", "submit_window_min": None},
    {"id": "kai-cenat", "name": "Kai Cenat — $10,000 GTA 6 Pool", "owner": "Clipped & Shipped",
     "network": "Content Rewards", "model": "pool", "cpm": 0, "cap_per_clip": 0, "min_payout": 0,
     "budget": 10000, "spent": 0, "status": "active", "priority": 6, "pool_target": 750000,
     "per_clip_min_views": 1000, "platforms": ["tiktok", "instagram", "youtube", "x"],
     "required_tags": ["#KaiCenat"], "source": "https://www.twitch.tv/kaicenat",
     "rules": "Kai Cenat GTA 6 marathon on Twitch and YouTube. He must be the main focus. 750,000 views needed to "
              "qualify for a pool share; each clip needs 1,000 views to count. Paid only when the brand ends it.",
     "submit_window_min": None},
    {"id": "clix", "name": "Clix GTA VI Marathon Pool", "owner": "Reach", "network": "Content Rewards",
     "model": "pool", "cpm": 0, "cap_per_clip": 0, "min_payout": 0, "budget": 5000, "spent": 0,
     "status": "active", "priority": 7, "pool_target": 400000, "per_clip_min_views": 0,
     "platforms": ["tiktok", "instagram", "youtube", "x"], "required_tags": ["#Clix"],
     "source": "https://www.twitch.tv/clix",
     "rules": "Clix marathon footage from 18 Nov 2026. He must be the primary focus. 400,000 views to qualify. "
              "Audience at least 50% USA/CA/AU/UK/NZ. No AI videos, no logos, no botting. One strike bans you "
              "from every Reach campaign.", "submit_window_min": None},
    {"id": "brettliftsxp", "name": "BrettLiftsXP GTA VI", "owner": "Funnel Clips Community",
     "network": "Content Rewards", "model": "cpm", "cpm": 2.0, "platform_cpm": {"instagram": 0.5, "youtube": 0.5},
     "cap_per_clip": 100, "min_payout": 2, "budget": 1000, "spent": 132, "status": "low", "priority": 8,
     "platforms": ["tiktok", "instagram", "youtube"], "required_tags": [],
     "source": "https://m.twitch.tv/brettliftsxp/home",
     "rules": "$2/1K on TikTok but only $0.50 on Instagram and YouTube. Recent streams only. Show Brett's face and "
              "their banner in every video. After minimum views you must send a screen recording of your in-app "
              "analytics. Top clipper has made $17.85 in four weeks.", "submit_window_min": None},
    {"id": "tokyo-girl", "name": "GTA 6 — Tokyo Girl (music)", "owner": "Placements", "network": "Content Rewards",
     "model": "cpm", "cpm": 0.7, "cap_per_clip": 35, "min_payout": 2, "budget": 2000, "spent": 88,
     "status": "low", "priority": 9, "platforms": ["tiktok", "instagram"], "required_tags": [],
     "source": "https://docs.google.com/document/d/1MouSmbi_618SmahnpcNKQOsveIZxBAR88z8piK_l63w/edit",
     "rules": "The song \"Tokyo Girl\" by Passive must play — only add it if the campaign licenses it to you. "
              "Visuals GTA 6 themed. The $35 cap binds hard: the one clipper on it turned 624,500 views into $80.68.",
     "submit_window_min": None},
    {"id": "bendadonnn", "name": "BenDaDonnn x Puffco GTA 6", "owner": "Launch Clipping", "network": "Content Rewards",
     "model": "cpm", "cpm": 1.0, "cap_per_clip": 400, "min_payout": 10, "budget": 10000, "spent": 0,
     "status": "blocked", "priority": 99, "platforms": ["tiktok", "instagram", "youtube", "x", "facebook"],
     "required_tags": [], "source": "https://twitch.tv/bendadonnn",
     "rules": "BLOCKED. To qualify the clip must feature Puffco cannabis vaporiser devices, hash jars or a Puffco "
              "shoutout. That means posting cannabis-product promotion from an Indian account. Cannabis is illegal "
              "in India outside narrow exceptions, and TikTok, YouTube and Instagram all restrict drug and "
              "drug-paraphernalia content. Do not clip.", "submit_window_min": None},
]
CAMPAIGN_KEYS = {"name", "owner", "network", "model", "cpm", "platform_cpm", "cap_per_clip", "min_payout", "budget",
                 "spent", "status", "priority", "platforms", "required_tags", "source", "rules", "submit_window_min",
                 "pool_target", "per_clip_min_views", "min_views", "deadline", "submit_url"}
SECRET_KEYS = ("meta_app_id", "meta_app_secret", "google_client_id", "google_client_secret",
               "tiktok_client_key", "tiktok_client_secret")


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _iso(t: dt.datetime | None = None) -> str:
    return (t or _now()).isoformat(timespec="seconds")


def _parse(s: str | None) -> dt.datetime | None:
    if not s:
        return None
    try:
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)


# ------------------------------------------------------------------ store
def _read(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=1, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, path)


def load() -> dict:
    with _lock:
        d = _read(DATA, {})
        d.setdefault("campaigns", [dict(c) for c in SEED_CAMPAIGNS])
        d.setdefault("posts", [])
        d.setdefault("uploads", [])
        d.setdefault("limits", {})
        d.setdefault("workspaces", [])
        return d


def save(d: dict) -> None:
    with _lock:
        _write(DATA, d)


def load_secrets() -> dict:
    with _lock:
        s = _read(SECRETS, {})
        s.setdefault("accounts", {})
        s.setdefault("settings", {})
        return s


def save_secrets(s: dict) -> None:
    with _lock:
        _write(SECRETS, s)
        try:
            os.chmod(SECRETS, 0o600)
        except OSError:
            pass


def settings() -> dict:
    s = load_secrets().get("settings", {})
    return {"redirect_base": s.get("redirect_base") or "http://localhost:8777",
            "auto_views": s.get("auto_views", True), "default_gap_min": int(s.get("default_gap_min") or 45),
            "youtube_privacy": s.get("youtube_privacy") or "public",
            "youtube_category": str(s.get("youtube_category") or "20")}


def configured(auth: str | None) -> bool:
    s = load_secrets()
    return {"meta": bool(s.get("meta_app_id") and s.get("meta_app_secret")),
            "google": bool(s.get("google_client_id") and s.get("google_client_secret")),
            "tiktok": bool(s.get("tiktok_client_key") and s.get("tiktok_client_secret"))}.get(auth or "", False)


def connected(platform: str) -> bool:
    acc = _acc(load_secrets())
    if platform == "instagram":
        return bool((acc.get("meta") or {}).get("ig_id"))
    if platform == "facebook":
        return bool((acc.get("meta") or {}).get("page_id"))
    if platform == "youtube":
        return bool((acc.get("google") or {}).get("refresh_token"))
    if platform == "tiktok":
        return bool((acc.get("tiktok") or {}).get("refresh_token"))
    return False


def account_who(platform: str) -> str | None:
    acc = _acc(load_secrets())
    m, g, t = acc.get("meta") or {}, acc.get("google") or {}, acc.get("tiktok") or {}
    return {"instagram": m.get("ig_username") and "@" + m["ig_username"], "facebook": m.get("page_name"),
            "youtube": g.get("channel"), "tiktok": t.get("display_name")}.get(platform)


# ------------------------------------------------------------------ media
def probe(path: str | Path) -> dict:
    try:
        from .pipeline.metadata import extract_metadata
        m = extract_metadata(path)
        return {"duration": round(float(m.get("duration") or 0), 2), "width": m.get("width"), "height": m.get("height")}
    except Exception:  # noqa: BLE001
        return {}


def source_info(src: dict) -> dict | None:
    """Resolve a post source to {path, name, clip_id, thumb, probe}. src = {type:'export'|'upload', id}."""
    if not src:
        return None
    if src.get("type") == "upload":
        u = next((x for x in load()["uploads"] if x["id"] == src.get("id")), None)
        if not u or not Path(u["path"]).exists():
            return None
        return {"path": u["path"], "name": u["name"], "clip_id": None, "thumb": None, "probe": u.get("probe") or {},
                "size": Path(u["path"]).stat().st_size}
    from .database import SessionLocal
    from .models import Export
    with SessionLocal() as db:
        e = db.get(Export, src.get("id"))
        if not e or e.status != "done" or not e.path or not Path(e.path).exists():
            return None
        out = (e.verification or {}).get("output") or {}
        pr = {"duration": out.get("duration"), "width": out.get("width"), "height": out.get("height")}
        if not (pr["width"] and pr["height"] and pr["duration"]):
            pr = probe(e.path) or pr
        thumb = Path(e.path).with_suffix(".jpg")
        return {"path": e.path, "name": e.clip.title if e.clip else Path(e.path).stem, "clip_id": e.clip_id,
                "thumb": f"/api/exports/{e.id}/thumb" if thumb.exists() else None, "probe": pr,
                "size": Path(e.path).stat().st_size}


# ------------------------------------------------------------------ checks
def _posts_24h(d: dict, platform: str) -> int:
    since = _now() - dt.timedelta(hours=24)
    n = 0
    ws = _WS.get()
    for p in d["posts"]:
        if _post_ws(p) != ws:
            continue
        r = (p.get("results") or {}).get(platform) or {}
        if r.get("ok") and r.get("auto") and (_parse(r.get("at")) or since) > since:
            n += 1
    return n


def preflight(payload: dict) -> dict:
    """What would stop this post, and what to watch out for. Problems block; warnings do not."""
    ws = _wsid(payload.get("workspace"))
    if ws != MAIN and not workspace(ws):
        return {"problems": ["This client project no longer exists"], "warnings": []}
    with in_ws(ws):
        return _preflight(payload)


def _preflight(payload: dict) -> dict:
    d = load()
    problems, warnings = [], []
    src = source_info(payload.get("source") or {})
    platforms = [p for p in payload.get("platforms") or [] if p in PLATFORMS]
    caption = payload.get("caption") or ""
    captions = payload.get("captions") or {}
    camp = next((c for c in d["campaigns"] if c["id"] == payload.get("campaign_id")), None)
    if not src:
        problems.append("Clip file not found (render not finished, or the file was deleted)")
    if not platforms:
        problems.append("No platform selected")
    for p in platforms:
        info, spec = PLATFORMS[p], SPECS[p]
        if info["auto"]:
            if not configured(info["auth"]):
                problems.append(f"{info['label']}: app keys are missing in Setup")
            elif not connected(p):
                problems.append(f"{info['label']}: account is not connected")
        else:
            warnings.append(f"{info['label']}: no auto-posting (the X API is paid) — after posting, use 'Manual' "
                            "to copy the caption and post it yourself")
        if src:
            pr = src.get("probe") or {}
            dur, mb = pr.get("duration") or 0, (src.get("size") or 0) / 1048576
            if dur and dur > spec["max_s"]:
                (problems if info["auto"] else warnings).append(
                    f"{info['label']}: clip is {dur:.0f}s, limit is {spec['max_s']}s")
            if dur and dur < spec["min_s"]:
                problems.append(f"{info['label']}: clip is {dur:.1f}s, minimum is {spec['min_s']}s")
            if mb > spec["max_mb"]:
                problems.append(f"{info['label']}: file {mb:.0f} MB, limit {spec['max_mb']} MB")
            if p == "youtube" and dur and dur > 180:
                warnings.append("YouTube: longer than 3 min, so it will post as a regular video, not a Short")
            if p == "facebook" and pr.get("height") and min(pr["height"], pr.get("width") or 9999) < 540:
                problems.append("Facebook Reels: needs at least 540p")
        lim = (d.get("limits") or {}).get(p)
        lim_t = _parse((lim or {}).get("until"))
        if lim_t and lim_t > _now():
            warnings.append(f"{info['label']}: the channel hit its upload limit at {lim['at'][:16].replace('T', ' ')} UTC — "
                            f"posting before ~{lim['until'][:16].replace('T', ' ')} UTC will likely fail. "
                            "Schedule it for after that, or it will auto-retry then.")
        cap = spec.get("cap24") or 0
        if cap and info["auto"]:
            used = _posts_24h(d, p)
            if used >= cap:
                problems.append(f"{info['label']}: {used} API posts in the last 24 h (limit ~{cap})")
            elif used >= cap * 0.8:
                warnings.append(f"{info['label']}: {used}/{cap} posts in 24 h — close to the limit")
        text = captions.get(p) or caption
        lim = {"instagram": 2200, "facebook": 2200, "tiktok": 2200, "youtube": 5000, "x": 280, "linkedin": 3000}[p]
        if len(text) > lim:
            problems.append(f"{info['label']}: caption {len(text)} characters, limit {lim}")
        if text.count("#") > 5 and p == "instagram":
            warnings.append("Instagram: more than 5 hashtags — Instagram now shows at most 5")
    if "youtube" in platforms and not (payload.get("title") or "").strip():
        warnings.append("YouTube: title is empty — the clip name will be used")
    if src and any(p in platforms for p in ("youtube", "facebook", "instagram")):
        mc = music_risk(src["path"])
        if mc and mc["level"] != "none":
            from .pipeline.music_check import fmt
            where = ", ".join(f"{fmt(a)}-{fmt(b)}" for a, b in mc["segments"][:3])
            msg = (f"Background music detected at {where} (~{mc['music_seconds']:.0f}s). Copyrighted songs get "
                   "YouTube Shorts blocked by Content ID (like \"Missing Person Alert\" with Faith Evans - Love Like "
                   "This) and Instagram/Facebook may mute them.")
            if "youtube" in platforms and mc["level"] == "likely" and not payload.get("allow_music"):
                problems.append(msg + " Cut the clip around the music, or tick 'Post anyway' if you have the rights.")
            else:
                warnings.append(msg if mc["level"] == "likely" else "Possible background music at " + where +
                                " — listen once before posting; a copyrighted song can get the post blocked.")
    if src:
        pr = src.get("probe") or {}
        if pr.get("width") and pr.get("height") and pr["height"] < pr["width"]:
            warnings.append("Clip is landscape. Campaigns want 9:16 vertical.")
        key = json.dumps(payload.get("source"), sort_keys=True)
        for p in platforms:
            for old in d["posts"]:
                if json.dumps(old.get("source"), sort_keys=True) == key and ((old.get("results") or {}).get(p) or {}).get("ok"):
                    warnings.append(f"{PLATFORMS[p]['label']}: this clip was already posted ({(old.get('finished_at') or '')[:16].replace('T', ' ')} UTC)")
                    break
    if camp:
        if camp.get("status") == "blocked":
            problems.append(f"{camp['name']}: this campaign is blocked — {camp.get('rules', '')[:90]}")
        for t in camp.get("required_tags") or []:
            for p in platforms or [None]:
                txt = (captions.get(p) if p else None) or caption
                if t.lower() not in txt.lower():
                    problems.append(f"Caption must include {t}" + (f" ({PLATFORMS[p]['label']})" if p and captions.get(p) else ""))
                    break
        for p in platforms:
            if camp.get("platforms") and p not in camp["platforms"]:
                warnings.append(f"{camp['name']} {PLATFORMS[p]['label']} is not accepted by this campaign — views there won't count")
        if camp.get("submit_window_min"):
            warnings.append(f"Submit the link to the campaign within {camp['submit_window_min']} minutes of posting")
        dl = _parse(camp.get("deadline"))
        if dl and dl < _now():
            problems.append(f"{camp['name']}: deadline has passed")
    elif payload.get("campaign_id"):
        warnings.append("Campaign not found")
    else:
        warnings.append("Not linked to a campaign — earnings won't be tracked")
    when = _parse(payload.get("scheduled_at"))
    if when and when < _now() - dt.timedelta(minutes=2):
        problems.append("The scheduled time is in the past")
    # de-duplicate while keeping order
    return {"problems": list(dict.fromkeys(problems)), "warnings": list(dict.fromkeys(warnings)),
            "source": {k: v for k, v in (src or {}).items() if k != "path"} if src else None}


# ------------------------------------------------------------------ posts
def create_post(payload: dict, user: str = "") -> dict:
    if payload.get("when") == "queue" and not payload.get("scheduled_at"):
        from .growth import next_slot              # next free posting slot of this project
        payload = {**payload, "scheduled_at": _iso(next_slot(payload.get("workspace")))}
    pf = preflight(payload)
    if pf["problems"]:
        raise ValueError(pf["problems"][0])
    when = _parse(payload.get("scheduled_at"))
    draft = bool(payload.get("draft")) and bool(when)
    platforms = [p for p in payload["platforms"] if p in PLATFORMS]
    src = source_info(payload["source"])
    post = {
        "id": uuid.uuid4().hex[:12], "source": payload["source"], "name": src["name"] if src else "",
        "clip_id": src.get("clip_id") if src else None, "thumb": src.get("thumb") if src else None,
        "campaign_id": payload.get("campaign_id") or None, "platforms": platforms,
        "caption": payload.get("caption") or "", "captions": {k: v for k, v in (payload.get("captions") or {}).items()
                                                               if k in platforms and v},
        "title": (payload.get("title") or (src["name"] if src else ""))[:100],
        "yt_privacy": payload.get("yt_privacy") or settings()["youtube_privacy"],
        "scheduled_at": _iso(when) if when else None,
        "status": "draft" if draft else "scheduled" if when else "queued",
        "origin": str(payload.get("origin") or "")[:60] or None,
        "results": {}, "submitted": {}, "created_at": _iso(), "created_by": user, "finished_at": None,
        "workspace": _wsid(payload.get("workspace")),
    }
    with _lock:
        d = load()
        d["posts"].append(post)
        save(d)
    if not when:
        enqueue(post["id"])
    return post


def approve_post(pid: str) -> dict:
    """A draft (made by Autopilot with 'ask me first') becomes a real scheduled post."""
    with _lock:
        d = load()
        p = next((x for x in d["posts"] if x["id"] == pid), None)
        if not p or p["status"] != "draft":
            raise ValueError("Only drafts can be approved")
        t = _parse(p.get("scheduled_at"))
        if not t or t < _now() + dt.timedelta(minutes=1):
            from .growth import next_slot
            p["scheduled_at"] = _iso(next_slot(p.get("workspace")))
        p["status"] = "scheduled"
        p["approved_at"] = _iso()
        save(d)
        return p


def update_post(pid: str, changes: dict) -> dict:
    with _lock:
        d = load()
        p = next((x for x in d["posts"] if x["id"] == pid), None)
        if not p:
            raise KeyError("post")
        if "views" in changes and isinstance(changes["views"], dict):
            for plat, v in changes["views"].items():
                r = p["results"].setdefault(plat, {})
                r["views"] = max(0, int(float(v or 0)))
                r["views_at"] = _iso()
                r["views_src"] = "manual"
        if "submitted" in changes and isinstance(changes["submitted"], dict):
            for plat, v in changes["submitted"].items():
                if v:
                    p["submitted"][plat] = _iso()
                else:
                    p["submitted"].pop(plat, None)
        if "manual_url" in changes and isinstance(changes["manual_url"], dict):
            for plat, url in changes["manual_url"].items():
                url = (url or "").strip()
                if plat in p["platforms"] and url.startswith("http"):
                    p["results"][plat] = {**p["results"].get(plat, {}), "ok": True, "url": url, "at": _iso(),
                                          "auto": False, "state": "done", "error": None}
            _finish_status(p)
        if p["status"] in ("scheduled", "draft"):
            if "scheduled_at" in changes:
                t = _parse(changes["scheduled_at"])
                if not t or t < _now():
                    raise ValueError("The new time must be in the future")
                p["scheduled_at"] = _iso(t)
            for k in ("caption", "title"):
                if k in changes:
                    p[k] = str(changes[k])[: 5000 if k == "caption" else 100]
        save(d)
        return p


def cancel_post(pid: str) -> dict:
    with _lock:
        d = load()
        p = next((x for x in d["posts"] if x["id"] == pid), None)
        if not p or p["status"] not in ("scheduled", "missed", "draft"):
            raise ValueError("Only scheduled posts can be cancelled")
        p["status"] = "cancelled"
        save(d)
        return p


def delete_post(pid: str) -> None:
    with _lock:
        d = load()
        p = next((x for x in d["posts"] if x["id"] == pid), None)
        if not p:
            return
        if p["status"] in ("posting", "queued"):
            raise ValueError("This post is running, it can't be removed now")
        d["posts"] = [x for x in d["posts"] if x["id"] != pid]
        save(d)


def retry_post(pid: str, platforms: list[str] | None = None) -> dict:
    """Re-run only platforms that failed (or a 'missed'/'check' post). Never re-posts a success."""
    with _lock:
        d = load()
        p = next((x for x in d["posts"] if x["id"] == pid), None)
        if not p:
            raise KeyError("post")
        if p["status"] in ("posting", "queued"):
            raise ValueError("Already running")
        todo = [x for x in (platforms or p["platforms"]) if x in p["platforms"]
                and not (p["results"].get(x) or {}).get("ok")]
        if not todo:
            raise ValueError("Nothing to retry — every platform already posted")
        for x in todo:
            p["results"].pop(x, None)
        p["retry_only"] = todo
        p["status"] = "queued"
        save(d)
    enqueue(pid)
    return p


def _finish_status(p: dict) -> None:
    res = [p["results"].get(x) or {} for x in p["platforms"]]
    if all(r.get("ok") for r in res):
        p["status"] = "done"
    elif any(r.get("ok") for r in res):
        p["status"] = "partial"
    elif all(r.get("state") == "manual" for r in res):
        p["status"] = "manual"
    else:
        p["status"] = "failed" if any(r.get("error") for r in res) else p["status"]
    if p["status"] in ("done", "partial", "failed", "manual"):
        p["finished_at"] = p.get("finished_at") or _iso()


# ------------------------------------------------------------------ worker
_q: list[str] = []
_q_cv = threading.Condition()
_started = False


def enqueue(pid: str) -> None:
    with _q_cv:
        if pid not in _q:
            _q.append(pid)
        _q_cv.notify()


def _set_result(pid: str, platform: str, **kw) -> None:
    with _lock:
        d = load()
        p = next((x for x in d["posts"] if x["id"] == pid), None)
        if p is None:
            return
        p["results"][platform] = {**(p["results"].get(platform) or {}), **kw}
        save(d)


def run_post(pid: str) -> None:
    p = next((x for x in load()["posts"] if x["id"] == pid), None)
    with in_ws(_post_ws(p or {})):
        _run_post(pid)


def _run_post(pid: str) -> None:
    with _lock:
        d = load()
        p = next((x for x in d["posts"] if x["id"] == pid), None)
        if not p or p["status"] not in ("queued",):
            return
        p["status"] = "posting"
        p["started_at"] = _iso()
        todo = p.pop("retry_only", None) or p["platforms"]
        save(d)
    src = source_info(p["source"])
    for plat in todo:
        if (p["results"].get(plat) or {}).get("ok"):
            continue
        if not PLATFORMS[plat]["auto"]:
            _set_result(pid, plat, ok=False, state="manual", error=None, at=_iso())
            continue
        if not src:
            _set_result(pid, plat, ok=False, state="failed", error="Clip file not found", at=_iso())
            continue
        _set_result(pid, plat, state="uploading", pct=0, error=None)
        try:
            text = (p.get("captions") or {}).get(plat) or p["caption"]
            res = POSTERS[plat](p, src, text, lambda pct, _pl=plat: _set_result(pid, _pl, pct=pct))
            _set_result(pid, plat, ok=True, state="done", auto=True, at=_iso(), pct=100, **res)
            log.info("posted %s to %s: %s", pid, plat, res.get("url"))
        except Exception as e:  # noqa: BLE001
            log.warning("post %s to %s failed: %s", pid, plat, e)
            extra = {}
            if _is_upload_limit(e):
                with _lock:
                    d = load()
                    until = _limit_until(d, plat)
                    d["limits"][_lkey(plat)] = {"at": _iso(), "until": until, "error": str(e)[:200]}
                    save(d)
                extra = {"retry_at": until, "limit": True}
            _set_result(pid, plat, ok=False, state="failed", error=_human_error(plat, e), at=_iso(), **extra)
    with _lock:
        d = load()
        p = next((x for x in d["posts"] if x["id"] == pid), None)
        if p:
            p["finished_at"] = None
            _finish_status(p)
            save(d)


LIMIT_HINTS = ("exceeded the number of videos", "uploadlimitexceeded", "upload limit")


def _is_upload_limit(e: Exception | str) -> bool:
    low = str(e).lower()
    return any(h in low for h in LIMIT_HINTS)


def _limit_until(d: dict, platform: str) -> str:
    """When a channel upload limit should be over: 24 h after the oldest upload in the last 24 h."""
    now = _now()
    times = []
    ws = _WS.get()
    for p in d["posts"]:
        if _post_ws(p) != ws:
            continue
        r = (p.get("results") or {}).get(platform) or {}
        t = _parse(r.get("at")) if r.get("ok") else None
        if t and (now - t).total_seconds() < 86400:
            times.append(t)
    base = min(times) if times else now
    return (base + dt.timedelta(hours=24, minutes=10)).isoformat(timespec="seconds")


def limit_status(platform: str) -> dict | None:
    lim = (load().get("limits") or {}).get(_lkey(platform))
    t = _parse((lim or {}).get("until"))
    return lim if t and t > _now() else None


def _human_error(platform: str, e: Exception) -> str:
    msg = str(e) or e.__class__.__name__
    low = msg.lower()
    if _is_upload_limit(e):
        return (f"{PLATFORMS[platform]['label']} upload limit reached — the channel has uploaded the most videos "
                "YouTube allows for now (new or unverified channels get a low limit; verify the channel at "
                "youtube.com/verify to raise it). ClipForge will retry automatically when the limit resets.")
    if "expired" in low or "invalid_grant" in low or "session has been invalidated" in low or "oauth" in low and "token" in low:
        return f"{PLATFORMS[platform]['label']} login expired — press Reconnect in Accounts. ({msg[:120]})"
    if "unaudited_client" in low:
        return "Your TikTok app is not audited yet — the account must be private and posts stay private."
    if "quota" in low or "rate" in low and "limit" in low:
        return f"{PLATFORMS[platform]['label']} daily limit reached — try again tomorrow. ({msg[:120]})"
    return msg[:300]


def _worker() -> None:
    while True:
        with _q_cv:
            while not _q:
                _q_cv.wait(timeout=30)
            pid = _q.pop(0)
        try:
            run_post(pid)
        except Exception:  # noqa: BLE001
            log.exception("publish worker crashed on %s", pid)


_last_views = 0.0


def _due_retries(now) -> list[tuple[str, list[str]]]:
    out = []
    for p in load()["posts"]:
        if p["status"] in ("queued", "posting", "scheduled", "cancelled", "draft"):
            continue
        plats = [k for k, r in (p.get("results") or {}).items()
                 if not r.get("ok") and r.get("retry_at") and _parse(r["retry_at"]) and _parse(r["retry_at"]) <= now]
        if plats:
            out.append((p["id"], plats))
    return out


def _ticker() -> None:
    global _last_views
    while True:
        time.sleep(30)
        try:
            now = _now()
            due = []
            with _lock:
                d = load()
                for p in d["posts"]:
                    t = _parse(p.get("scheduled_at"))
                    if p["status"] == "scheduled" and t and t <= now:
                        p["status"] = "queued"
                        due.append(p["id"])
                if due:
                    save(d)
            for pid in due:
                enqueue(pid)
            for pid, plats in _due_retries(now):
                try:
                    retry_post(pid, plats)
                    log.info("auto-retry %s on %s after upload limit", pid, plats)
                except (KeyError, ValueError):
                    pass
            if settings()["auto_views"] and time.time() - _last_views > 3 * 3600:
                _last_views = time.time()
                sync_views()
                try:
                    check_youtube_status()
                except Exception:  # noqa: BLE001
                    log.exception("youtube status check")
        except Exception:  # noqa: BLE001
            log.exception("publish ticker")


def start() -> None:
    """Called once at server start. Marks interrupted posts, re-queues due ones, starts threads."""
    global _started
    if _started:
        return
    _started = True
    now = _now()
    requeue = []
    with _lock:
        d = load()
        for p in d["posts"]:
            if p["status"] == "posting":
                p["status"] = "check"
                for x in p["platforms"]:
                    r = p["results"].get(x) or {}
                    if r.get("state") == "uploading":
                        r.update(state="failed", error="The server restarted mid-upload. Check on the platform whether "
                                                       "it posted, then press Retry.")
                        p["results"][x] = r
            elif p["status"] == "queued":
                requeue.append(p["id"])
            elif p["status"] == "scheduled":
                t = _parse(p.get("scheduled_at"))
                if t and t < now - dt.timedelta(hours=2):
                    p["status"] = "missed"        # PC was off at that time; a human decides to post late or not
            for x, r in (p.get("results") or {}).items():   # older upload-limit failures: plan the auto-retry
                if r.get("state") == "failed" and not r.get("retry_at") and _is_upload_limit(r.get("error") or ""):
                    with in_ws(_post_ws(p)):
                        until = _limit_until(d, x)
                        d["limits"][_lkey(x)] = {"at": r.get("at") or _iso(), "until": until}
                    r.update(retry_at=until, limit=True, error=_human_error(x, Exception(r.get("error") or "")))
        save(d)
    threading.Thread(target=_worker, name="publish-worker", daemon=True).start()
    threading.Thread(target=_ticker, name="publish-ticker", daemon=True).start()
    try:
        from . import growth
        growth.start()
    except Exception:  # noqa: BLE001
        log.exception("autopilot did not start")
    try:
        from . import social
        social.start()
    except Exception:  # noqa: BLE001
        log.exception("inbox sync did not start")
    for pid in requeue:
        enqueue(pid)


# ------------------------------------------------------------------ HTTP helpers
def _http():
    import requests
    s = requests.Session()
    s.headers["User-Agent"] = "FODO-ClipForge/0.15"
    return s


def _check(r, what: str) -> dict:
    try:
        j = r.json()
    except ValueError:
        j = {}
    if r.status_code >= 400 or (isinstance(j, dict) and j.get("error") and j["error"] not in ("", {}) and
                                not (isinstance(j["error"], dict) and j["error"].get("code") in ("ok", None, ""))):
        err = j.get("error") if isinstance(j, dict) else None
        if isinstance(err, dict):
            msg = err.get("error_user_msg") or err.get("message") or err.get("code")
        else:
            msg = j.get("error_description") or err or r.text[:200]
        raise RuntimeError(f"{what}: {msg}")
    return j


class _Progress:
    """File reader that reports upload progress (0-100) while requests streams it."""

    def __init__(self, path: str, cb, start: int = 0, length: int | None = None):
        self.f = open(path, "rb")  # noqa: SIM115
        self.f.seek(start)
        self.total = length if length is not None else Path(path).stat().st_size - start
        self.left = self.total
        self.cb = cb
        self.last = -1

    def __len__(self):
        return self.total

    def read(self, n: int = -1) -> bytes:
        if self.left <= 0:
            return b""
        n = self.left if n < 0 else min(n, self.left)
        b = self.f.read(n)
        self.left -= len(b)
        pct = int(100 * (self.total - self.left) / max(1, self.total))
        if self.cb and pct != self.last and pct % 5 == 0:
            self.last = pct
            try:
                self.cb(min(99, pct))
            except Exception:  # noqa: BLE001
                pass
        return b

    def close(self):
        self.f.close()


# ------------------------------------------------------------------ Meta
def _meta() -> dict:
    m = _acc(load_secrets()).get("meta") or {}
    if not m.get("page_token"):
        raise RuntimeError("Instagram/Facebook is not connected")
    return m


def post_instagram(post: dict, src: dict, caption: str, progress) -> dict:
    m = _meta()
    if not m.get("ig_id"):
        raise RuntimeError("No Instagram professional account is linked to this Facebook Page")
    tok, s = m["page_token"], _http()
    size = Path(src["path"]).stat().st_size
    c = _check(s.post(f"{GRAPH}/{m['ig_id']}/media", data={
        "media_type": "REELS", "upload_type": "resumable", "caption": caption, "share_to_feed": "true",
        "access_token": tok}, timeout=60), "Instagram container")
    cid = c["id"]
    up = c.get("uri") or f"https://rupload.facebook.com/ig-api-upload/{GRAPH_V}/{cid}"
    body = _Progress(src["path"], progress)
    try:
        _check(s.post(up, data=body, headers={"Authorization": f"OAuth {tok}", "offset": "0",
                                              "file_size": str(size)}, timeout=3600), "Instagram upload")
    finally:
        body.close()
    for _ in range(90):                                        # up to 15 min of processing
        st = _check(s.get(f"{GRAPH}/{cid}", params={"fields": "status_code,status", "access_token": tok}, timeout=30),
                    "Instagram status")
        code = st.get("status_code")
        if code == "FINISHED":
            break
        if code in ("ERROR", "EXPIRED"):
            raise RuntimeError(f"Instagram processing {code}: {st.get('status', '')}")
        time.sleep(10)
    else:
        raise RuntimeError("Instagram did not finish processing within 15 min")
    pub = _check(s.post(f"{GRAPH}/{m['ig_id']}/media_publish", data={"creation_id": cid, "access_token": tok},
                        timeout=60), "Instagram publish")
    url = None
    try:
        url = s.get(f"{GRAPH}/{pub['id']}", params={"fields": "permalink", "access_token": tok}, timeout=20).json().get("permalink")
    except Exception:  # noqa: BLE001
        pass
    return {"id": pub["id"], "url": url}


def post_facebook(post: dict, src: dict, caption: str, progress) -> dict:
    m = _meta()
    tok, s, page = m["page_token"], _http(), m["page_id"]
    size = Path(src["path"]).stat().st_size
    st = _check(s.post(f"{GRAPH}/{page}/video_reels", data={"upload_phase": "start", "access_token": tok}, timeout=60),
                "Facebook start")
    vid = st["video_id"]
    up = st.get("upload_url") or f"https://rupload.facebook.com/video-upload/{GRAPH_V}/{vid}"
    body = _Progress(src["path"], progress)
    try:
        _check(s.post(up, data=body, headers={"Authorization": f"OAuth {tok}", "offset": "0",
                                              "file_size": str(size)}, timeout=3600), "Facebook upload")
    finally:
        body.close()
    _check(s.post(f"{GRAPH}/{page}/video_reels", data={
        "upload_phase": "finish", "video_id": vid, "video_state": "PUBLISHED", "description": caption,
        "access_token": tok}, timeout=60), "Facebook publish")
    return {"id": vid, "url": f"https://www.facebook.com/reel/{vid}"}


# ------------------------------------------------------------------ YouTube
def _google_token() -> str:
    s = load_secrets()
    g = _acc(s).get("google") or {}
    if not g.get("refresh_token"):
        raise RuntimeError("YouTube is not connected")
    if g.get("expires_at", 0) > time.time() + 60:
        return g["access_token"]
    j = _check(_http().post("https://oauth2.googleapis.com/token", data={
        "client_id": s["google_client_id"], "client_secret": s["google_client_secret"],
        "refresh_token": g["refresh_token"], "grant_type": "refresh_token"}, timeout=30), "Google token")
    with _lock:
        s = load_secrets()
        _acc(s)["google"].update(access_token=j["access_token"], expires_at=time.time() + j.get("expires_in", 3600))
        save_secrets(s)
    return j["access_token"]


def post_youtube(post: dict, src: dict, caption: str, progress) -> dict:
    tok, s = _google_token(), _http()
    size = Path(src["path"]).stat().st_size
    title = (post.get("title") or src["name"] or "Clip")[:100]
    meta = {"snippet": {"title": title, "description": caption[:5000], "categoryId": settings()["youtube_category"]},
            "status": {"privacyStatus": post.get("yt_privacy") or "public", "selfDeclaredMadeForKids": False,
                       "containsSyntheticMedia": False}}
    r = s.post("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status",
               json=meta, headers={"Authorization": f"Bearer {tok}", "X-Upload-Content-Type": "video/mp4",
                                   "X-Upload-Content-Length": str(size)}, timeout=60)
    _check(r, "YouTube start")
    loc = r.headers.get("Location")
    if not loc:
        raise RuntimeError("YouTube did not return an upload URL")
    body = _Progress(src["path"], progress)
    try:
        j = _check(s.put(loc, data=body, headers={"Content-Type": "video/mp4", "Content-Length": str(size)},
                         timeout=7200), "YouTube upload")
    finally:
        body.close()
    return {"id": j["id"], "url": f"https://youtube.com/shorts/{j['id']}"}


# ------------------------------------------------------------------ TikTok
TT = "https://open.tiktokapis.com"


def _tiktok_token() -> str:
    s = load_secrets()
    t = _acc(s).get("tiktok") or {}
    if not t.get("refresh_token"):
        raise RuntimeError("TikTok is not connected")
    if t.get("expires_at", 0) > time.time() + 120:
        return t["access_token"]
    j = _check(_http().post(f"{TT}/v2/oauth/token/", data={
        "client_key": s["tiktok_client_key"], "client_secret": s["tiktok_client_secret"],
        "grant_type": "refresh_token", "refresh_token": t["refresh_token"]},
        headers={"Content-Type": "application/x-www-form-urlencoded"}, timeout=30), "TikTok token")
    with _lock:
        s = load_secrets()
        # the refresh token rotates: store the new one immediately or the account locks out
        _acc(s)["tiktok"].update(access_token=j["access_token"], expires_at=time.time() + j.get("expires_in", 86400),
                                       refresh_token=j.get("refresh_token") or t["refresh_token"])
        save_secrets(s)
    return j["access_token"]


def tiktok_chunks(size: int) -> tuple[int, int]:
    """(chunk_size, total_chunk_count) per TikTok's media transfer rules: chunks 5-64 MB, the last one
    absorbs the remainder (up to 128 MB), files under 64 MB go as one chunk."""
    mb = 1024 * 1024
    if size <= 64 * mb:
        return size, 1
    chunk = 10 * mb
    return chunk, size // chunk


def post_tiktok(post: dict, src: dict, caption: str, progress) -> dict:
    tok, s = _tiktok_token(), _http()
    h = {"Authorization": f"Bearer {tok}", "Content-Type": "application/json; charset=UTF-8"}
    info = _check(s.post(f"{TT}/v2/post/publish/creator_info/query/", headers=h, timeout=30), "TikTok creator info")
    data = info.get("data") or {}
    opts = data.get("privacy_level_options") or ["SELF_ONLY"]
    privacy = "PUBLIC_TO_EVERYONE" if "PUBLIC_TO_EVERYONE" in opts else ("SELF_ONLY" if "SELF_ONLY" in opts else opts[0])
    maxd = data.get("max_video_post_duration_sec")
    dur = (src.get("probe") or {}).get("duration") or 0
    if maxd and dur and dur > maxd:
        raise RuntimeError(f"TikTok allows at most {maxd}s videos on this account")
    size = Path(src["path"]).stat().st_size
    chunk, count = tiktok_chunks(size)
    init = _check(s.post(f"{TT}/v2/post/publish/video/init/", headers=h, json={
        "post_info": {"title": caption[:2200], "privacy_level": privacy, "disable_comment": False,
                      "disable_duet": False, "disable_stitch": False},
        "source_info": {"source": "FILE_UPLOAD", "video_size": size, "chunk_size": chunk,
                        "total_chunk_count": count}}, timeout=60), "TikTok init")
    url = (init.get("data") or {}).get("upload_url")
    pub = (init.get("data") or {}).get("publish_id")
    if not url:
        raise RuntimeError("TikTok did not return an upload URL")
    for i in range(count):
        start = i * chunk
        end = size - 1 if i == count - 1 else start + chunk - 1
        body = _Progress(src["path"], None, start, end - start + 1)
        try:
            r = s.put(url, data=body, headers={"Content-Type": "video/mp4", "Content-Length": str(end - start + 1),
                                               "Content-Range": f"bytes {start}-{end}/{size}"}, timeout=1800)
        finally:
            body.close()
        if r.status_code not in (200, 201, 206):
            raise RuntimeError(f"TikTok chunk {i + 1}/{count}: HTTP {r.status_code}")
        progress(int(100 * (i + 1) / count) - 1)
    note = None if privacy == "PUBLIC_TO_EVERYONE" else "Posted as private (TikTok app audit pending)"
    post_id = None
    for _ in range(30):
        st = s.post(f"{TT}/v2/post/publish/status/fetch/", headers=h, json={"publish_id": pub}, timeout=30).json()
        sd = st.get("data") or {}
        if sd.get("status") == "PUBLISH_COMPLETE":
            ids = sd.get("publicaly_available_post_id") or sd.get("publicly_available_post_id") or []
            post_id = str(ids[0]) if ids else None
            break
        if sd.get("status") == "FAILED":
            raise RuntimeError(f"TikTok: {sd.get('fail_reason') or 'publish failed'}")
        time.sleep(6)
    user = (_acc(load_secrets()).get("tiktok") or {}).get("username")
    url_out = f"https://www.tiktok.com/@{user}/video/{post_id}" if post_id and user else None
    return {"id": post_id or pub, "url": url_out, "note": note, "privacy": privacy}


POSTERS = {"instagram": post_instagram, "facebook": post_facebook, "youtube": post_youtube, "tiktok": post_tiktok}


# ------------------------------------------------------------------ views
def sync_views() -> dict:
    """Fetch real view counts where the platform API gives them (YouTube, Instagram, Facebook),
    for every client project with its own login."""
    out = {"updated": 0, "errors": []}
    for ws in sorted({_post_ws(p) for p in load()["posts"]}):
        with in_ws(ws):
            r = _sync_views()
        out["updated"] += r["updated"]
        out["errors"] += [(f"{workspace_name(ws)} · " if ws != MAIN else "") + e for e in r["errors"]]
    return out


def _sync_views() -> dict:
    d = load()
    cutoff = _now() - dt.timedelta(days=45)
    yt, ig, fb = [], [], []
    ws = _WS.get()
    for p in d["posts"]:
        if _post_ws(p) != ws:
            continue
        for plat, r in (p.get("results") or {}).items():
            if not (r.get("ok") and r.get("auto") and r.get("id")) or (_parse(r.get("at")) or cutoff) < cutoff:
                continue
            (yt if plat == "youtube" else ig if plat == "instagram" else fb if plat == "facebook" else []).append((p["id"], plat, r["id"]))
    got: dict[tuple, int] = {}
    errors = []
    s = _http()
    if yt:
        try:
            tok = _google_token()
            for i in range(0, len(yt), 50):
                part = yt[i:i + 50]
                j = _check(s.get("https://www.googleapis.com/youtube/v3/videos", params={
                    "part": "statistics", "id": ",".join(x[2] for x in part)},
                    headers={"Authorization": f"Bearer {tok}"}, timeout=30), "YouTube views")
                by = {it["id"]: int(it.get("statistics", {}).get("viewCount", 0)) for it in j.get("items", [])}
                for pid, plat, vid in part:
                    if vid in by:
                        got[(pid, plat)] = by[vid]
        except Exception as e:  # noqa: BLE001
            errors.append(f"YouTube: {e}")
    if ig or fb:
        try:
            tok = _meta()["page_token"]
            for pid, plat, mid in ig:
                j = s.get(f"{GRAPH}/{mid}/insights", params={"metric": "views", "access_token": tok}, timeout=30).json()
                v = ((j.get("data") or [{}])[0].get("values") or [{}])[0].get("value")
                if isinstance(v, int):
                    got[(pid, plat)] = v
            for pid, plat, vid in fb:
                j = s.get(f"{GRAPH}/{vid}/video_insights", params={"metric": "blue_reels_play_count",
                                                                    "access_token": tok}, timeout=30).json()
                v = ((j.get("data") or [{}])[0].get("values") or [{}])[0].get("value")
                if isinstance(v, int):
                    got[(pid, plat)] = v
        except Exception as e:  # noqa: BLE001
            errors.append(f"Meta: {e}")
    if got:
        with _lock:
            d = load()
            for p in d["posts"]:
                for plat in list((p.get("results") or {}).keys()):
                    if (p["id"], plat) in got:
                        p["results"][plat].update(views=got[(p["id"], plat)], views_at=_iso(), views_src="api")
            save(d)
    return {"updated": len(got), "errors": errors}


# ------------------------------------------------------------------ stats
def _estimate(c: dict, platform: str, views: int) -> float:
    if c.get("model") != "cpm":
        return 0.0
    if c.get("min_views") and views < c["min_views"]:
        return 0.0
    rate = (c.get("platform_cpm") or {}).get(platform, c.get("cpm") or 0)
    e = views / 1000 * rate
    if c.get("cap_per_clip"):
        e = min(e, c["cap_per_clip"])
    if c.get("min_payout") and e < c["min_payout"]:
        e = 0.0          # below the floor pays nothing
    return e


def overview(ws: str | None = None) -> dict:
    d = load()
    camps = {c["id"]: c for c in d["campaigns"]}
    posts = d["posts"] if ws is None else [p for p in d["posts"] if _post_ws(p) == _wsid(ws)]
    now = _now()
    per_c = {cid: {"id": cid, "clips": 0, "views": 0, "estimate": 0.0, "qualifying": 0, "pending_submit": 0,
                   "submitted": 0} for cid in camps}
    per_p = {k: {"posts": 0, "views": 0, "failed": 0, "last24": 0} for k in PLATFORMS}
    to_submit = []
    days = {(now - dt.timedelta(days=i)).date().isoformat(): 0 for i in range(13, -1, -1)}
    for p in posts:
        c = camps.get(p.get("campaign_id"))
        for plat in p["platforms"]:
            r = p["results"].get(plat) or {}
            if r.get("ok"):
                v = int(r.get("views") or 0)
                per_p[plat]["posts"] += 1
                per_p[plat]["views"] += v
                at = _parse(r.get("at"))
                if at and at > now - dt.timedelta(hours=24):
                    per_p[plat]["last24"] += 1
                if at and at.date().isoformat() in days:
                    days[at.date().isoformat()] += 1
                if c:
                    s = per_c[c["id"]]
                    s["clips"] += 1
                    s["views"] += v
                    s["estimate"] += _estimate(c, plat, v)
                    if c.get("model") == "pool" and v >= (c.get("per_clip_min_views") or 0):
                        s["qualifying"] += v
                    if (p.get("submitted") or {}).get(plat):
                        s["submitted"] += 1
                    elif not c.get("platforms") or plat in c["platforms"]:
                        s["pending_submit"] += 1
                        due = None
                        if c.get("submit_window_min") and at:
                            due = _iso(at + dt.timedelta(minutes=c["submit_window_min"]))
                        to_submit.append({"post_id": p["id"], "platform": plat, "url": r.get("url"), "name": p["name"],
                                          "campaign": c["name"], "campaign_id": c["id"], "due": due,
                                          "submit_url": c.get("submit_url") or c.get("source")})
            elif r.get("state") == "failed":
                per_p[plat]["failed"] += 1
    for s in per_c.values():
        c = camps[s["id"]]
        s["estimate"] = round(s["estimate"], 2)
        if c.get("model") == "pool":
            s["pool_pct"] = min(100, round(100 * s["qualifying"] / c["pool_target"])) if c.get("pool_target") else 0
            s["estimate"] = None
        else:
            s["budget_left"] = max(0, (c.get("budget") or 0) - (c.get("spent") or 0))
    upcoming = sorted([p for p in posts if p["status"] == "scheduled"], key=lambda p: p["scheduled_at"])[:12]
    to_submit.sort(key=lambda x: (x["due"] is None, x["due"] or ""))
    st = {k: sum(1 for p in posts if p["status"] == k) for k in
          ("draft", "scheduled", "queued", "posting", "done", "partial", "failed", "manual", "missed", "check", "cancelled")}
    return {
        "kpis": {"posted": sum(v["posts"] for v in per_p.values()),
                 "views": sum(v["views"] for v in per_p.values()),
                 "estimate": round(sum(s["estimate"] or 0 for s in per_c.values()), 2),
                 "scheduled": st["scheduled"], "to_submit": len(to_submit), "drafts": st["draft"],
                 "attention": st["failed"] + st["partial"] + st["missed"] + st["check"] + st["manual"]
                 + sum(1 for p in posts for r in (p.get("results") or {}).values() if r.get("issue")),
                 "active_campaigns": sum(1 for c in d["campaigns"] if c.get("status") != "blocked")},
        "status_counts": st, "campaigns": list(per_c.values()), "platforms": per_p,
        "days": [{"day": k, "posts": v} for k, v in days.items()], "upcoming": upcoming, "to_submit": to_submit[:30],
        "caps": {k: SPECS[k]["cap24"] for k in PLATFORMS},
    }


def accounts_status(ws: str | None = None) -> dict:
    with in_ws(ws):
        return _accounts_status()


def _accounts_status() -> dict:
    out = {}
    for k, info in PLATFORMS.items():
        out[k] = {"label": info["label"], "icon": info["icon"], "auto": info["auto"], "auth": info["auth"],
                  "configured": configured(info["auth"]) if info["auth"] else False,
                  "connected": connected(k), "who": account_who(k), "spec": SPECS[k]}
    s = load_secrets()
    acc = _acc(s)
    m = acc.get("meta") or {}
    for k, a in (("instagram", "meta"), ("facebook", "meta"), ("youtube", "google")):
        out[k]["can_reply"] = bool((acc.get(a) or {}).get("can_reply"))
    out["_meta_pages"] = [{"id": p["id"], "name": p["name"], "ig": p.get("ig_username")} for p in m.get("pages", [])]
    return out


def masked_secrets() -> dict:
    s = load_secrets()
    out = {}
    for k in SECRET_KEYS:
        v = s.get(k) or ""
        out[k] = ("•" * 6 + v[-4:]) if v and "secret" in k else v
        out[k + "_set"] = bool(v)
    out["settings"] = settings()
    base = settings()["redirect_base"].rstrip("/")
    out["redirects"] = {"meta": f"{base}/api/publish/oauth/meta", "google": f"{base}/api/publish/oauth/google",
                        "tiktok": f"{base}/api/publish/oauth/tiktok"}
    return out


def update_secrets(changes: dict) -> dict:
    with _lock:
        s = load_secrets()
        for k in SECRET_KEYS:
            if k in changes:
                v = str(changes[k] or "").strip()
                if v.startswith("•"):
                    continue          # masked value sent back unchanged
                if len(v) > 300:
                    raise ValueError(f"{k} is too long")
                s[k] = v
        st = changes.get("settings")
        if isinstance(st, dict):
            cur = s["settings"]
            if "redirect_base" in st:
                b = str(st["redirect_base"]).strip().rstrip("/")
                if not (b.startswith("http://localhost") or b.startswith("http://127.0.0.1") or b.startswith("https://")):
                    raise ValueError("Redirect base must look like http://localhost:8777")
                cur["redirect_base"] = b
            if "auto_views" in st:
                cur["auto_views"] = bool(st["auto_views"])
            if "default_gap_min" in st:
                cur["default_gap_min"] = max(1, min(1440, int(st["default_gap_min"] or 45)))
            if st.get("youtube_privacy") in ("public", "unlisted", "private"):
                cur["youtube_privacy"] = st["youtube_privacy"]
            if "youtube_category" in st and str(st["youtube_category"]).isdigit():
                cur["youtube_category"] = str(st["youtube_category"])
        save_secrets(s)
    return masked_secrets()


def disconnect(auth: str, ws: str | None = None) -> None:
    with _lock, in_ws(ws):
        s = load_secrets()
        _acc(s).pop(auth, None)
        save_secrets(s)


# ------------------------------------------------------------------ OAuth
_states: dict[str, dict] = {}


def _new_state(kind: str, **extra) -> str:
    for k in [k for k, v in _states.items() if v["t"] < time.time() - 900]:
        _states.pop(k, None)
    st = _secrets.token_urlsafe(24)
    _states[st] = {"kind": kind, "t": time.time(), **extra}
    return st


def take_state(state: str, kind: str) -> dict:
    v = _states.pop(state or "", None)
    if not v or v["kind"] != kind or v["t"] < time.time() - 900:
        raise ValueError("This login link expired or is invalid — press Connect again")
    return v


def redirect_uri(kind: str) -> str:
    return f"{settings()['redirect_base'].rstrip('/')}/api/publish/oauth/{kind}"


REPLY_SCOPES = {"meta": ",instagram_manage_comments,pages_manage_engagement,pages_read_user_content",
                "google": " https://www.googleapis.com/auth/youtube.force-ssl"}


def auth_url(kind: str, ws: str | None = None, replies: bool = False) -> str:
    """replies=True also asks for the comment permissions the Inbox needs to answer comments. It is opt-in so
    the normal Connect keeps working on Meta apps that do not have those permissions added yet."""
    ws = _wsid(ws)
    extra = REPLY_SCOPES.get(kind, "") if replies else ""
    if ws != MAIN and not workspace(ws):
        raise ValueError("Client project not found")
    s = load_secrets()
    if kind == "meta":
        if not configured("meta"):
            raise ValueError("Add the Meta App ID and Secret in Setup")
        return "https://www.facebook.com/" + GRAPH_V + "/dialog/oauth?" + urllib.parse.urlencode({
            "client_id": s["meta_app_id"], "redirect_uri": redirect_uri("meta"),
            "state": _new_state("meta", ws=ws, replies=replies), "response_type": "code",
            "scope": "instagram_basic,instagram_content_publish,instagram_manage_insights,pages_show_list,"
                     "pages_read_engagement,pages_manage_posts,read_insights,business_management" + extra})
    if kind == "google":
        if not configured("google"):
            raise ValueError("Add the Google Client ID and Secret in Setup")
        return "https://accounts.google.com/o/oauth2/v2/auth?" + urllib.parse.urlencode({
            "client_id": s["google_client_id"], "redirect_uri": redirect_uri("google"), "response_type": "code",
            "scope": "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly" + extra,
            "access_type": "offline", "prompt": "consent select_account",
            "state": _new_state("google", ws=ws, replies=replies)})
    if kind == "tiktok":
        if not configured("tiktok"):
            raise ValueError("Add the TikTok Client Key and Secret in Setup")
        verifier = _secrets.token_urlsafe(48)[:64]
        # TikTok's desktop flow wants the hex SHA-256 of the verifier (not base64url)
        challenge = hashlib.sha256(verifier.encode()).hexdigest()
        return "https://www.tiktok.com/v2/auth/authorize/?" + urllib.parse.urlencode({
            "client_key": s["tiktok_client_key"], "redirect_uri": redirect_uri("tiktok"), "response_type": "code",
            "scope": "user.info.basic,video.publish,video.upload", "state": _new_state("tiktok", verifier=verifier, ws=ws),
            "code_challenge": challenge, "code_challenge_method": "S256"})
    raise ValueError("unknown")


def finish_oauth(kind: str, code: str, state: str) -> str:
    st = take_state(state, kind)
    with in_ws(st.get("ws")):
        msg = _finish_oauth(kind, code, st)
    ws = _wsid(st.get("ws"))
    return msg + (f" — saved to client project “{workspace_name(ws)}”" if ws != MAIN else "")


def _finish_oauth(kind: str, code: str, st: dict) -> str:
    s, h = load_secrets(), _http()
    if kind == "meta":
        short = _check(h.get(f"{GRAPH}/oauth/access_token", params={
            "client_id": s["meta_app_id"], "client_secret": s["meta_app_secret"],
            "redirect_uri": redirect_uri("meta"), "code": code}, timeout=30), "Meta token")
        long = h.get(f"{GRAPH}/oauth/access_token", params={
            "grant_type": "fb_exchange_token", "client_id": s["meta_app_id"], "client_secret": s["meta_app_secret"],
            "fb_exchange_token": short["access_token"]}, timeout=30).json()
        user_tok = long.get("access_token") or short["access_token"]
        pages = _check(h.get(f"{GRAPH}/me/accounts", params={
            "fields": "id,name,access_token,instagram_business_account{id,username}", "limit": 100,
            "access_token": user_tok}, timeout=30), "Meta pages").get("data", [])
        if not pages:
            raise RuntimeError("No Facebook Page found. Your Instagram professional account must be linked to a Page.")
        lst = [{"id": p["id"], "name": p["name"], "token": p["access_token"],
                "ig_id": (p.get("instagram_business_account") or {}).get("id"),
                "ig_username": (p.get("instagram_business_account") or {}).get("username")} for p in pages]
        pick = next((p for p in lst if p["ig_id"]), lst[0])
        with _lock:
            s = load_secrets()
            _acc(s)["meta"] = {"user_token": user_tok, "pages": lst, "connected_at": _iso(),
                               "can_reply": bool(st.get("replies")), **_page_fields(pick)}
            save_secrets(s)
        return f"Facebook Page: {pick['name']}" + (f" · Instagram @{pick['ig_username']}" if pick["ig_username"] else "")
    if kind == "google":
        t = _check(h.post("https://oauth2.googleapis.com/token", data={
            "code": code, "client_id": s["google_client_id"], "client_secret": s["google_client_secret"],
            "redirect_uri": redirect_uri("google"), "grant_type": "authorization_code"}, timeout=30), "Google token")
        if not t.get("refresh_token"):
            raise RuntimeError("Google did not return a refresh token — remove the app at myaccount.google.com/permissions and connect again")
        ch = h.get("https://www.googleapis.com/youtube/v3/channels", params={"part": "snippet", "mine": "true"},
                   headers={"Authorization": f"Bearer {t['access_token']}"}, timeout=30).json()
        name = ((ch.get("items") or [{}])[0].get("snippet") or {}).get("title") or "YouTube channel"
        with _lock:
            s = load_secrets()
            _acc(s)["google"] = {"refresh_token": t["refresh_token"], "access_token": t["access_token"],
                                       "expires_at": time.time() + t.get("expires_in", 3600), "channel": name,
                                       "connected_at": _iso(), "can_reply": bool(st.get("replies"))}
            save_secrets(s)
        return f"YouTube: {name}"
    if kind == "tiktok":
        t = _check(h.post(f"{TT}/v2/oauth/token/", data={
            "client_key": s["tiktok_client_key"], "client_secret": s["tiktok_client_secret"], "code": code,
            "grant_type": "authorization_code", "redirect_uri": redirect_uri("tiktok"),
            "code_verifier": st.get("verifier", "")},
            headers={"Content-Type": "application/x-www-form-urlencoded"}, timeout=30), "TikTok token")
        u = h.get(f"{TT}/v2/user/info/", params={"fields": "open_id,display_name,username"},
                  headers={"Authorization": f"Bearer {t['access_token']}"}, timeout=30).json()
        ud = (u.get("data") or {}).get("user") or {}
        with _lock:
            s = load_secrets()
            _acc(s)["tiktok"] = {"access_token": t["access_token"], "refresh_token": t["refresh_token"],
                                       "expires_at": time.time() + t.get("expires_in", 86400),
                                       "display_name": ud.get("display_name") or "TikTok",
                                       "username": ud.get("username"), "connected_at": _iso()}
            save_secrets(s)
        return f"TikTok: {ud.get('display_name') or 'connected'}"
    raise ValueError("unknown")


def _page_fields(p: dict) -> dict:
    return {"page_id": p["id"], "page_name": p["name"], "page_token": p["token"], "ig_id": p.get("ig_id"),
            "ig_username": p.get("ig_username")}


def choose_page(page_id: str, ws: str | None = None) -> None:
    with _lock, in_ws(ws):
        s = load_secrets()
        m = _acc(s).get("meta") or {}
        p = next((x for x in m.get("pages", []) if x["id"] == page_id), None)
        if not p:
            raise ValueError("Page not found")
        m.update(_page_fields(p))
        save_secrets(s)


# ------------------------------------------------------------------ campaigns & uploads
def save_campaign(b: dict) -> dict:
    with _lock:
        d = load()
        clean = {k: v for k, v in b.items() if k in CAMPAIGN_KEYS}
        if isinstance(clean.get("required_tags"), str):
            clean["required_tags"] = [t if t.startswith("#") else "#" + t for t in clean["required_tags"].split() if t.strip("#")]
        if "platforms" in clean:
            clean["platforms"] = [p for p in clean["platforms"] or [] if p in PLATFORMS]
        if clean.get("status") and clean["status"] not in ("active", "low", "paused", "blocked", "ended"):
            clean.pop("status")
        for k in ("cpm", "cap_per_clip", "min_payout", "budget", "spent", "pool_target", "per_clip_min_views", "min_views"):
            if k in clean:
                try:
                    clean[k] = float(clean[k] or 0)
                except (TypeError, ValueError):
                    clean.pop(k)
        cur = next((c for c in d["campaigns"] if c["id"] == b.get("id")), None)
        if cur:
            cur.update(clean)
        else:
            if not (clean.get("name") or "").strip():
                raise ValueError("Enter a campaign name")
            cur = {"id": uuid.uuid4().hex[:8], "model": "cpm", "platforms": [], "required_tags": [], "status": "active",
                   "priority": 50, "network": "Content Rewards", "rules": "", **clean}
            d["campaigns"].append(cur)
        save(d)
        return cur


def delete_campaign(cid: str) -> None:
    with _lock:
        d = load()
        d["campaigns"] = [c for c in d["campaigns"] if c["id"] != cid]
        save(d)


def add_upload(name: str, src_path: Path, campaign_id: str | None = None, ws: str | None = None) -> dict:
    UPLOADS.mkdir(parents=True, exist_ok=True)
    uid = uuid.uuid4().hex[:12]
    ext = Path(name).suffix.lower() or ".mp4"
    dest = UPLOADS / f"{uid}{ext}"
    os.replace(src_path, dest)
    u = {"id": uid, "name": Path(name).stem[:120], "path": str(dest), "size": dest.stat().st_size,
         "probe": probe(dest), "campaign_id": campaign_id, "created_at": _iso(), "workspace": _wsid(ws)}
    with _lock:
        d = load()
        d["uploads"].append(u)
        save(d)
    return u


def delete_upload(uid: str) -> None:
    with _lock:
        d = load()
        u = next((x for x in d["uploads"] if x["id"] == uid), None)
        if not u:
            return
        if any(p["source"] == {"type": "upload", "id": uid} and p["status"] in ("scheduled", "queued", "posting", "draft")
               for p in d["posts"]):
            raise ValueError("This file has a scheduled post — cancel it first")
        try:
            Path(u["path"]).unlink()
        except OSError:
            pass
        d["uploads"] = [x for x in d["uploads"] if x["id"] != uid]
        save(d)


def posted_map() -> dict:
    """{export_id: {platform: url|True}} — which clips went where, for the Exports page badges."""
    out: dict = {}
    for p in load()["posts"]:
        src = p.get("source") or {}
        if src.get("type") != "export":
            continue
        for plat, r in (p.get("results") or {}).items():
            if r.get("ok"):
                out.setdefault(src["id"], {})[plat] = r.get("url") or True
                if r.get("issue"):
                    out[src["id"]].setdefault("_issues", {})[plat] = r["issue"]
            elif r.get("state") == "failed" and p["status"] != "cancelled":
                _mark_failed(out.setdefault(src["id"], {}), plat, r)
        if p["status"] == "scheduled":
            out.setdefault(src["id"], {}).setdefault("_scheduled", p["scheduled_at"])
    for m in out.values():
        _clean_failed(m)
    return out


def _mark_failed(m: dict, plat: str, r: dict) -> None:
    m.setdefault("_failed", {})[plat] = {"error": r.get("error") or "Failed", "retry_at": r.get("retry_at")}


def _clean_failed(m: dict) -> None:
    f = m.get("_failed") or {}
    for plat in [k for k in f if k in m]:
        f.pop(plat)
    if not f:
        m.pop("_failed", None)


def posted_by_clip() -> dict:
    """{clip_id: {platform: url|True, _scheduled: iso, _posting: True}} — post marks on every page."""
    out: dict = {}
    for p in load()["posts"]:
        cid = p.get("clip_id")
        if not cid:
            continue
        m = out.setdefault(cid, {})
        for plat, r in (p.get("results") or {}).items():
            if r.get("ok"):
                m[plat] = r.get("url") or m.get(plat) or True
                if r.get("issue"):
                    m.setdefault("_issues", {})[plat] = r["issue"]
            elif r.get("state") == "failed" and p["status"] != "cancelled":
                _mark_failed(m, plat, r)
        if p["status"] == "scheduled":
            m["_scheduled"] = min(m.get("_scheduled") or p["scheduled_at"], p["scheduled_at"])
        if p["status"] in ("queued", "posting"):
            m["_posting"] = True
    for m in out.values():
        _clean_failed(m)
    return {k: v for k, v in out.items() if v}


def music_risk(path: str) -> dict | None:
    """Cached background-music estimate for a clip file (see pipeline/music_check.py)."""
    try:
        from .pipeline.music_check import check
        return check(path, DIR / "music_cache")
    except Exception:  # noqa: BLE001
        log.exception("music check failed for %s", path)
        return None


def check_youtube_status() -> dict:
    """Ask YouTube what happened to every video we posted: still live, blocked by a copyright
    claim, rejected, or removed. Marks the post so every page shows it. Every project's channel."""
    out = {"checked": 0, "problems": 0}
    for ws in sorted({_post_ws(p) for p in load()["posts"]}):
        with in_ws(ws):
            if not connected("youtube"):
                continue
            r = _check_youtube_status()
        out["checked"] += r["checked"]
        out["problems"] += r["problems"]
    return out


def _check_youtube_status() -> dict:
    d = load()
    ids = []
    ws = _WS.get()
    for p in d["posts"]:
        if _post_ws(p) != ws:
            continue
        r = (p.get("results") or {}).get("youtube") or {}
        if r.get("ok") and r.get("auto") and r.get("id"):
            ids.append((p["id"], r["id"]))
    if not ids:
        return {"checked": 0, "problems": 0}
    tok, s = _google_token(), _http()
    found: dict[str, dict] = {}
    for i in range(0, len(ids), 50):
        part = ids[i:i + 50]
        j = _check(s.get("https://www.googleapis.com/youtube/v3/videos", params={
            "part": "status,contentDetails", "id": ",".join(x[1] for x in part)},
            headers={"Authorization": f"Bearer {tok}"}, timeout=30), "YouTube status")
        for it in j.get("items", []):
            found[it["id"]] = it
    bad = 0
    with _lock:
        d = load()
        byid = {p["id"]: p for p in d["posts"]}
        for pid, vid in ids:
            p = byid.get(pid)
            if not p:
                continue
            r = p["results"]["youtube"]
            it = found.get(vid)
            issue = None
            if it is None:
                issue = "Removed on YouTube (deleted, or no longer on this channel)"
            else:
                st = it.get("status") or {}
                rr = ((it.get("contentDetails") or {}).get("regionRestriction") or {}).get("blocked") or []
                if st.get("uploadStatus") == "rejected":
                    why = st.get("rejectionReason") or "rejected"
                    issue = ("Blocked by a copyright claim" if why in ("claim", "copyright") else f"Rejected by YouTube ({why})")
                elif st.get("uploadStatus") == "failed":
                    issue = f"Upload failed on YouTube ({st.get('failureReason') or 'unknown'})"
                elif len(rr) > 20:
                    issue = f"Blocked in {len(rr)} countries (copyright claim)"
                elif st.get("privacyStatus") == "private" and p.get("yt_privacy") != "private":
                    issue = "Set to private on YouTube"
            r["issue"] = issue
            r["checked_at"] = _iso()
            bad += bool(issue)
        save(d)
    return {"checked": len(ids), "problems": bad}


# ------------------------------------------------------------------ client projects
WS_KINDS = ("client", "brand", "personal", "creator", "business")
WS_FIELDS = ("name", "kind", "color", "emoji", "contact_name", "company", "email", "phone", "website", "city",
             "niche", "notes", "start_date", "retainer", "goals", "status")
MANUAL_PLATFORMS = {
    "x": "X (Twitter)", "linkedin": "LinkedIn", "threads": "Threads", "snapchat": "Snapchat",
    "pinterest": "Pinterest", "whatsapp": "WhatsApp channel", "telegram": "Telegram", "moj": "Moj",
    "josh": "Josh", "sharechat": "ShareChat", "website": "Website / blog", "other": "Other",
    "instagram": "Instagram (track only)", "facebook": "Facebook (track only)", "youtube": "YouTube (track only)",
    "tiktok": "TikTok (track only)",
}
_COLORS = ("#ff5900", "#8b5cf6", "#22c55e", "#0ea5e9", "#ec4899", "#eab308", "#14b8a6", "#ef4444")


def workspaces() -> list[dict]:
    return [w for w in load()["workspaces"] if not w.get("deleted")]


def workspace(ws: str) -> dict | None:
    if _wsid(ws) == MAIN:
        return {"id": MAIN, "name": "My accounts", "kind": "personal", "color": "#ff5900", "emoji": "★",
                "manual": load().get("main_manual", []), "main": True}
    return next((w for w in workspaces() if w["id"] == ws), None)


def workspace_name(ws: str) -> str:
    w = workspace(ws)
    return (w or {}).get("name") or "Project"


def _clean_ws(b: dict, cur: dict | None = None) -> dict:
    w = dict(cur or {})
    for k in WS_FIELDS:
        if k in b:
            v = b[k]
            v = "" if v is None else (str(v).strip() if not isinstance(v, (int, float)) else v)
            if isinstance(v, str) and len(v) > (2000 if k in ("notes", "goals") else 160):
                raise ValueError(f"{k} is too long")
            w[k] = v
    if not str(w.get("name") or "").strip():
        raise ValueError("Give the project a name")
    if w.get("kind") not in WS_KINDS:
        w["kind"] = "client"
    if w.get("email") and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", w["email"]):
        raise ValueError("That email does not look right")
    if w.get("website") and not re.match(r"^(https?://)?[\w.-]+\.[a-z]{2,}", w["website"], re.I):
        raise ValueError("That website does not look right")
    if not re.fullmatch(r"#[0-9a-fA-F]{6}", str(w.get("color") or "")):
        w["color"] = _COLORS[len(workspaces()) % len(_COLORS)]
    w["emoji"] = str(w.get("emoji") or "")[:4]
    if w.get("status") not in ("active", "paused", "ended"):
        w["status"] = "active"
    return w


def save_workspace(b: dict) -> dict:
    with _lock:
        d = load()
        wid = b.get("id")
        if wid == MAIN:
            raise ValueError("Your own accounts project cannot be renamed")
        cur = next((w for w in d["workspaces"] if w["id"] == wid and not w.get("deleted")), None) if wid else None
        if wid and not cur:
            raise ValueError("Project not found")
        w = _clean_ws(b, cur)
        if any(x["name"].lower() == w["name"].lower() and x["id"] != w.get("id") and not x.get("deleted")
               for x in d["workspaces"]):
            raise ValueError("A project with this name already exists")
        if cur:
            cur.update(w, updated_at=_iso())
            w = cur
        else:
            w.update(id="ws_" + uuid.uuid4().hex[:10], created_at=_iso(), manual=[])
            d["workspaces"].append(w)
        save(d)
        return w


def delete_workspace(wid: str) -> None:
    """Removes a client project and its saved logins. Its old posts stay in history."""
    if _wsid(wid) == MAIN:
        raise ValueError("Your own accounts project cannot be deleted")
    with _lock:
        d = load()
        w = next((x for x in d["workspaces"] if x["id"] == wid and not x.get("deleted")), None)
        if not w:
            raise ValueError("Project not found")
        if any(_post_ws(p) == wid and p["status"] in ("scheduled", "queued", "posting", "draft") for p in d["posts"]):
            raise ValueError("This project has scheduled or running posts — cancel them first")
        w.update(deleted=True, deleted_at=_iso())
        save(d)
        s = load_secrets()
        s.get("workspaces", {}).pop(wid, None)          # forget its tokens
        save_secrets(s)


def _manual_list(d: dict, wid: str) -> list:
    if _wsid(wid) == MAIN:
        return d.setdefault("main_manual", [])
    w = next((x for x in d["workspaces"] if x["id"] == wid and not x.get("deleted")), None)
    if not w:
        raise ValueError("Project not found")
    return w.setdefault("manual", [])


def save_manual_account(wid: str, b: dict) -> dict:
    """An account you track by hand (X, LinkedIn, Threads, ... or any profile without a login)."""
    plat = b.get("platform")
    if plat not in MANUAL_PLATFORMS:
        raise ValueError("Pick a platform")
    handle = str(b.get("handle") or "").strip()[:80]
    url = str(b.get("url") or "").strip()[:300]
    if not handle and not url:
        raise ValueError("Add the handle or the profile link")
    if url and not re.match(r"^https?://", url):
        url = "https://" + url
    fol = b.get("followers")
    fol = None if fol in (None, "") else int(float(str(fol).replace(",", "")))
    if fol is not None and not (0 <= fol < 10 ** 10):
        raise ValueError("Followers number looks wrong")
    with _lock:
        d = load()
        lst = _manual_list(d, wid)
        cur = next((m for m in lst if m["id"] == b.get("id")), None) if b.get("id") else None
        m = cur or {"id": "ma_" + uuid.uuid4().hex[:8], "added_at": _iso(), "history": []}
        m.update(platform=plat, handle=handle, url=url, note=str(b.get("note") or "")[:200])
        if fol is not None and (not m["history"] or m["history"][-1]["followers"] != fol):
            m["history"].append({"at": _iso(), "followers": fol})
            m["history"] = m["history"][-60:]
        m["followers"] = fol if fol is not None else m.get("followers")
        if not cur:
            lst.append(m)
        save(d)
        return m


def delete_manual_account(wid: str, mid: str) -> None:
    with _lock:
        d = load()
        lst = _manual_list(d, wid)
        lst[:] = [m for m in lst if m["id"] != mid]
        save(d)


def _ws_stats_live(ws: str) -> dict:
    """Followers / totals from the platform APIs for the project's connected accounts (best effort)."""
    out: dict = {}
    h = _http()
    with in_ws(ws):
        acc = _acc(load_secrets())
        m = acc.get("meta") or {}
        if m.get("page_token"):
            tok = m["page_token"]
            if m.get("ig_id"):
                try:
                    j = _check(h.get(f"{GRAPH}/{m['ig_id']}", params={
                        "fields": "username,followers_count,media_count,profile_picture_url", "access_token": tok},
                        timeout=20), "Instagram profile")
                    out["instagram"] = {"followers": j.get("followers_count"), "posts": j.get("media_count"),
                                        "avatar": j.get("profile_picture_url"),
                                        "url": f"https://instagram.com/{j.get('username') or m.get('ig_username')}"}
                except Exception as e:  # noqa: BLE001
                    out["instagram"] = {"error": str(e)[:160]}
            try:
                j = _check(h.get(f"{GRAPH}/{m['page_id']}", params={
                    "fields": "name,followers_count,fan_count,link", "access_token": tok}, timeout=20), "Facebook page")
                out["facebook"] = {"followers": j.get("followers_count") or j.get("fan_count"), "url": j.get("link")}
            except Exception as e:  # noqa: BLE001
                out["facebook"] = {"error": str(e)[:160]}
        if (acc.get("google") or {}).get("refresh_token"):
            try:
                tok = _google_token()
                j = _check(h.get("https://www.googleapis.com/youtube/v3/channels", params={
                    "part": "statistics,snippet", "mine": "true"}, headers={"Authorization": f"Bearer {tok}"},
                    timeout=20), "YouTube channel")
                it = (j.get("items") or [{}])[0]
                st = it.get("statistics") or {}
                out["youtube"] = {"followers": None if st.get("hiddenSubscriberCount") else int(st.get("subscriberCount") or 0),
                                  "views": int(st.get("viewCount") or 0), "posts": int(st.get("videoCount") or 0),
                                  "avatar": (((it.get("snippet") or {}).get("thumbnails") or {}).get("default") or {}).get("url"),
                                  "url": f"https://youtube.com/channel/{it.get('id')}" if it.get("id") else None}
            except Exception as e:  # noqa: BLE001
                out["youtube"] = {"error": str(e)[:160]}
        t = acc.get("tiktok") or {}
        if t.get("refresh_token"):
            out["tiktok"] = {"url": f"https://www.tiktok.com/@{t['username']}" if t.get("username") else None,
                             "followers": None, "note": "Follower count needs TikTok's user.info.stats permission"}
    return out


def workspace_stats(ws: str, refresh: bool = False) -> dict:
    """Cached for 30 minutes so opening a project is quick."""
    ws = _wsid(ws)
    d = load()
    c = (d.get("ws_stats") or {}).get(ws)
    if c and not refresh and (_parse(c.get("at")) or _now()) > _now() - dt.timedelta(minutes=30):
        return c
    live = _ws_stats_live(ws)
    c = {"at": _iso(), "accounts": live}
    with _lock:
        d = load()
        d.setdefault("ws_stats", {})[ws] = c
        hist = d.setdefault("ws_follow_hist", {}).setdefault(ws, [])
        snap = {k: v.get("followers") for k, v in live.items() if isinstance(v.get("followers"), int)}
        if snap and (not hist or hist[-1]["f"] != snap):
            hist.append({"at": _iso(), "f": snap})
            del hist[:-90]
        save(d)
    return c


def workspace_dashboard(ws: str, refresh: bool = False) -> dict:
    ws = _wsid(ws)
    w = workspace(ws)
    if not w:
        raise ValueError("Project not found")
    stats = workspace_stats(ws, refresh)
    d = load()
    hist = (d.get("ws_follow_hist") or {}).get(ws, [])
    acc = accounts_status(ws)
    for k, a in acc.items():
        if k.startswith("_"):
            continue
        live = (stats.get("accounts") or {}).get(k) or {}
        a["live"] = live
        if isinstance(live.get("followers"), int) and len(hist) > 1:
            old = next((hh["f"].get(k) for hh in hist if isinstance(hh["f"].get(k), int)
                        and (_parse(hh["at"]) or _now()) >= _now() - dt.timedelta(days=7)), None)
            a["followers_7d"] = live["followers"] - old if old is not None else None
    ov = overview(ws)
    posts = [p for p in d["posts"] if _post_ws(p) == ws]
    recent = sorted(posts, key=lambda p: p.get("finished_at") or p.get("created_at") or "", reverse=True)[:20]
    uploads = [u for u in d["uploads"] if _wsid(u.get("workspace")) == ws]
    manual = workspace(ws).get("manual") or []
    return {"workspace": w, "accounts": acc, "manual": manual, "manual_platforms": MANUAL_PLATFORMS,
            "stats_at": stats.get("at"), "overview": ov, "recent": recent, "uploads": list(reversed(uploads))[:40],
            "follow_history": hist[-30:]}


def workspaces_summary() -> list[dict]:
    """One card per project for the Clients list: connected count, posts, views, next post."""
    d = load()
    out = []
    for w in [workspace(MAIN)] + workspaces():
        ws = w["id"]
        acc = accounts_status(ws)
        conn = [k for k, a in acc.items() if not k.startswith("_") and a.get("connected")]
        posts = [p for p in d["posts"] if _post_ws(p) == ws]
        views = sum(int(r.get("views") or 0) for p in posts for r in (p.get("results") or {}).values() if r.get("ok"))
        nxt = min((p["scheduled_at"] for p in posts if p["status"] == "scheduled" and p.get("scheduled_at")), default=None)
        fol = sum(v.get("followers") or 0 for v in (((d.get("ws_stats") or {}).get(ws) or {}).get("accounts") or {}).values()
                  if isinstance(v.get("followers"), int))
        fol += sum(m.get("followers") or 0 for m in (w.get("manual") or []))
        out.append({**{k: w.get(k) for k in ("id", "name", "kind", "color", "emoji", "contact_name", "company",
                                              "status", "niche", "main")},
                    "connected": conn, "manual_count": len(w.get("manual") or []),
                    "posts": sum(1 for p in posts if p["status"] in ("done", "partial")), "views": views,
                    "scheduled": sum(1 for p in posts if p["status"] == "scheduled"), "next_post": nxt,
                    "failed": sum(1 for p in posts if p["status"] in ("failed", "partial", "missed")),
                    "followers": fol})
    return out
