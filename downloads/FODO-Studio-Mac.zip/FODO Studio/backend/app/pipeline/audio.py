"""Audio extraction and energy/silence analysis (numpy over raw PCM)."""
from __future__ import annotations

import subprocess
from pathlib import Path

import numpy as np

SAMPLE_RATE = 16000


def extract_wav(video_path: str | Path, out_path: str | Path) -> Path:
    out = Path(out_path)
    subprocess.run(
        [
            "ffmpeg", "-y", "-v", "error", "-i", str(video_path),
            "-vn", "-ac", "1", "-ar", str(SAMPLE_RATE), "-f", "wav", str(out),
        ],
        check=True, capture_output=True,
    )
    return out


def load_pcm(wav_path: str | Path) -> np.ndarray:
    raw = subprocess.run(
        ["ffmpeg", "-v", "error", "-i", str(wav_path), "-f", "s16le", "-ac", "1",
         "-ar", str(SAMPLE_RATE), "-"],
        capture_output=True, check=True,
    ).stdout
    return np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0


def energy_profile(pcm: np.ndarray, window_s: float = 0.5) -> np.ndarray:
    """RMS energy per window; index i covers [i*window_s, (i+1)*window_s)."""
    win = int(SAMPLE_RATE * window_s)
    n = len(pcm) // win
    if n == 0:
        return np.zeros(1, dtype=np.float32)
    trimmed = pcm[: n * win].reshape(n, win)
    return np.sqrt((trimmed**2).mean(axis=1))


def silence_regions(pcm: np.ndarray, window_s: float = 0.25, rel_thresh: float = 0.08,
                    min_len_s: float = 0.6) -> list[tuple[float, float]]:
    """Regions quieter than rel_thresh * median speech energy, >= min_len_s long."""
    prof = energy_profile(pcm, window_s)
    if prof.max() <= 0:
        return [(0.0, len(pcm) / SAMPLE_RATE)]
    speech_level = np.median(prof[prof > prof.max() * 0.05]) if (prof > prof.max() * 0.05).any() else prof.max()
    quiet = prof < speech_level * rel_thresh
    regions: list[tuple[float, float]] = []
    start = None
    for i, q in enumerate(quiet):
        t = i * window_s
        if q and start is None:
            start = t
        elif not q and start is not None:
            if t - start >= min_len_s:
                regions.append((start, t))
            start = None
    if start is not None and len(quiet) * window_s - start >= min_len_s:
        regions.append((start, len(quiet) * window_s))
    return regions


def mean_energy(pcm: np.ndarray, start: float, end: float) -> float:
    a, b = int(start * SAMPLE_RATE), int(end * SAMPLE_RATE)
    seg = pcm[a:b]
    if len(seg) == 0:
        return 0.0
    return float(np.sqrt((seg**2).mean()))
