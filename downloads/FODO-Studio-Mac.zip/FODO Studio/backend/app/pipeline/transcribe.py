"""Transcription providers.

Primary: faster-whisper (local, word-level timestamps). The model downloads
from Hugging Face on first run — needs internet once on the owner's machine.

Fallback: imported transcript (SRT or word-level JSON). This is also a real
product feature (bring-your-own transcript) and is what CI tests use, because
the build environment cannot reach Hugging Face.

Transcript format (list of words):
    [{"w": "Hello", "s": 0.0, "e": 0.32}, ...]
"""
from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path

from ..config import WHISPER_COMPUTE, WHISPER_DEVICE, WHISPER_MODEL

Word = dict  # {"w": str, "s": float, "e": float}


def whisper_available() -> bool:
    try:
        import faster_whisper  # noqa: F401
        return True
    except ImportError:
        return False


_LAST_DEVICE: dict = {}


def _register_cuda_dlls() -> None:
    """Windows: make pip-installed NVIDIA DLLs (nvidia-cublas-cu12, nvidia-cudnn-cu12) findable."""
    if os.name != "nt":
        return
    import site
    roots = [Path(p) for p in site.getsitepackages()] + [Path(sys.prefix) / "Lib" / "site-packages"]
    for root in roots:
        nv = root / "nvidia"
        if not nv.is_dir():
            continue
        for bin_dir in nv.glob("*/bin"):
            try:
                os.add_dll_directory(str(bin_dir))
            except OSError:
                pass
            os.environ["PATH"] = str(bin_dir) + os.pathsep + os.environ.get("PATH", "")


_CUDA_PROBE = r"""
import os, sys, site, ctypes
from pathlib import Path
if os.name == "nt":
    for root in [Path(p) for p in site.getsitepackages()] + [Path(sys.prefix) / "Lib" / "site-packages"]:
        for b in (root / "nvidia").glob("*/bin"):
            os.add_dll_directory(str(b)); os.environ["PATH"] = str(b) + os.pathsep + os.environ["PATH"]
    for dll in ("cublas64_12.dll", "cublasLt64_12.dll", "cudnn64_9.dll"):
        ctypes.WinDLL(dll)
import ctranslate2
assert ctranslate2.get_cuda_device_count() > 0
print("CUDA_OK")
"""
_CUDA_OK: bool | None = None


def cuda_usable() -> bool:
    """Probe CUDA in a separate process (a failed CUDA load can hang the caller). Cached."""
    global _CUDA_OK
    if _CUDA_OK is None:
        import subprocess
        try:
            r = subprocess.run([sys.executable, "-c", _CUDA_PROBE], capture_output=True,
                               text=True, timeout=60)
            _CUDA_OK = r.returncode == 0 and "CUDA_OK" in r.stdout
        except (OSError, subprocess.TimeoutExpired):
            _CUDA_OK = False
    return _CUDA_OK


def _whisper_device() -> str:
    from ..settings_store import get
    d = get("whisper_device")
    return d if d in ("auto", "cuda", "cpu") and d != "auto" else WHISPER_DEVICE


def _device_plan() -> list[tuple[str, str]]:
    WHISPER_DEVICE = _whisper_device()  # noqa: N806 - admin setting overrides config
    if WHISPER_DEVICE == "cpu":
        return [("cpu", WHISPER_COMPUTE)]
    plan: list[tuple[str, str]] = []
    try:
        if not cuda_usable():
            raise RuntimeError("CUDA libraries not usable")
        _register_cuda_dlls()
        import ctranslate2
        if ctranslate2.get_cuda_device_count() > 0:
            supported = ctranslate2.get_supported_compute_types("cuda")
            for ct in ("int8_float16", "float16", "int8"):
                if ct in supported:
                    plan.append(("cuda", ct))
    except Exception:  # noqa: BLE001
        pass
    if WHISPER_DEVICE != "cuda" or not plan:
        plan.append(("cpu", WHISPER_COMPUTE))
    return plan


_MODELS: dict = {}


def _cpu_kw(device: str) -> dict:
    """On CPU, use as many threads as this PC's power plan allows (saver leaves room for other apps)."""
    if device != "cpu":
        return {}
    try:
        from ..power import cpu_threads
        return {"cpu_threads": cpu_threads()}
    except Exception:  # noqa: BLE001
        return {}


def _model(name: str, device: str, compute: str):
    from faster_whisper import WhisperModel
    k = (name, device, compute)
    if k not in _MODELS:
        if len(_MODELS) >= 2:                      # keep RAM / VRAM bounded
            _MODELS.pop(next(iter(_MODELS)))
        _MODELS[k] = WhisperModel(name, device=device, compute_type=compute, **_cpu_kw(device))
    return _MODELS[k]


def transcribe_mixed(video_path: str | Path, start: float, end: float, chunks: list[tuple[float, float]],
                     prompt: str | None = None, progress=None, force: str | None = None,
                     force_all: str | None = None) -> list[Word]:
    """Code-switched speech (Hindi / Punjabi / English in one clip): detect the language of every
    sentence-sized chunk and transcribe each chunk in its own language. Whisper's per-clip language
    (or its 'multilingual' mode) tends to translate the minority language instead of writing it."""
    import subprocess

    import numpy as np

    from ..config import WHISPER_CAPTION_MODEL
    from ..settings_store import get
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}", "-i", str(video_path),
           "-vn", "-ac", "1", "-ar", "16000", "-f", "f32le", "-"]
    audio = np.frombuffer(subprocess.run(cmd, capture_output=True).stdout, np.float32).copy()
    name = get("caption_model") or WHISPER_CAPTION_MODEL
    last = None
    for device, compute in _device_plan():
        try:
            m = _model(name, device, compute)
            out: list[Word] = []
            for i, (a, b) in enumerate(chunks):
                seg = audio[int(max(0.0, a - start) * 16000): int(max(0.0, b - start) * 16000)]
                if len(seg) < 16000 * 0.4:
                    continue
                if force_all:
                    # one language for the whole clip: no per-chunk language-ID (it mislabels Indian
                    # speech); only silent chunks are skipped, Whisper's own filters drop noise below
                    if float(np.sqrt(np.mean(seg ** 2))) < 0.003:
                        continue
                    lang = force_all
                    segs, _info = m.transcribe(seg, word_timestamps=True, language=lang, beam_size=5,
                                               vad_filter=False, condition_on_previous_text=False,
                                               initial_prompt=prompt or None)
                    for sg in segs:
                        if (sg.no_speech_prob > 0.6 or sg.avg_logprob < -1.0 or sg.compression_ratio > 2.4):
                            continue
                        for w in sg.words or []:
                            out.append({"w": w.word.strip(), "s": round(a + w.start, 3), "e": round(a + w.end, 3),
                                        "lang": lang})
                    if progress:
                        progress((i + 1) / len(chunks))
                    continue
                pad = np.concatenate([seg, np.zeros(16000 * 2, np.float32)]) if len(seg) < 16000 * 3 else seg
                lang, prob, allp = m.detect_language(pad)
                probs = dict(allp)
                if lang in ("ur", "ne", "mr"):
                    lang = "hi"
                known = ("hi", "pa", "en", "gu", "bn", "ta", "te", "kn", "ml")
                if lang not in known and prob >= 0.3:
                    # crowd noise / music is 'heard' as Spanish, Japanese, Thai... - no caption there
                    continue
                if lang not in known or prob < 0.3:
                    indian = max(("hi", "pa", "ur"), key=lambda k: probs.get(k, 0))
                    lang = "hi" if probs.get(indian, 0) >= 0.15 else ("en" if probs.get("en", 0) >= 0.2 else None)
                    if lang is None:
                        continue
                if lang == "en" and probs.get("hi", 0) + probs.get("ur", 0) >= 0.25:
                    lang = "hi"                            # Hinglish: written in Hindi, shown in Roman
                if force and lang != "en":
                    lang = force                           # user asked for this script; English stays English
                segs, _info = m.transcribe(seg, word_timestamps=True, language=lang, beam_size=5,
                                           vad_filter=False, condition_on_previous_text=False,
                                           initial_prompt=prompt or None)
                for sg in segs:
                    # drop what Whisper itself is unsure about (noise, mumbling, repeated loops)
                    if (sg.no_speech_prob > 0.6 or sg.avg_logprob < -1.0 or sg.compression_ratio > 2.4):
                        continue
                    for w in sg.words or []:
                        out.append({"w": w.word.strip(), "s": round(a + w.start, 3), "e": round(a + w.end, 3),
                                    "lang": lang or ""})
                if progress:
                    progress((i + 1) / len(chunks))
            return out
        except Exception as e:  # noqa: BLE001
            last = e
            continue
    raise RuntimeError(f"Caption transcription failed: {last}")


def _run(device: str, compute: str, audio, language, progress, task: str = "transcribe",
         model_name: str | None = None, prompt: str | None = None, info_out: dict | None = None,
         multilingual: bool = False) -> tuple[list[Word], float]:
    from faster_whisper import WhisperModel

    from ..settings_store import get
    model = WhisperModel(model_name or get("whisper_model") or WHISPER_MODEL, device=device, compute_type=compute,
                         **_cpu_kw(device))
    segments, info = model.transcribe(audio, word_timestamps=True, language=language,
                                      vad_filter=True, task=task, initial_prompt=prompt or None,
                                      beam_size=5, condition_on_previous_text=False,
                                      **({"multilingual": True} if multilingual and language is None else {}))
    if info_out is not None:
        info_out.update({"language": info.language, "probability": round(info.language_probability or 0, 3)})
    words: list[Word] = []
    total = info.duration or 1.0
    for seg in segments:  # lazy: CUDA errors (missing DLLs) surface here
        for w in seg.words or []:
            words.append({"w": w.word.strip(), "s": round(w.start, 3), "e": round(w.end, 3)})
        if progress:
            progress(min(seg.end / total, 1.0))
    return words, total


def transcribe_whisper(wav_path: str | Path, progress=None, language: str | None = None) -> list[Word]:
    """Transcribe on the GPU when it works, otherwise on the CPU (automatic fallback)."""
    import logging
    import time

    from .audio import load_pcm

    log = logging.getLogger("clipforge.whisper")
    # Decode with FFmpeg ourselves and hand Whisper a float32 16 kHz array:
    # avoids faster-whisper's PyAV path (breaks across PyAV versions).
    audio = load_pcm(wav_path)
    errors = []
    for device, compute in _device_plan():
        t0 = time.time()
        try:
            words, dur = _run(device, compute, audio, language, progress)
        except Exception as e:  # noqa: BLE001
            log.warning("Whisper on %s/%s failed (%s) - trying next option", device, compute, e)
            errors.append(f"{device}/{compute}: {e}")
            continue
        took = time.time() - t0
        _LAST_DEVICE.update({"device": device, "compute": compute, "seconds": round(took, 1),
                             "audio_seconds": round(dur, 1),
                             "speed_x_realtime": round(dur / took, 1) if took else None})
        log.info("Whisper %s/%s: %.0fs audio in %.0fs (%.1fx realtime)",
                 device, compute, dur, took, dur / took if took else 0)
        return words
    raise RuntimeError("Transcription failed: " + " | ".join(errors))


def detect_language(video_path: str | Path, start: float, end: float, accurate: bool = True) -> tuple[str, float]:
    """Spoken language of one part of a video (the analysis transcript can be wrong: the small
    model sometimes 'hears' Hindi as English and writes a translation)."""
    import subprocess

    import numpy as np
    from faster_whisper import WhisperModel

    from ..config import WHISPER_CAPTION_MODEL
    from ..settings_store import get
    mid = (start + end) / 2
    a = max(start, mid - 15)
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{a:.3f}", "-t", f"{min(30.0, end - a):.3f}", "-i", str(video_path),
           "-vn", "-ac", "1", "-ar", "16000", "-f", "f32le", "-"]
    audio = np.frombuffer(subprocess.run(cmd, capture_output=True).stdout, np.float32).copy()
    names = [get("caption_model") or WHISPER_CAPTION_MODEL, None] if accurate else [None]
    for name in names:
        for device, compute in _device_plan():
            try:
                model = WhisperModel(name or get("whisper_model") or WHISPER_MODEL, device=device,
                                     compute_type=compute, **_cpu_kw(device))
                lang, prob, _all = model.detect_language(audio)
                return lang, float(prob)
            except Exception:  # noqa: BLE001
                continue
    return "", 0.0


def language_probs(video_path: str | Path, windows: list[tuple[float, float]]) -> dict[str, float]:
    """Average spoken-language probabilities over a few windows of a video (big caption model)."""
    import subprocess

    import numpy as np

    from ..config import WHISPER_CAPTION_MODEL
    from ..settings_store import get
    clips = []
    for a, b in windows:
        cmd = ["ffmpeg", "-v", "error", "-ss", f"{a:.3f}", "-t", f"{b - a:.3f}", "-i", str(video_path),
               "-vn", "-ac", "1", "-ar", "16000", "-f", "f32le", "-"]
        au = np.frombuffer(subprocess.run(cmd, capture_output=True).stdout, np.float32).copy()
        if len(au) >= 16000 * 3 and float(np.sqrt(np.mean(au ** 2))) > 0.003:      # skip silence
            clips.append(au)
    if not clips:
        return {}
    for name in (get("caption_model") or WHISPER_CAPTION_MODEL, None):
        for device, compute in _device_plan():
            try:
                m = _model(name or get("whisper_model") or WHISPER_MODEL, device, compute)
                tot: dict[str, float] = {}
                for au in clips:
                    _lang, _prob, allp = m.detect_language(au)
                    for k, v in allp:
                        tot[k] = tot.get(k, 0.0) + float(v) / len(clips)
                return tot
            except Exception:  # noqa: BLE001
                continue
    return {}


def language_scores(video_path: str | Path, windows: list[tuple[float, float]],
                    langs: tuple[str, ...] = ("hi", "en")) -> dict[str, float]:
    """How well each language explains the speech: mean log-probability when Whisper is forced to
    transcribe the windows in that language. Far more reliable than Whisper's language-ID on Indian
    speech (large-v3-turbo 'hears' Hindi TV dialogue as English at 0.9)."""
    import subprocess

    import numpy as np

    from ..config import WHISPER_CAPTION_MODEL
    from ..settings_store import get
    clips = []
    for a, b in windows:
        cmd = ["ffmpeg", "-v", "error", "-ss", f"{a:.3f}", "-t", f"{b - a:.3f}", "-i", str(video_path),
               "-vn", "-ac", "1", "-ar", "16000", "-f", "f32le", "-"]
        au = np.frombuffer(subprocess.run(cmd, capture_output=True).stdout, np.float32).copy()
        if len(au) >= 16000 * 3 and float(np.sqrt(np.mean(au ** 2))) > 0.003:
            clips.append(au)
    if not clips:
        return {}
    for name in (get("caption_model") or WHISPER_CAPTION_MODEL, None):
        for device, compute in _device_plan():
            try:
                m = _model(name or get("whisper_model") or WHISPER_MODEL, device, compute)
                out: dict[str, float] = {}
                for lang in langs:
                    lp, n = 0.0, 0
                    for au in clips:
                        segs, _ = m.transcribe(au, language=lang, beam_size=1, vad_filter=True,
                                               condition_on_previous_text=False, without_timestamps=True)
                        for sg in segs:
                            if sg.no_speech_prob > 0.7:
                                continue
                            dur = max(0.2, sg.end - sg.start)
                            lp += sg.avg_logprob * dur
                            n += dur
                    if n:
                        out[lang] = lp / n
                return out
            except Exception:  # noqa: BLE001
                continue
    return {}


def transcribe_range(video_path: str | Path, start: float, end: float, language: str | None = None,
                     task: str = "transcribe", accurate: bool = False, prompt: str | None = None,
                     multilingual: bool = False) -> list[Word]:
    """Transcribe (or translate to English with task='translate') just one part of a video.
    Word times are returned in source-video time."""
    import subprocess

    import numpy as np
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}", "-i", str(video_path),
           "-vn", "-ac", "1", "-ar", "16000", "-f", "f32le", "-"]
    audio = np.frombuffer(subprocess.run(cmd, capture_output=True).stdout, np.float32).copy()
    from ..config import WHISPER_CAPTION_MODEL
    from ..settings_store import get
    models = [get("caption_model") or WHISPER_CAPTION_MODEL, "medium", None] if accurate else [None]
    errors = []
    for (device, compute), model_name in ((d, m) for m in models for d in _device_plan()):
        try:
            words, _ = _run(device, compute, audio, language, None, task=task, model_name=model_name,
                            prompt=prompt, multilingual=multilingual)
            return [{**w, "s": round(w["s"] + start, 3), "e": round(w["e"] + start, 3)} for w in words]
        except Exception as e:  # noqa: BLE001
            errors.append(f"{device}/{compute}: {e}")
    raise RuntimeError("Caption transcription failed: " + " | ".join(errors))


def last_transcription_info() -> dict:
    return dict(_LAST_DEVICE)


_SRT_TIME = re.compile(r"(\d+):(\d+):(\d+)[,.](\d+)")


def _srt_ts(ts: str) -> float:
    m = _SRT_TIME.match(ts.strip())
    if not m:
        raise ValueError(f"Bad SRT timestamp: {ts}")
    h, mi, s, ms = (int(x) for x in m.groups())
    return h * 3600 + mi * 60 + s + ms / 1000


def parse_srt(text: str) -> list[Word]:
    """Parse SRT; distribute words evenly inside each cue (approx word timing)."""
    words: list[Word] = []
    blocks = re.split(r"\n\s*\n", text.strip())
    for block in blocks:
        lines = [ln for ln in block.splitlines() if ln.strip()]
        if len(lines) < 2:
            continue
        time_line = next((ln for ln in lines if "-->" in ln), None)
        if not time_line:
            continue
        start_s, end_s = (t.strip() for t in time_line.split("-->"))
        start, end = _srt_ts(start_s), _srt_ts(end_s)
        content = " ".join(ln for ln in lines[lines.index(time_line) + 1 :])
        toks = content.split()
        if not toks:
            continue
        step = (end - start) / len(toks)
        for i, tok in enumerate(toks):
            words.append({
                "w": tok,
                "s": round(start + i * step, 3),
                "e": round(start + (i + 1) * step, 3),
            })
    return words


def parse_transcript_file(path: str | Path) -> list[Word]:
    p = Path(path)
    text = p.read_text(encoding="utf-8", errors="replace")
    if p.suffix.lower() == ".json":
        data = json.loads(text)
        if isinstance(data, list) and data and {"w", "s", "e"} <= set(data[0]):
            return data
        raise ValueError("JSON transcript must be a list of {w,s,e} objects")
    return parse_srt(text)


def words_to_sentences(words: list[Word]) -> list[dict]:
    """Group words into sentences on terminal punctuation or >0.8s gaps."""
    sentences: list[dict] = []
    current: list[Word] = []
    for i, w in enumerate(words):
        current.append(w)
        gap = (words[i + 1]["s"] - w["e"]) if i + 1 < len(words) else 99
        if re.search(r"[.!?।]$", w["w"]) or gap > 0.8:
            sentences.append({
                "text": " ".join(x["w"] for x in current),
                "s": current[0]["s"],
                "e": current[-1]["e"],
                "words": current,
            })
            current = []
    if current:
        sentences.append({
            "text": " ".join(x["w"] for x in current),
            "s": current[0]["s"],
            "e": current[-1]["e"],
            "words": current,
        })
    return sentences
