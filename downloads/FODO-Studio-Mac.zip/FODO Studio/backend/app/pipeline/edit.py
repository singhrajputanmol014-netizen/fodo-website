"""Edit intelligence: dead-air removal (jump cuts), edit presets, motion graphics
(hook title card) and sound-design events. Pure functions - FFmpeg work lives in compose.py.

Presets follow what performs in 2026 short-form (researched Nov 2026):
- podcast_pro   : jump cuts on pauses (4-8 per minute), punch-in on cuts, word captions,
                  subtle whoosh on layout changes, hook title, progress bar, light music bed
- hormozi       : tight pacing, bold pop-word captions, bigger punch-ins, punchy SFX, upbeat music
- documentary   : slow, cinematic grade, minimal captions, no SFX, cinematic music, gentle trims
- clean_talk    : talking-head clean - light trims, clean grade, simple captions, no SFX
- raw           : exactly the original - no trims, no grade, no music, no SFX, original voice only
"""
from __future__ import annotations

from pathlib import Path
import re

SFX_DIR = Path(__file__).parent / "assets" / "sfx"

DEAD_AIR = {             # remove silences longer than this (seconds); None = keep everything
    "off": None,
    "light": 1.5,        # only long dead air - a 1-2 s thinking pause is part of a conversation (default)
    "normal": 1.0,
    "tight": 0.6,        # faster pacing; below this speech starts to sound robotic
}
SFX_LEVEL = {"off": 0.0, "subtle": 0.10, "punchy": 0.18}

# Researched Nov 2026: top podcast channels (Diary of a CEO, Flagrant, Figuring Out, TRS clips)
# keep clips conversational - little or no music, at most a soft swoosh, no zooms without a reason,
# only real dead air removed. Over-editing makes a clip feel cheap.
PRESETS: dict[str, dict] = {
    # Every preset is a complete "look" researched from a real creator family (Nov 2026):
    # framing, caption treatment, title graphics, sound and how the clip ends.
    "podcast_pro": {
        "tags": "raj shamani, figuring out, ranveer allahbadia, beerbiceps podcast, shubhankar mishra, nikhil kamath, prakhar gupta, podcast, interview, guest",
        "label": "Podcast Premium (Figuring Out style)",
        "desc": "4:5 picture on a dark frame, clean captions, one key word now and then glows big in yellow, soft music, fade-out ending",
        "edit_style": "clean", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "subtle",
        "music_mood": "calm", "music_volume": 8, "animation": "static", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False, "slow_push": False,
        "frame": "frame45", "title_kind": "open_box", "keyword_pop": True, "outro": 0.8, "intro": 0.0,
        "captions": True, "caption": {"words_per_line": 6, "size": 80, "upper": False, "box": False,
                                      "position": "lower", "color": "#FFFFFF", "outline": 2},
    },
    "desi_reel": {
        "tags": "desi, hindi podcast, indian reel, sandeep maheshwari, emotional, bhakti, spiritual, hindi",
        "label": "Desi Podcast Reel", "desc": "Full screen, warm Indian colour, bold yellow-highlight captions (Hindi font), emotional music bed, fade-out ending",
        "edit_style": "warm", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "subtle",
        "music_mood": "cinematic", "music_volume": 10, "animation": "highlight_word", "font": "Hind Bold (Hindi)",
        "hook_title": False, "progress_bar": False, "highlight": "#FFD400", "slow_push": True,
        "frame": "fill", "title_kind": "open_box", "outro": 0.7,
        "captions": True, "caption": {"words_per_line": 3, "size": 84, "upper": False, "box": False,
                                      "position": "lower", "color": "#FFFFFF", "outline": 4},
    },
    "hormozi": {
        "punch": True,
        "tags": "alex hormozi, hormozi, gary vee, iman gadzhi, business, sales, money, entrepreneur, startup, marketing",
        "label": "Business / High-energy (Hormozi 2026)",
        "desc": "Headline box on top the whole clip that turns into a call-to-action at the end, clean lowercase captions, punchy colour, progress bar, whooshes",
        "edit_style": "high_energy", "dead_air": "normal", "jump_zoom": 1.0, "sfx": "punchy",
        "music_mood": "upbeat", "music_volume": 9, "animation": "static", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": True,
        "frame": "fill", "title_kind": "top_box", "cta": "Follow for more", "outro": 0.0,
        "captions": True, "caption": {"words_per_line": 5, "size": 90, "upper": False, "box": False,
                                      "position": "lower", "color": "#FFFFFF", "outline": 3},
    },
    "documentary": {
        "tags": "dhruv rathee, documentary, explainer, news, history, abhi and niyu, johnny harris, vox, facts, story",
        "label": "Documentary (Dhruv Rathee style)",
        "desc": "Cinematic grade with film grain, no word captions, name label slides in, slow camera push, fades in from black and out to black, cinematic music",
        "edit_style": "cinematic", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "cinematic", "music_volume": 12, "animation": "static", "font": "Archivo Black",
        "hook_title": False, "progress_bar": False, "slow_push": True, "highlight": "#1E5BFF",
        "frame": "fill", "title_kind": "lower_third", "grain": True, "intro": 0.6, "outro": 1.2,
        "captions": False, "caption": {"words_per_line": 6, "size": 72, "upper": False, "box": False,
                                       "position": "lower", "color": "#FFFFFF", "outline": 2},
    },
    "clean_talk": {
        "tags": "diary of a ceo, doac, steven bartlett, chris williamson, modern wisdom, jay shetty, lex fridman, joe rogan, big podcast",
        "label": "Big Podcast, one word (Diary of a CEO style)",
        "desc": "Huge 2-line hook words for the first seconds, then one bold word at a time in the middle, no music, no effects",
        "edit_style": "clean", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "none", "music_volume": 0, "animation": "static", "font": "Archivo Black",
        "hook_title": False, "progress_bar": False,
        "frame": "fill", "title_kind": "big_hook", "outro": 0.5,
        "captions": True, "caption": {"words_per_line": 1, "size": 92, "upper": True, "box": False,
                                      "position": "center_low", "color": "#FFFFFF", "outline": 3},
    },
    "tv_clip": {
        "tags": "tmkoc, taarak mehta, jethalal, serial, tv serial, sab tv, cid, kapil sharma, daily soap",
        "label": "TV serial, wide frame (TMKOC style)",
        "desc": "Like official TV-show pages: whole-height frame that keeps both actors in shot (no split, no face zoom), title line on screen, no cuts in the comic timing, screen fades at the end",
        "edit_style": "clean", "dead_air": "off", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "none", "music_volume": 0, "animation": "static", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False, "framing": "tv",
        "frame": "tv", "title_kind": "center", "outro": 1.0,
        "captions": False, "caption": {"words_per_line": 5, "size": 80, "upper": False, "box": False,
                                       "position": "lower", "color": "#FFFFFF", "outline": 3},
    },
    "comedy_skit": {
        "tags": "skit, comedy, relatable, bb ki vines, bhuvan bam, harsh beniwal, ashish chanchlani, round2hell, funny",
        "label": "Comedy skit / relatable",
        "desc": "Small white premise pill on top for the whole clip, no captions, natural pacing, quick fade at the end",
        "edit_style": "dynamic", "dead_air": "light", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "none", "music_volume": 0, "animation": "static", "font": "Poppins ExtraBold",
        "hook_title": False, "progress_bar": False,
        "frame": "fill", "title_kind": "premise", "outro": 0.5,
        "captions": False, "caption": {"words_per_line": 5, "size": 80, "upper": False, "box": False,
                                       "position": "lower", "color": "#FFFFFF", "outline": 3},
    },
    "vlog": {
        "tags": "vlog, travel, mumbiker nikhil, sourav joshi, flying beast, casey neistat, trip, tour, daily vlog",
        "label": "Vlog / travel",
        "desc": "Wide 6:5 picture across the screen on a soft blurred background, big spaced title at the start, \"WATCH FULL VIDEO\" end card, upbeat music",
        "edit_style": "dynamic", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "subtle",
        "music_mood": "upbeat", "music_volume": 10, "animation": "static", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False,
        "frame": "frame65", "title_kind": "spaced", "cta": "Watch full video", "outro": 0.6,
        "captions": True, "caption": {"words_per_line": 6, "size": 84, "upper": False, "box": False,
                                      "position": "lower", "color": "#FFFFFF", "outline": 3},
    },
    "clip_page": {
        "tags": "clip page, think school, ankur warikoo, warikoo, mkbhd, elon musk, quotes, black template, edu, finance",
        "label": "Clip page (black template)",
        "desc": "The most common clip-page look: black background, headline on top with one coloured key word, video in a rounded box, 2-3 word captions under it with a yellow active word",
        "edit_style": "clean", "dead_air": "light", "jump_zoom": 1.0, "sfx": "subtle",
        "music_mood": "calm", "music_volume": 7, "animation": "highlight_word", "font": "Archivo Black",
        "hook_title": False, "progress_bar": False, "highlight": "#FFD400",
        "frame": "boxed", "title_kind": "clip_page", "outro": 0.6,
        "captions": True, "caption": {"words_per_line": 3, "size": 84, "upper": True, "box": False,
                                      "position": "under_box", "color": "#FFFFFF", "outline": 2},
    },
    "stream_clip": {
        "punch": True,
        "tags": "ishowspeed, speed, kai cenat, xqc, carryminati, carryislive, total gaming, ajjubhai, mortal, scout, techno gamerz, gaming, stream, live, valorant, bgmi, free fire, gta, minecraft, fortnite",
        "label": "Live stream / gaming (Speed, Kai Cenat, xQc)",
        "desc": "Facecam on top, gameplay below, white premise box for the first seconds, one huge word at a time at the seam, colour flash on the big moments, punchy whooshes",
        "edit_style": "dynamic", "dead_air": "normal", "jump_zoom": 1.0, "sfx": "punchy",
        "music_mood": "none", "music_volume": 0, "animation": "one_word", "font": "Archivo Black",
        "hook_title": False, "progress_bar": False, "highlight": "#FFE600",
        "frame": "stream", "title_kind": "premise_box", "flash": True, "outro": 0.3,
        "captions": True, "caption": {"words_per_line": 1, "size": 104, "upper": True, "box": False,
                                      "position": "seam", "color": "#FFFFFF", "outline": 6},
    },
    "sitcom": {
        "tags": "the office, brooklyn 99, b99, friends, sitcom, peacock, shemaroo, movie scene, hera pheri, welcome, bollywood, prime video, netflix scene",
        "label": "Sitcom / movie scene (The Office, Peacock, Shemaroo)",
        "desc": "Like official show pages: the crop follows whoever is speaking, clean white subtitles, no cuts in the comic timing, holds on the reaction at the end",
        "edit_style": "clean", "dead_air": "off", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "none", "music_volume": 0, "animation": "subtitle", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False, "framing": "speaker",
        "frame": "fill", "title_kind": "none", "outro": 0.5, "end_hold": 1.2,
        "captions": True, "caption": {"words_per_line": 7, "size": 82, "upper": False, "box": False,
                                      "position": "low_subtitle", "color": "#FFFFFF", "outline": 3},
    },
    "motivation": {
        "tags": "david goggins, goggins, motivation, gym, discipline, mindset, workout, fitness, hustle",
        "label": "Motivation / gym edit (Goggins style)",
        "desc": "Cinemascope black bars, teal cinematic grade with grain, one big word at a time with key words in red, label in the top bar, cinematic music, ends on black",
        "edit_style": "cinematic", "dead_air": "light", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "cinematic", "music_volume": 14, "animation": "one_word", "font": "Archivo Black",
        "hook_title": False, "progress_bar": False, "highlight": "#FF2D2D",
        "frame": "cinema", "title_kind": "cinema_label", "grain": True, "intro": 0.4, "outro": 1.4,
        "captions": True, "caption": {"words_per_line": 1, "size": 96, "upper": True, "box": False,
                                      "position": "middle", "color": "#FFFFFF", "outline": 0},
    },
    "meme": {
        "punch": True,
        "tags": "meme, vine boom, funny edit, shitpost, reaction meme, troll",
        "label": "Meme edit (white top text)",
        "desc": "Meme template: premise in black on a white top, the clip under it, small white subtitles, colour flash on the punchlines, quick ending",
        "edit_style": "dynamic", "dead_air": "normal", "jump_zoom": 1.0, "sfx": "punchy",
        "music_mood": "none", "music_volume": 0, "animation": "subtitle", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False, "highlight": "#FFE600",
        "frame": "white_top", "title_kind": "white_top", "flash": True, "outro": 0.3,
        "captions": True, "caption": {"words_per_line": 7, "size": 90, "upper": False, "box": False,
                                      "position": "low_subtitle", "color": "#FFFFFF", "outline": 3},
    },
    # ---- v0.8 recipes (built only from tested building blocks: frames, title graphics,
    #      caption animations, grades, music moods). Status per style: see the compatibility matrix.
    "cinematic_luxury": {
        "tags": "cinematic, luxury, premium, aesthetic, slow, elegant, brand film",
        "label": "Cinematic Luxury", "desc": "4:5 picture on a dark blurred frame, soft warm low-saturation grade, slow camera push, elegant serif captions, fade in and out, cinematic music",
        "edit_style": "luxury", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "cinematic", "music_volume": 12, "animation": "static", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False, "slow_push": True, "highlight": "#E8C27A",
        "frame": "frame45", "title_kind": "spaced", "intro": 0.6, "outro": 1.2,
        "captions": True, "caption": {"words_per_line": 5, "size": 82, "upper": False, "box": False,
                                      "position": "lower", "color": "#F3EDE2", "outline": 1},
    },
    "film_trailer": {
        "punch": True,
        "tags": "trailer, movie trailer, epic, dramatic, teaser, hype",
        "label": "Film Trailer", "desc": "Full-screen moody teal-orange grade, huge hook words first, one huge word at a time in the middle, flashes on key words, rising music, long fade-out",
        "edit_style": "moody", "dead_air": "normal", "jump_zoom": 1.0, "sfx": "punchy",
        "music_mood": "cinematic", "music_volume": 16, "animation": "one_word", "font": "Bebas Neue",
        "hook_title": False, "progress_bar": False, "highlight": "#FF5900", "flash": True,
        "frame": "fill", "title_kind": "big_hook", "intro": 0.5, "outro": 1.5,
        "captions": True, "caption": {"words_per_line": 1, "size": 120, "upper": True, "box": False,
                                      "position": "middle", "color": "#FFFFFF", "outline": 0},
    },
    "vintage_film": {
        "tags": "vintage, film, old film, nostalgia, retro film, analog, film grain",
        "label": "Vintage Film", "desc": "Faded warm film grade with grain and vignette, subtitle-style captions, gentle fade-out",
        "edit_style": "vintage", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "calm", "music_volume": 9, "animation": "subtitle", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False, "frame": "frame45", "title_kind": "none", "outro": 1.0,
        "captions": True, "caption": {"words_per_line": 7, "size": 82, "upper": False, "box": False,
                                      "position": "low_subtitle", "color": "#FFF4DC", "outline": 2},
    },
    "retro_vhs": {
        "tags": "vhs, retro, 90s, y2k, glitch, old tape, nostalgia",
        "label": "Retro VHS / Y2K", "desc": "VHS colour bleed, tape noise, pop-in retro captions, upbeat music",
        "edit_style": "vhs", "dead_air": "normal", "jump_zoom": 1.0, "sfx": "subtle",
        "music_mood": "upbeat", "music_volume": 10, "animation": "pop_words", "font": "Righteous",
        "hook_title": False, "progress_bar": False, "highlight": "#FF4FD8",
        "frame": "fill", "title_kind": "premise", "outro": 0.4,
        "captions": True, "caption": {"words_per_line": 3, "size": 92, "upper": True, "box": False,
                                      "position": "lower", "color": "#FFFFFF", "outline": 4},
    },
    "neon_typography": {
        "punch": True,
        "tags": "neon, night, gaming, cyberpunk, glow, club, tech",
        "label": "Neon Typography", "desc": "Cool saturated night grade, glowing word-by-word highlight, punch-ins, upbeat music",
        "edit_style": "neon", "dead_air": "normal", "jump_zoom": 1.0, "sfx": "punchy",
        "music_mood": "upbeat", "music_volume": 11, "animation": "highlight_word", "font": "Bangers",
        "hook_title": False, "progress_bar": False, "highlight": "#00F0FF",
        "frame": "fill", "title_kind": "big_hook", "outro": 0.4,
        "captions": True, "caption": {"words_per_line": 3, "size": 100, "upper": True, "box": False,
                                      "position": "lower", "color": "#FF4FD8", "outline": 5},
    },
    "karaoke_captions": {
        "tags": "karaoke, word by word, captions, subtitles, music, lyrics, sing",
        "label": "Karaoke Captions", "desc": "Each word lights up exactly when it is spoken, big readable lines, clean colour",
        "edit_style": "clean", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "none", "music_volume": 0, "animation": "karaoke", "font": "Poppins ExtraBold",
        "hook_title": False, "progress_bar": False, "highlight": "#FFD400",
        "frame": "fill", "title_kind": "open_box", "outro": 0.5,
        "captions": True, "caption": {"words_per_line": 4, "size": 92, "upper": False, "box": False,
                                      "position": "lower", "color": "#FFFFFF", "outline": 4},
    },
    "kinetic_typography": {
        "punch": True,
        "tags": "kinetic typography, motion text, one word, fast captions, dynamic captions, text animation",
        "label": "Kinetic Typography", "desc": "One huge word at a time popping in the middle, colour flashes on key words, punch-ins, fast pacing",
        "edit_style": "high_energy", "dead_air": "tight", "jump_zoom": 1.0, "sfx": "punchy",
        "music_mood": "upbeat", "music_volume": 12, "animation": "one_word", "font": "Anton",
        "hook_title": False, "progress_bar": True, "highlight": "#FF5900", "flash": True,
        "frame": "fill", "title_kind": "none", "outro": 0.3,
        "captions": True, "caption": {"words_per_line": 1, "size": 130, "upper": True, "box": False,
                                      "position": "middle", "color": "#FFFFFF", "outline": 6},
    },
    "minimal_editorial": {
        "tags": "minimal, editorial, clean, aesthetic, simple, calm, minimalist, apple",
        "label": "Minimal Editorial", "desc": "No effects, soft luxury grade, small clean lowercase lines, no music, quiet fade at the end",
        "edit_style": "luxury", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "none", "music_volume": 0, "animation": "subtitle", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False, "frame": "frame45", "title_kind": "spaced", "outro": 0.8,
        "captions": True, "caption": {"words_per_line": 6, "size": 80, "upper": False, "box": False,
                                      "position": "low_subtitle", "color": "#FFFFFF", "outline": 1},
    },
    "corporate_premium": {
        "tags": "corporate, business authority, linkedin, company, ceo, b2b, professional, brand",
        "label": "Corporate Premium (LinkedIn)", "desc": "Bright clean grade, name label slides in, boxed captions for easy reading, soft music",
        "edit_style": "bright", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "subtle",
        "music_mood": "calm", "music_volume": 7, "animation": "static", "font": "Montserrat Alt ExtraBold",
        "hook_title": False, "progress_bar": False, "highlight": "#2F6BFF",
        "frame": "frame45", "title_kind": "lower_third", "outro": 0.7,
        "captions": True, "caption": {"words_per_line": 5, "size": 72, "upper": False, "box": True,
                                      "position": "lower", "color": "#FFFFFF", "outline": 0},
    },
    "news_commentary": {
        "tags": "news, commentary, current affairs, explainer, breaking, opinion, politics, update",
        "label": "News Commentary", "desc": "Headline box on top, boxed captions, punchy colour, progress bar, subtle whooshes",
        "edit_style": "dynamic", "dead_air": "normal", "jump_zoom": 1.0, "sfx": "subtle",
        "music_mood": "none", "music_volume": 0, "animation": "static", "font": "Archivo Black",
        "hook_title": False, "progress_bar": True, "highlight": "#E10600",
        "frame": "fill", "title_kind": "top_box", "outro": 0.4,
        "captions": True, "caption": {"words_per_line": 5, "size": 78, "upper": False, "box": True,
                                      "position": "lower", "color": "#FFFFFF", "outline": 0},
    },
    "tutorial_edit": {
        "tags": "tutorial, how to, educational, teaching, course, explain, guide, steps, tips",
        "label": "Tutorial / Educational", "desc": "Clear title on top, boxed captions, key terms pop in yellow, progress bar, no music",
        "edit_style": "bright", "dead_air": "normal", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "none", "music_volume": 0, "animation": "highlight_word", "font": "Poppins ExtraBold",
        "hook_title": False, "progress_bar": True, "highlight": "#FFD400", "keyword_pop": True,
        "frame": "fill", "title_kind": "top_box", "outro": 0.4,
        "captions": True, "caption": {"words_per_line": 4, "size": 84, "upper": False, "box": True,
                                      "position": "lower", "color": "#FFFFFF", "outline": 0},
    },
    "product_ugc_ad": {
        "punch": True,
        "tags": "ugc, ad, advertisement, product, review, unboxing, shop, d2c, brand, sale",
        "label": "Product / UGC Ad", "desc": "Bright punchy grade, huge hook words first, bold captions, punch-ins, progress bar, 'Shop now' call-to-action",
        "edit_style": "bright", "dead_air": "tight", "jump_zoom": 1.0, "sfx": "punchy",
        "music_mood": "upbeat", "music_volume": 10, "animation": "pop_words", "font": "Lilita One",
        "hook_title": False, "progress_bar": True, "highlight": "#FF5900", "cta": "Shop now",
        "frame": "fill", "title_kind": "big_hook", "outro": 0.3,
        "captions": True, "caption": {"words_per_line": 3, "size": 96, "upper": False, "box": False,
                                      "position": "lower", "color": "#FFFFFF", "outline": 5},
    },
    "pov_story": {
        "tags": "pov, storytelling, story time, micro drama, relatable, social story",
        "label": "POV Storytelling", "desc": "Premise pill on top for the whole clip (\"POV: …\"), subtitle captions, soft music, fade-out",
        "edit_style": "warm", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "subtle",
        "music_mood": "lofi", "music_volume": 9, "animation": "subtitle", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False, "frame": "fill", "title_kind": "premise", "outro": 0.7,
        "captions": True, "caption": {"words_per_line": 6, "size": 84, "upper": False, "box": False,
                                      "position": "low_subtitle", "color": "#FFFFFF", "outline": 3},
    },
    "luxury_fashion": {
        "tags": "fashion, luxury fashion, model, lookbook, beauty, style, outfit, vogue",
        "label": "Luxury Fashion", "desc": "4:5 picture on a dark frame, soft luxury grade, slow push, no word captions - spaced serif title, music-led",
        "edit_style": "luxury", "dead_air": "light", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "cinematic", "music_volume": 16, "animation": "static", "font": "Playfair Display SC",
        "hook_title": False, "progress_bar": False, "slow_push": True,
        "frame": "frame45", "title_kind": "spaced", "intro": 0.6, "outro": 1.2,
        "captions": False, "caption": {"words_per_line": 5, "size": 70, "upper": True, "box": False,
                                       "position": "lower", "color": "#FFFFFF", "outline": 1},
    },
    "moody_editorial": {
        "tags": "moody, dark, emotional, deep talk, sad, reflective, night",
        "label": "Moody Editorial", "desc": "Dark teal-orange grade, 4:5 frame, quiet subtitle captions, emotional music, long fade",
        "edit_style": "moody", "dead_air": "auto", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "cinematic", "music_volume": 10, "animation": "subtitle", "font": "Poppins SemiBold",
        "hook_title": False, "progress_bar": False, "frame": "frame45", "title_kind": "open_box", "outro": 1.2,
        "captions": True, "caption": {"words_per_line": 6, "size": 84, "upper": False, "box": False,
                                      "position": "lower", "color": "#F2F2F2", "outline": 2},
    },
    "bold_creator": {
        "punch": True,
        "tags": "bold creator, mrbeast, big captions, youtube shorts, viral, energetic, creator",
        "label": "Bold Creator", "desc": "Full screen, huge uppercase pop-in captions with colour highlight, punch-ins, whooshes, upbeat music",
        "edit_style": "high_energy", "dead_air": "tight", "jump_zoom": 1.0, "sfx": "punchy",
        "music_mood": "upbeat", "music_volume": 9, "animation": "pop_words", "font": "Anton",
        "hook_title": False, "progress_bar": True, "highlight": "#FFE600",
        "frame": "fill", "title_kind": "big_hook", "outro": 0.3,
        "captions": True, "caption": {"words_per_line": 2, "size": 112, "upper": True, "box": False,
                                      "position": "lower", "color": "#FFFFFF", "outline": 6},
    },
    "raw": {
        "tags": "raw, no edit, original, plain",
        "label": "Raw (original voice only)", "desc": "No trims, no effects, no music - just the reframed clip with captions",
        "edit_style": "raw", "dead_air": "off", "jump_zoom": 1.0, "sfx": "off",
        "music_mood": "none", "music_volume": 0, "animation": "static", "font": "Poppins ExtraBold",
        "hook_title": False, "progress_bar": False,
        "frame": "fill", "title_kind": "none", "outro": 0.3,
        "captions": True, "caption": {"words_per_line": 4, "size": 82, "upper": False, "box": False,
                                      "position": "lower", "color": "#FFFFFF", "outline": 3},
    },
}

MUSIC_MOODS = {          # mood -> built-in original track
    "none": None,
    "calm": "builtin:calm_piano_pad",
    "lofi": "builtin:lofi_chill",
    "upbeat": "builtin:upbeat_pulse",
    "cinematic": "builtin:cinematic_rise",
}


def resolve(opts: dict) -> dict:
    """Merge a preset with explicit user choices (explicit wins)."""
    base = dict(PRESETS.get(opts.get("preset") or "podcast_pro", PRESETS["podcast_pro"]))
    for k, v in opts.items():
        if v is not None and v != "":
            base[k] = v
    if "music" not in opts or opts.get("music") in (None, ""):
        base["music"] = MUSIC_MOODS.get(base.get("music_mood", "none"))
    if base.get("music") == "none":
        base["music"] = None
    return base


# ------------------------------------------------------------------ jump cuts ----
def keep_ranges(words: list[dict], start: float, end: float, max_gap: float | None,
                pad: float = 0.10, min_piece: float = 0.30) -> list[tuple[float, float]]:
    """Clip-relative ranges to keep. Silences longer than max_gap between words are cut,
    leaving `pad` seconds of air on both sides so speech never sounds clipped."""
    dur = end - start
    if not max_gap:
        return [(0.0, dur)]
    ws = sorted((w for w in words if w["e"] > start and w["s"] < end), key=lambda w: w["s"])
    if not ws:
        return [(0.0, dur)]
    ranges: list[list[float]] = []
    cur_a = max(0.0, ws[0]["s"] - start - pad)
    cur_b = min(dur, ws[0]["e"] - start + pad)
    for w in ws[1:]:
        s, e = w["s"] - start, w["e"] - start
        if s - (cur_b - pad) > max_gap:
            ranges.append([cur_a, cur_b])
            cur_a = max(cur_b, s - pad)
        cur_b = min(dur, max(cur_b, e + pad))
    ranges.append([cur_a, min(dur, cur_b + 0.15)])
    out: list[list[float]] = []
    for a, b in ranges:
        if b - a < min_piece and out:
            out[-1][1] = b
        else:
            out.append([a, b])
    return [(round(a, 3), round(b, 3)) for a, b in out if b - a > 0.05]


def silences(video: str | Path, start: float, end: float, frame: float = 0.02) -> list[tuple[float, float]]:
    """Silent stretches (clip-relative) measured on the actual audio - word timestamps
    from Whisper stretch over pauses, so they cannot be trusted for dead air."""
    import subprocess

    import numpy as np
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}", "-i", str(video),
           "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"]
    raw = subprocess.run(cmd, capture_output=True).stdout
    x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768.0
    hop = int(16000 * frame)
    if len(x) < hop * 5:
        return []
    n = len(x) // hop
    rms = np.sqrt(np.mean(x[: n * hop].reshape(n, hop) ** 2, axis=1) + 1e-12)
    db = 20 * np.log10(rms)
    speech = np.percentile(db, 75)
    floor = np.percentile(db, 8)
    thr = max(floor + 0.35 * (speech - floor), speech - 24.0)
    quiet = db < thr
    # smooth: a quiet run must be quiet; ignore 1-frame blips of noise
    out, i = [], 0
    while i < n:
        if quiet[i]:
            j = i
            while j < n and (quiet[j] or (j + 1 < n and quiet[j + 1] and not quiet[j] and j - i > 2)):
                j += 1
            out.append((round(i * frame, 3), round(j * frame, 3)))
            i = j
        else:
            i += 1
    return out


MAX_CUTS_PER_MIN = 3     # more than this and a talk starts to feel chopped up


def keep_from_silences(sil: list[tuple[float, float]], dur: float, max_gap: float | None,
                       pad: float = 0.25, min_piece: float = 2.0) -> list[tuple[float, float]]:
    """Cut silences longer than max_gap, leaving `pad` of air on each side. Only the longest
    pauses are cut (max MAX_CUTS_PER_MIN per minute) and no kept piece is shorter than
    `min_piece` - so a long clip never turns into a string of jump cuts."""
    if not max_gap:
        return [(0.0, dur)]
    long_ = sorted((x for x in sil if x[1] - x[0] > max_gap), key=lambda x: x[0] - x[1])
    allowed = max(1, int(round(dur / 60.0 * MAX_CUTS_PER_MIN)))
    cuts = sorted((a + pad, b - pad) for a, b in long_[:allowed])
    keep, t = [], 0.0
    for a, b in cuts:
        if a - t > 0.02:
            keep.append([t, a])
        t = b
    if dur - t > 0.02:
        keep.append([t, dur])
    out: list[list[float]] = []
    for a, b in keep:
        if out and b - a < min_piece:
            out[-1][1] = b
        else:
            out.append([a, b])
    return [(round(a, 3), round(b, 3)) for a, b in out] or [(0.0, dur)]


def remap_time(t: float, keep: list[tuple[float, float]]) -> float | None:
    """Clip-relative source time -> output time (None if t falls in a removed gap)."""
    acc = 0.0
    for a, b in keep:
        if t < a:
            return None
        if t <= b:
            return acc + (t - a)
        acc += b - a
    return None


def remap_words(words: list[dict], start: float, end: float,
                keep: list[tuple[float, float]]) -> list[dict]:
    out = []
    for w in words:
        if w["e"] <= start or w["s"] >= end:
            continue
        s = remap_time(max(0.0, w["s"] - start), keep)
        e = remap_time(min(end - start, w["e"] - start), keep)
        if s is None and e is None:
            continue
        if s is None:
            s = max(0.0, e - (w["e"] - w["s"]))
        if e is None:
            e = s + (w["e"] - w["s"])
        out.append({**w, "s": round(s, 3), "e": round(max(e, s + 0.05), 3)})
    return out


def kept_duration(keep: list[tuple[float, float]]) -> float:
    return round(sum(b - a for a, b in keep), 3)


# ---------------------------------------------------------------- sound design ----
def sfx_events(changes: list[float], duration: float, level: str, hook: bool) -> list[dict]:
    """Where sound effects go (output timeline). Deliberately sparse: a soft swoosh as the
    hook title lands, and on at most two layout changes (single <-> split). Never on every
    cut - constant effects are what makes an edit sound cheap."""
    vol = SFX_LEVEL.get(level, 0.0)
    if vol <= 0:
        return []
    ev = []
    if hook:
        ev.append({"name": "whoosh", "t": 0.0, "vol": vol})
    last = 0.0
    for t in sorted(changes):
        if 2.0 < t < duration - 1.0 and t - last >= 6.0 and len(ev) < 3:
            ev.append({"name": "whoosh", "t": max(0.0, t - 0.25), "vol": vol * 0.8})
            last = t
    return ev


def sfx_path(name: str) -> Path:
    return SFX_DIR / f"{name}.wav"


# ------------------------------------------------------------- motion graphics ----
def _ass_t(t: float) -> str:
    h = int(t // 3600)
    m = int(t % 3600 // 60)
    s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


HOOK_STYLES = {"box": "Solid box", "outline": "White text, black outline", "colour": "Coloured text, outline",
               "minimal": "Small & minimal"}


def hook_title_ass(title: str, play_w: int, play_h: int, out_path: Path,
                   font: str = "Anton", accent: str = "#FF5900", show: float = 3.2,
                   text_color: str = "#FFFFFF", style: str = "box") -> Path:
    """Optional title card at the top of the first seconds (pop-in, hold, fade)."""
    from .captions import FONTS, hex_to_ass
    font = FONTS.get(font, font)
    words = (title or "").strip().upper().split()
    if not words:
        raise ValueError("empty title")
    if len(words) > 4:
        mid = (len(words) + 1) // 2
        text = " ".join(words[:mid]) + "\\N" + " ".join(words[mid:])
    else:
        text = " ".join(words)
    text = text.replace("{", "").replace("}", "")
    style = style if style in HOOK_STYLES else "box"
    size = int(play_w * (0.07 if style == "minimal" else 0.1))
    acc, txt = hex_to_ass(accent, 0), hex_to_ass(text_color, 0)
    black = "&H00000000"
    if style == "box":
        primary, outline_c, back, border, outline, shadow = txt, acc, acc, 3, 14, 0
    elif style == "outline":
        primary, outline_c, back, border, outline, shadow = txt, black, "&H80000000", 1, 6, 2
    elif style == "colour":
        primary, outline_c, back, border, outline, shadow = acc, black, "&H80000000", 1, 6, 2
    else:
        primary, outline_c, back, border, outline, shadow = txt, black, "&H90000000", 1, 3, 3
    margin = int(play_h * 0.1)
    ass = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {play_w}
PlayResY: {play_h}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Hook,{font},{size},{primary},{primary},{outline_c},{back},1,0,0,0,100,100,1,0,{border},{outline},{shadow},8,60,60,{margin},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
Dialogue: 1,{_ass_t(0.0)},{_ass_t(show)},Hook,,0,0,0,,{{\\fad(90,320)\\fscx62\\fscy62\\t(0,170,\\fscx108\\fscy108)\\t(170,300,\\fscx100\\fscy100)}}{text}
"""
    out_path = Path(out_path)
    out_path.write_text(ass, encoding="utf-8")
    return out_path


_TV_WORDS = re.compile(r"\b(episode|ep\s?\d|full episode|serial|scene|movie|film|sitcom|tmkoc|taarak|comedy show|"
                       r"kapil|web ?series|season|natak|drama)\b", re.I)


def content_kind(meta: dict | None) -> str:
    """Rough guess what the source is, so Auto picks a style that suits it."""
    meta = meta or {}
    w, h = meta.get("width") or 0, meta.get("height") or 0
    title = f"{meta.get('source_title') or ''} {meta.get('filename') or ''}"
    if _TV_WORDS.search(title) or (h and h <= 576) or (w and h and w / h < 1.45):
        return "tv"
    if re.search(r"\b(stream|live|gameplay|gaming|valorant|bgmi|pubg|free ?fire|gta|minecraft|fortnite|"
                 r"cod|warzone|twitch|kick|ishowspeed|kai cenat|xqc)\b", title, re.I):
        return "stream"
    if re.search(r"\b(motivation|motivational|discipline|goggins|mindset|gym|workout)\b", title, re.I):
        return "motivation"
    if re.search(r"\b(the office|brooklyn|friends|sitcom|scene|hera pheri|welcome|movie)\b", title, re.I):
        return "sitcom"
    if re.search(r"\b(vlog|travel|trip|tour)\b", title, re.I):
        return "vlog"
    if re.search(r"\b(documentary|explained|history|story of)\b", title, re.I):
        return "documentary"
    return "talk"


def auto_plan(topics: list[dict], video_minutes: float, meta: dict | None = None) -> dict:
    """'Auto' mode: choose how many / which topics and the edit, like an editor would."""
    n = max(1, min(8, round(video_minutes / 12) + 1))
    good = [t for t in sorted(topics, key=lambda t: -t["score"]) if t["score"] >= 55]
    chosen = (good or sorted(topics, key=lambda t: -t["score"]))[:n]
    energetic = sum(1 for t in chosen if (t.get("breakdown") or {}).get("factors", {}).get("energy", 0) >= 9)
    kind = content_kind(meta)
    if kind == "tv":
        preset = "tv_clip"
    elif kind == "stream":
        preset = "stream_clip"
    elif kind in ("vlog", "documentary", "motivation", "sitcom"):
        preset = kind
    else:
        preset = "hormozi" if energetic > len(chosen) / 2 else "podcast_pro"
    return {"topic_ids": [t["id"] for t in chosen], "preset": preset, "aspect": "9:16",
            "framing": "auto", "reason": f"{len(chosen)} strongest topics (score >= 55), "
                                          f"{PRESETS[preset]['label']} edit"}


FILLERS = {"um", "umm", "uh", "uhh", "uhm", "hmm", "hm", "er", "erm", "ah", "aah", "mm", "mmm"}


def apply_cuts(keep: list[tuple[float, float]] | None, dur: float, cuts: list) -> list[tuple[float, float]] | None:
    """Remove the user's manual cut ranges (clip time, from the timeline editor) from `keep`."""
    spans = sorted((max(0.0, float(a)), min(dur, float(b))) for a, b in (cuts or []) if float(b) - float(a) >= 0.1)
    if not spans:
        return keep
    out = []
    for a, b in (keep or [(0.0, dur)]):
        cur = a
        for s_, e_ in spans:
            if e_ <= cur or s_ >= b:
                continue
            if s_ - cur > 0.15:
                out.append((cur, s_))
            cur = max(cur, e_)
        if b - cur > 0.15:
            out.append((cur, b))
    return out or keep


def cut_fillers(keep: list[tuple[float, float]] | None, words: list[dict], start: float, end: float
                ) -> list[tuple[float, float]] | None:
    """Remove filler sounds (um, uh, hmm) from the kept ranges (clip time)."""
    spans = []
    for w in words or []:
        k = "".join(ch for ch in (w.get("w") or "").lower() if ch.isalpha())
        if k in FILLERS and w["s"] >= start and w["e"] <= end and w["e"] - w["s"] >= 0.15:
            spans.append((w["s"] - start - 0.03, w["e"] - start + 0.03))
    if not spans:
        return keep
    out = []
    for a, b in (keep or [(0.0, end - start)]):
        cur = a
        for s_, e_ in sorted(spans):
            if e_ <= cur or s_ >= b:
                continue
            if s_ - cur > 0.3:
                out.append((cur, s_))
            cur = max(cur, e_)
        if b - cur > 0.3:
            out.append((cur, b))
    return out or keep


def text_layers_ass(layers: list[dict], play_w: int, play_h: int, total: float, out_path: Path,
                    font: str = "Poppins ExtraBold") -> Path | None:
    """Editor text layers (title, CTA, labels): each with its own time range, position and colour."""
    from .captions import FONTS, hex_to_ass
    if not layers:
        return None
    font = FONTS.get(font, font)
    styles, events = [], []
    for i, t in enumerate(layers):
        a = max(0.0, min(float(t.get("start") or 0), max(0.0, total - 0.2)))
        b = float(t.get("end") or total)
        b = min(total, b if b > a else total)
        size = int(play_w * int(t.get("size") or 72) / 1080)
        col = hex_to_ass(t.get("color") or "#FFFFFF", 0)
        if t.get("bg"):
            back, border, outline, shadow = hex_to_ass(t["bg"], 0), 3, max(8, size // 6), 0
            oc = back
        else:
            back, border, outline, shadow, oc = "&H80000000", 1, max(3, size // 16), 2, "&H00000000"
        align = {"top": 8, "middle": 5, "bottom": 2}.get(t.get("pos"), 8)
        mv = int(play_h * (0.12 if t.get("pos") == "top" else 0.2 if t.get("pos") == "bottom" else 0))
        styles.append(f"Style: TL{i},{font},{size},{col},{col},{oc},{back},1,0,0,0,100,100,0,0,"
                      f"{border},{outline},{shadow},{align},70,70,{mv},1")
        text = str(t.get("text") or "").replace("{", "").replace("}", "").replace("\n", "\\N")
        tag = "\\fad(150,200)"
        if t.get("x") is not None and t.get("y") is not None:       # dragged on the editor canvas
            tag += f"\\an5\\pos({int(float(t['x']) * play_w)},{int(float(t['y']) * play_h)})"
        events.append(f"Dialogue: 2,{_ass_t(a)},{_ass_t(b)},TL{i},,0,0,0,,{{{tag}}}{text}")
    ass = (f"[Script Info]\nScriptType: v4.00+\nPlayResX: {play_w}\nPlayResY: {play_h}\nWrapStyle: 0\n\n"
           "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, "
           "BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, "
           "Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n" + "\n".join(styles) +
           "\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n" +
           "\n".join(events) + "\n")
    out_path = Path(out_path)
    out_path.write_text(ass, encoding="utf-8")
    return out_path
