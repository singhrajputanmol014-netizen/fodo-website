"""AI Editorial Director (v1) - decides HOW a clip should be edited before it is rendered.

It reads the clip's words, timing and content type and writes an explicit, reproducible editing
plan: every decision has a value and a reason. The renderer then follows the plan; the plan is
saved with the export so the same inputs always give the same edit.

v1 decisions (all deterministic, no randomness):
  * opening   - start on a real sentence start, skip a weak lead-in ("so", "um", "and yeah")
                and dead air before the first word
  * ending    - finish the sentence / pay-off line, then a short breath (settle_end)
  * pacing    - how much silence to cut, from the measured speaking rate and the content type
  * music     - whether a music bed suits this footage (TV/gaming audio, dense speech)
  * captions  - whether captions help, given language and speech density
  * zoom      - punch-ins only where the style and the source resolution allow it
  * story     - does the clip hold one complete thought (starts and ends on sentence borders)
"""
from __future__ import annotations

import hashlib
import json

VERSION = 2
END_MARKS = (".", "?", "!", "।", "...")
WEAK_OPENERS = {"so", "and", "but", "um", "uh", "umm", "uhh", "yeah", "like", "okay", "ok", "right",
                "hmm", "well", "also", "then", "basically", "actually", "toh", "aur", "matlab", "haan"}
FILLERS = {"um", "umm", "uh", "uhh", "uhm", "hmm", "hm", "er", "erm", "ah", "mm"}


def _txt(w: dict) -> str:
    return (w.get("w") or "").strip()


def _ends(w: dict) -> bool:
    return _txt(w).endswith(END_MARKS)


def _norm(w: dict) -> str:
    return _txt(w).lower().strip(".,!?;:\"'")


def _with_pause_marks(words: list[dict]) -> list[dict]:
    """Some transcripts (fast model, word timestamps) carry no punctuation at all. Then a pause
    of 0.6 s+ is the best sentence border we have: mark it so the sentence logic still works."""
    if not words:
        return words
    punct = sum(1 for w in words if _ends(w)) / len(words)
    if punct >= 0.02:
        return words
    out = []
    for a, b in zip(words, words[1:] + [None]):
        if b is None or b["s"] - a["e"] >= 0.6:
            a = {**a, "w": _txt(a) + "."}
        out.append(a)
    return out


def settle_start(words: list[dict], start: float, end: float, max_fwd: float = 4.0,
                 max_back: float = 3.0) -> tuple[float, str]:
    """Move the start onto the beginning of a sentence. Returns (new_start, reason)."""
    words = _with_pause_marks([w for w in words if w["e"] > start - 60 and w["s"] < end + 10])
    ws = [w for w in words if w["e"] > start - max_back and w["s"] < end]
    if not ws:
        return start, "no words - start unchanged"
    inside = [w for w in ws if w["s"] >= start - 0.05]
    if not inside:
        return start, "no words inside the clip - start unchanged"
    first = inside[0]
    idx = ws.index(first)
    prev = ws[idx - 1] if idx > 0 else None
    # a word cut in half at the start -> include it
    cut = next((w for w in ws if w["s"] < start < w["e"]), None)
    if cut is not None:
        first, idx = cut, ws.index(cut)
        prev = ws[idx - 1] if idx > 0 else None
        reason = f"first word \"{_txt(cut)}\" was cut in half - start moved to it"
    sentence_start = prev is None or _ends(prev) or (first["s"] - prev["e"]) > 1.2
    if cut is None:
        reason = ""
    if not sentence_start:
        # forward: next sentence start within max_fwd, keeping most of the clip
        fwd = None
        for j in range(idx, len(ws) - 1):
            if ws[j + 1]["s"] - start > max_fwd:
                break
            if _ends(ws[j]):
                fwd = ws[j + 1]
                break
        back = None
        for j in range(idx - 1, -1, -1):
            if start - ws[j]["s"] > max_back:
                break
            if (j == 0 and ws[0] is words[0]) or (j > 0 and _ends(ws[j - 1])):
                back = ws[j]
                break
        if fwd is not None and (end - fwd["s"]) >= 0.8 * (end - start):
            first, reason = fwd, f"clip began mid-sentence - moved forward {fwd['s'] - start:.1f}s to the next sentence"
        elif back is not None:
            first, reason = back, f"clip began mid-sentence - moved back {start - back['s']:.1f}s to the sentence start"
        else:
            reason = (reason + "; " if reason else "") + \
                "begins mid-sentence and no sentence start within 4 s - kept"
    # weak lead-in words / fillers at the very start (max 3 words, max 1.5 s)
    k = ws.index(first)
    skipped = []
    while k < len(ws) - 1 and len(skipped) < 3 and _norm(ws[k]) in WEAK_OPENERS \
            and ws[k + 1]["s"] - first["s"] <= 1.5 and not _ends(ws[k]):
        skipped.append(_txt(ws[k]))
        k += 1
    if skipped and _norm(ws[k]) not in FILLERS:
        first = ws[k]
        reason = (reason + "; " if reason else "") + f"skipped weak lead-in \"{' '.join(skipped)}\""
    new_start = max(0.0, first["s"] - 0.12)          # a breath before the first syllable
    if not reason:
        reason = "already on a sentence start" if abs(new_start - start) < 0.3 else \
                 f"trimmed {new_start - start:.1f}s of silence before the first word"
    return round(new_start, 3), reason


def _speech_stats(words: list[dict], start: float, end: float) -> dict:
    ws = [w for w in words if w["s"] >= start and w["e"] <= end]
    dur = max(0.1, end - start)
    talk = sum(w["e"] - w["s"] for w in ws)
    gaps = [b["s"] - a["e"] for a, b in zip(ws, ws[1:])]
    return {"words": len(ws), "wpm": round(len(ws) / dur * 60), "speech_share": round(talk / dur, 2),
            "long_pauses": sum(1 for g in gaps if g > 1.0),
            "sentences": sum(1 for w in ws if _ends(w))}


def audio_energy(video_path: str, start: float, end: float) -> dict | None:
    """Loudness curve of the clip's sound (0.25 s windows): where the voice gets intense
    (emotional peak), how strong the first 3 s are vs the rest (hook energy)."""
    import subprocess
    import numpy as np
    try:
        r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{max(0, start):.3f}", "-t", f"{end - start:.3f}",
                            "-i", str(video_path), "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
                           capture_output=True, timeout=120)
    except (OSError, subprocess.SubprocessError):
        return None
    pcm = np.frombuffer(r.stdout, np.int16).astype(np.float32) / 32768.0
    win = 4000
    n = pcm.size // win
    if n < 8:
        return None
    db = 20 * np.log10(np.sqrt((pcm[: n * win].reshape(n, win) ** 2).mean(axis=1)) + 1e-6)
    sm = np.convolve(np.pad(db, (2, 1), mode="edge"), np.ones(4) / 4, mode="valid")   # 1 s smoothing
    voiced = sm[sm > -45]
    if voiced.size < 4:
        return None
    med = float(np.median(voiced))
    k = int(np.argmax(sm))
    head = float(np.mean(sm[: min(12, n)]))
    return {"median_db": round(med, 1), "peak_db": round(float(sm[k]), 1), "peak_t": round(start + k * 0.25, 2),
            "peak_rise_db": round(float(sm[k]) - med, 1), "hook_db": round(head - med, 1),
            "dynamic_db": round(float(np.percentile(voiced, 90) - np.percentile(voiced, 10)), 1)}


def plan(words: list[dict] | None, start: float, end: float, p: dict, kind: str,
         meta: dict | None = None, video_path: str | None = None) -> dict:
    """Editing plan for one clip. `p` = export params (style already merged), `kind` from
    edit.content_kind (talk/tv/stream/motivation/sitcom/vlog/documentary)."""
    words = _with_pause_marks([w for w in (words or []) if w["e"] > start - 60 and w["s"] < end + 10])
    meta = meta or {}
    decisions: list[dict] = []
    overrides: dict = {}

    def decide(what, choice, why, applied=True):
        decisions.append({"what": what, "choice": choice, "why": why, "applied": applied})

    st = _speech_stats(words, start, end)
    # 1) opening
    if words:
        ns, why = settle_start(words, start, end)
        if abs(ns - start) >= 0.05:
            overrides["start"] = ns
        decide("opening", f"{ns:.2f}s (was {start:.2f}s)", why, abs(ns - start) >= 0.05)
    # 2) ending is settled by the renderer (settle_end): record the rule
    decide("ending", "finish the sentence + pay-off line, then 0.45 s breath",
           "an ending cut on the last syllable feels wrong; the line after a statement is often the punchline")
    # 3) pacing / dead air
    da = p.get("dead_air", "off")
    if da == "auto":
        if kind in ("tv", "sitcom", "stream"):
            choice, why = "off", f"{kind} footage: pauses are comic timing / gameplay - keep them"
        elif st["wpm"] >= 165:
            choice, why = "light", f"fast speaker ({st['wpm']} wpm) - only cut long dead air"
        elif st["wpm"] < 120 or st["long_pauses"] >= 4:
            choice, why = "normal", f"slow speech ({st['wpm']} wpm, {st['long_pauses']} pauses >1 s) - tighten"
        else:
            choice, why = "light", f"normal pace ({st['wpm']} wpm)"
        overrides["dead_air"] = choice
        decide("pacing", f"dead-air cut: {choice}", why)
    else:
        decide("pacing", f"dead-air cut: {da} (style/user choice)",
               f"speech {st['wpm']} wpm, {st['long_pauses']} pauses >1 s", applied=False)
    # 4) music
    music = p.get("music")
    if music and kind in ("tv", "sitcom", "stream"):
        decide("music", "advise: no music bed",
               f"{kind} footage has its own sound (laughs, game audio) - a bed can clash", applied=False)
    elif music and st["speech_share"] > 0.85:
        decide("music", "keep bed low and ducked", f"speech fills {st['speech_share']*100:.0f}% of the clip",
               applied=False)
    else:
        decide("music", "as chosen" if music else "none", "no conflict found", applied=False)
    # 5) captions
    if p.get("captions", True):
        decide("captions", "on", f"{st['words']} words ({st['wpm']} wpm) - most viewers watch muted")
    else:
        decide("captions", "off", "turned off in the style / by the user", applied=False)
    # 6) zoom
    src_h = int(meta.get("height") or 0)
    if p.get("punch_zoom") and src_h and src_h < 1080:
        overrides["punch_zoom"] = False
        decide("zoom", "punch-ins off", f"source is only {src_h}p - zooming would blur faces")
    else:
        decide("zoom", "punch-ins " + ("on" if p.get("punch_zoom") else "off"),
               "style choice; total enlargement capped at 2.15x of the source", applied=False)
    # 7) energy: emotional peak + hook strength (measured on the clip's audio)
    s_eff = overrides.get("start", start)          # measure the clip as it will be rendered
    en = audio_energy(video_path, s_eff, end) if video_path else None
    if en:
        rel = en["peak_t"] - s_eff
        if en["peak_rise_db"] >= 6:
            decide("emotional peak", f"{en['peak_t']:.1f}s ({rel:.0f}s into the clip)",
                   f"voice {en['peak_rise_db']:+.0f} dB above its normal level - the most intense moment",
                   applied=False)
        if en["hook_db"] < -3:
            tip = (f"; the strongest moment is at {rel:.0f}s - consider starting closer to it" if rel > 4
                   else " (pauses or a quiet lead-in)")
            decide("hook", "weak opening energy",
                   f"first 3 s are {abs(en['hook_db']):.0f} dB quieter than the clip{tip}", applied=False)
        else:
            decide("hook", "opening energy OK", f"first 3 s at {en['hook_db']:+.0f} dB vs the clip average",
                   applied=False)
        if en["dynamic_db"] > 22 and p.get("music"):
            decide("mix", "keep ducking on", f"voice level swings {en['dynamic_db']:.0f} dB - music must step back "
                   "under loud parts", applied=False)
    # 8) story completeness
    s0 = overrides.get("start", start)
    inside = [w for w in words if w["s"] >= s0 - 0.05 and w["e"] <= end + 3.5]
    complete = bool(inside) and st["sentences"] >= 1
    decide("story", "complete thought" if complete else "fragment",
           f"{st['sentences']} sentence ends inside the clip" if complete else
           "no sentence ends inside the clip - it may feel cut", applied=False)

    inputs = {"start": start, "end": end, "kind": kind, "n_words": len(words),
              "style": p.get("preset") or p.get("style_preset"), "dead_air": da}
    digest = hashlib.sha1(json.dumps([inputs, [(w["s"], w["e"], w.get("w")) for w in words
                                              if start - 5 <= w["s"] <= end + 5]],
                                     sort_keys=True).encode()).hexdigest()[:12]
    return {"version": VERSION, "inputs": inputs, "inputs_hash": digest, "speech": st, "energy": en,
            "decisions": decisions, "overrides": overrides}
