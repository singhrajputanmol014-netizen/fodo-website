"""Smart scans of long videos (no download). Each scan runs in its own light thread (network only, no GPU),
so it never waits behind renders. Stored in storage/scans/<id>.json (the transcript can be a few MB)."""
from __future__ import annotations

import json
import logging
import threading
import time
import uuid

from .config import STORAGE_DIR

log = logging.getLogger("clipforge.scans")
DIR = STORAGE_DIR / "scans"
_lock = threading.Lock()


def _path(sid: str):
    return DIR / f"{sid}.json"


def get(sid: str, words: bool = False) -> dict | None:
    if not (len(sid) == 12 and sid.isalnum()):
        return None
    try:
        d = json.loads(_path(sid).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not words:
        d.pop("words", None)
    return d


def _save(d: dict) -> None:
    DIR.mkdir(parents=True, exist_ok=True)
    tmp = _path(d["id"]).with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    tmp.replace(_path(d["id"]))


def _update(sid: str, **kw) -> None:
    with _lock:
        d = get(sid, words=True) or {"id": sid}
        d.update(kw)
        _save(d)


def list_all() -> list[dict]:
    out = []
    for f in DIR.glob("*.json") if DIR.exists() else []:
        d = get(f.stem)
        if d:
            d.pop("candidates", None)
            d.pop("heatmap", None)
            d.pop("chapters", None)
            out.append(d)
    return sorted(out, key=lambda d: d.get("created", 0), reverse=True)


def delete(sid: str) -> bool:
    p = _path(sid)
    if get(sid) is None:
        return False
    p.unlink(missing_ok=True)
    return True


def start(url: str, user_id: str, project_id: str, mode: str = "auto", sid: str | None = None,
          hours: float = 4.0) -> dict:
    old = get(sid) if sid else None
    sid = sid or uuid.uuid4().hex[:12]
    d = {"id": sid, "url": url, "user_id": user_id, "project_id": project_id, "status": "scanning", "mode": mode,
         "hours": hours,
         "stage": "Starting", "progress": 0.0, "created": int(time.time()),
         "fetched": (old or {}).get("fetched") or [], "title": (old or {}).get("title")}
    with _lock:
        _save(d)

    def run():
        from .config import WORK_DIR
        from .pipeline import smart_scan
        prog = lambda f, s="": _update(sid, progress=round(f, 2), stage=s)   # noqa: E731
        try:
            if mode == "rewind":
                from .pipeline import live_rewind
                r = live_rewind.scan(url, hours, WORK_DIR / f"scan_{sid}", prog)
            else:
                try:
                    r = smart_scan.scan(url, progress=prog, mode=mode, work=WORK_DIR / f"scan_{sid}")
                except smart_scan.LiveNow:
                    # still live: scan the hours that already went out (sound), fetch only chosen parts
                    from .pipeline import live_rewind
                    _update(sid, mode="rewind")
                    r = live_rewind.scan(url, hours, WORK_DIR / f"scan_{sid}", prog)
            _update(sid, status="done", stage="Scan done", progress=1.0, **r)
            log.info("scan %s: %s - %d candidates (%s)", sid, r.get("title"), len(r["candidates"]), r["captions"])
        except Exception as e:  # noqa: BLE001
            log.exception("scan %s failed", sid)
            msg = str(e).replace("ERROR: ", "")
            from .pipeline.url_import import BOT_MSG, is_bot_check, is_login_wall
            if is_bot_check(msg) or msg.startswith("YouTube asked this PC"):
                msg = BOT_MSG.replace("then tries again by itself in 10 minutes", "then gave up - press Scan again in 10-30 minutes")
            elif is_login_wall(msg):
                msg = "This video needs a login (private / members-only / age-restricted)."
            _update(sid, status="failed", stage=msg[:300])

    threading.Thread(target=run, daemon=True, name=f"scan-{sid}").start()
    return d
