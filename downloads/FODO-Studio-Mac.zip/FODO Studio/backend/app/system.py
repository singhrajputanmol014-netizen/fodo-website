"""Hardware & capability detection, storage usage, cache cleanup."""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
from pathlib import Path

from .config import EXPORTS_DIR, STORAGE_DIR, UPLOADS_DIR, WORK_DIR


def _run(cmd: list[str]) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=10).stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""


def ram_gb() -> float | None:
    try:
        import ctypes  # Windows
        if os.name == "nt":
            class MEM(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MEM(); m.dwLength = ctypes.sizeof(MEM)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return round(m.ullTotalPhys / 1e9, 1)
        if platform.system() == "Darwin":                 # macOS has no SC_PHYS_PAGES
            return round(int(_run(["sysctl", "-n", "hw.memsize"]).strip() or 0) / 1e9, 1) or None
        return round(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") / 1e9, 1)
    except Exception:  # noqa: BLE001
        return None


_HW_CACHE: dict[str, bool] = {}


def _hw_encoder_works(enc: str) -> bool:
    """Being compiled into FFmpeg != usable. Encode 5 black frames to prove it."""
    if enc not in _HW_CACHE:
        try:
            r = subprocess.run(
                ["ffmpeg", "-v", "error", "-f", "lavfi", "-i", "color=black:s=256x256:d=0.2",
                 "-c:v", enc, "-f", "null", "-"], capture_output=True, timeout=20)
            _HW_CACHE[enc] = r.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            _HW_CACHE[enc] = False
    return _HW_CACHE[enc]


def detect_hardware() -> dict:
    encoders_raw = _run(["ffmpeg", "-hide_banner", "-encoders"])
    hw = [e for e in ("h264_nvenc", "hevc_nvenc", "h264_qsv", "hevc_qsv", "h264_amf",
                      "h264_videotoolbox", "libx264", "libx265", "libaom-av1", "libsvtav1")
          if e in encoders_raw]
    hw = [e for e in hw if e.startswith("lib") or _hw_encoder_works(e)]
    nvidia = _run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"]).strip()
    cuda = False
    try:
        import ctranslate2
        cuda = ctranslate2.get_cuda_device_count() > 0
    except Exception:  # noqa: BLE001
        pass
    du = shutil.disk_usage(STORAGE_DIR)
    ffv = _run(["ffmpeg", "-version"]).splitlines()
    return {
        "os": f"{platform.system()} {platform.release()}",
        "cpu": platform.processor() or platform.machine(),
        "cpu_cores": os.cpu_count(),
        "ram_gb": ram_gb(),
        "gpu": nvidia or None,
        "whisper_cuda": cuda,
        "ffmpeg": ffv[0] if ffv else None,
        "encoders": hw,
        "hardware_encoders": [e for e in hw if any(x in e for x in ("nvenc", "qsv", "amf", "videotoolbox"))],
        "disk_free_gb": round(du.free / 1e9, 1),
        "recommended_profile": "quality" if (nvidia or (os.cpu_count() or 2) >= 8) else "balanced",
    }


def _dir_size(p: Path) -> int:
    return sum(f.stat().st_size for f in p.rglob("*") if f.is_file()) if p.exists() else 0


def storage_usage() -> dict:
    return {k: round(_dir_size(d) / 1e6, 1) for k, d in
            {"uploads_mb": UPLOADS_DIR, "work_cache_mb": WORK_DIR, "exports_mb": EXPORTS_DIR}.items()}


def clear_cache() -> float:
    """Delete regenerable intermediates (audio wav, proxies, caption files). Never uploads/exports."""
    freed = _dir_size(WORK_DIR)
    for child in WORK_DIR.iterdir():
        if child.is_dir():
            shutil.rmtree(child, ignore_errors=True)
        else:
            child.unlink(missing_ok=True)
    return round(freed / 1e6, 1)
