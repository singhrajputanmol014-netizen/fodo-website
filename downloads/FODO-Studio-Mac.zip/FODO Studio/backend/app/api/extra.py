"""Phase 5-7 API: templates, chat editor, undo, batch export, URL import,
search, analytics, hardware, model management, cache."""
from __future__ import annotations

import re
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import func
from sqlalchemy.orm import Session as DBSession

from ..auth import audit, current_user, require_role
from ..config import ASPECT_RATIOS, MAX_UPLOAD_MB, PERFORMANCE_PROFILES, UPLOADS_DIR, WORK_DIR, WHISPER_MODEL
from ..database import get_db
from ..jobs import enqueue
from ..models import Clip, EditHistory, Export, Job, Project, Template, Topic, User, Video
from ..pipeline import audio as audio_mod
from ..pipeline import chat_editor, llm
from ..pipeline.captions import CAPTION_STYLES
from ..pipeline.metadata import extract_metadata
from ..pipeline.scoring import HOOK_PATTERNS
from ..pipeline.templates import BUILTIN_TEMPLATES, TEMPLATE_KEYS
from ..pipeline.transcribe import words_to_sentences
from ..pipeline.url_import import UnsafeURL, validate_url
from ..system import clear_cache, detect_hardware, storage_usage


def _power_profile() -> str:
    from ..power import export_profile
    return export_profile()


router = APIRouter(prefix="/api")


# ------------------------------------------------------------- helpers ----
def snapshot(db: DBSession, clip: Clip, source: str, desc: str) -> None:
    db.add(EditHistory(clip_id=clip.id, source=source, description=desc[:500], before={
        "start": clip.start, "end": clip.end, "title": clip.title, "settings": dict(clip.settings)}))


def _get_clip(db: DBSession, clip_id: str) -> Clip:
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    return c


def _resolve_template(db: DBSession, key: str) -> dict:
    if key in BUILTIN_TEMPLATES:
        return BUILTIN_TEMPLATES[key]
    t = db.get(Template, key)
    if t is None:
        raise HTTPException(404, "Template not found")
    return t.config


def _apply_template_to(clip: Clip, cfg: dict) -> None:
    s = dict(clip.settings)
    for k in TEMPLATE_KEYS:
        if k in cfg:
            s[k] = cfg[k]
    clip.settings = s


@router.get("/caption_styles")
def caption_styles(user: User = Depends(current_user)):
    return CAPTION_STYLES


# ----------------------------------------------------------- templates ----
@router.get("/templates")
def list_templates(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    custom = [{"id": t.id, "label": t.name, "custom": True, **t.config}
              for t in db.query(Template).order_by(Template.created_at.desc()).all()]
    builtin = [{"id": k, "custom": False, **v} for k, v in BUILTIN_TEMPLATES.items()]
    return {"builtin": builtin, "custom": custom, "caption_styles": list(CAPTION_STYLES)}


@router.post("/templates")
def save_template(payload: dict, user: User = Depends(require_role("editor")),
                  db: DBSession = Depends(get_db)):
    name = str(payload.get("name", "")).strip()[:100]
    if not name:
        raise HTTPException(400, "Name required")
    cfg = {k: payload[k] for k in TEMPLATE_KEYS if k in payload}
    if cfg.get("caption_style") not in CAPTION_STYLES:
        raise HTTPException(400, "Invalid caption_style")
    if cfg.get("aspect", "9:16") not in ASPECT_RATIOS:
        raise HTTPException(400, "Invalid aspect")
    if cfg.get("profile", "balanced") not in PERFORMANCE_PROFILES:
        raise HTTPException(400, "Invalid profile")
    if cfg.get("placement", "lower") not in ("lower", "middle"):
        raise HTTPException(400, "Invalid placement")
    t = Template(name=name, config=cfg, owner_id=user.id)
    db.add(t)
    db.commit()
    audit(db, user.id, "template.create", name)
    return {"id": t.id, "name": name, "config": cfg}


@router.delete("/templates/{tid}")
def delete_template(tid: str, user: User = Depends(require_role("editor")),
                    db: DBSession = Depends(get_db)):
    t = db.get(Template, tid)
    if t is None:
        raise HTTPException(404, "Not found")
    db.delete(t)
    db.commit()
    return {"ok": True}


@router.post("/clips/{clip_id}/apply_template")
def apply_template(clip_id: str, payload: dict, user: User = Depends(require_role("editor")),
                   db: DBSession = Depends(get_db)):
    c = _get_clip(db, clip_id)
    cfg = _resolve_template(db, str(payload.get("template", "")))
    snapshot(db, c, "manual", f"apply template {payload.get('template')}")
    _apply_template_to(c, cfg)
    db.commit()
    return {"settings": c.settings}


# ---------------------------------------------------------------- undo ----
@router.post("/clips/{clip_id}/undo")
def undo(clip_id: str, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    c = _get_clip(db, clip_id)
    h = (db.query(EditHistory).filter_by(clip_id=clip_id)
         .order_by(EditHistory.id.desc()).first())
    if h is None:
        raise HTTPException(400, "Nothing to undo")
    b = h.before
    c.start, c.end, c.title, c.settings = b["start"], b["end"], b["title"], b["settings"]
    db.delete(h)
    db.commit()
    return {"undone": h.description, "start": c.start, "end": c.end, "settings": c.settings}


@router.get("/clips/{clip_id}/history")
def history(clip_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    rows = db.query(EditHistory).filter_by(clip_id=clip_id).order_by(EditHistory.id.desc()).all()
    return [{"id": r.id, "source": r.source, "description": r.description,
             "at": r.created_at.isoformat()} for r in rows]


# ---------------------------------------------------------- chat editor ----
def _sentences(video: Video) -> list[dict]:
    return words_to_sentences(video.transcript or [])


def _hook_points(text: str) -> int:
    t = text.lower()
    return sum(p for pat, _, p in HOOK_PATTERNS if re.search(pat, t))


def _silences_for(video: Video) -> list[tuple[float, float]]:
    wav = WORK_DIR / video.id / "audio.wav"
    if not wav.exists():
        wav.parent.mkdir(parents=True, exist_ok=True)
        audio_mod.extract_wav(video.path, wav)
    return audio_mod.silence_regions(audio_mod.load_pcm(wav))


def _execute(db: DBSession, user: User, clip: Clip, actions: list[dict]) -> list[dict]:
    """Apply validated actions. Returns per-action results describing REAL state changes."""
    results: list[dict] = []
    video = clip.video
    changed = any(a["type"] not in ("find_clips", "suggest_hooks", "export") for a in actions)
    if changed:
        snapshot(db, clip, "chat", "; ".join(chat_editor.describe(a) for a in actions))
    for a in actions:
        ty = a["type"]
        before = {"start": clip.start, "end": clip.end, "settings": dict(clip.settings)}
        r: dict = {"action": a, "description": chat_editor.describe(a)}
        if ty == "set_aspect":
            clip.settings = {**clip.settings, "aspect": a["aspect"]}
        elif ty == "set_resolution":
            clip.settings = {**clip.settings, "resolution": a["resolution"]}
        elif ty == "set_caption_style":
            clip.settings = {**clip.settings, "caption_style": a["caption_style"]}
        elif ty == "set_profile":
            clip.settings = {**clip.settings, "profile": a["profile"]}
        elif ty == "apply_template":
            _apply_template_to(clip, BUILTIN_TEMPLATES[a["template"]])
        elif ty == "set_duration":
            ends = [s["e"] for s in _sentences(video) if s["e"] > clip.start + 2]
            if ends:
                target = clip.start + a["seconds"]
                clip.end = round(min(ends, key=lambda e: abs(e - target)) + 0.2, 3)
        elif ty == "trim_silence":
            s, e = clip.start, clip.end
            for lo, hi in _silences_for(video):
                if lo <= s < hi:
                    s = min(hi, e - 1)
                if lo < e <= hi:
                    e = max(lo, s + 1)
            clip.start, clip.end = round(s, 3), round(e, 3)
        elif ty == "find_clips":
            kw = {"funny": r"funn|laugh|joke|crazy|hilarious|insane", "question": r"\?",
                  "number": r"\d|percent|hundred|thousand|million",
                  "emotional": r"never|always|truth|secret|mistake|love|hate|fear"}.get(a["kind"])
            pool = sorted(video.clips, key=lambda c: -c.score)
            hits = [c for c in pool if kw and re.search(kw, c.text.lower())] if kw else pool
            r["clips"] = [{"id": c.id, "title": c.title, "score": c.score,
                           "start": c.start, "end": c.end} for c in hits[:5]]
            r["note"] = (f"{len(hits)} matching clip(s)" if kw else "Top-ranked clips")
            if kw and not hits:
                r["note"] = "No clips matched — keyword search is literal; try different words."
        elif ty == "suggest_hooks":
            sents = [s for s in _sentences(video) if clip.start - 30 <= s["s"] <= clip.end + 30]
            ranked = sorted(sents, key=lambda s: -_hook_points(s["text"]))[: a["count"]]
            r["hooks"] = [{"text": s["text"], "start": s["s"], "end": s["e"],
                           "hook_points": _hook_points(s["text"])} for s in ranked]
            r["note"] = "Verbatim lines from the video (no invented quotes). Set one as clip start to use it."
        elif ty == "export":
            st = clip.settings
            params = {"aspect": st.get("aspect", "9:16"), "caption_style": st.get("caption_style", "fodo_orange"),
                      "resolution": st.get("resolution", "1080p"), "profile": st.get("profile") or _power_profile(),
                      "placement": st.get("placement", "lower"),
                      "audio_normalize": st.get("audio_normalize", True), "captions": True,
                      "start": clip.start, "end": clip.end}
            exp = Export(clip_id=clip.id, params=params)
            db.add(exp)
            db.flush()
            r["export_id"] = exp.id
            r["_enqueue"] = True
        after = {"start": clip.start, "end": clip.end, "settings": dict(clip.settings)}
        r["state_changed"] = before != after
        results.append(r)
    db.commit()
    for r in results:
        if r.pop("_enqueue", False):
            r["job_id"] = enqueue("export", r["export_id"])
    audit(db, user.id, "chat.apply", "; ".join(r["description"] for r in results))
    return results


@router.post("/clips/{clip_id}/chat")
def chat(clip_id: str, payload: dict, user: User = Depends(require_role("editor")),
         db: DBSession = Depends(get_db)):
    """Two-step: {message} -> preview of actions; {actions, apply:true} -> executes."""
    clip = _get_clip(db, clip_id)
    if payload.get("apply"):
        actions = chat_editor.validate(payload.get("actions") or [])
        if not actions:
            raise HTTPException(400, "No valid actions to apply")
        results = _execute(db, user, clip, actions)
        return {"applied": True, "results": results,
                "clip": {"start": clip.start, "end": clip.end, "settings": clip.settings}}
    msg = str(payload.get("message", "")).strip()
    if not msg:
        raise HTTPException(400, "Empty message")
    interp = chat_editor.interpret(msg)
    preview = [{"action": a, "description": chat_editor.describe(a)} for a in interp["actions"]]
    readonly = all(a["type"] in ("find_clips", "suggest_hooks") for a in interp["actions"])
    if interp["actions"] and readonly:
        # Safe read-only queries run immediately.
        return {"applied": True, "results": _execute(db, user, clip, interp["actions"]),
                "source": interp["source"]}
    return {"applied": False, "preview": preview, "actions": interp["actions"],
            "source": interp["source"],
            "reply": ("Here's what I'll do — confirm to apply." if preview else
                      "I couldn't map that to an edit. Try e.g. 'make it a 9:16 reel with orange captions', "
                      "'remove silence', 'use the luxury brand preset', 'make a 4K landscape export'.")}


# --------------------------------------------------------------- topics ----
def _topic_json(t: Topic) -> dict:
    return {"id": t.id, "start": t.start, "end": t.end, "duration": round(t.end - t.start, 1),
            "title": t.title, "summary": t.summary, "keywords": t.keywords, "score": t.score,
            "breakdown": t.breakdown, "clip_id": t.clip_id, "text": t.text[:600],
            "created_at": t.created_at.isoformat() if t.created_at else None}


@router.get("/videos/{video_id}/topics")
def list_topics(video_id: str, q: str = "", user: User = Depends(current_user),
                db: DBSession = Depends(get_db)):
    rows = db.query(Topic).filter_by(video_id=video_id).order_by(Topic.score.desc()).all()
    if q.strip():
        terms = [t for t in re.findall(r"\w+", q.lower()) if len(t) > 2]
        def match(t: Topic) -> int:
            hay = f"{t.title} {t.summary} {' '.join(t.keywords or [])} {t.text}".lower()
            return sum(hay.count(x) for x in terms)
        rows = sorted((r for r in rows if match(r)), key=lambda r: -match(r))
    return [_topic_json(t) for t in rows]


def _make_clip_from_topic(db: DBSession, t: Topic, opts: dict) -> Clip:
    settings = {"aspect": opts.get("aspect", "9:16"),
                "caption_style": opts.get("caption_style", "fodo_orange"),
                "resolution": opts.get("resolution", "1080p"),
                "profile": opts.get("profile") or _power_profile(), "placement": "lower",
                "topic_id": t.id}
    for k in ("framing", "edit_style", "music", "music_volume", "duck", "caption_design"):
        if k in opts:
            settings[k] = opts[k]
    start, end = t.start, t.end
    target = {"30": 30.0, "60": 60.0, "90": 90.0, "180": 180.0}.get(str(opts.get("clip_length") or "full"))
    if target:
        from ..pipeline.topics import best_window
        v = db.get(Video, t.video_id)
        start, end, why = best_window(v.transcript or [], t.start, t.end, target)
        settings["window"] = why
    c = Clip(video_id=t.video_id, start=start, end=end, score=t.score,
             score_breakdown=t.breakdown, title=t.title, text=t.text, settings=settings)
    db.add(c)
    db.flush()
    t.clip_id = c.id
    return c


def queue_topic_clips(db: DBSession, rows: list, payload: dict, origin: str = "manual") -> list[dict]:
    """Create clips for the chosen topics and queue their renders (shared by the
    manual 'make clips' button and Auto mode)."""
    from ..main import _render_options
    if payload.get("aspect", "9:16") not in ASPECT_RATIOS:
        raise HTTPException(400, "Bad aspect")
    if payload.get("resolution", "1080p") not in ("720p", "1080p", "1440p", "2160p"):
        raise HTTPException(400, "Bad resolution")
    opts = {**payload, **_render_options(payload, {})}
    made = []
    for t in rows:
        c = _make_clip_from_topic(db, t, opts)
        try:                                              # v0.14 tracking: who picked it and when
            from ..tracking import now_iso as _now_iso
            c.settings = {**(c.settings or {}), "origin": origin, "selected_at": _now_iso()}
        except Exception:
            pass
        params = {"aspect": c.settings["aspect"], "caption_style": c.settings["caption_style"],
                  "resolution": c.settings["resolution"], "profile": c.settings["profile"],
                  "captions": bool(payload.get("captions", True)), "placement": "lower",
                  "audio_normalize": True, "start": c.start, "end": c.end,
                  **_render_options(payload, c.settings)}
        e = Export(clip_id=c.id, params=params)
        db.add(e)
        made.append((t, c, e))
    db.commit()
    return [{"topic_id": t.id, "clip_id": c.id, "export_id": e.id, "job_id": enqueue("export", e.id)}
            for t, c, e in made]


@router.get("/style_preview/{preset}")
def style_preview(preset: str, video_id: str | None = None, crop_x: float | None = None,
                  user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """One still frame of how a clip looks in this edit style - from the user's own video when given,
    otherwise from a drawn studio mock-up. Cached on disk."""
    from fastapi.responses import FileResponse

    from ..pipeline import preview
    from ..pipeline.edit import PRESETS
    if preset not in PRESETS:
        raise HTTPException(404, "Unknown style")
    d = WORK_DIR / "previews"
    d.mkdir(parents=True, exist_ok=True)
    cx = None if crop_x is None else round(max(0.0, min(1.0, float(crop_x))), 2)
    v = db.get(Video, video_id) if video_id else None
    title = "Your clip title shows here"
    if v and v.path and Path(v.path).exists():
        top = (db.query(Topic).filter_by(video_id=v.id).order_by(Topic.score.desc()).first())
        t = ((top.start + top.end) / 2) if top else float((v.meta or {}).get("duration") or 20) * 0.35
        title = (top.title if top else title)[:60]
        key = preview.cache_key(v.id, preset, cx, round(t, 1))
        out = d / f"{key}.jpg"
        if not out.exists():
            base = d / f"{v.id}_{int(t * 10)}.png"
            if not base.exists() and not preview.frame_from_video(v, t, base):
                raise HTTPException(500, "Could not read a frame from the video")
            boxes = preview.faces_in_image(base)
            preview.render(preset, base, boxes, out, title, crop_x=cx)
    else:
        key = preview.cache_key("mock", preset, cx)
        out = d / f"{key}.jpg"
        if not out.exists():
            stream = PRESETS[preset].get("frame") == "stream"
            base = d / ("mock_stream.png" if stream else "mock.png")
            src, boxes = (preview.mock_stream if stream else preview.mock_frame)(base)
            preview.render(preset, src, boxes, out, "Why he left everything at 21", crop_x=cx)
    return FileResponse(out, media_type="image/jpeg", headers={"Cache-Control": "max-age=3600"})


@router.post("/videos/{video_id}/ranking")
def make_ranking(video_id: str, payload: dict, user: User = Depends(require_role("editor")),
                 db: DBSession = Depends(get_db)):
    """'TOP N' ranking video from the chosen topics (best first). payload: {topic_ids, title,
    seconds (each moment, 6-30), + style options}."""
    from ..main import _render_options
    from ..pipeline.topics import best_window
    v = db.get(Video, video_id)
    if v is None:
        raise HTTPException(404, "Video not found")
    ids = [i for i in (payload.get("topic_ids") or []) if isinstance(i, str)]
    rows = {t.id: t for t in db.query(Topic).filter(Topic.video_id == video_id, Topic.id.in_(ids)).all()}
    tops = [rows[i] for i in ids if i in rows]
    if not 2 <= len(tops) <= 10:
        raise HTTPException(400, "Pick 2 to 10 topics for a ranking")
    secs = max(6.0, min(30.0, float(payload.get("seconds") or 12)))
    segs = []
    for t in reversed(tops):                       # play #N ... #1
        a, b, _why = best_window(v.transcript or [], t.start, t.end, secs)
        segs.append([round(a, 2), round(b, 2), t.title])
    title = (payload.get("title") or "").strip()[:60] or f"best moments of {Path(v.filename).stem}"[:60]
    opts = {**payload, **_render_options(payload, {})}
    c = Clip(video_id=video_id, start=min(s[0] for s in segs), end=max(s[1] for s in segs),
             score=max(t.score for t in tops), title=f"Top {len(tops)} - {title}"[:500], text="",
             settings={"aspect": payload.get("aspect", "9:16"), "ranking": True})
    db.add(c)
    db.flush()
    params = {"aspect": payload.get("aspect", "9:16"), "resolution": payload.get("resolution", "1080p"),
              "profile": payload.get("profile") or _power_profile(), "captions": bool(payload.get("captions", True)),
              "caption_style": payload.get("caption_style", "fodo_orange"), "placement": "lower",
              "start": c.start, "end": c.end, "segments": segs, "ranking_title": title,
              **{k: v_ for k, v_ in opts.items() if k not in ("start", "end")}}
    e = Export(clip_id=c.id, params=params)
    db.add(e)
    db.commit()
    return {"clip_id": c.id, "export_id": e.id, "job_id": enqueue("export", e.id), "segments": segs}


@router.post("/videos/{video_id}/make_clips")
def make_clips(video_id: str, payload: dict, user: User = Depends(require_role("editor")),
               db: DBSession = Depends(get_db)):
    """Create (and render) clips only for the chosen topics.
    payload: {topic_ids:[...]} or {top_n: 5} or {query: "money"} + style options."""
    from ..main import _render_options
    rows = db.query(Topic).filter_by(video_id=video_id).order_by(Topic.score.desc()).all()
    if payload.get("topic_ids"):
        wanted = set(payload["topic_ids"])
        rows = [r for r in rows if r.id in wanted]
    elif payload.get("query"):
        rows = [r for r in rows if r.id in {t["id"] for t in list_topics(video_id, payload["query"], user, db)}]
        rows = rows[: int(payload.get("top_n") or 3)]
    else:
        rows = rows[: max(1, min(int(payload.get("top_n") or 5), 50))]
    if not rows:
        raise HTTPException(400, "No matching topics")
    out = queue_topic_clips(db, rows, payload)
    audit(db, user.id, "clips.from_topics", f"video={video_id} n={len(out)}")
    return {"queued": out}


# ---------------------------------------------------------------- music ----
@router.get("/music/search")
def music_search(q: str = "", page: int = 1, user: User = Depends(current_user)):
    """Search free, commercially-usable Creative Commons music online (Openverse)."""
    from ..pipeline.music_online import search_openverse
    try:
        return search_openverse(q, page)
    except UnsafeURL as e:
        raise HTTPException(502, str(e))


@router.get("/music/discover")
def music_discover(q: str = "", category: str = "", genre: str = "", user: User = Depends(current_user)):
    """Music by video type (podcast, gaming, vlog ...) and genre, with ⭐ recommended and 🔥 trending styles."""
    from ..pipeline.music_online import discover
    return discover(q, category or None, genre or None)


@router.post("/music/openverse")
def music_from_openverse(payload: dict, user: User = Depends(require_role("editor")),
                         db: DBSession = Depends(get_db)):
    from ..config import MUSIC_USER_DIR
    from ..pipeline.music_online import fetch_openverse
    try:
        m = fetch_openverse(str(payload.get("id", "")), MUSIC_USER_DIR)
    except UnsafeURL as e:
        raise HTTPException(400, str(e))
    audit(db, user.id, "music.openverse", f"{m.get('title')} ({m.get('license')})")
    return m


@router.get("/music/search_all")
def music_search_all(q: str = "", providers: str = "", user: User = Depends(current_user)):
    """Internet Archive + ccMixter + NCS (each independent; one failing is reported, not fatal)."""
    from ..pipeline.music_providers import search_all
    return search_all(q.strip()[:120], [p for p in providers.split(",") if p] or None)


@router.get("/music/preview")
def music_preview(url: str, user: User = Depends(current_user)):
    """Stream a ccMixter preview through the server (ccMixter blocks other sites' Referer)."""
    import urllib.request
    from fastapi.responses import StreamingResponse
    from ..pipeline.music_online import UA
    if not re.fullmatch(r"https?://ccmixter\.org/content/[^\s?#]+\.mp3", url or ""):
        raise HTTPException(400, "Preview is only proxied for ccMixter tracks")
    try:
        r = urllib.request.urlopen(urllib.request.Request(url, headers={**UA, "Referer": "https://ccmixter.org/"}), timeout=20)
    except OSError as e:
        raise HTTPException(502, f"ccMixter: {e}")
    return StreamingResponse(iter(lambda: r.read(64 * 1024), b""), media_type="audio/mpeg")


@router.post("/music/fetch")
def music_fetch(payload: dict, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    from ..config import MUSIC_USER_DIR
    from ..pipeline.music_providers import fetch
    try:
        m = fetch(str(payload.get("id", "")), MUSIC_USER_DIR)
    except UnsafeURL as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(502, f"Music source error: {str(e)[:200]}")
    audit(db, user.id, "music.fetch", f"{m.get('title')} ({m.get('license')}) {payload.get('id')}")
    return m


@router.get("/music/youtube/search")
def music_youtube_search(q: str = "", free: int = 1, user: User = Depends(current_user)):
    """YouTube search. free=1 uses YouTube's Creative-Commons filter; free=0 searches everything
    (copyrighted songs come back as preview + hook only)."""
    from ..pipeline.music_youtube import search
    try:
        return search(q, bool(free))
    except UnsafeURL as e:
        raise HTTPException(502, str(e))


@router.get("/music/youtube/{vid}")
def music_youtube_info(vid: str, user: User = Depends(current_user)):
    """Licence status, Most-replayed graph and the suggested 15 s hook for one YouTube video."""
    from ..pipeline.music_youtube import details
    try:
        return details(vid)
    except UnsafeURL as e:
        raise HTTPException(502, str(e))


@router.post("/music/youtube/mp3")
def music_youtube_mp3(payload: dict, user: User = Depends(require_role("editor")),
                      db: DBSession = Depends(get_db)):
    """MP3 for Creative-Commons / official-NCS tracks only (re-checked on the video page)."""
    from ..config import MUSIC_USER_DIR
    from ..pipeline.music_youtube import download_mp3
    try:
        m = download_mp3(str(payload.get("id", "")), MUSIC_USER_DIR)
    except UnsafeURL as e:
        raise HTTPException(403 if "Copyrighted" in str(e) else 400, str(e))
    audit(db, user.id, "music.youtube", f"{m.get('title')} ({m.get('license')}) {payload.get('id')}")
    return m


@router.post("/music/from_link")
def music_from_link(payload: dict, user: User = Depends(require_role("editor")),
                    db: DBSession = Depends(get_db)):
    """Audio-only download from a link the owner has rights to (YouTube Audio Library, NCS ...)."""
    from ..config import MUSIC_USER_DIR
    from ..pipeline.music_online import from_link
    if not payload.get("confirm_rights"):
        raise HTTPException(400, "Please confirm you have the right to use this music.")
    try:
        m = from_link(str(payload.get("url", "")).strip(), MUSIC_USER_DIR)
    except UnsafeURL as e:
        raise HTTPException(400, str(e))
    audit(db, user.id, "music.from_link", str(payload.get("url"))[:200])
    return m


@router.delete("/music/{music_id}")
def music_delete(music_id: str, user: User = Depends(require_role("editor"))):
    from ..config import MUSIC_USER_DIR
    kind, _, name = music_id.partition(":")
    if kind != "user":
        raise HTTPException(400, "Built-in tracks can't be deleted")
    p = MUSIC_USER_DIR / Path(name).name
    if not p.exists():
        raise HTTPException(404, "Not found")
    p.unlink()
    p.with_suffix(p.suffix + ".json").unlink(missing_ok=True)
    return {"deleted": True}


@router.get("/music")
def music_list(user: User = Depends(current_user)):
    from ..config import MUSIC_USER_DIR
    from ..pipeline.compose import list_music
    return list_music(MUSIC_USER_DIR)


@router.post("/music")
async def music_upload(file: UploadFile = File(...), user: User = Depends(require_role("editor"))):
    from ..config import MUSIC_USER_DIR
    name = Path(file.filename or "track.mp3").name
    if Path(name).suffix.lower() not in (".mp3", ".m4a", ".wav", ".aac", ".ogg", ".flac"):
        raise HTTPException(400, "Upload an mp3/m4a/wav/aac/ogg/flac file")
    safe = re.sub(r"[^A-Za-z0-9._ -]", "_", name)[:120]
    dest = MUSIC_USER_DIR / safe
    data = await file.read()
    if len(data) > 60 * 1024 * 1024:
        raise HTTPException(413, "Music file too large (60 MB max)")
    dest.write_bytes(data)
    return {"id": f"user:{safe}", "name": Path(safe).stem}


@router.get("/music/{music_id}/file")
def music_file(music_id: str, user: User = Depends(current_user)):
    from fastapi.responses import FileResponse
    from ..config import MUSIC_USER_DIR
    from ..pipeline.compose import music_path
    p = music_path(music_id, MUSIC_USER_DIR)
    if not p:
        raise HTTPException(404, "Not found")
    return FileResponse(p)


@router.get("/music/{music_id}/analysis")
def music_analysis(music_id: str, user: User = Depends(current_user)):
    """Song structure: tempo, beats, sections and 3 suggested hooks (intro / chorus / drop)."""
    from ..config import MUSIC_USER_DIR
    from ..pipeline.compose import music_path
    from ..pipeline.music_analysis import analyze
    p = music_path(music_id, MUSIC_USER_DIR)
    if not p:
        raise HTTPException(404, "Not found")
    try:
        return analyze(p, WORK_DIR / "music_analysis")
    except RuntimeError as e:
        raise HTTPException(422, str(e)) from e


@router.get("/render_options")
def render_options(user: User = Depends(current_user)):
    from ..pipeline.captions import ANIMATIONS, FONTS, POSITIONS
    from ..pipeline.compose import EDIT_STYLES
    return {"edit_styles": {k: v["label"] for k, v in EDIT_STYLES.items()},
            "framing": {"auto": "Auto — the style decides; one consistent look per clip",
                        "tv": "TV / film scene — whole height, both actors in frame, never split",
                        "manual": "Manual — I choose the crop position",
                        "smart": "Smart — follows the talker moment by moment",
                        "split": "Always split when 2-3 people are visible",
                        "speaker": "Only the person talking", "wide": "Full frame"},
            "fonts": list(FONTS), "animations": list(ANIMATIONS), "positions": list(POSITIONS)}


# -------------------------------------------------------- live activity ----
@router.get("/activity")
def live_activity(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """Everything running in the background: jobs, their step timelines, recent logs."""
    from ..activity import recent_logs, steps_for
    jobs = db.query(Job).order_by(Job.created_at.desc()).limit(15).all()

    def label(j: Job) -> str:
        if j.kind in ("analyze", "import_url"):
            v = db.get(Video, j.target_id)
            return v.filename if v else j.target_id
        if j.kind == "export":
            e = db.get(Export, j.target_id)
            if e:
                return f"{(e.clip.title or 'clip')[:60]} → {e.params.get('aspect')} {e.params.get('resolution')}"
        return j.target_id
    names = {"analyze": "AI analysis", "import_url": "Link download", "export": "Export"}
    return {
        "jobs": [{"id": j.id, "kind": names.get(j.kind, j.kind), "target": label(j), "target_id": j.target_id,
                  "status": j.status, "stage": j.stage, "progress": j.progress,
                  "error": j.error, "created": j.created_at.isoformat(),
                  "steps": steps_for(j.id)} for j in jobs],
        "running": sum(1 for j in jobs if j.status == "running"),
        "queued": sum(1 for j in jobs if j.status == "queued"),
        "logs": recent_logs(),
        "disk_free_gb": round(__import__("shutil").disk_usage(str(UPLOADS_DIR)).free / 1e9, 1),
    }


# --------------------------------------------------------- batch export ----
@router.post("/videos/{video_id}/batch_export")
def batch_export(video_id: str, payload: dict, user: User = Depends(require_role("editor")),
                 db: DBSession = Depends(get_db)):
    v = db.get(Video, video_id)
    if v is None:
        raise HTTPException(404, "Video not found")
    top_n = max(1, min(int(payload.get("top_n", 5)), 12))
    min_score = float(payload.get("min_score", 0))
    tpl = _resolve_template(db, payload["template"]) if payload.get("template") else {}
    resolution = payload.get("resolution", "1080p")
    if resolution not in ("720p", "1080p", "1440p", "2160p"):
        raise HTTPException(400, "Bad resolution")
    clips = [c for c in sorted(v.clips, key=lambda c: -c.score) if c.score >= min_score][:top_n]
    out = []
    for c in clips:
        st = {**c.settings, **{k: tpl[k] for k in TEMPLATE_KEYS if k in tpl}}
        params = {"aspect": st.get("aspect", "9:16"), "caption_style": st.get("caption_style", "fodo_orange"),
                  "resolution": resolution, "profile": st.get("profile") or _power_profile(),
                  "placement": st.get("placement", "lower"), "audio_normalize": st.get("audio_normalize", True),
                  "captions": True, "start": c.start, "end": c.end}
        e = Export(clip_id=c.id, params=params)
        db.add(e)
        out.append({"clip_id": c.id, "export": e})
    db.commit()
    out = [{"clip_id": o["clip_id"], "export_id": o["export"].id,
            "job_id": enqueue("export", o["export"].id)} for o in out]
    audit(db, user.id, "export.batch", f"video={video_id} n={len(out)}")
    return {"queued": out}


# ----------------------------------------------------------- URL import ----
@router.post("/projects/{project_id}/import_url")
def import_url(project_id: str, payload: dict, user: User = Depends(require_role("editor")),
               db: DBSession = Depends(get_db)):
    """Queue a download (YouTube, Kick, Twitch, Vimeo, X, ... or a direct file),
    then auto-run AI clip discovery. Returns immediately with job ids."""
    from ..pipeline.url_import import is_direct_media, ytdlp_supported
    if db.get(Project, project_id) is None:
        raise HTTPException(404, "Project not found")
    url = str(payload.get("url", "")).strip()
    if not payload.get("confirm_rights"):
        raise HTTPException(400, "Please confirm you own or have permission to use this video.")
    try:
        validate_url(url)
    except UnsafeURL as e:
        raise HTTPException(400, str(e))
    if not (is_direct_media(url) or ytdlp_supported(url)):
        raise HTTPException(400, "This site isn't supported. Try a YouTube/Kick/Twitch/Vimeo link "
                                 "or a direct .mp4 link.")
    v = Video(project_id=project_id, filename=url[:200], path="", status="queued",
              meta={"source_url": url, "auto_analyze": bool(payload.get("auto_analyze", True)),
                    "auto_mode": ({"aspect": payload.get("aspect") or "9:16"}
                                  if payload.get("auto_mode") else None)})
    db.add(v)
    db.commit()
    job = enqueue("import_url", v.id)
    audit(db, user.id, "video.import_url", url[:300])
    return {"video_id": v.id, "job_id": job}


# ------------------------------------------------------------------ smart scan (no full download) --
@router.post("/scans")
def scan_start(payload: dict, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    from .. import scans
    from ..pipeline.url_import import ytdlp_supported
    url = str(payload.get("url", "")).strip()
    if not payload.get("confirm_rights"):
        raise HTTPException(400, "Please confirm you own this video or have permission to clip it.")
    try:
        validate_url(url)
    except UnsafeURL as e:
        raise HTTPException(400, str(e))
    if not ytdlp_supported(url):
        raise HTTPException(400, "This site isn't supported. Use a YouTube / Twitch / Kick video link.")
    pid = payload.get("project_id")
    if not pid or db.get(Project, pid) is None:
        pr = Project(name="Smart scans", owner_id=user.id)
        db.add(pr)
        db.commit()
        pid = pr.id
    mode = "rewind" if payload.get("mode") == "rewind" else "auto"
    try:
        hours = max(0.25, min(12.0, float(payload.get("hours") or 4)))
    except (TypeError, ValueError):
        hours = 4.0
    d = scans.start(url, user.id, pid, mode=mode, hours=hours)
    audit(db, user.id, "scan.start", f"{mode} {url[:300]}")
    return d


@router.post("/scans/{sid}/rescan")
def scan_rescan(sid: str, payload: dict, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    """Scan the same video again; mode 'audio' downloads the SOUND only (about 2 % of the video size)."""
    from .. import scans
    d = scans.get(sid)
    if d is None:
        raise HTTPException(404, "Scan not found")
    if d.get("status") == "scanning":
        raise HTTPException(400, "Already scanning")
    mode = payload.get("mode") if payload.get("mode") in ("auto", "audio", "chat", "rewind") else "auto"
    try:
        hours = max(0.25, min(12.0, float(payload.get("hours") or 4)))
    except (TypeError, ValueError):
        hours = 4.0
    audit(db, user.id, "scan.rescan", f"{sid} {mode}")
    return scans.start(d["url"], user.id, d["project_id"], mode=mode, sid=sid, hours=hours)


@router.get("/scans")
def scan_list(user: User = Depends(current_user)):
    from .. import scans
    return scans.list_all()


@router.get("/scans/{sid}")
def scan_get(sid: str, user: User = Depends(current_user)):
    from .. import scans
    d = scans.get(sid)
    if d is None:
        raise HTTPException(404, "Scan not found")
    return d


@router.get("/scans/{sid}/search")
def scan_search(sid: str, q: str, user: User = Depends(current_user)):
    from .. import scans
    from ..pipeline.smart_scan import search
    d = scans.get(sid, words=True)
    if d is None:
        raise HTTPException(404, "Scan not found")
    return search(d.get("words") or [], q[:80])


@router.delete("/scans/{sid}")
def scan_delete(sid: str, user: User = Depends(require_role("editor"))):
    from .. import scans
    if not scans.delete(sid):
        raise HTTPException(404, "Scan not found")
    return {"ok": True}


@router.post("/scans/{sid}/fetch")
def scan_fetch(sid: str, payload: dict, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    """Download ONLY the chosen moments (plus a few seconds either side) and make one clip from each."""
    from .. import scans
    d = scans.get(sid)
    if d is None or d.get("status") != "done":
        raise HTTPException(404, "Scan not ready")
    if payload.get("aspect", "9:16") not in ASPECT_RATIOS:
        raise HTTPException(400, "Bad aspect")
    dur = float(d.get("duration") or 0)
    pad = 5.0                       # handles: the editor can extend the clip into them
    moments = []
    for m in (payload.get("moments") or [])[:25]:
        try:
            a, b = float(m["start"]), float(m["end"])
        except (KeyError, TypeError, ValueError):
            continue
        a, b = max(0.0, a), min(dur or b, b)
        if 5 <= b - a <= 600:
            moments.append((a, b, str(m.get("title") or "Clip")[:150], float(m.get("score") or 70)))
    if not moments:
        raise HTTPException(400, "Choose at least one moment (5 s to 10 min long)")
    out = []
    for a, b, title, score in moments:
        sa, sb = max(0.0, a - pad), min(dur or b + pad, b + pad)
        hh, mm, ss = int(a // 3600), int(a % 3600 // 60), int(a % 60)
        v = Video(project_id=d["project_id"], path="", status="queued",
                  filename=f"✂ {(d.get('title') or 'Video')[:110]} · {hh}:{mm:02d}:{ss:02d} · {title[:60]}.mp4",
                  meta={"source_url": d["url"], "section": [round(sa, 2), round(sb, 2)], "scan_id": sid,
                        "live_rewind": bool(d.get("live_rewind")),
                        "auto_analyze": True,
                        "auto_mode": {"aspect": payload.get("aspect", "9:16"), "preset": payload.get("preset") or None,
                                      "moment": {"start": round(a - sa, 2), "end": round(b - sa, 2),
                                                 "title": title, "score": score}}})
        db.add(v)
        db.commit()
        out.append({"video_id": v.id, "job_id": enqueue("import_url", v.id), "start": a, "end": b, "title": title})
    scans._update(sid, fetched=(d.get("fetched") or []) + [{"video_id": o["video_id"], "start": o["start"],
                                                            "end": o["end"], "title": o["title"]} for o in out])
    audit(db, user.id, "scan.fetch", f"{sid} {len(out)} moments")
    return {"queued": out}


# ------------------------------------------------------------------ live stream watcher --
@router.get("/live")
def live_list(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    from .. import live
    out = []
    for w in live.list_all():
        vids = [p["video_id"] for p in w.get("parts", [])]
        rows = db.query(Video).filter(Video.id.in_(vids)).all() if vids else []
        by = {v.id: v for v in rows}
        clips = 0
        for p in w.get("parts", []):
            v = by.get(p["video_id"])
            p["status"] = v.status if v else "deleted"
            p["clips"] = len(v.clips) if v else 0
            clips += p["clips"]
        out.append({**w, "clips": clips, "running": w["id"] in live._threads})
    return out


@router.post("/live")
def live_start(payload: dict, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    from .. import live
    from ..pipeline.url_import import ytdlp_supported
    url = str(payload.get("url", "")).strip()
    if not payload.get("confirm_rights"):
        raise HTTPException(400, "Please confirm you own this stream or have permission to clip it.")
    try:
        validate_url(url)
    except UnsafeURL as e:
        raise HTTPException(400, str(e))
    if not ytdlp_supported(url):
        raise HTTPException(400, "This site isn't supported. Use a YouTube, Twitch or Kick live link.")
    if payload.get("aspect", "9:16") not in ASPECT_RATIOS:
        raise HTTPException(400, "Bad aspect")
    pid = payload.get("project_id")
    if not pid or db.get(Project, pid) is None:
        pr = Project(name="Live streams", owner_id=user.id)
        db.add(pr)
        db.commit()
        pid = pr.id
    try:
        w = live.start(url, pid, user.id, chunk_minutes=float(payload.get("chunk_minutes", 5)),
                       max_hours=float(payload.get("max_hours", 4)), auto_clips=bool(payload.get("auto_clips", True)),
                       min_score=float(payload.get("min_score", 60)), max_clips=int(payload.get("max_clips", 2)),
                       aspect=payload.get("aspect", "9:16"))
    except (ValueError, TypeError) as e:
        raise HTTPException(400, str(e))
    audit(db, user.id, "live.start", url[:300])
    return w


@router.post("/live/{wid}/stop")
def live_stop(wid: str, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    from .. import live
    if not live.stop(wid):
        raise HTTPException(404, "Watch not found")
    audit(db, user.id, "live.stop", wid)
    return {"ok": True}


@router.post("/live/{wid}/resume")
def live_resume(wid: str, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    from .. import live
    try:
        w = live.resume(wid)
    except ValueError as e:
        raise HTTPException(400, str(e))
    audit(db, user.id, "live.resume", wid)
    return w


@router.delete("/live/{wid}")
def live_remove(wid: str, user: User = Depends(require_role("editor"))):
    from .. import live
    if not live.remove(wid):
        raise HTTPException(400, "Stop the watch first (or it does not exist).")
    return {"ok": True}


@router.get("/videos/{video_id}/pipeline")
def pipeline_status(video_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """Combined download -> analysis status for link imports."""
    v = db.get(Video, video_id)
    if v is None:
        raise HTTPException(404, "Video not found")
    aj = (v.meta or {}).get("analyze_job")
    job = db.get(Job, aj) if aj else None
    n_topics = db.query(Topic).filter_by(video_id=v.id).count()
    return {"status": v.status, "title": (v.meta or {}).get("source_title") or v.filename,
            "clips": len(v.clips), "topics": n_topics, "analyze_job": aj,
            "analyze": ({"status": job.status, "stage": job.stage, "progress": job.progress,
                         "error": job.error} if job else None)}


# --------------------------------------------------------------- search ----
@router.get("/videos/{video_id}/search")
def search_transcript(video_id: str, q: str, user: User = Depends(current_user),
                      db: DBSession = Depends(get_db)):
    v = db.get(Video, video_id)
    if v is None:
        raise HTTPException(404, "Video not found")
    terms = [t for t in re.findall(r"\w+", q.lower()) if len(t) > 2]
    if not terms:
        return []
    hits = []
    for s in _sentences(v):
        low = s["text"].lower()
        score = sum(low.count(t) for t in terms)
        if score:
            hits.append({"text": s["text"], "start": s["s"], "end": s["e"], "matches": score})
    return sorted(hits, key=lambda h: -h["matches"])[:20]


# ------------------------------------------------------------ analytics ----
@router.get("/analytics")
def analytics(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """Only real, locally-recorded numbers. No social metrics are invented."""
    exports_done = db.query(Export).filter_by(status="done").all()
    total_out_s = sum(float(e.params.get("end", 0)) - float(e.params.get("start", 0)) for e in exports_done)
    labelled = db.query(Clip.label, func.count()).filter(Clip.label.isnot(None)).group_by(Clip.label).all()
    lab = dict(labelled)
    good = db.query(func.avg(Clip.score)).filter(Clip.label == "successful").scalar()
    bad = db.query(func.avg(Clip.score)).filter(Clip.label == "unsuccessful").scalar()
    return {
        "projects": db.query(Project).count(),
        "videos": db.query(Video).count(),
        "source_minutes": round(sum((v.meta or {}).get("duration", 0) for v in db.query(Video).all()) / 60, 1),
        "clips_generated": db.query(Clip).count(),
        "exports_done": len(exports_done),
        "exports_failed": db.query(Export).filter_by(status="failed").count(),
        "exported_minutes": round(total_out_s / 60, 1),
        "feedback": {"successful": lab.get("successful", 0), "unsuccessful": lab.get("unsuccessful", 0)},
        "avg_score_successful": round(good, 1) if good else None,
        "avg_score_unsuccessful": round(bad, 1) if bad else None,
        "by_aspect": _count_params(exports_done, "aspect"),
        "by_style": _count_params(exports_done, "caption_style"),
        "note": "Platform performance (views, retention) is not tracked unless you import it.",
    }


def _count_params(exports: list[Export], key: str) -> dict:
    out: dict[str, int] = {}
    for e in exports:
        k = (e.params or {}).get(key, "?")
        out[k] = out.get(k, 0) + 1
    return out


# ----------------------------------------------------- system / models ----
@router.get("/system/hardware")
def hardware(user: User = Depends(current_user)):
    return detect_hardware()


@router.get("/admin/models")
def models(user: User = Depends(require_role("admin"))):
    try:
        import faster_whisper  # noqa: F401
        fw = True
    except ImportError:
        fw = False
    return {"whisper": {"installed": fw, "model": WHISPER_MODEL},
            "ollama": llm.status(),
            "face_detector": "OpenCV Haar cascade (bundled)",
            "scene_detector": "PySceneDetect ContentDetector"}


@router.get("/admin/storage")
def storage(user: User = Depends(require_role("admin"))):
    return storage_usage()


@router.post("/admin/cache/clear")
def cache_clear(user: User = Depends(require_role("owner")), db: DBSession = Depends(get_db)):
    freed = clear_cache()
    audit(db, user.id, "cache.clear", f"{freed} MB")
    return {"freed_mb": freed}


@router.get("/admin/failed_jobs")
def failed_jobs(user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    rows = db.query(Job).filter_by(status="failed").order_by(Job.created_at.desc()).limit(50).all()
    return [{"id": j.id, "kind": j.kind, "target": j.target_id, "error": j.error,
             "at": j.created_at.isoformat()} for j in rows]


@router.post("/admin/jobs/{job_id}/retry")
def retry_job(job_id: str, user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    j = db.get(Job, job_id)
    if j is None or j.status != "failed":
        raise HTTPException(400, "Only failed jobs can be retried")
    if j.kind == "export":
        e = db.get(Export, j.target_id)
        if e:
            e.status, e.error = "queued", None
            db.commit()
    return {"job_id": enqueue(j.kind, j.target_id)}


# -------------------------------------------------------------- library / storage ----
def _fsize(p) -> int:
    try:
        p = Path(p)
        if p.is_file():
            return p.stat().st_size
        if p.is_dir():
            return sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
    except OSError:
        pass
    return 0


def _video_files(v: Video) -> dict:
    exports = [Path(e.path) for c in v.clips for e in c.exports if e.path]
    work = [WORK_DIR / v.id] + [WORK_DIR / c.id for c in v.clips]
    src = Path(v.path) if v.path else None
    return {"source": src, "exports": exports, "work": work,
            "partial": list(UPLOADS_DIR.glob(f"{v.id}*")) if v.id else []}


def _video_bytes(v: Video) -> dict:
    f = _video_files(v)
    src = _fsize(f["source"]) if f["source"] else 0
    partial = sum(_fsize(p) for p in f["partial"] if not f["source"] or p != f["source"])
    return {"source": src + partial, "exports": sum(_fsize(p) for p in f["exports"]),
            "work": sum(_fsize(p) for p in f["work"])}


def _cancel_video_jobs(db: DBSession, v: Video) -> int:
    from ..jobs import cancel
    ids = {v.id} | {c.id for c in v.clips} | {e.id for c in v.clips for e in c.exports}
    n = 0
    for j in db.query(Job).filter(Job.status.in_(("queued", "running"))).all():
        if j.target_id in ids:
            n += int(cancel(j.id))
    return n


@router.get("/library")
def library(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    import shutil
    projects = []
    total = 0
    for p in db.query(Project).order_by(Project.created_at.desc()).all():
        vids = []
        for v in sorted(p.videos, key=lambda x: x.created_at, reverse=True):
            b = _video_bytes(v)
            size = sum(b.values())
            total += size
            vids.append({"id": v.id, "title": (v.meta or {}).get("source_title") or v.filename,
                         "status": v.status, "created_at": v.created_at.isoformat(),
                         "duration": (v.meta or {}).get("duration"),
                         "topics": db.query(Topic).filter_by(video_id=v.id).count(),
                         "clips": len(v.clips),
                         "exports": sum(1 for c in v.clips for e in c.exports if e.status == "done"),
                         "bytes": b, "size": size,
                         "source_url": (v.meta or {}).get("source_url")})
        projects.append({"id": p.id, "name": p.name, "videos": vids,
                         "size": sum(x["size"] for x in vids)})
    du = shutil.disk_usage(str(UPLOADS_DIR))
    running = [{"id": j.id, "kind": j.kind, "target_id": j.target_id, "stage": j.stage,
                "progress": j.progress, "status": j.status}
               for j in db.query(Job).filter(Job.status.in_(("queued", "running"))).all()]
    return {"projects": projects, "total_bytes": total, "disk_free": du.free, "disk_total": du.total,
            "jobs": running}


def _delete_video(db: DBSession, v: Video, keep_source: bool = False) -> int:
    import shutil
    _cancel_video_jobs(db, v)
    f = _video_files(v)
    freed = 0
    paths = f["exports"] + f["work"] + ([] if keep_source else ([f["source"]] if f["source"] else []) + f["partial"])
    for p in paths:
        if p is None:
            continue
        p = Path(p)
        # never touch anything outside our storage folder
        from ..config import STORAGE_DIR
        try:
            p.resolve().relative_to(STORAGE_DIR.resolve())
        except ValueError:
            continue
        freed += _fsize(p)
        try:
            shutil.rmtree(p) if p.is_dir() else p.unlink(missing_ok=True)
        except OSError:
            pass
    if keep_source:
        for c in v.clips:
            for e in c.exports:
                e.path = None
                e.status = "deleted"
        return freed
    for c in list(v.clips):
        db.query(EditHistory).filter_by(clip_id=c.id).delete()
        for e in list(c.exports):
            db.delete(e)
        db.delete(c)
    db.query(Topic).filter_by(video_id=v.id).delete()
    db.delete(v)
    return freed


@router.delete("/videos/{video_id}")
def delete_video(video_id: str, only_exports: bool = False, user: User = Depends(require_role("editor")),
                 db: DBSession = Depends(get_db)):
    """Delete a video with all its clips, renders and work files (frees disk space).
    only_exports=true keeps the video + topics and deletes only rendered files."""
    v = db.get(Video, video_id)
    if v is None:
        raise HTTPException(404, "Video not found")
    name = v.filename
    freed = _delete_video(db, v, keep_source=only_exports)
    db.commit()
    audit(db, user.id, "video.delete" + (".exports" if only_exports else ""), f"{name[:120]} freed={freed}")
    return {"deleted": True, "freed_bytes": freed}


@router.delete("/projects/{project_id}")
def delete_project(project_id: str, user: User = Depends(require_role("editor")),
                   db: DBSession = Depends(get_db)):
    p = db.get(Project, project_id)
    if p is None:
        raise HTTPException(404, "Project not found")
    freed = 0
    for v in list(p.videos):
        freed += _delete_video(db, v)
    db.flush()
    db.delete(p)
    db.commit()
    audit(db, user.id, "project.delete", f"{p.name[:120]} freed={freed}")
    return {"deleted": True, "freed_bytes": freed}


@router.post("/videos/{video_id}/cancel")
def cancel_video(video_id: str, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    """Stop download / analysis / renders running for this video."""
    v = db.get(Video, video_id)
    if v is None:
        raise HTTPException(404, "Video not found")
    n = _cancel_video_jobs(db, v)
    audit(db, user.id, "video.cancel", v.filename[:120])
    return {"cancelled": n}


# ---------------------------------------------------------------- edit options ----
@router.get("/edit_options")
def edit_options(user: User = Depends(current_user)):
    from ..pipeline.edit import DEAD_AIR, MUSIC_MOODS, PRESETS, SFX_LEVEL
    return {"presets": {k: {"label": v["label"], "desc": v["desc"], **{x: v[x] for x in v if x not in ("label", "desc")}}
                        for k, v in PRESETS.items()},
            "dead_air": list(DEAD_AIR), "sfx": list(SFX_LEVEL), "music_moods": list(MUSIC_MOODS),
            "music_map": MUSIC_MOODS,
            "formats": [{"id": "9:16", "label": "Reel / Shorts / TikTok (9:16)"},
                        {"id": "16:9", "label": "Normal YouTube (16:9)"},
                        {"id": "1:1", "label": "Square (1:1)"},
                        {"id": "4:5", "label": "Instagram feed (4:5)"}],
            "framing": [{"id": "auto", "label": "Auto (the style decides) - one consistent look, split only when it is the clip's main layout"},
                        {"id": "tv", "label": "TV / film scene - whole height, both actors in frame, never split"},
                        {"id": "speaker", "label": "Only the person talking"},
                        {"id": "smart", "label": "Talker when one talks, split when both"},
                        {"id": "wide", "label": "Full frame (blurred background)"}]}


@router.get("/videos/{video_id}/auto_plan")
def video_auto_plan(video_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    from ..pipeline.edit import auto_plan
    v = db.get(Video, video_id)
    if v is None:
        raise HTTPException(404, "Video not found")
    tops = [{"id": t.id, "score": t.score, "breakdown": t.breakdown}
            for t in db.query(Topic).filter_by(video_id=video_id).all()]
    if not tops:
        raise HTTPException(400, "No topics yet - analysis has to finish first")
    return auto_plan(tops, ((v.meta or {}).get("duration") or 0) / 60, {**(v.meta or {}), "filename": v.filename})



# ---------------- caption studio ----------------

@router.get("/exports/{export_id}/subtitles")
def export_subtitles(export_id: str, fmt: str = "srt", user: User = Depends(current_user),
                     db: DBSession = Depends(get_db)):
    from fastapi.responses import Response
    from ..main import export_filename
    from ..pipeline.captions import srt_to_vtt
    e = db.get(Export, export_id)
    if e is None or not e.path:
        raise HTTPException(404, "Export not ready")
    fmt = fmt.lower()
    if fmt not in ("srt", "vtt", "ass"):
        raise HTTPException(400, "fmt must be srt, vtt or ass")
    src = Path(e.path).with_suffix(".ass" if fmt == "ass" else ".srt")
    if not src.exists():
        raise HTTPException(404, "No subtitle file for this export (rendered before v0.8 or captions off)")
    text = src.read_text(encoding="utf-8")
    if fmt == "vtt":
        text = srt_to_vtt(text)
    name = Path(export_filename(e)).with_suffix("." + fmt).name
    media = {"srt": "application/x-subrip", "vtt": "text/vtt", "ass": "text/x-ssa"}[fmt]
    return Response(text, media_type=media + "; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.get("/my_styles")
def my_styles_get(user: User = Depends(current_user)):
    from .. import my_styles
    return my_styles.get(user.id)


@router.post("/my_styles")
def my_styles_add(payload: dict, user: User = Depends(current_user)):
    from .. import my_styles
    try:
        return my_styles.add(user.id, str(payload.get("name", "")), payload.get("opts") or {})
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.delete("/my_styles/{sid}")
def my_styles_delete(sid: str, user: User = Depends(current_user)):
    from .. import my_styles
    if not my_styles.delete(user.id, sid):
        raise HTTPException(404, "Style not found")
    return {"ok": True}


@router.put("/my_styles/favourites")
def my_styles_favs(payload: dict, user: User = Depends(current_user)):
    from .. import my_styles
    return {"favourites": my_styles.set_favourites(user.id, payload.get("favourites") or [])}


@router.get("/clips/{clip_id}/timeline")
def clip_timeline(clip_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """Text-based timeline: transcript lines around the clip (video time) + trim points + manual cuts."""
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    lo, hi = max(0.0, c.start - 15), c.end + 15
    words = [w for w in (c.video.transcript or []) if w["e"] > lo and w["s"] < hi]
    lines, cur = [], []
    for w in words:
        cur.append(w)
        t = (w.get("w") or "").strip()
        if t.endswith((".", "?", "!", "।")) or len(cur) >= 12 or (cur and w["e"] - cur[0]["s"] > 5):
            lines.append(cur); cur = []
    if cur:
        lines.append(cur)
    return {"start": c.start, "end": c.end, "video_duration": float(c.video.meta.get("duration") or 0) or None,
            "cut_ranges": (c.settings or {}).get("cut_ranges") or [],
            "lines": [{"s": round(l[0]["s"], 2), "e": round(l[-1]["e"], 2),
                       "text": " ".join((w.get("w") or "").strip() for w in l)} for l in lines]}


@router.put("/clips/{clip_id}/timeline")
def save_timeline(clip_id: str, payload: dict, user: User = Depends(require_role("editor")),
                  db: DBSession = Depends(get_db)):
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    snapshot(db, c, "manual", "timeline edit")             # undo point in clip history
    try:
        start, end = float(payload.get("start", c.start)), float(payload.get("end", c.end))
    except (TypeError, ValueError):
        raise HTTPException(400, "Bad start/end")
    vd = float(c.video.meta.get("duration") or 0) or None
    start = max(0.0, start)
    if vd:
        end = min(end, vd)
    if end - start < 3:
        raise HTTPException(400, "A clip must be at least 3 seconds long")
    cuts = []
    for r in (payload.get("cut_ranges") or [])[:60]:
        try:
            a, b = float(r[0]), float(r[1])
        except (TypeError, ValueError, IndexError):
            continue
        a, b = max(a, start), min(b, end)
        if b - a >= 0.1:
            cuts.append([round(a, 2), round(b, 2)])
    if sum(b - a for a, b in cuts) > (end - start) - 2:
        raise HTTPException(400, "That would cut almost the whole clip")
    s = dict(c.settings or {})
    s["cut_ranges"] = sorted(cuts)
    c.start, c.end, c.settings = start, end, s
    db.commit()
    audit(db, user.id, "clip.timeline", f"{clip_id} {start:.1f}-{end:.1f} cuts={len(cuts)}")
    return {"ok": True, "start": start, "end": end, "cut_ranges": s["cut_ranges"]}


@router.get("/clips/{clip_id}/captions")
def clip_captions(clip_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """Caption lines (source time) for manual correction. Words come from the last render."""
    from ..pipeline.captions import apply_override, group_words
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    ws = (c.settings or {}).get("caption_words")
    if not ws:
        ws = [w for w in (c.video.transcript or []) if w["s"] >= c.start - 0.05 and w["e"] <= c.end + 0.05]
        source = "analysis transcript (render once for the accurate captions)"
    else:
        source = "captions of the last render"
    ws = apply_override(ws, (c.settings or {}).get("caption_override"))
    lines = [{"s": ln[0]["s"], "e": ln[-1]["e"], "text": " ".join(w["w"].strip() for w in ln)}
             for ln in group_words(ws, max_words=7, max_gap=0.7)]
    return {"lines": lines, "source": source,
            "edited": len(((c.settings or {}).get("caption_override") or {}).get("lines", []))}


@router.put("/clips/{clip_id}/captions")
def save_clip_captions(clip_id: str, payload: dict, user: User = Depends(require_role("editor")),
                       db: DBSession = Depends(get_db)):
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    lines = []
    for ln in (payload.get("lines") or [])[:600]:
        try:
            s0, s1 = float(ln["s"]), float(ln["e"])
        except (KeyError, TypeError, ValueError):
            raise HTTPException(400, "each line needs s, e, text")
        if s1 <= s0:
            continue
        lines.append({"s": s0, "e": s1, "text": str(ln.get("text") or "")[:300]})
    old = {(round(x["s"], 2), round(x["e"], 2)): x for x in ((c.settings or {}).get("caption_override") or {}).get("lines", [])}
    for x in lines:
        old[(round(x["s"], 2), round(x["e"], 2))] = x
    c.settings = {**(c.settings or {}), "caption_override": {"lines": list(old.values())}}
    db.commit()
    audit(db, user.id, "captions.edit", f"clip={clip_id} lines={len(lines)}")
    return {"saved": len(lines), "total_edited": len(old)}


@router.delete("/clips/{clip_id}/captions")
def reset_clip_captions(clip_id: str, user: User = Depends(require_role("editor")),
                        db: DBSession = Depends(get_db)):
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    st = dict(c.settings or {})
    st.pop("caption_override", None)
    c.settings = st
    db.commit()
    return {"reset": True}


@router.get("/fonts")
def list_fonts(user: User = Depends(current_user)):
    from ..pipeline.captions import FONTS, user_fonts
    return {"builtin": list(FONTS.keys()), "uploaded": list(user_fonts().keys()),
            "note": "Upload only fonts you are licensed to use in videos (e.g. SIL Open Font License)."}


@router.post("/fonts")
async def upload_font(file: UploadFile = File(...), user: User = Depends(require_role("editor"))):
    from ..pipeline.captions import user_font_dir, user_fonts
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", Path(file.filename or "font.ttf").name)
    if Path(name).suffix.lower() not in (".ttf", ".otf"):
        raise HTTPException(400, "Only .ttf or .otf fonts")
    data = await file.read()
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(413, "Font too large (10 MB max)")
    dest = user_font_dir() / name
    dest.write_bytes(data)
    try:
        from PIL import ImageFont
        fam, style = ImageFont.truetype(str(dest), 20).getname()
    except Exception:  # noqa: BLE001  - not a real font file
        dest.unlink(missing_ok=True)
        raise HTTPException(400, "Not a valid font file")
    return {"family": fam, "style": style, "fonts": list(user_fonts().keys())}



@router.post("/clips/{clip_id}/content_pack")
def clip_content_pack(clip_id: str, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    """Titles, descriptions, hashtags, hook text... (local LLM or fallback). Saved on the clip, editable."""
    from ..pipeline.content_pack import build
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    ws = (c.settings or {}).get("caption_words") or [
        w for w in (c.video.transcript or []) if w["s"] >= c.start - 0.05 and w["e"] <= c.end + 0.05]
    text = " ".join(w["w"].strip() for w in ws) or (c.text or "")
    meta = c.video.meta or {}
    pack = build(c.title or "Clip", text, meta.get("uploader") or "", "")
    c.settings = {**(c.settings or {}), "content_pack": pack}
    db.commit()
    return pack


def _clip_text(c: Clip) -> str:
    ws = (c.settings or {}).get("caption_words") or [
        w for w in (c.video.transcript or []) if w["s"] >= c.start - 0.05 and w["e"] <= c.end + 0.05]
    return " ".join(w["w"].strip() for w in ws) or (c.text or "")


# ------------------------------------------------------------------ watermarks / logos --
@router.get("/watermarks")
def watermarks_list(user: User = Depends(current_user)):
    from .. import watermarks
    return watermarks.list_all()


@router.post("/watermarks")
async def watermarks_upload(file: UploadFile = File(...), user: User = Depends(require_role("editor"))):
    from .. import watermarks
    data = await file.read()
    try:
        return watermarks.save(data, Path(file.filename or "Logo").stem)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/watermarks/{wid}/image")
def watermarks_image(wid: str, user: User = Depends(current_user)):
    from fastapi.responses import FileResponse
    from .. import watermarks
    p = watermarks.path_of(wid)
    if not p:
        raise HTTPException(404, "Logo not found")
    return FileResponse(p, media_type="image/png")


@router.post("/watermarks/{wid}/remove_bg")
def watermarks_remove_bg(wid: str, payload: dict | None = None, user: User = Depends(require_role("editor"))):
    from .. import watermarks
    p = payload or {}
    try:
        return watermarks.remove_background(wid, str(p.get("method", "auto")), int(p.get("tolerance", 40)))
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.delete("/watermarks/{wid}")
def watermarks_delete(wid: str, user: User = Depends(require_role("editor"))):
    from .. import watermarks
    if not watermarks.delete(wid):
        raise HTTPException(404, "Logo not found")
    return {"ok": True}


# ------------------------------------------------------------------ filters / effects --
@router.get("/fx/catalog")
def fx_catalog(user: User = Depends(current_user)):
    from ..pipeline.fx import ADJUST_KEYS, EFFECTS, FILTERS, POSITIONS
    return {"filters": [{"id": k, "label": v["label"], "group": v["group"]} for k, v in FILTERS.items()],
            "effects": [{"id": k, "label": v["label"], "group": v["group"]} for k, v in EFFECTS.items()],
            "adjust": list(ADJUST_KEYS), "positions": list(POSITIONS) + ["custom"],
            "layouts": [{"id": k, "label": v["label"]} for k, v in _layouts().items()],
            "speeds": [0.75, 1.0, 1.1, 1.25, 1.5]}


def _layouts():
    from ..main import LAYOUTS
    return LAYOUTS


@router.post("/clips/{clip_id}/fx_preview")
def fx_preview(clip_id: str, payload: dict, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """One frame of the clip with the chosen filter / adjustments / effects (+ watermark), as JPEG."""
    import hashlib
    import json as _json
    import subprocess
    from fastapi.responses import Response
    from .. import watermarks
    from ..pipeline import fx as fxmod
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    cache = WORK_DIR / "fxprev"
    cache.mkdir(parents=True, exist_ok=True)
    t = float(payload.get("t", (c.start + c.end) / 2))
    t = min(max(t, c.start), c.end)
    aspect = payload.get("aspect") if payload.get("aspect") in ASPECT_RATIOS else "9:16"
    aw, ah = ASPECT_RATIOS[aspect]
    A = aw / ah
    frame = cache / f"{clip_id}_{int(t * 10)}_{aspect.replace(':', 'x')}.jpg"
    if not frame.exists():
        # centre crop to the export shape, so the logo / effects sit where they will in the video
        vf = f"crop='min(iw,ih*{A:.5f})':'min(ih,iw/{A:.5f})',scale=-2:{720 if A < 1 else 540}"
        r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", c.video.path, "-frames:v", "1",
                            "-vf", vf, "-q:v", "3", str(frame)], capture_output=True, timeout=60)
        if r.returncode or not frame.exists():
            raise HTTPException(500, "Could not read a frame from the video")
    fxc = fxmod.clean(payload.get("fx"))
    wm = fxmod.clean_watermark(payload.get("watermark"))
    wpath = watermarks.path_of(wm["id"]) if wm else None
    key = hashlib.md5(_json.dumps([str(frame), fxc, wm], sort_keys=True).encode()).hexdigest()[:16]
    out = cache / f"p_{key}.jpg"
    if not out.exists():
        g = fxmod.graph("0:v", "f0", fxc, "p")
        ins = ["-i", str(frame)]
        if wpath:
            from PIL import Image
            W, H = Image.open(frame).size
            g += ";" + fxmod.watermark_graph("f0", "1:v", "f1", wm, W, H)
            ins += ["-i", str(wpath)]
            last = "[f1]"
        else:
            last = "[f0]"
        r = subprocess.run(["ffmpeg", "-y", "-v", "error", *ins, "-filter_complex", g, "-map", last,
                            "-frames:v", "1", "-q:v", "3", str(out)], capture_output=True, text=True, timeout=60)
        if r.returncode or not out.exists():
            raise HTTPException(500, "Preview failed: " + (r.stderr or "")[-300:])
    return Response(out.read_bytes(), media_type="image/jpeg")


@router.get("/social/platforms")
def social_platforms(user: User = Depends(current_user)):
    from ..pipeline.social_copy import PLATFORMS
    return [{"id": k, **{x: v[x] for x in ("label", "icon", "caption_max", "hashtags", "title_max")}} for k, v in PLATFORMS.items()]


@router.post("/clips/{clip_id}/social")
def clip_social(clip_id: str, payload: dict, user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    """Heading + caption + hashtags (+ YouTube tags) for one platform, written for this clip."""
    from ..pipeline.social_copy import PLATFORMS, build
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    plats = payload.get("platforms") or [payload.get("platform")]
    plats = [p for p in plats if p in PLATFORMS]
    if not plats:
        raise HTTPException(400, "Choose a platform")
    text = _clip_text(c)
    ctx = social_context(c, text)
    soc = dict((c.settings or {}).get("social") or {})
    from ..pipeline.social_copy import build_all
    try:
        variant = max(0, min(50, int(payload.get("variant") or 0)))
    except (TypeError, ValueError):
        variant = 0
    avoid = payload.get("avoid") if isinstance(payload.get("avoid"), dict) else None
    soc.update(build_all(plats, c.title or "Clip", text, ctx["channel"], str(payload.get("tone") or "")[:60], ctx,
                         fast=bool(payload.get("fast")), variant=variant, avoid=avoid,
                         emoji=payload.get("emoji", True) is not False))
    c.settings = {**(c.settings or {}), "social": soc}
    db.commit()
    return soc


def social_context(c: Clip, text: str | None = None) -> dict:
    """Creator / game / stream facts for a clip, from its video's source info."""
    from ..pipeline.social_copy import context
    m = c.video.meta or {}
    channel = m.get("source_uploader") or m.get("uploader") or ""
    site = m.get("source_site") or m.get("site") or ""
    src_title = m.get("source_title") or ""
    if not src_title:
        from pathlib import Path as _P
        src_title = _P(str(c.video.filename or "")).stem
    return context(c.title or "", text if text is not None else _clip_text(c), channel, src_title, site,
                   bool(m.get("live_watch")))


@router.get("/clips/{clip_id}/social")
def get_clip_social(clip_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    return (c.settings or {}).get("social") or {}


@router.put("/clips/{clip_id}/social/{platform}")
def save_clip_social(clip_id: str, platform: str, payload: dict, user: User = Depends(require_role("editor")),
                     db: DBSession = Depends(get_db)):
    from ..pipeline.social_copy import PLATFORMS
    c = db.get(Clip, clip_id)
    if c is None or platform not in PLATFORMS:
        raise HTTPException(404, "Not found")
    soc = dict((c.settings or {}).get("social") or {})
    cur = dict(soc.get(platform) or {"platform": platform})
    for k in ("heading", "caption", "first_comment"):
        if k in payload:
            cur[k] = str(payload[k])[:PLATFORMS[platform]["caption_max"]]
    for k in ("hashtags", "tags"):
        if isinstance(payload.get(k), list):
            cur[k] = [str(x)[:60] for x in payload[k]][:30]
    cur["edited"] = True
    soc[platform] = cur
    c.settings = {**(c.settings or {}), "social": soc}
    db.commit()
    return cur


@router.get("/clips/{clip_id}/content_pack")
def get_clip_content_pack(clip_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    return (c.settings or {}).get("content_pack") or {}


@router.put("/clips/{clip_id}/content_pack")
def save_clip_content_pack(clip_id: str, payload: dict, user: User = Depends(require_role("editor")),
                           db: DBSession = Depends(get_db)):
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    pack = {k: v for k, v in (payload or {}).items() if k in (
        "titles", "descriptions", "hashtags", "hook_text", "thumbnail", "summary", "keywords",
        "audience", "platform_copy", "category", "source")}
    c.settings = {**(c.settings or {}), "content_pack": pack}
    db.commit()
    return {"saved": True}



# ---------------- trend registry ----------------

@router.get("/trends")
def trends_list(user: User = Depends(current_user)):
    from .. import trends
    return {"trends": trends.load(), "note": "Each trend lists the evidence it was seen in. Disabling one never changes saved projects."}


@router.patch("/trends/{trend_id}")
def trends_update(trend_id: str, payload: dict, user: User = Depends(require_role("admin")),
                  db: DBSession = Depends(get_db)):
    from .. import trends
    try:
        t = trends.update(trend_id, payload or {})
    except KeyError:
        raise HTTPException(404, "Unknown trend")
    audit(db, user.id, "trend.update", f"{trend_id} {sorted((payload or {}).keys())}")
    return t


@router.post("/trends")
def trends_add(payload: dict, user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    from .. import trends
    try:
        t = trends.add(payload or {})
    except ValueError as e:
        raise HTTPException(400, str(e))
    audit(db, user.id, "trend.add", t["id"])
    return t


# ------------------------------------------------------------------ v0.14 one link box + clip tracker --
@router.get("/link_check")
def link_check(url: str, user: User = Depends(current_user)):
    """Look at a link (no download) and say what kind of video it is: live now, upcoming,
    a long finished stream / podcast, or a normal video. Used by the single 'Paste a link' box."""
    from ..pipeline.url_import import is_direct_media, ytdlp_supported
    url = (url or "").strip()
    try:
        validate_url(url)
    except UnsafeURL as e:
        raise HTTPException(400, str(e))
    if is_direct_media(url):
        return {"kind": "video", "live": False, "title": url.rsplit("/", 1)[-1][:120], "duration": None,
                "site": "direct file", "suggest": "video", "why": "Direct video file"}
    if not ytdlp_supported(url):
        raise HTTPException(400, "This site isn't supported. Try a YouTube / Kick / Twitch / Vimeo link or a direct .mp4 link.")
    try:
        import yt_dlp
        opts = {"quiet": True, "no_warnings": True, "skip_download": True, "noplaylist": True,
                "socket_timeout": 20, "ignore_no_formats_error": True, "extract_flat": False,
                "js_runtimes": {"deno": {}, "node": {}}}
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
        except TypeError:                                  # older yt-dlp without js_runtimes
            opts.pop("js_runtimes", None)
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=False)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"Could not read this link: {str(e)[:200]}")
    status = info.get("live_status") or ("is_live" if info.get("is_live") else "not_live")
    dur = info.get("duration")
    site = info.get("extractor_key") or ""
    youtube = "youtube" in site.lower()
    if status == "is_live":
        suggest, why = "live", "This stream is LIVE right now"
    elif status == "is_upcoming":
        suggest, why = "live", "This stream has not started yet - ClipForge will wait for it"
    elif youtube and dur and dur >= 90 * 60:
        suggest, why = "scan", f"Long video ({int(dur // 3600)} h {int(dur % 3600 // 60)} min) - Smart scan avoids a full download"
    else:
        suggest, why = "video", "Normal video - download it and find the clips"
    return {"kind": suggest, "live": status == "is_live", "upcoming": status == "is_upcoming",
            "was_live": status == "was_live", "title": info.get("title") or "", "duration": dur,
            "uploader": info.get("uploader") or info.get("channel") or "", "site": site,
            "suggest": suggest, "why": why}


@router.get("/tracker")
def clip_tracker(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """Every clip with where it came from (project, live stream / video, part, position in the
    original) and the time of each step: video added, downloaded, analysed, clip selected,
    render queued, rendered, downloaded."""
    from ..tracking import clip_times, export_times, source_info
    pnames = {p.id: p.name for p in db.query(Project).all()}
    rows = db.query(Clip).order_by(Clip.created_at.desc()).limit(1500).all()
    vcache: dict = {}
    out = []
    for c in rows:
        v = c.video
        if v is None:
            continue
        if v.id not in vcache:
            vcache[v.id] = source_info(v, pnames.get(v.project_id))
        src = vcache[v.id]
        exps = sorted(c.exports, key=lambda e: e.created_at.isoformat() if e.created_at else "", reverse=True)
        out.append({"clip_id": c.id, "title": c.title, "score": c.score, "video_id": v.id,
                    "start": c.start, "end": c.end, "duration": round(c.end - c.start, 1),
                    "abs_start": round(src["offset"] + c.start, 1), "abs_end": round(src["offset"] + c.end, 1),
                    "label": c.label, "source": src, "times": clip_times(c),
                    "exports": [{"id": e.id, "status": e.status, "aspect": (e.params or {}).get("aspect"),
                                 "resolution": (e.params or {}).get("resolution"), "times": export_times(e),
                                 "error": (e.error or "")[:160]} for e in exps[:6]]})
    return {"clips": out, "projects": [{"id": k, "name": n} for k, n in pnames.items()]}


# ------------------------------------------------------- caption style library ----
@router.get("/caption_library")
def caption_library(clip_id: str | None = None, lang: str | None = None,
                    user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """All caption presets by section + fonts; with clip_id also the Auto pick and 4 suggestions."""
    from ..pipeline import caption_library as cl
    out = cl.library_json()
    text, deva = "", lang in ("hindi", "devanagari")
    if clip_id:
        c = db.get(Clip, clip_id)
        if c:
            words = [w for w in (c.video.transcript or []) if c.start - 0.1 <= w.get("s", 0) <= c.end + 0.1]
            if not lang or lang == "auto":
                from ..pipeline.caption_lang import script_of
                deva = deva or script_of(words) == "devanagari"
            text = f"{c.title or ''} {getattr(c.video, 'filename', '') or ''} " + " ".join(w.get("w", "") for w in words[:150])
    out["auto"] = cl.auto_pick(text, deva)
    out["suggested"] = cl.suggest(text, deva, 5)
    out["devanagari"] = deva
    return out


@router.get("/caption_fonts/{name}")
def caption_font_file(name: str):
    """Bundled caption fonts (OFL/Apache) for previews. Public: no user data."""
    from fastapi.responses import FileResponse
    from ..pipeline.caption_library import FONT_FILES
    from ..pipeline.captions import FONTS_DIR
    files = {v[1] for v in FONT_FILES.values()}
    if name not in files:
        raise HTTPException(404, "Unknown font")
    return FileResponse(FONTS_DIR / name, media_type="font/ttf", headers={"Cache-Control": "public, max-age=604800"})
