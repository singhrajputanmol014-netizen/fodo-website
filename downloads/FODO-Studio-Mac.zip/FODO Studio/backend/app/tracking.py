"""Where every video / clip came from and when each step happened (v0.14).

Read-only helpers: they only look at fields that already exist (Video.meta, Clip.settings,
Export.verification, created_at columns). Nothing here changes the database schema, so
older databases keep working and older rows simply show fewer timestamps.
"""
from __future__ import annotations

import datetime as _dt
from pathlib import Path


def now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


def _iso(d) -> str | None:
    if d is None:
        return None
    if isinstance(d, str):
        return d
    try:
        if d.tzinfo is None:                       # SQLite gives naive UTC values back
            d = d.replace(tzinfo=_dt.timezone.utc)
        return d.isoformat(timespec="seconds")
    except AttributeError:
        return None


KINDS = {
    "live": ("🔴", "Live stream"),
    "rewind": ("⏪", "Live stream (earlier hours)"),
    "scan": ("🎯", "Smart-scan moment"),
    "link": ("🔗", "Full video from link"),
    "upload": ("📁", "Uploaded file"),
}


def source_info(v, project_name: str | None = None) -> dict:
    """One plain description of a video: what kind of source it is, its title, project,
    where it sits inside the original stream / video, and the time of every step."""
    m = v.meta or {}
    if m.get("live_watch"):
        kind = "live"
    elif m.get("scan_id"):
        kind = "rewind" if m.get("live_rewind") else "scan"
    elif m.get("source_url"):
        kind = "link"
    else:
        kind = "upload"
    icon, label = KINDS[kind]
    title = m.get("source_title") or ""
    if not title and kind == "scan":
        title = str(v.filename or "").lstrip("✂ ").split(" · ")[0]
    if not title:
        title = Path(str(v.filename or "video")).stem
    offset = 0.0
    if kind == "live":
        offset = float(m.get("live_offset") or 0)
    elif kind in ("scan", "rewind") and m.get("section"):
        try:
            offset = float(m["section"][0])
        except (TypeError, ValueError, IndexError):
            offset = 0.0
    part = None
    if kind == "live":
        part = f"Part {m.get('live_part')}"
    elif kind in ("scan", "rewind"):
        mo = (m.get("auto_mode") or {}).get("moment") if isinstance(m.get("auto_mode"), dict) else None
        part = (mo or {}).get("title") or "Moment"
    return {
        "kind": kind, "icon": icon, "label": label, "title": title, "part": part,
        "offset": round(offset, 1),            # seconds into the ORIGINAL stream / video
        "url": m.get("source_url"), "site": m.get("source_site"), "uploader": m.get("source_uploader"),
        "live_watch": m.get("live_watch"), "scan_id": m.get("scan_id"),
        "project_id": v.project_id, "project_name": project_name,
        "duration": m.get("duration"), "status": v.status,
        "times": {
            "added": _iso(v.created_at),
            "downloaded": m.get("downloaded_at"),
            "analysis_started": m.get("analyze_started_at"),
            "analyzed": m.get("analyzed_at"),
        },
    }


def clip_times(c) -> dict:
    s = c.settings or {}
    return {"selected": s.get("selected_at") or _iso(c.created_at), "origin": s.get("origin") or "manual"}


def export_times(e) -> dict:
    ver = e.verification or {}
    return {"queued": _iso(e.created_at), "rendered": ver.get("rendered_at"),
            "downloaded": ver.get("downloaded_at"), "downloads": ver.get("downloads", 0)}
