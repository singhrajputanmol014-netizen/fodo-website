@echo off
cd /d "%~dp0"
title Install FODO Studio
echo Installing FODO Studio for this Windows user...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=Join-Path $env:LOCALAPPDATA 'FODO Studio'; New-Item -ItemType Directory -Force -Path $d | Out-Null; Get-ChildItem -Force -LiteralPath '%~dp0' | Where-Object { $_.Name -ne 'Install FODO Studio.bat' } | Copy-Item -Destination $d -Recurse -Force; $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path ([Environment]::GetFolderPath('Desktop')) 'FODO Studio.lnk')); $s.TargetPath=(Join-Path $d 'FODO Studio.bat'); $s.WorkingDirectory=$d; $s.IconLocation=(Join-Path $d 'fodo.ico'); $s.WindowStyle=7; $s.Save(); & (Join-Path $d 'setup.ps1')"
echo.
echo Done. Open FODO Studio from the icon on your desktop.
pause
