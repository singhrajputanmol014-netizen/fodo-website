"""Admin Control Panel: live hardware, what uses the GPU/CPU, health checks with one-click fixes,
runtime settings, maintenance actions and a diagnostics bundle. Admin / owner only."""
from __future__ import annotations

import io
import json
import os
import shlex
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session as DBSession

from .. import monitor, power, settings_store
from ..auth import audit, require_role
from ..config import BASE_DIR, STORAGE_DIR, UPLOADS_DIR, WORK_DIR
from ..database import get_db
from ..models import Export, Job, User, Video

router = APIRouter(prefix="/api/admin/panel")
_NO_WIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
ACTIONS: dict[str, dict] = {}          # name -> {status, log, started, finished}
_health_cache: dict = {"t": 0, "data": None}


def _run(cmd, timeout=60) -> tuple[int, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WIN)
        return r.returncode, (r.stdout + r.stderr)[-4000:]
    except Exception as e:  # noqa: BLE001
        return -1, str(e)


def _ollama_exe() -> str | None:
    for p in (Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Ollama" / "ollama.exe",   # Windows
              BASE_DIR / "tools" / "ollama" / "ollama",                                         # Mac installer
              Path("/Applications/Ollama.app/Contents/Resources/ollama")):                      # Mac app
        if os.environ.get("LOCALAPPDATA") or p.parts[0] == "/":
            if p.exists():
                return str(p)
    return shutil.which("ollama")


def _setup_hint() -> str:
    return "run setup.bat again" if sys.platform == "win32" else "run setup.sh again (FODO Studio folder)"


def _http_json(url: str, timeout: float = 2.0):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode())


# ------------------------------------------------------------------- health ----
def _checks() -> list[dict]:
    from ..jobs import worker_alive
    from ..pipeline import llm
    from ..pipeline.transcribe import cuda_usable, last_transcription_info
    from ..system import _hw_encoder_works
    out = []

    def add(key, name, ok, detail, fix=None, level=None, uses=None):
        out.append({"key": key, "name": name, "status": level or ("ok" if ok else "fail"), "detail": detail,
                    "fix": fix, "uses": uses})

    code, txt = _run(["ffmpeg", "-version"], 15)
    add("ffmpeg", "FFmpeg (video engine)", code == 0, txt.splitlines()[0] if code == 0 else "FFmpeg not found - " + _setup_hint())
    from .. import power as _power
    hw = _power.hardware()
    g = monitor.snapshot().get("gpu") or (monitor._gpu() if hasattr(monitor, "_gpu") else None)
    gpus = ", ".join(x["name"] for x in hw.get("gpus") or []) or "none found"
    add("gpu", "Graphics card", True,
        (f"{g['name']} · driver {g['driver']} · {g['mem_total']:.0f} MB VRAM" if g else gpus)
        + f" · power plan: {_power.effective_mode()}", level="ok")
    from ..system import detect_hardware
    hw_list = [e for e in detect_hardware().get("hardware_encoders", []) if e.startswith("h264_")]
    use_hw = settings_store.get("hw_encode")
    if hw_list:
        enc = hw_list[0]
        works = _hw_encoder_works(enc)
        label = {"nvenc": "NVIDIA NVENC", "qsv": "Intel Quick Sync", "amf": "AMD AMF", "videotoolbox": "Apple VideoToolbox"}.get(enc.split("_")[-1], enc)
        add("nvenc", f"GPU video encoding ({label})", works and use_hw,
            ("Working - clips are encoded on the graphics card" if use_hw else "Works, but switched OFF in settings (CPU encoding is slower)")
            if works else "Not working - clips are encoded on the CPU (slower). Re-test after a driver update.",
            fix="retest_nvenc", level=None if (works and use_hw) else "warn", uses="GPU" if works and use_hw else "CPU")
    else:
        add("nvenc", "Video encoding", True, "CPU (x264): this PC has no graphics-card encoder FFmpeg can use. "
            "Clips still render; the power plan keeps it smooth.", level="ok", uses="CPU")
    dev = settings_store.get("whisper_device")
    info = last_transcription_info() or {}
    if g:                                       # NVIDIA present: GPU speech AI is worth having
        cuda = cuda_usable()
        add("whisper_gpu", "AI transcription on GPU (Whisper CUDA)", cuda and dev != "cpu",
            (f"Ready on GPU" + (f" - last run {info.get('speed_x_realtime')}x realtime on {info.get('device')}" if info.get("device") else ""))
            if cuda else "CUDA libraries not usable - transcription falls back to the CPU (about 4x slower)",
            fix=None if cuda else "install_cuda", level=None if (cuda and dev != "cpu") else "warn",
            uses="GPU" if cuda and dev != "cpu" else "CPU")
    else:
        add("whisper_gpu", "AI transcription", True,
            f"Runs on the CPU with {_power.cpu_threads()} threads (no NVIDIA card)"
            + (f" - last run {info.get('speed_x_realtime')}x realtime" if info.get("speed_x_realtime") else ""),
            level="ok", uses="CPU")
    st = llm.status()
    add("ollama", "Local AI (Ollama) running", st.get("available"),
        "Running" if st.get("available") else "Not running - topic titles & viral ratings use the simpler fallback",
        fix=None if st.get("available") else "start_ollama", level=None if st.get("available") else "warn")
    if st.get("available"):
        add("llm_model", f"AI model {st.get('configured')}", st.get("model_installed"),
            "Installed" if st.get("model_installed") else "Model not downloaded (~2 GB)",
            fix=None if st.get("model_installed") else "pull_llm", level=None if st.get("model_installed") else "warn")
    cap_model = settings_store.get("caption_model")
    cached = any(cap_model in p.name for p in (Path.home() / ".cache" / "huggingface" / "hub").glob("models--*")) \
        if (Path.home() / ".cache" / "huggingface" / "hub").exists() else False
    add("caption_model", f"Accurate-captions model ({cap_model})", cached,
        "Downloaded" if cached else "Not downloaded yet - downloads on first 'Accurate captions' (~1.6 GB). Download now to avoid the wait.",
        fix=None if cached else "download_caption_model", level=None if cached else "warn")
    code, ver = _run([sys.executable, "-m", "yt_dlp", "--version"], 30)
    add("ytdlp", "Link downloader (yt-dlp)", code == 0, f"version {ver.strip()}" if code == 0 else "yt-dlp missing",
        fix="update_ytdlp")
    deno = shutil.which("deno") or shutil.which("node")
    add("deno", "YouTube JS runtime (Deno)", bool(deno), deno or "Deno not found - some YouTube links fail. " + _setup_hint().capitalize(),
        level=None if deno else "warn")
    try:
        _http_json("https://api.openverse.org/v1/audio/?q=lofi&page_size=1", 6)
        add("openverse", "Online music library (Openverse)", True, "Reachable")
    except Exception as e:  # noqa: BLE001
        add("openverse", "Online music library (Openverse)", False, f"Not reachable ({str(e)[:60]})", level="warn")
    du = shutil.disk_usage(str(STORAGE_DIR))
    gb = du.free / 1e9
    add("disk", "Free disk space", gb > 10, f"{gb:.1f} GB free",
        fix="clear_temp", level="ok" if gb > 25 else ("warn" if gb > 10 else "fail"))
    add("worker", "Background job worker", worker_alive(), "Running" if worker_alive() else "Stopped - nothing will process",
        fix=None if worker_alive() else "restart_worker")
    return out


# ------------------------------------------------------------------ actions ----
def _bg(name: str, fn) -> dict:
    cur = ACTIONS.get(name)
    if cur and cur["status"] == "running":
        return cur
    st = {"status": "running", "log": "", "started": time.time(), "finished": None}
    ACTIONS[name] = st

    def run():
        try:
            st["log"] = fn() or "Done"
            st["status"] = "done"
        except Exception as e:  # noqa: BLE001
            st["log"] = f"{type(e).__name__}: {e}"
            st["status"] = "failed"
        st["finished"] = time.time()
        _health_cache["t"] = 0
    threading.Thread(target=run, daemon=True).start()
    return st


def _act_retest_nvenc():
    from .. import system
    system._HW_CACHE.clear()
    ok = system._hw_encoder_works("h264_nvenc")
    return "NVENC works" if ok else "NVENC still not working - update the NVIDIA driver (GeForce Experience / nvidia.com)"


def _act_install_cuda():
    code, out = _run([sys.executable, "-m", "pip", "install", "--upgrade", "nvidia-cublas-cu12", "nvidia-cudnn-cu12==9.*"], 1800)
    from ..pipeline import transcribe
    if hasattr(transcribe.cuda_usable, "cache_clear"):
        transcribe.cuda_usable.cache_clear()
    return out[-1500:] + ("\nInstalled - restart the server to use the GPU." if code == 0 else "\nInstall failed")


def _act_start_ollama():
    exe = _ollama_exe()
    if not exe:
        return "Ollama is not installed - " + _setup_hint() + "."
    subprocess.Popen([exe, "serve"], creationflags=_NO_WIN | getattr(subprocess, "DETACHED_PROCESS", 0),
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(20):
        time.sleep(1)
        try:
            _http_json("http://127.0.0.1:11434/api/tags", 1)
            return "Ollama started"
        except Exception:  # noqa: BLE001
            pass
    return "Started, but not answering yet - check again in a minute"


def _act_pull_llm():
    exe = _ollama_exe()
    if not exe:
        return "Ollama is not installed - " + _setup_hint() + "."
    code, out = _run([exe, "pull", settings_store.get("llm_model")], 3600)
    return out[-800:] if out else ("Done" if code == 0 else "Failed")


def _act_download_caption_model():
    from faster_whisper import download_model
    path = download_model(settings_store.get("caption_model"))
    return f"Downloaded to {path}"


def _act_update_ytdlp():
    code, out = _run([sys.executable, "-m", "pip", "install", "--upgrade", "yt-dlp[default]"], 900)
    return out[-1200:]


def _act_clear_temp():
    freed = 0
    for p in WORK_DIR.iterdir() if WORK_DIR.exists() else []:
        if p.is_dir():
            freed += sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
            shutil.rmtree(p, ignore_errors=True)
    return f"Freed {freed / 1e6:.0f} MB of temporary work files"


def _act_retry_failed(db: DBSession):
    n = 0
    for j in db.query(Job).filter(Job.status == "failed").all():
        j.status, j.error, j.progress = "queued", None, 0.0
        n += 1
    db.commit()
    from ..jobs import _wake
    _wake.set()
    return f"Re-queued {n} failed job(s)"


def _act_cancel_all(db: DBSession):
    from ..jobs import cancel
    n = sum(int(cancel(j.id)) for j in db.query(Job).filter(Job.status.in_(("queued", "running"))).all())
    return f"Cancelled {n} job(s)"


def _act_restart_worker():
    from ..jobs import start_worker, worker_alive
    if worker_alive():
        return "Worker already running"
    start_worker()
    return "Worker restarted"


def _act_restart_server():
    bat = BASE_DIR / "run.bat"
    if sys.platform == "win32" and bat.exists():          # FODO's own copy: run.bat stops the old server itself
        subprocess.Popen(["cmd", "/c", "start", "", str(bat)], cwd=str(BASE_DIR),
                         creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
        return "Restarting… the page reconnects in about 15 seconds"
    launcher = BASE_DIR / "FODO Studio.bat"
    if sys.platform == "win32" and launcher.exists():     # installed copy: start again after this one exits
        helper = BASE_DIR / "restart_fodo.bat"
        helper.write_text('@echo off\r\ntimeout /t 3 /nobreak >nul\r\ncall "%~dp0FODO Studio.bat"\r\n', encoding="ascii")
        subprocess.Popen(["cmd", "/c", "start", "", "/min", str(helper)], cwd=str(BASE_DIR),
                         creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
        threading.Timer(1.0, lambda: os._exit(0)).start()
        return "Restarting… the page reconnects in about 15 seconds"
    cmd = BASE_DIR / "FODO Studio.command"
    if sys.platform == "darwin" and cmd.exists():
        # a fresh Terminal window starts the server again; this process exits a moment later
        subprocess.Popen(["/bin/bash", "-c", f"sleep 3; open -a Terminal {shlex.quote(str(cmd))}"],
                         start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        threading.Timer(1.0, lambda: os._exit(0)).start()
        return "Restarting… the page reconnects in about 15 seconds"
    return "Restart this copy by closing its window and opening FODO Studio again"


SIMPLE = {"retest_nvenc": _act_retest_nvenc, "install_cuda": _act_install_cuda, "start_ollama": _act_start_ollama,
          "pull_llm": _act_pull_llm, "download_caption_model": _act_download_caption_model,
          "update_ytdlp": _act_update_ytdlp, "clear_temp": _act_clear_temp, "restart_worker": _act_restart_worker}
ACTION_LABELS = {"retest_nvenc": "Re-test GPU encoding", "install_cuda": "Install GPU (CUDA) libraries for Whisper",
                 "start_ollama": "Start local AI (Ollama)", "pull_llm": "Download AI model",
                 "download_caption_model": "Download accurate-captions model",
                 "update_ytdlp": "Update link downloader (yt-dlp)", "clear_temp": "Clear temporary files",
                 "restart_worker": "Restart job worker", "retry_failed": "Retry failed jobs",
                 "cancel_all": "Stop all jobs", "restart_server": "Restart ClipForge server"}


# ------------------------------------------------------------------ routes ----
@router.get("")
def panel(user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    from ..activity import steps_for
    from ..pipeline.transcribe import last_transcription_info
    snap = monitor.snapshot()
    run = db.query(Job).filter(Job.status == "running").first()
    queued = db.query(Job).filter(Job.status == "queued").count()
    current = None
    if run:
        current = {"id": run.id, "kind": run.kind, "stage": run.stage, "progress": run.progress,
                   "steps": steps_for(run.id)[-4:]}
    last_exp = db.query(Export).filter(Export.status == "done").order_by(Export.created_at.desc()).first()
    enc = ((last_exp.verification or {}).get("output") or {}).get("encoder") if last_exp else None
    g = snap.get("gpu") or {}
    oll = snap.get("ollama") or {}
    stage = (current or {}).get("stage", "").lower()
    usage = [
        {"name": "Video encoding", "where": "GPU (NVENC)" if (enc or "").endswith("nvenc") else ("CPU (x264)" if enc else "—"),
         "active": "render" in stage or "encode" in stage or "piece" in stage, "detail": f"last clip: {enc or 'none yet'}"},
        {"name": "AI transcription (Whisper)", "where": (last_transcription_info() or {}).get("device", "—").upper(),
         "active": "transcrib" in stage or "caption" in stage, "detail": "speech → text"},
        {"name": "Face & camera-cut tracking", "where": "CPU (OpenCV)", "active": "track" in stage, "detail": "who is speaking"},
        {"name": "Local AI titles (Ollama)",
         "where": ("GPU" if any(m.get("vram") for m in oll.get("loaded", [])) else "CPU") if oll.get("loaded") else ("idle" if oll.get("running") else "stopped"),
         "active": "ai reading" in stage, "detail": ", ".join(m["name"] for m in oll.get("loaded", [])) or "no model loaded"},
    ]
    return {"live": snap, "history": monitor.history(), "current": current, "queued": queued, "usage": usage,
            "gpu_apps": g.get("apps", []), "settings": _panel_settings(), "choices": settings_store.CHOICES,
            "power": power.status(),
            "actions": {k: {**v, "label": ACTION_LABELS.get(k, k)} for k, v in ACTIONS.items()},
            "action_labels": ACTION_LABELS, "python": sys.version.split()[0], "pid": os.getpid(),
            "platform": sys.platform, "nvidia": bool(g)}


@router.get("/health")
def health(refresh: bool = False, user: User = Depends(require_role("admin"))):
    if refresh or not _health_cache["data"] or time.time() - _health_cache["t"] > 60:
        _health_cache["data"] = _checks()
        _health_cache["t"] = time.time()
    return {"checks": _health_cache["data"], "checked_at": _health_cache["t"]}


@router.post("/action/{name}")
def action(name: str, user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    audit(db, user.id, "admin.action", name)
    if name in SIMPLE:
        return _bg(name, SIMPLE[name])
    if name == "retry_failed":
        return {"status": "done", "log": _act_retry_failed(db)}
    if name == "cancel_all":
        return {"status": "done", "log": _act_cancel_all(db)}
    if name == "restart_server":
        msg = _act_restart_server()
        return {"status": "done", "log": msg}
    raise HTTPException(404, "Unknown action")


def _panel_settings() -> dict:
    """What the owner chose; speech models stay "" (= Auto, follow the power plan) until picked."""
    s = settings_store.raw()
    ex = settings_store.explicit()
    for k in settings_store.POWER_KEYS:
        s[k] = ex.get(k) or ""
    return s


@router.get("/settings")
def get_settings(user: User = Depends(require_role("admin"))):
    return {"settings": _panel_settings(), "choices": settings_store.CHOICES, "power": power.status()}


@router.get("/power")
def power_status(user: User = Depends(require_role("admin"))):
    return power.status()


@router.post("/power")
def power_set(payload: dict, user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    m = (payload or {}).get("mode")
    if m not in power.MODES:
        raise HTTPException(400, "Unknown power mode")
    settings_store.update({"power_mode": m})
    power.apply_priority()
    audit(db, user.id, "admin.power", m)
    return power.status()


@router.post("/power/refresh")
def power_refresh(user: User = Depends(require_role("admin"))):
    power.refresh()
    power.apply_priority()
    return power.status()


@router.post("/settings")
def set_settings(payload: dict, user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    s = settings_store.update(payload or {})
    audit(db, user.id, "admin.settings", json.dumps(payload)[:300])
    _health_cache["t"] = 0
    return {"settings": s}


@router.get("/diagnostics")
def diagnostics(user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    """One zip with everything needed to understand a problem (no passwords, no videos)."""
    from ..activity import recent_logs
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("health.json", json.dumps(_checks(), indent=1, default=str))
        z.writestr("live.json", json.dumps({"live": monitor.snapshot(), "history": monitor.history()}, indent=1, default=str))
        z.writestr("settings.json", json.dumps(settings_store.load(), indent=1))
        z.writestr("recent_logs.json", json.dumps(recent_logs(), indent=1, default=str))
        jobs = [{"kind": j.kind, "status": j.status, "stage": j.stage, "error": j.error,
                 "created": j.created_at.isoformat()} for j in db.query(Job).order_by(Job.created_at.desc()).limit(60)]
        z.writestr("jobs.json", json.dumps(jobs, indent=1))
        for name in ("run_log.txt", "setup_log.txt"):
            p = BASE_DIR / name
            if p.exists():
                z.writestr(name, p.read_text(encoding="utf-8", errors="replace")[-400_000:])
    buf.seek(0)
    audit(db, user.id, "admin.diagnostics", "")
    return StreamingResponse(buf, media_type="application/zip",
                             headers={"Content-Disposition": f'attachment; filename="clipforge-diagnostics-{time.strftime("%Y%m%d-%H%M")}.zip"'})
