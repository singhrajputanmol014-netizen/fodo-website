"""Admin-editable runtime settings (storage/settings.json). Read on every use, so a change in
the Control Panel applies to the next job without restarting the server."""
from __future__ import annotations

import json
import threading
from pathlib import Path

from .config import STORAGE_DIR

PATH = STORAGE_DIR / "settings.json"
_lock = threading.Lock()

DEFAULTS: dict = {
    "whisper_device": "auto",            # auto | cuda | cpu
    "whisper_model": "",                 # "" = config default (small)
    "caption_model": "",                 # "" = this PC's power plan picks the "Accurate captions" model
    "llm_model": "qwen2.5:3b",           # Ollama model for topic titles / viral rating
    "use_llm": True,
    "hw_encode": True,                   # NVENC / QSV when available
    "default_preset": "podcast_pro",
    "default_resolution": "1080p",
    "quality_check": True,               # inspect every finished export (Quality Inspector)
    "auto_repair_passes": 2,             # extra render passes the repair loop may use (0 = report only)
    "power_mode": "auto",                # auto | max | balanced | saver (power.py picks from the hardware)
}
# Keys the power engine fills in when the owner has not chosen them in the Control Panel.
POWER_KEYS = {"whisper_model": "whisper", "caption_model": "caption"}
CHOICES = {
    "whisper_device": ["auto", "cuda", "cpu"],
    "whisper_model": ["", "tiny", "base", "small", "medium", "large-v3-turbo", "large-v3"],
    "caption_model": ["", "large-v3-turbo", "medium", "small", "large-v3"],
    "default_resolution": ["720p", "1080p", "1440p", "2160p"],
    "auto_repair_passes": [0, 1, 2, 3],
    "power_mode": ["auto", "max", "balanced", "saver"],
}


def _file() -> dict:
    with _lock:
        try:
            data = json.loads(Path(PATH).read_text(encoding="utf-8-sig"))
        except (OSError, ValueError):
            data = {}
    return {k: v for k, v in data.items() if k in DEFAULTS}


def raw() -> dict:
    """Settings without the power profile (power.py reads the mode from here)."""
    return {**DEFAULTS, **_file()}


def load() -> dict:
    data = _file()
    out = {**DEFAULTS, **data}
    try:
        from . import power
        pl = power.plan()
        for k, src in POWER_KEYS.items():
            if not data.get(k):              # not chosen by the owner -> follow this PC's power plan
                out[k] = pl[src]
    except Exception:  # noqa: BLE001
        pass
    return out


def explicit() -> dict:
    """Only what the owner actually chose (for the Control Panel)."""
    return _file()


def get(key: str):
    return load().get(key, DEFAULTS.get(key))


def update(changes: dict) -> dict:
    cur = raw()
    for k, v in changes.items():
        if k not in DEFAULTS:
            continue
        if isinstance(DEFAULTS[k], bool):
            v = bool(v)
        elif k in CHOICES and v not in CHOICES[k]:
            continue
        elif not isinstance(v, str) or len(v) > 80:
            continue
        cur[k] = v
    with _lock:
        PATH.parent.mkdir(parents=True, exist_ok=True)
        PATH.write_text(json.dumps(cur, indent=1), encoding="utf-8")
    return cur
