"""Live stream watcher: record a live stream in short parts while it is on air and hand every finished
part to the normal pipeline (transcribe -> find topics -> score -> optional automatic clips).

  watch = one live link being followed. A background thread:
    1. asks yt-dlp for the live playlist (waits if the stream has not started yet),
    2. runs FFmpeg copying the stream into parts of N minutes (no re-encode, light on the PC),
    3. every finished part becomes a normal Video in the project and is queued for analysis.
       With auto clips on, topics scoring >= min_score are rendered automatically (max per part).
  The playlist link expires after a few hours, so FFmpeg is restarted with a fresh link while the
  stream is still live. Stops on: Stop button, stream end, max hours, low disk space.

Only for streams the user owns or has permission to clip (the UI asks for that confirmation).
State lives in storage/live_watches.json; recordings in storage/live/<id>/ until they are imported.
"""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
import threading
import time
import uuid
from pathlib import Path

from .config import STORAGE_DIR, UPLOADS_DIR

log = logging.getLogger("clipforge.live")
PATH = STORAGE_DIR / "live_watches.json"
LIVE_DIR = STORAGE_DIR / "live"
MAX_ACTIVE = 2
MIN_FREE_GB = 5.0
WAIT_FOR_START_MIN = 180
_lock = threading.RLock()
_threads: dict[str, "Watcher"] = {}
ACTIVE = ("starting", "waiting", "watching", "stopping")


# ------------------------------------------------------------------ store --
def _read() -> dict:
    try:
        return json.loads(PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _write(d: dict) -> None:
    PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(PATH)


def _update(wid: str, **kw) -> dict:
    with _lock:
        d = _read()
        w = d.get(wid)
        if w is None:
            return {}
        w.update(kw)
        _write(d)
        return w


def list_all() -> list[dict]:
    return sorted(_read().values(), key=lambda w: w.get("created", 0), reverse=True)


def get(wid: str) -> dict | None:
    return _read().get(wid)


def mark_interrupted() -> None:
    """Called at server start. A watch that was recording when the server stopped carries on by itself
    (until its original end time); one already past its end time is closed."""
    resume = []
    with _lock:
        d = _read()
        ch = False
        for w in d.values():
            if w.get("status") in ACTIVE and w["id"] not in _threads:
                ch = True
                if w.get("status") == "stopping" or time.time() > w.get("created", 0) + w.get("max_hours", 4) * 3600:
                    w["status"], w["note"] = "stopped", "Server was restarted."
                else:
                    w["status"], w["note"] = "starting", "Server was restarted - carrying on…"
                    resume.append(w["id"])
        if ch:
            _write(d)
    for wid in resume:
        t = Watcher(wid)
        _threads[wid] = t
        t.start()
        log.info("live %s: resumed after server restart", wid)


# ------------------------------------------------------------------ stream lookup --
def resolve(url: str) -> dict:
    """{'live': bool, 'upcoming': bool, 'title', 'uploader', 'input': [ffmpeg input args]} via yt-dlp."""
    import yt_dlp
    opts = {"quiet": True, "no_warnings": True, "skip_download": True, "noplaylist": True,
            "format": "b[height<=1080]/bv*[height<=1080]+ba/b", "js_runtimes": {"deno": {}, "node": {}},
            "socket_timeout": 30, "ignore_no_formats_error": True}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)
    status = info.get("live_status") or ("is_live" if info.get("is_live") else "not_live")
    out = {"live": status == "is_live", "upcoming": status == "is_upcoming", "status": status,
           "title": info.get("title") or "Live stream", "uploader": info.get("uploader") or info.get("channel") or "",
           "site": info.get("extractor_key") or "", "input": None}
    if out["live"]:
        fmts = info.get("requested_formats") or [info]
        args = []
        for f in fmts:
            if not f.get("url"):
                continue
            hdr = "".join(f"{k}: {v}\r\n" for k, v in (f.get("http_headers") or {}).items())
            args += (["-headers", hdr] if hdr else []) + ["-i", f["url"]]
        out["input"] = args or None
        out["height"] = info.get("height")
    return out


def _kill_orphan_recorders(folder: Path, pid: int | None) -> None:
    """A recorder FFmpeg left running by a previous server process would keep writing into this folder."""
    import os
    import sys
    try:
        if sys.platform == "win32":
            ps = ("Get-CimInstance Win32_Process -Filter \"Name='ffmpeg.exe'\" | Where-Object { $_.CommandLine -like '*"
                  + str(folder).replace("'", "''") + "*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }")
            subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, timeout=30,
                           creationflags=0x08000000)
        else:
            subprocess.run(["pkill", "-f", str(folder)], capture_output=True, timeout=10)
            if pid:
                try:
                    os.kill(int(pid), 9)
                except OSError:
                    pass
        time.sleep(2)
    except Exception:  # noqa: BLE001
        log.exception("could not stop an old recorder")


def resume(wid: str) -> dict:
    """Carry on a stopped / failed watch (same link and settings) until its original end time."""
    with _lock:
        w = get(wid)
        if w is None:
            raise ValueError("Watch not found")
        if wid in _threads:
            raise ValueError("Already running")
        if time.time() > w.get("created", 0) + w.get("max_hours", 4) * 3600:
            w = _update(wid, created=int(time.time()))     # past its end: start a fresh window
        active = [x for x in _read().values() if x["id"] in _threads]
        if len(active) >= MAX_ACTIVE:
            raise ValueError(f"Already watching {MAX_ACTIVE} streams - stop one first.")
        w = _update(wid, status="starting", note="Carrying on…")
        t = Watcher(wid)
        _threads[wid] = t
        t.start()
    return w


# ------------------------------------------------------------------ the watcher --
class Watcher(threading.Thread):
    def __init__(self, wid: str):
        super().__init__(daemon=True, name=f"live-{wid}")
        self.wid = wid
        self.stop_flag = threading.Event()
        self.proc: subprocess.Popen | None = None
        self.dir = LIVE_DIR / wid
        self.run_no = 0
        self._tries: dict[str, int] = {}
        self._gave_up: set = set()

    # -- helpers
    def _w(self) -> dict:
        return get(self.wid) or {}

    def _free_gb(self) -> float:
        return shutil.disk_usage(STORAGE_DIR).free / 1e9

    def _start_ffmpeg(self, input_args: list[str], seconds: int) -> None:
        self.run_no += 1
        self.dir.mkdir(parents=True, exist_ok=True)
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *input_args,
               "-c", "copy", "-bsf:a", "aac_adtstoasc", "-f", "segment", "-segment_time", str(seconds),
               "-reset_timestamps", "1", "-segment_format", "mp4",
               str(self.dir / f"r{self.run_no:02d}_%04d.mp4")]
        kw = {"creationflags": 0x08000000} if hasattr(subprocess, "CREATE_NO_WINDOW") else {}
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                                     stderr=subprocess.PIPE, **kw)
        _update(self.wid, ffmpeg_pid=self.proc.pid)

    def _stop_ffmpeg(self) -> None:
        p = self.proc
        if not p or p.poll() is not None:
            return
        try:
            p.stdin.write(b"q")          # lets FFmpeg close the current part properly
            p.stdin.flush()
            p.wait(timeout=15)
        except Exception:  # noqa: BLE001
            p.terminate()
            try:
                p.wait(timeout=5)
            except Exception:  # noqa: BLE001
                p.kill()

    def _import_finished(self, final: bool) -> None:
        """Hand over every finished part (all but the newest while FFmpeg is still writing it)."""
        # parts that an earlier version gave up on too early (read before FFmpeg had closed them)
        for f in sorted(self.dir.glob("r*_*.failed")):
            if (f.stem, f.stat().st_size) not in self._gave_up:
                try:
                    f.rename(f.with_suffix(".mp4"))
                except OSError:
                    pass
        files = sorted(self.dir.glob("r*_*.mp4"))
        ready = files if final else files[:-1]
        for f in ready:
            try:
                if f.stat().st_size < 200_000:        # a broken / empty tail
                    f.unlink(missing_ok=True)
                    continue
                # FFmpeg finishes a part a moment AFTER it opens the next one (it writes the index last):
                # wait until the file has been quiet for a while before reading it
                if not final and time.time() - f.stat().st_mtime < 20:
                    continue
                self._to_video(f)
            except Exception as e:  # noqa: BLE001
                tries = self._tries.get(f.name, 0) + 1
                self._tries[f.name] = tries
                if tries < 4 and not final:
                    log.warning("live %s: part %s not readable yet (try %d): %s", self.wid, f.name, tries, e)
                    continue                           # read it again next round
                log.exception("live %s: part %s failed", self.wid, f.name)
                _update(self.wid, note=f"Part {f.name} could not be used (it may be cut off)."[:300])
                try:
                    self._gave_up.add((f.stem, f.stat().st_size))
                    f.rename(f.with_suffix(".failed"))
                except OSError:
                    pass                               # still open somewhere - try again next round

    def _to_video(self, f: Path) -> None:
        from .database import SessionLocal
        from .jobs import enqueue
        from .models import Video
        from .pipeline.metadata import extract_metadata
        w = self._w()
        n = len(w.get("parts", [])) + 1
        meta = extract_metadata(f)
        dur = float(meta.get("duration") or 0)
        if dur < 20:
            f.unlink(missing_ok=True)
            return
        offset = float(w.get("recorded_seconds", 0))
        db = SessionLocal()
        try:
            auto = None
            if w.get("auto_clips"):
                auto = {"aspect": w.get("aspect", "9:16"),
                        "live": {"min_score": w.get("min_score", 60), "max_clips": w.get("max_clips", 2)}}
            from .models import Project
            pid = w["project_id"]
            if db.get(Project, pid) is None:           # the project was deleted while the stream ran
                pr = db.query(Project).filter_by(name="Live streams", owner_id=w.get("user_id")).first()
                if pr is None:
                    pr = Project(name="Live streams", owner_id=w.get("user_id"))
                    db.add(pr)
                    db.commit()
                pid = pr.id
                _update(self.wid, project_id=pid)
                log.info("live %s: project was deleted - parts now go to 'Live streams'", self.wid)
            hh, mm = int(offset // 3600), int(offset % 3600 // 60)
            v = Video(project_id=pid, path="", status="uploaded",
                      filename=f"🔴 {w.get('title', 'Live')[:150]} · part {n} ({hh}:{mm:02d}).mp4",
                      meta={**meta, "source_url": w["url"], "source_title": w.get("title"),
                            "source_uploader": w.get("uploader"), "source_site": w.get("site"),
                            "live_watch": self.wid, "live_part": n, "live_offset": round(offset, 1),
                            "auto_mode": auto})
            db.add(v)
            db.commit()
            UPLOADS_DIR.mkdir(parents=True, exist_ok=True)
            dest = UPLOADS_DIR / f"{v.id}.mp4"
            shutil.move(str(f), dest)
            v.path = str(dest)
            db.commit()                                   # path must be saved before the worker picks the job
            v.meta = {**v.meta, "analyze_job": enqueue("analyze", v.id)}
            db.commit()
            vid = v.id
        finally:
            db.close()
        with _lock:
            d = _read()
            x = d.get(self.wid)
            if x is not None:
                x.setdefault("parts", []).append({"n": n, "video_id": vid, "offset": round(offset, 1),
                                                  "duration": round(dur, 1), "at": int(time.time())})
                x["recorded_seconds"] = round(offset + dur, 1)
                _write(d)
        log.info("live %s: part %d (%.0f s) queued for analysis", self.wid, n, dur)

    def _retry_failed_parts(self) -> None:
        """Re-queue analysis for parts whose analysis failed (e.g. after a crash or a fixed bug)."""
        from .database import SessionLocal
        from .jobs import enqueue
        from .models import Video
        ids = [p["video_id"] for p in self._w().get("parts", [])]
        if not ids:
            return
        db = SessionLocal()
        try:
            for v in db.query(Video).filter(Video.id.in_(ids), Video.status == "failed").all():
                if v.path and Path(v.path).exists():
                    v.status = "uploaded"
                    db.commit()
                    v.meta = {**(v.meta or {}), "analyze_job": enqueue("analyze", v.id)}
                    db.commit()
                    log.info("live %s: re-queued analysis of %s", self.wid, v.filename)
        finally:
            db.close()

    # -- main loop
    def run(self) -> None:
        try:
            self._run()
        except Exception as e:  # noqa: BLE001
            log.exception("live watch %s crashed", self.wid)
            _update(self.wid, status="error", note=str(e)[:300], ended=int(time.time()))
        finally:
            self._stop_ffmpeg()
            try:
                self._import_finished(final=True)
            except Exception:  # noqa: BLE001
                log.exception("live %s: final import failed", self.wid)
            _threads.pop(self.wid, None)

    def _run(self) -> None:
        w = self._w()
        url, seconds = w["url"], int(w["chunk_minutes"] * 60)
        deadline = w.get("created", time.time()) + w["max_hours"] * 3600
        self.dir.mkdir(parents=True, exist_ok=True)
        _kill_orphan_recorders(self.dir, w.get("ffmpeg_pid"))
        old = sorted(self.dir.glob("r*_*.mp4"))
        self.run_no = max((int(f.name[1:3]) for f in old if f.name[1:3].isdigit()), default=0)
        if old:                                   # parts left over from before a restart
            self._import_finished(final=True)
        self._retry_failed_parts()
        was_live = bool(w.get("parts"))
        wait_until = time.time() + WAIT_FOR_START_MIN * 60
        fails = 0
        while not self.stop_flag.is_set() and time.time() < deadline:
            if self._free_gb() < MIN_FREE_GB:
                _update(self.wid, status="stopped", note=f"Stopped: less than {MIN_FREE_GB:.0f} GB free on the disk.",
                        ended=int(time.time()))
                return
            try:
                info = resolve(url)
                fails = 0
            except Exception as e:  # noqa: BLE001
                msg = str(e).lower()
                if not was_live and any(k in msg for k in ("will begin", "premiere", "not currently live", "offline",
                                                             "is not live", "scheduled")) \
                        and w.get("wait_for_start") and time.time() < wait_until:
                    _update(self.wid, status="waiting", note="Waiting for the stream to start…")
                    self.stop_flag.wait(60)
                    continue
                fails += 1
                if fails >= 4:
                    _update(self.wid, status="ended" if was_live else "error", ended=int(time.time()),
                            note=("Stream ended." if was_live else f"Could not open the stream: {e}")[:300])
                    return
                self.stop_flag.wait(20)
                continue
            _update(self.wid, title=info["title"], uploader=info["uploader"], site=info["site"])
            if not info["live"] or not info["input"]:
                if was_live:
                    _update(self.wid, status="ended", note="Stream ended.", ended=int(time.time()))
                    return
                if time.time() > wait_until or not (info["upcoming"] or w.get("wait_for_start")):
                    _update(self.wid, status="error", ended=int(time.time()),
                            note="This link is not live right now. For a finished stream use the normal link import.")
                    return
                _update(self.wid, status="waiting", note="Waiting for the stream to start…")
                self.stop_flag.wait(60)
                continue
            was_live = True
            _update(self.wid, status="watching", note="")
            self._start_ffmpeg(info["input"], seconds)
            t0 = time.time()
            while self.proc.poll() is None:
                if self.stop_flag.wait(5) or time.time() > deadline:
                    break
                self._import_finished(final=False)
                if self._free_gb() < MIN_FREE_GB:
                    break
            err = ""
            if self.proc.poll() is not None:
                try:
                    err = (self.proc.stderr.read() or b"").decode("utf-8", "replace")[-300:]
                except Exception:  # noqa: BLE001
                    pass
            self._stop_ffmpeg()
            self._import_finished(final=True)
            if self.stop_flag.is_set():
                break
            if time.time() - t0 < 20:      # FFmpeg died straight away: do not spin
                fails += 1
                if fails >= 3:
                    _update(self.wid, status="error", ended=int(time.time()),
                            note=("Recording keeps failing. " + err)[:300])
                    return
                self.stop_flag.wait(15)
        st = self._w().get("status")
        if st in ACTIVE:
            _update(self.wid, status="stopped", ended=int(time.time()),
                    note="Stopped by you." if self.stop_flag.is_set() else f"Reached the {w['max_hours']} hour limit.")


# ------------------------------------------------------------------ API used by the routes --
def _same_stream_key(url: str) -> str:
    """youtube.com/live/ID?si=a and youtube.com/watch?v=ID&si=b are the same stream."""
    import re
    import urllib.parse
    u = urllib.parse.urlparse(url.strip())
    q = urllib.parse.parse_qs(u.query)
    m = re.search(r"/(?:live|shorts|embed)/([\w-]{6,})", u.path)
    if "youtu" in u.netloc and (q.get("v") or m or u.netloc.endswith("youtu.be")):
        return "yt:" + (q["v"][0] if q.get("v") else m.group(1) if m else u.path.strip("/"))
    return (u.netloc.lower().removeprefix("www.") + u.path.rstrip("/")).lower()


def start(url: str, project_id: str, user_id: str, chunk_minutes: float = 5, max_hours: float = 4,
          auto_clips: bool = True, min_score: float = 60, max_clips: int = 2, aspect: str = "9:16",
          wait_for_start: bool = True) -> dict:
    with _lock:
        active = [w for w in _read().values() if w.get("status") in ACTIVE and w["id"] in _threads]
        if len(active) >= MAX_ACTIVE:
            raise ValueError(f"Already watching {MAX_ACTIVE} streams - stop one first.")
        if any(_same_stream_key(w["url"]) == _same_stream_key(url) for w in active):
            raise ValueError("This stream is already being watched.")
        if shutil.disk_usage(STORAGE_DIR).free / 1e9 < MIN_FREE_GB:
            raise ValueError(f"Less than {MIN_FREE_GB:.0f} GB free on the disk.")
        wid = uuid.uuid4().hex[:12]
        w = {"id": wid, "url": url, "project_id": project_id, "user_id": user_id, "status": "starting",
             "title": "Live stream", "uploader": "", "site": "", "note": "",
             "chunk_minutes": max(1.0, min(15.0, float(chunk_minutes))),
             "max_hours": max(0.25, min(12.0, float(max_hours))), "auto_clips": bool(auto_clips),
             "min_score": max(0.0, min(100.0, float(min_score))), "max_clips": max(1, min(5, int(max_clips))),
             "aspect": aspect, "wait_for_start": bool(wait_for_start),
             "created": int(time.time()), "parts": [], "recorded_seconds": 0}
        d = _read()
        d[wid] = w
        _write(d)
        t = Watcher(wid)
        _threads[wid] = t
        t.start()
    return w


def stop(wid: str) -> bool:
    t = _threads.get(wid)
    if t is None:
        w = get(wid)
        if w and w.get("status") in ACTIVE:
            _update(wid, status="stopped", note="Stopped.", ended=int(time.time()))
        return w is not None
    _update(wid, status="stopping", note="Finishing the current part…")
    t.stop_flag.set()
    return True


def remove(wid: str) -> bool:
    """Forget a finished watch (its videos and clips stay in the project)."""
    with _lock:
        d = _read()
        w = d.get(wid)
        if w is None or wid in _threads:
            return False
        d.pop(wid)
        _write(d)
    shutil.rmtree(LIVE_DIR / wid, ignore_errors=True)
    return True


def stop_all() -> None:
    for t in list(_threads.values()):
        t.stop_flag.set()
