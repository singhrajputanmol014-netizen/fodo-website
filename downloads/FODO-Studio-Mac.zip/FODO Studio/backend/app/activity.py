"""In-memory live activity: per-job step timeline + ring buffer of recent log lines.

Shown on the Live Activity page so the owner can see exactly what runs in the
background. Lost on server restart by design (jobs table keeps the durable state).
"""
from __future__ import annotations

import collections
import re
import logging
import threading
import time

_lock = threading.Lock()
_steps: dict[str, list[dict]] = {}          # job_id -> [{stage, start, end}]
_LOG = collections.deque(maxlen=400)


def step(job_id: str, stage: str) -> None:
    """Record a stage transition (same base stage = update, not new step)."""
    base = re.sub(r"\s*\d+(\.\d+)?\s*%.*$", "", stage.split(" — ")[0]).strip()
    now = time.time()
    with _lock:
        steps = _steps.setdefault(job_id, [])
        if steps and steps[-1]["base"] == base:
            steps[-1]["stage"] = stage
            return
        if steps and steps[-1]["end"] is None:
            steps[-1]["end"] = now
        steps.append({"base": base, "stage": stage, "start": now, "end": None})
        if len(_steps) > 50:
            _steps.pop(next(iter(_steps)))


def finish(job_id: str) -> None:
    with _lock:
        for s in _steps.get(job_id, []):
            if s["end"] is None:
                s["end"] = time.time()


def steps_for(job_id: str) -> list[dict]:
    now = time.time()
    with _lock:
        return [{"stage": s["stage"], "seconds": round((s["end"] or now) - s["start"], 1),
                 "running": s["end"] is None} for s in _steps.get(job_id, [])]


class _RingHandler(logging.Handler):
    def emit(self, record: logging.LogRecord) -> None:
        msg = record.getMessage()
        if "GET /api/" in msg or "HTTP Request: GET http://testserver" in msg:
            return  # polling noise
        _LOG.append({"t": time.strftime("%H:%M:%S", time.localtime(record.created)),
                     "level": record.levelname, "src": record.name.replace("clipforge.", ""),
                     "msg": msg[:400]})


def install_log_capture() -> None:
    h = _RingHandler(level=logging.INFO)
    for name in ("clipforge", "faster_whisper", "pyscenedetect", "uvicorn.error"):
        lg = logging.getLogger(name)
        lg.setLevel(logging.INFO)
        lg.addHandler(h)


def recent_logs(n: int = 120) -> list[dict]:
    return list(_LOG)[-n:]
