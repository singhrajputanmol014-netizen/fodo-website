"""Text that is already burned into the source video (subtitles, headline strips, news tickers).

Cropping a 16:9 frame to 9:16 cuts such text in half, which looks broken. We find horizontal bands
near the top or bottom of the frame that contain text in many sampled frames, and the renderer then
crops them out (a slight zoom) instead of showing half-cut words.

Only wide text BANDS are handled. Small corner logos / channel watermarks are left alone on purpose:
removing someone else's watermark is not something this tool does.
"""
from __future__ import annotations

import subprocess

import numpy as np

SAMPLES = 14


def _frames(video: str, start: float, end: float, w: int = 640):
    import cv2
    dur = max(0.5, end - start)
    for i in range(SAMPLES):
        t = start + dur * (i + 0.5) / SAMPLES
        r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{t:.2f}", "-i", str(video), "-frames:v", "1",
                            "-vf", f"scale={w}:-2", "-f", "image2pipe", "-vcodec", "png", "-"],
                           capture_output=True)
        if r.returncode == 0 and r.stdout:
            img = cv2.imdecode(np.frombuffer(r.stdout, np.uint8), cv2.IMREAD_GRAYSCALE)
            if img is not None:
                yield img


def text_rows(gray) -> np.ndarray:
    """Boolean per row: does this row belong to a line of text?"""
    import cv2
    h, w = gray.shape
    grad = cv2.morphologyEx(gray, cv2.MORPH_GRADIENT, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    _, bw = cv2.threshold(grad, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    joined = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (max(9, w // 60), 1)))
    n, _lab, stats, _ = cv2.connectedComponentsWithStats(joined, connectivity=8)
    rows = np.zeros(h, bool)
    for i in range(1, n):
        x, y, cw, ch, area = stats[i]
        if cw < w * 0.12 or not (h * 0.018 <= ch <= h * 0.11) or cw < 3 * ch:
            continue
        fill = bw[y:y + ch, x:x + cw].mean() / 255
        if 0.18 <= fill <= 0.75:                       # letters: neither empty nor a solid block
            rows[y:y + ch] = True
    return rows


def detect(video: str, start: float, end: float) -> dict | None:
    """{'keep_top': fraction, 'keep_bottom': fraction} of the frame height to KEEP, or None.
    A band counts when text shows in its rows in >= 35 % of the sampled frames."""
    hits = None
    n = 0
    for g in _frames(video, start, end):
        r = text_rows(g).astype(float)
        hits = r if hits is None else (hits[: len(r)] + r[: len(hits)])
        n += 1
    if not n or hits is None:
        return None
    freq = hits / n
    h = len(freq)
    present = freq >= 0.35
    top_cut, bot_cut = 0.0, 1.0
    # bottom band (subtitles, tickers, lower thirds): rows in the lower 35 %
    low = np.where(present[int(h * 0.65):])[0]
    if len(low):
        first = int(h * 0.65) + low.min()
        bot_cut = max(0.70, first / h - 0.015)
    high = np.where(present[: int(h * 0.30)])[0]
    if len(high):
        last = high.max()
        top_cut = min(0.25, last / h + 0.015)
    if top_cut <= 0.0 and bot_cut >= 1.0:
        return None
    if bot_cut - top_cut < 0.62:                       # never throw away more than ~38 % of the picture
        return None
    return {"keep_top": round(float(top_cut), 3), "keep_bottom": round(float(bot_cut), 3)}


def to_crop(band: dict | None, sw: int, sh: int) -> tuple[int, int] | None:
    """(y0, height) in source pixels, even numbers."""
    if not band:
        return None
    y0 = int(band["keep_top"] * sh) // 2 * 2
    y1 = int(band["keep_bottom"] * sh) // 2 * 2
    return (y0, y1 - y0) if y1 - y0 > sh * 0.5 else None


def remap_box(box: list[float], sh: int, y0: int, nh: int) -> list[float]:
    """Face box (normalised to the full frame) -> normalised to the cropped frame."""
    y = (box[1] * sh - y0) / nh
    hh = box[3] * sh / nh
    return [box[0], max(0.0, min(1.0 - hh, y)), box[2], min(1.0, hh)]
