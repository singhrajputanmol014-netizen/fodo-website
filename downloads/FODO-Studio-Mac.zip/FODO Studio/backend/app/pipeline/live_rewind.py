"""Rewind a stream that is STILL LIVE: find moments in the hours that already went out, and fetch only those.

YouTube keeps the earlier part of a live stream when the streamer has DVR on (rewind up to about 12 hours,
yt-dlp can reach further back on some streams). Every few seconds of the stream is one numbered piece
("sq"), served on its own. So:
  1. sound scan  - fetch only the low-quality audio pieces of the last N hours (about 25 MB per hour),
                   measure loudness per second, find the loud bursts (same rules as the normal sound scan)
  2. fetch       - for each chosen moment, fetch only the video + audio pieces that cover it (+ handles),
                   join them and mux them (no re-encode)
Piece number -> stream time is piece * piece length, so the scan and the fetch always agree on content.
YouTube only (yt-dlp's live-from-start support). Twitch / Kick: not yet.
"""
from __future__ import annotations

import logging
import math
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import numpy as np

log = logging.getLogger("clipforge.rewind")
WORKERS = 12
CHUNK = 96                      # pieces fetched per batch (written to disk in order)
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/131.0 Safari/537.36")


class NotRewindable(ValueError):
    pass


def _opts() -> dict:
    return {"quiet": True, "no_warnings": True, "skip_download": True, "noplaylist": True,
            "live_from_start": True, "js_runtimes": {"deno": {}, "node": {}}, "socket_timeout": 30}


def _with_sq(url: str, sq: int) -> str:
    u = urlsplit(url)
    q = [(k, v) for k, v in parse_qsl(u.query, keep_blank_values=True) if k != "sq"] + [("sq", str(sq))]
    return urlunsplit((u.scheme, u.netloc, u.path, urlencode(q), u.fragment))


def _first_piece(fmt: dict) -> tuple[str, int]:
    """Base URL + number of pieces so far, from yt-dlp's piece generator (first batch only)."""
    gen = fmt["fragments"]
    it = gen({}) if callable(gen) else iter(gen)
    try:
        first = next(it)
    finally:
        if hasattr(it, "close"):
            it.close()
    return first["url"], int(first.get("fragment_count") or 0)


def probe(url: str) -> dict:
    """What can be rewound: piece length, pieces so far, chosen audio / video formats."""
    import yt_dlp
    from .url_import import ydl_extract
    info = ydl_extract(_opts(), url)
    status = info.get("live_status")
    if info.get("extractor_key") != "Youtube":
        raise NotRewindable("Going back in a stream that is still live works for YouTube only (for now). "
                            "Twitch / Kick: scan the stream's VOD link instead.")
    if status not in ("is_live", "post_live"):
        raise NotRewindable("This video is not live any more - use the normal Smart scan.")
    fmts = [f for f in info.get("formats") or [] if f.get("fragments") and f.get("is_from_start", True)]
    auds = [f for f in fmts if f.get("vcodec") in (None, "none") and f.get("acodec") not in (None, "none")]
    vids = [f for f in fmts if f.get("vcodec") not in (None, "none") and f.get("acodec") in (None, "none")
            and (f.get("height") or 0) <= 1080]
    if not auds or not vids:
        raise NotRewindable("YouTube does not offer the earlier part of this stream (the streamer may have "
                            "turned DVR / rewind off).")
    m4a = [f for f in auds if f.get("ext") == "m4a"] or auds
    scan_a = min(m4a, key=lambda f: f.get("abr") or f.get("tbr") or 999)
    best_a = max(m4a, key=lambda f: f.get("abr") or f.get("tbr") or 0)
    mp4v = [f for f in vids if f.get("ext") == "mp4"] or vids
    best_v = max(mp4v, key=lambda f: ((f.get("height") or 0), f.get("fps") or 0, f.get("tbr") or 0))
    base, head = _first_piece(scan_a)
    seg = float(scan_a.get("target_duration") or best_v.get("target_duration") or 5.0)
    if head <= 0:
        raise NotRewindable("Could not read how far back this stream goes.")
    return {"info": info, "seg": seg, "head": head, "scan_audio": scan_a, "audio": best_a, "video": best_v,
            "audio_base": base, "status": status,
            "start_ts": info.get("release_timestamp") or info.get("timestamp")}


def _get(url: str, tries: int = 4, headers: dict | None = None) -> bytes:
    import urllib.request
    err = None
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, **(headers or {})})
            with urllib.request.urlopen(req, timeout=30) as r:
                return r.read()
        except Exception as e:  # noqa: BLE001
            err = e
            time.sleep(0.6 * (k + 1))
    raise RuntimeError(f"piece download failed: {err}")


def fetch_pieces(base: str, first: int, last: int, out: Path, progress=None, label="",
                 headers: dict | None = None) -> int:
    """Pieces first..last-1 joined into one file, in order. Missing pieces are skipped. -> pieces written."""
    n, done = max(0, last - first), 0
    ok = 0
    with open(out, "wb") as fh, ThreadPoolExecutor(WORKERS) as ex:
        for c0 in range(first, last, CHUNK):
            ids = list(range(c0, min(last, c0 + CHUNK)))
            for data in ex.map(lambda s: _safe_get(_with_sq(base, s), headers), ids):
                if data:
                    fh.write(data)
                    ok += 1
            done += len(ids)
            if progress:
                progress(done / max(1, n), f"{label} {done}/{n} pieces")
    return ok


def _safe_get(url: str, headers: dict | None = None) -> bytes | None:
    try:
        return _get(url, headers=headers)
    except Exception as e:  # noqa: BLE001
        log.warning("rewind: %s", e)
        return None


def _levels(path: Path) -> np.ndarray:
    proc = subprocess.Popen(["ffmpeg", "-v", "error", "-i", str(path), "-ac", "1", "-ar", "8000", "-f", "s16le", "-"],
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    vals = []
    while True:
        buf = proc.stdout.read(16000)
        if len(buf) < 16000:
            break
        x = np.frombuffer(buf, np.int16).astype(np.float32) / 32768
        vals.append(20 * np.log10(np.sqrt((x ** 2).mean()) + 1e-6))
    proc.wait()
    return np.array(vals)


def scan(url: str, hours: float, work: Path, progress=None) -> dict:
    """Sound scan of the last `hours` of a stream that is live now. Times are stream time (from its start)."""
    from .smart_scan import audio_candidates
    p = progress or (lambda f, s="": None)
    p(0.03, "Reading the live stream")
    pr = probe(url)
    seg, head = pr["seg"], pr["head"]
    want = int(math.ceil(max(0.25, float(hours)) * 3600 / seg))
    first = max(0, head - want)
    work.mkdir(parents=True, exist_ok=True)
    aud = work / "rewind_audio.m4a"
    p(0.06, f"Sound of the last {(head - first) * seg / 3600:.1f} h ({head - first} pieces)")
    got = fetch_pieces(pr["audio_base"], first, head, aud,
                       lambda f, s: p(0.06 + 0.7 * f, "Downloading sound only: " + s), "",
                       headers=pr["scan_audio"].get("http_headers"))
    if got < 0.5 * (head - first):
        raise RuntimeError(f"Only {got} of {head - first} sound pieces came through - try again in a minute.")
    p(0.8, "Measuring loudness")
    lv = _levels(aud)
    aud.unlink(missing_ok=True)
    offset = first * seg
    covered = len(lv)
    cands = audio_candidates(lv, float(covered))
    for c in cands:
        c["start"] = round(c["start"] + offset, 1)
        c["end"] = round(c["end"] + offset, 1)
        t = c["start"] + 35
        c["title"] = f"Loud moment at {int(t // 3600)}:{int(t % 3600 // 60):02d}:{int(t % 60):02d}"
        c["reasons"] = c["reasons"] + ["found while the stream was live (sound only)"]
    info = pr["info"]
    log.info("rewind %s: %.1f h scanned (%d pieces of %.1fs, %d s of sound), %d moments",
             info.get("id"), (head - first) * seg / 3600, head - first, seg, covered, len(cands))
    return {"title": info.get("title"), "uploader": info.get("uploader") or info.get("channel"),
            "duration": round(head * seg, 1), "url": info.get("webpage_url") or url, "site": "Youtube",
            "thumbnail": info.get("thumbnail"),
            "captions": f"live now - sound of the last {(head - first) * seg / 3600:.1f} h scanned "
                        f"(captions and Most replayed appear only after the stream ends)",
            "has_heatmap": False, "signals": ["sound"] if cands else [], "mode": "rewind", "was_stream": True,
            "heatmap": [], "chapters": [], "candidates": cands, "words": [],
            "live_rewind": {"seg": seg, "head": head, "scanned_from": round(offset, 1), "at": int(time.time())}}


def download_section(url: str, a: float, b: float, out: Path, progress=None) -> tuple[Path, float, float]:
    """Video + audio for stream time a..b (piece aligned). -> (file, real start, real end)."""
    p = progress or (lambda f: None)
    pr = probe(url)                                         # fresh links (they expire after some hours)
    seg = pr["seg"]
    s0, s1 = max(0, int(a // seg)), min(pr["head"], int(math.ceil(b / seg)))
    if s1 <= s0:
        raise RuntimeError("That part of the stream is not available any more.")
    out = Path(out)
    tmp = out.with_suffix("")
    vb, _ = _first_piece(pr["video"])
    ab, _ = _first_piece(pr["audio"])
    v_part, a_part = tmp.with_name(tmp.name + ".v.mp4"), tmp.with_name(tmp.name + ".a.m4a")
    nv = fetch_pieces(vb, s0, s1, v_part, lambda f, s: p(0.85 * f), headers=pr["video"].get("http_headers"))
    na = fetch_pieces(ab, s0, s1, a_part, lambda f, s: p(0.85 + 0.1 * f), headers=pr["audio"].get("http_headers"))
    if nv < 0.8 * (s1 - s0) or na < 0.8 * (s1 - s0):
        raise RuntimeError(f"Only {min(nv, na)} of {s1 - s0} stream pieces came through - try again.")
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(v_part), "-i", str(a_part), "-map", "0:v:0",
                        "-map", "1:a:0", "-c", "copy", "-movflags", "+faststart", str(out)],
                       capture_output=True, text=True)
    v_part.unlink(missing_ok=True)
    a_part.unlink(missing_ok=True)
    if r.returncode != 0 or not out.exists():
        raise RuntimeError(f"joining the stream pieces failed: {r.stderr[-300:]}")
    p(1.0)
    return out, s0 * seg, s1 * seg


def free_check(path: Path, need_gb: float = 1.0) -> None:
    if shutil.disk_usage(path).free / 1e9 < need_gb:
        raise RuntimeError("Not enough free disk space.")
