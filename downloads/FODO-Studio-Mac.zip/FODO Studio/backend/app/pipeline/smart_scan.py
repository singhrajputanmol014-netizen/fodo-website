"""Smart scan: find clip-worthy moments in a long YouTube video / finished live stream WITHOUT downloading it.

What YouTube gives without the video file (via yt-dlp, a few KB-MB):
  * captions (auto or uploaded) with word timings  -> full transcript
  * "Most replayed" heatmap (100 points)            -> where viewers rewatch
  * chapters                                         -> creator's own sections
The transcript goes through the same topic finder + scoring as a normal analysis; heatmap peaks add a
bonus (and become candidates on their own when there are no captions). Afterwards only the chosen
moments are downloaded (yt-dlp download_ranges), transcribed with Whisper and rendered.
No GPU / Whisper work happens during the scan.
"""
from __future__ import annotations

import json
import logging
import re

import numpy as np

from .topics import best_window, score_topic, segment_topics

log = logging.getLogger("clipforge.scan")
MAX_CANDIDATES = 40
CLIP_MIN, CLIP_TARGET, CLIP_MAX = 15.0, 55.0, 150.0


class LiveNow(ValueError):
    """The link is a stream that is live right now (handled by live_rewind)."""


# ------------------------------------------------------------------ yt-dlp --
def _ydl_opts() -> dict:
    return {"quiet": True, "no_warnings": True, "skip_download": True, "noplaylist": True,
            "js_runtimes": {"deno": {}, "node": {}}, "socket_timeout": 30, "ignore_no_formats_error": True}


def _pick_track(info: dict) -> tuple[str, str, list] | None:
    """(kind, lang, formats). Uploaded captions first, then the original-language auto captions.
    Machine-translated auto tracks are a last resort."""
    subs, auto = info.get("subtitles") or {}, info.get("automatic_captions") or {}
    lang = (info.get("language") or "").split("-")[0]
    subs = {k: v for k, v in subs.items() if k != "live_chat"}
    for k in [lang, "hi", "en"] + list(subs):
        if k and k in subs:
            return "uploaded", k, subs[k]
    orig = [k for k in auto if k.endswith("-orig")]
    for k in orig + [lang, "hi", "en"]:
        if k and k in auto:
            return ("auto" if k in orig or k == lang else "auto-translated"), k, auto[k]
    return None


def parse_json3(raw: dict) -> list[dict]:
    """YouTube json3 captions -> [{'w','s','e'}]. Auto captions carry per-word offsets; uploaded
    captions are whole lines, whose words are spread evenly over the line."""
    words: list[dict] = []
    evs = [e for e in raw.get("events", []) if e.get("segs")]
    for i, ev in enumerate(evs):
        t0 = ev.get("tStartMs", 0) / 1000
        dur = ev.get("dDurationMs", 0) / 1000
        t_end = t0 + dur if dur else (evs[i + 1].get("tStartMs", 0) / 1000 if i + 1 < len(evs) else t0 + 2)
        segs = [s for s in ev["segs"] if (s.get("utf8") or "").strip()]
        if not segs:
            continue
        if len(segs) == 1 and len(segs[0]["utf8"].split()) > 1:      # uploaded line
            parts = segs[0]["utf8"].split()
            step = max(0.05, (t_end - t0) / len(parts))
            for j, p in enumerate(parts):
                words.append({"w": " " + p, "s": round(t0 + j * step, 3), "e": round(t0 + (j + 1) * step, 3)})
            continue
        for j, s in enumerate(segs):
            st = t0 + s.get("tOffsetMs", 0) / 1000
            nx = t0 + segs[j + 1].get("tOffsetMs", 0) / 1000 if j + 1 < len(segs) else t_end
            for p in s["utf8"].split():
                words.append({"w": " " + p, "s": round(st, 3), "e": round(max(st + 0.05, min(nx, st + 1.5)), 3)})
    words.sort(key=lambda w: w["s"])
    for a, b in zip(words, words[1:]):                                 # no overlaps
        if a["e"] > b["s"]:
            a["e"] = max(a["s"] + 0.02, b["s"])
    return words


def _fetch_captions(ydl, fmts: list) -> list[dict]:
    by = {f.get("ext"): f for f in fmts}
    f = by.get("json3")
    if f:
        return parse_json3(json.loads(ydl.urlopen(f["url"]).read().decode("utf-8", "replace")))
    f = by.get("vtt") or by.get("srv3") or (fmts[0] if fmts else None)
    if not f:
        return []
    return parse_vtt(ydl.urlopen(f["url"]).read().decode("utf-8", "replace"))


def parse_vtt(text: str) -> list[dict]:
    words = []
    for m in re.finditer(r"(\d+):(\d\d):(\d\d)\.(\d+) --> (\d+):(\d\d):(\d\d)\.(\d+)[^\n]*\n(.+?)(?:\n\n|\Z)", text, re.S):
        g = m.groups()
        a = int(g[0]) * 3600 + int(g[1]) * 60 + int(g[2]) + int(g[3][:3].ljust(3, "0")) / 1000
        b = int(g[4]) * 3600 + int(g[5]) * 60 + int(g[6]) + int(g[7][:3].ljust(3, "0")) / 1000
        line = re.sub(r"<[^>]+>", "", g[8]).replace("\n", " ").split()
        if words and line and " ".join(w["w"].strip() for w in words[-len(line):]) == " ".join(line):
            continue                                                    # rolling auto-caption repeat
        step = max(0.05, (b - a) / max(1, len(line)))
        for j, p in enumerate(line):
            words.append({"w": " " + p, "s": round(a + j * step, 3), "e": round(a + (j + 1) * step, 3)})
    return words


# ------------------------------------------------------------------ live chat replay --
HYPE = re.compile(r"(😂|🤣|💀|🔥|😱|😭|kekw|lmao|lmfao|lol+|omg|wtf|pog|clip|haha+|hahaha|bhai+|💯|😳|🤯|op\b|w+\b|l+\b|"
                  r"arre|bc\b|xd)", re.I)


def parse_live_chat(lines) -> list[tuple[float, str]]:
    """yt-dlp .live_chat.json (one JSON object per line) -> [(seconds, message text)]."""
    out = []
    for line in lines:
        try:
            o = json.loads(line)
        except ValueError:
            continue
        r = o.get("replayChatItemAction") or {}
        try:
            t = int(r.get("videoOffsetTimeMsec")) / 1000
        except (TypeError, ValueError):
            continue
        for act in r.get("actions") or []:
            item = (act.get("addChatItemAction") or {}).get("item") or {}
            m = item.get("liveChatTextMessageRenderer") or item.get("liveChatPaidMessageRenderer")
            if not m:
                continue
            txt = "".join(x.get("text") or ((x.get("emoji") or {}).get("shortcuts") or [""])[0]
                          for x in (m.get("message") or {}).get("runs") or [])
            out.append((t, txt[:200]))
    return out


def chat_candidates(msgs: list[tuple[float, str]], duration: float, n: int = 30) -> list[dict]:
    """Moments where chat suddenly explodes. Chat reacts ~5-20 s AFTER the moment, so the clip starts
    well before the spike."""
    if len(msgs) < 50:
        return []
    B = 10.0
    nb = int(max(duration, msgs[-1][0]) // B) + 1
    cnt, hype = np.zeros(nb), np.zeros(nb)
    texts: dict[int, list[str]] = {}
    for t, txt in msgs:
        i = int(t // B)
        if 0 <= i < nb:
            cnt[i] += 1
            hype[i] += 1 if HYPE.search(txt) else 0
            texts.setdefault(i, []).append(txt)
    k = 61                                                    # ~10 min rolling baseline
    pad = np.pad(cnt, (k // 2, k // 2), mode="edge")
    base = np.array([np.median(pad[i:i + k]) for i in range(nb)])
    sm = np.convolve(cnt, [0.25, 0.5, 0.25], mode="same")
    ratio = (sm + 1) / (base + 1)
    order = np.argsort(-(ratio * (1 + hype / np.maximum(cnt, 1))))
    out, used = [], []
    for i in order:
        if len(out) >= n or ratio[i] < 2.0:
            break
        if cnt[i] < 6:
            continue
        t = i * B + B / 2
        if any(abs(t - u) < 90 for u in used):
            continue
        used.append(t)
        hs = hype[i] / max(cnt[i], 1)
        a, b = max(0.0, t - 50), min(duration or t + 15, t + 12)
        sample = [x for x in texts.get(i, []) if x.strip()][:6]
        top = max(set(sample), key=sample.count) if sample else ""
        out.append({"start": round(a, 1), "end": round(b, 1),
                    "score": round(min(100.0, 35 + 14 * float(np.log2(ratio[i])) + 25 * hs), 1),
                    "title": f"Chat went off: “{top[:40]}”" if top else "Chat went off",
                    "text": " | ".join(sample)[:600], "heat": 0.0, "source": "chat",
                    "reasons": [f"Chat exploded: {int(cnt[i])} messages in 10 s ({ratio[i]:.1f}x normal)"]
                    + ([f"{hs * 100:.0f}% hype / laugh messages"] if hs >= 0.2 else [])})
    return out


def _read_chat(url: str, work, progress, duration: float = 0) -> list[tuple[float, str]]:
    import yt_dlp
    work.mkdir(parents=True, exist_ok=True)
    for f in work.glob("chat*"):
        f.unlink(missing_ok=True)
    opts = {**_ydl_opts(), "writesubtitles": True, "subtitleslangs": ["live_chat"], "outtmpl": str(work / "chat"),
            "noprogress": True}
    import threading
    stop = threading.Event()

    def watch():
        while not stop.wait(8):
            part = next(iter(work.glob("chat*.live_chat.json.part")), None)
            if part is None:
                continue
            try:
                with part.open("rb") as fh:
                    fh.seek(0, 2)
                    size = fh.tell()
                    fh.seek(max(0, size - 300000))
                    tail = fh.read().decode("utf-8", "replace").splitlines()
                t = max((int(m.group(1)) for m in (re.search(r'"videoOffsetTimeMsec": ?"(\d+)"', x) for x in tail) if m),
                        default=0) / 1000
                frac = t / duration if duration else 0
                progress(0.1 + 0.8 * min(1.0, frac),
                         f"Reading live chat: {int(t // 3600)}:{int(t % 3600 // 60):02d} of "
                         f"{int(duration // 3600)}:{int(duration % 3600 // 60):02d} ({size / 1e6:.0f} MB of text)")
            except OSError:
                pass
    threading.Thread(target=watch, daemon=True).start()
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
    finally:
        stop.set()
    files = list(work.glob("chat*.live_chat.json"))
    if not files:
        return []
    with files[0].open(encoding="utf-8", errors="replace") as fh:
        msgs = parse_live_chat(fh)
    for f in work.glob("chat*"):
        f.unlink(missing_ok=True)
    return msgs


# ------------------------------------------------------------------ audio-only scan --
def audio_candidates(db: np.ndarray, duration: float, n: int = 30) -> list[dict]:
    """Loud bursts (laughing, shouting, hype) against the stream's own normal level. db: 1 value per second."""
    if len(db) < 120:
        return []
    k = 301
    pad = np.pad(db, (k // 2, k // 2), mode="edge")
    base = np.array([np.median(pad[i:i + k]) for i in range(len(db))])
    # a quiet "starting soon" / break screen must not make normal talking look like a peak
    floor = float(np.median(db)) - 6
    lift = np.convolve(db - np.maximum(base, floor), np.ones(3) / 3, mode="same")
    edge = min(180, len(db) // 20)
    lift[:edge] = 0
    lift[len(lift) - edge:] = 0
    out, used = [], []
    for i in np.argsort(-lift):
        if lift[i] < 5 or len(out) >= n:
            break
        t = float(i)
        if any(abs(t - u) < 90 for u in used):
            continue
        used.append(t)
        out.append({"start": round(max(0.0, t - 35), 1), "end": round(min(duration or t + 20, t + 20), 1),
                    "score": round(min(95.0, 40 + 2.5 * float(lift[i])), 1), "title": f"Loud moment at {int(t // 3600)}:{int(t % 3600 // 60):02d}:{int(t % 60):02d}",
                    "text": "", "heat": 0.0, "source": "audio",
                    "reasons": [f"{lift[i]:.0f} dB louder than usual (laughing / shouting / hype)"]})
    return out


def _audio_levels(url: str, work, progress) -> np.ndarray:
    import subprocess
    import yt_dlp
    work.mkdir(parents=True, exist_ok=True)
    for f in work.glob("aud*"):
        f.unlink(missing_ok=True)
    opts = {**_ydl_opts(), "skip_download": False, "format": "worstaudio/bestaudio/worst", "noprogress": True,
            "outtmpl": str(work / "aud.%(ext)s"), "retries": 10, "fragment_retries": 15}

    def hook(d):
        if d.get("status") == "downloading":
            tot = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            got = d.get("downloaded_bytes") or 0
            progress(0.1 + 0.6 * (got / tot if tot else 0), f"Downloading sound only {got / 1e6:.0f}/{tot / 1e6:.0f} MB")
    opts["progress_hooks"] = [hook]
    with yt_dlp.YoutubeDL(opts) as ydl:
        ydl.download([url])
    f = next((x for x in work.glob("aud.*") if x.suffix not in (".part", ".ytdl")), None)
    if f is None:
        return np.zeros(0)
    progress(0.75, "Measuring loudness")
    proc = subprocess.Popen(["ffmpeg", "-v", "error", "-i", str(f), "-ac", "1", "-ar", "8000", "-f", "s16le", "-"],
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    vals = []
    while True:
        buf = proc.stdout.read(16000)
        if len(buf) < 16000:
            break
        x = np.frombuffer(buf, np.int16).astype(np.float32) / 32768
        vals.append(20 * np.log10(np.sqrt((x ** 2).mean()) + 1e-6))
    proc.wait()
    for x in work.glob("aud*"):
        x.unlink(missing_ok=True)
    return np.array(vals)


# ------------------------------------------------------------------ scoring --
def heat_at(heat: list[dict], a: float, b: float) -> float:
    vals = [h["value"] for h in heat if h["end_time"] > a and h["start_time"] < b]
    return float(max(vals)) if vals else 0.0


def heat_peaks(heat: list[dict], duration: float, n: int = 12) -> list[tuple[float, float]]:
    """Most-replayed peaks -> (centre, value)."""
    if not heat:
        return []
    v = np.array([h["value"] for h in heat])
    out = []
    for i in range(len(v)):
        lo, hi = max(0, i - 2), min(len(v), i + 3)
        if v[i] >= v[lo:hi].max() and v[i] >= max(0.35, np.median(v) * 1.5):
            out.append(((heat[i]["start_time"] + heat[i]["end_time"]) / 2, float(v[i])))
    return sorted(out, key=lambda x: -x[1])[:n]


def _text(words: list[dict], a: float, b: float) -> str:
    return " ".join(w["w"].strip() for w in words if a <= w["s"] < b)


def candidates(words: list[dict], heat: list[dict], duration: float, chapters: list | None = None) -> list[dict]:
    out: list[dict] = []
    if words:
        for t in segment_topics(words):
            sc = score_topic(t, np.zeros(0), 0.0, None)
            a, b = sc["start"], sc["end"]
            why = []
            if b - a > CLIP_MAX or b - a < CLIP_MIN:
                a, b, w_ = best_window(words, a, b, CLIP_TARGET)
                if w_ != "full topic":
                    why.append(f"Best part of a {sc['duration']:.0f} s topic")
            h = heat_at(heat, a, b)
            s = sc["score"] * 0.75 + h * 25
            if h >= 0.5:
                why.insert(0, f"Most replayed: {h * 100:.0f}% of the peak")
            out.append({"start": round(a, 1), "end": round(b, 1), "score": round(min(100.0, s), 1),
                        "title": sc["title"], "text": _text(words, a, b)[:600], "heat": round(h, 2),
                        "reasons": why + sc.get("reasons", [])[:3], "source": "captions"})
    for c, v in heat_peaks(heat, duration):
        if any(o["start"] - 5 <= c <= o["end"] + 5 for o in out):
            continue
        a, b = max(0.0, c - 35), min(duration, c + 25)
        if words:
            a, b, _ = best_window(words, max(0.0, c - 60), min(duration, c + 60), CLIP_TARGET)
        out.append({"start": round(a, 1), "end": round(b, 1), "score": round(40 + v * 50, 1),
                    "title": (_text(words, a, b)[:60] or "Most replayed moment"), "text": _text(words, a, b)[:600],
                    "heat": round(v, 2), "reasons": [f"Most replayed: {v * 100:.0f}% of the peak"], "source": "heatmap"})
    for ch in chapters or []:
        for o in out:
            if ch.get("start_time", -1) <= o["start"] < ch.get("end_time", -1):
                o["chapter"] = ch.get("title")
    out.sort(key=lambda o: -o["score"])
    keep: list[dict] = []
    for o in out:                                    # no two candidates over the same seconds
        if all(o["end"] <= k["start"] + 3 or o["start"] >= k["end"] - 3 for k in keep):
            keep.append(o)
        if len(keep) >= MAX_CANDIDATES:
            break
    return keep


def scan(url: str, progress=None, llm_titles: bool = True, mode: str = "auto", work=None) -> dict:
    """mode: auto (captions + heatmap, seconds) | chat (+ live chat replay: best for streams, minutes) |
    audio (+ sound-only loudness scan)."""
    import yt_dlp
    from pathlib import Path
    work = Path(work) if work else Path(".") / "_scan_tmp"
    p = progress or (lambda f, s="": None)
    p(0.05, "Reading video details")
    from .url_import import ydl_extract
    info = ydl_extract(_ydl_opts(), url)
    with yt_dlp.YoutubeDL(_ydl_opts()) as ydl:
        if info.get("live_status") in ("is_live", "post_live"):
            raise LiveNow("This stream is still live.")
        duration = float(info.get("duration") or 0)
        heat = [h for h in (info.get("heatmap") or []) if "value" in h]
        track = _pick_track(info)
        words: list[dict] = []
        cap_note = "no captions on this video"
        if track:
            p(0.25, f"Reading {track[0]} captions ({track[1]})")
            try:
                words = _fetch_captions(ydl, track[2])
                cap_note = f"{track[0]} captions ({track[1]}), {len(words)} words"
            except Exception as e:  # noqa: BLE001
                cap_note = f"captions could not be read: {e}"[:200]
                log.warning("scan: %s", cap_note)
    p(0.6, "Finding the strongest moments")
    cands = candidates(words, heat, duration, info.get("chapters"))
    signals = []
    if words:
        signals.append("captions")
    if heat:
        signals.append("most replayed")
    chat_note = ""
    was_stream = info.get("live_status") in ("was_live", "post_live") or info.get("was_live")
    if mode == "chat":
        try:
            msgs = _read_chat(url, work, p, duration)
            cc = chat_candidates(msgs, duration)
            chat_note = f"live chat: {len(msgs)} messages"
            if cc:
                signals.append("live chat")
                taken = [(c["start"], c["end"]) for c in cands]
                cands += [c for c in cc if all(c["end"] <= a - 3 or c["start"] >= b + 3 for a, b in taken)]
        except Exception as e:  # noqa: BLE001
            chat_note = f"live chat could not be read: {str(e)[:120]}"
            log.warning("scan chat: %s", e)
    if mode == "audio":
        lv = _audio_levels(url, work, p)
        ac = audio_candidates(lv, duration)
        if ac:
            signals.append("sound")
        taken = [(c["start"], c["end"]) for c in cands]
        cands += [c for c in ac if all(c["end"] <= a - 3 or c["start"] >= b + 3 for a, b in taken)]
    cands.sort(key=lambda o: -o["score"])
    cands = cands[:MAX_CANDIDATES]
    if llm_titles and cands:
        try:
            from . import llm
            from .topics import llm_review
            if llm.status().get("model_installed"):
                p(0.75, "AI writing titles for the top moments")
                top = [dict(c, summary="", keywords=[], factors={}, reasons=list(c["reasons"])) for c in cands[:15]]
                llm_review(top, llm)
                for c, t in zip(cands, top):
                    c.update(title=t.get("title") or c["title"], score=t["score"], reasons=t["reasons"][:4])
                    if t.get("summary"):
                        c["summary"] = t["summary"]
                cands.sort(key=lambda o: -o["score"])
        except Exception:  # noqa: BLE001
            log.exception("scan: AI titles skipped")
    p(1.0, "Scan done")
    step = max(1, len(heat) // 100) if heat else 1
    return {"title": info.get("title"), "uploader": info.get("uploader") or info.get("channel"),
            "duration": duration, "url": info.get("webpage_url") or url, "site": info.get("extractor_key"),
            "thumbnail": info.get("thumbnail"), "captions": cap_note + (f" · {chat_note}" if chat_note else ""),
            "has_heatmap": bool(heat), "signals": signals, "mode": mode, "was_stream": bool(was_stream),
            "heatmap": [round(h["value"], 3) for h in heat[::step]], "chapters": [
                {"title": c.get("title"), "start": c.get("start_time"), "end": c.get("end_time")}
                for c in (info.get("chapters") or [])][:200],
            "candidates": cands, "words": words}


def search(words: list[dict], q: str, limit: int = 40) -> list[dict]:
    """Where a word / phrase is said -> [{t, text}] (case-insensitive, Hinglish friendly)."""
    q = q.strip().lower()
    if not q or not words:
        return []
    toks = [w["w"].strip().lower() for w in words]
    qt = q.split()
    out = []
    for i in range(len(toks) - len(qt) + 1):
        if all(qt[j] in toks[i + j] for j in range(len(qt))):
            t = words[i]["s"]
            if out and t - out[-1]["t"] < 20:
                continue
            out.append({"t": round(t, 1), "text": _text(words, t - 6, t + 10)[:200]})
            if len(out) >= limit:
                break
    return out
