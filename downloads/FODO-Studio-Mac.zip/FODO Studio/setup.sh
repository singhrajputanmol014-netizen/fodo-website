#!/bin/bash
# FODO Studio - one-time setup on this Mac (safe to run again).
# Homebrew -> Python 3.12, FFmpeg, Deno; the app's Python packages; a local AI model sized to the memory.
set -e
cd "$(dirname "$0")"
exec > >(tee setup_log.txt) 2>&1
echo "FODO Studio setup for Mac"
echo "This takes 5-15 minutes the first time (downloads about 1-3 GB). Keep this window open."

RAM_GB=$(( $(sysctl -n hw.memsize) / 1073741824 ))
CHIP=$(sysctl -n machdep.cpu.brand_string)
echo "This Mac: $CHIP, ${RAM_GB} GB memory"

# Stop FODO Studio from THIS folder if it is running (updates).
pkill -f "$(pwd)/.venv/bin/python -m uvicorn backend.app.main" 2>/dev/null || true

if ! command -v brew >/dev/null 2>&1; then
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$($b shellenv)"; done
fi
if ! command -v brew >/dev/null 2>&1; then
  echo ""
  echo "==> Installing Homebrew (Apple's popular package manager). It asks for YOUR Mac password: type it and press Enter."
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$($b shellenv)"; done
fi
command -v brew >/dev/null 2>&1 || { echo "Homebrew is missing. Install it from https://brew.sh and run this again."; exit 1; }

echo ""; echo "==> Python, FFmpeg and Deno"
brew list python@3.12 >/dev/null 2>&1 || brew install python@3.12
command -v ffmpeg >/dev/null 2>&1 || brew install ffmpeg
command -v deno >/dev/null 2>&1 || brew install deno || true
PY="$(brew --prefix python@3.12)/bin/python3.12"

echo ""; echo "==> App packages (first time 3-6 minutes)"
[ -x .venv/bin/python ] || "$PY" -m venv .venv
.venv/bin/python -m pip install --upgrade pip --quiet
.venv/bin/python -m pip install -r requirements.txt --quiet

mkdir -p storage
if [ "$RAM_GB" -ge 16 ]; then LLM="qwen2.5:3b"; elif [ "$RAM_GB" -ge 8 ]; then LLM="qwen2.5:1.5b"; else LLM=""; fi
USE_LLM=false
if [ -n "$LLM" ]; then
  echo ""; echo "==> Local AI model $LLM (one time download)"
  command -v ollama >/dev/null 2>&1 || brew install ollama || true
  if command -v ollama >/dev/null 2>&1; then
    (curl -s http://127.0.0.1:11434/api/tags >/dev/null) || (ollama serve >/dev/null 2>&1 &) ; sleep 4
    ollama pull "$LLM" && USE_LLM=true
  fi
else
  echo "Less than 8 GB memory: local AI titles are switched off so clipping stays smooth."
fi
.venv/bin/python - "$LLM" "$USE_LLM" <<'PYEOF'
import json, sys, pathlib
p = pathlib.Path("storage/settings.json")
s = json.loads(p.read_text()) if p.exists() else {}
if sys.argv[1]:
    s["llm_model"] = sys.argv[1]
s["use_llm"] = sys.argv[2] == "true"
p.write_text(json.dumps(s, indent=1))
PYEOF

echo ""; echo "==> Checking"
.venv/bin/python -c "import fastapi, faster_whisper, cv2, scenedetect, yt_dlp; print('All parts OK')"
touch .setup_done
echo ""
echo "FODO Studio is ready. Open it from Applications > FODO Studio (or Launchpad)."
echo "It checks this Mac's chip and memory on first start and sets its power to match."
