"""Business tools API (see app/social.py).

/api/social/*  — signed-in: inbox, analytics, approval links, link-in-bio editor, reports.
/a/{token}     — public client approval page (only the posts of that one project, token expires).
/l/{slug}      — public link-in-bio page.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse, Response

from .. import publish as P
from .. import social as S
from ..auth import current_user, require_role
from ..models import User

router = APIRouter()
NOINDEX = {"X-Robots-Tag": "noindex", "Referrer-Policy": "no-referrer", "X-Content-Type-Options": "nosniff"}


def _bad(e: Exception):
    raise HTTPException(400, str(e)) from e


def _ws_ok(ws: str):
    if ws and ws != P.MAIN and not P.workspace(ws):
        raise HTTPException(404, "Project not found")


# ------------------------------------------------------------------ inbox
@router.get("/api/social/inbox")
def inbox(ws: str = "", status: str = "", tag: str = "", platform: str = "", q: str = "",
          user: User = Depends(current_user)):
    return S.inbox(ws or None, status, tag, platform, q)


@router.post("/api/social/inbox/sync")
def inbox_sync(payload: dict | None = None, user: User = Depends(require_role("editor"))):
    ws = (payload or {}).get("workspace") or None
    if ws:
        _ws_ok(ws)
    return S.sync_inbox(ws)


@router.post("/api/social/inbox/{iid}/status")
def inbox_status(iid: str, payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return S.set_status(iid, payload.get("status") or "")
    except ValueError as e:
        _bad(e)


@router.post("/api/social/inbox/{iid}/reply")
def inbox_reply(iid: str, payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return S.reply(iid, payload.get("text") or "", user.email)
    except ValueError as e:
        _bad(e)


@router.post("/api/social/inbox/{iid}/suggest")
def inbox_suggest(iid: str, user: User = Depends(require_role("editor"))):
    try:
        return S.suggest_reply(iid)
    except ValueError as e:
        _bad(e)


@router.post("/api/social/saved_replies")
def saved_reply(payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return S.save_saved_reply(payload)
    except ValueError as e:
        _bad(e)


@router.delete("/api/social/saved_replies/{rid}")
def saved_reply_del(rid: str, user: User = Depends(require_role("editor"))):
    S.delete_saved_reply(rid)
    return {"ok": True}


# ------------------------------------------------------------------ analytics
@router.get("/api/social/analytics")
def analytics(ws: str = "", days: int = 30, user: User = Depends(current_user)):
    _ws_ok(ws)
    return S.social_analytics(ws or None, max(7, min(days, 365)))


@router.get("/api/social/best_times")
def best_times(ws: str = "", user: User = Depends(current_user)):
    _ws_ok(ws)
    return S.best_times(ws or None)


# ------------------------------------------------------------------ reports
@router.get("/api/social/report/{ws}")
def report(ws: str, days: int = 30, user: User = Depends(current_user)):
    try:
        return S.report(ws, days)
    except ValueError as e:
        _bad(e)


@router.get("/api/social/report/{ws}/html", response_class=HTMLResponse)
def report_html(ws: str, days: int = 30, user: User = Depends(current_user)):
    try:
        return HTMLResponse(S.report_html(ws, days))
    except ValueError as e:
        _bad(e)


@router.get("/api/social/report/{ws}/csv")
def report_csv(ws: str, days: int = 30, user: User = Depends(current_user)):
    _ws_ok(ws)
    name = "".join(c for c in P.workspace_name(P._wsid(ws)) if c.isalnum() or c in "-_ ")[:40].strip() or "report"
    return Response(S.report_csv(ws, days), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{name} posts {days}d.csv"'})


# ------------------------------------------------------------------ approval links
@router.get("/api/social/approval_links")
def links(ws: str = "", user: User = Depends(current_user)):
    return S.list_links(ws or None)


@router.post("/api/social/approval_links")
def link_new(payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return S.create_link(payload.get("workspace") or "", payload.get("label") or "", payload.get("days") or 14,
                             user.email)
    except ValueError as e:
        _bad(e)


@router.delete("/api/social/approval_links/{tok}")
def link_revoke(tok: str, user: User = Depends(require_role("editor"))):
    try:
        S.revoke_link(tok)
    except ValueError as e:
        _bad(e)
    return {"ok": True}


@router.get("/a/{tok}", response_class=HTMLResponse)
def approval_page(tok: str):
    return HTMLResponse(S.approval_page(tok), headers=NOINDEX)


@router.get("/a/{tok}/media/{pid}")
def approval_media(tok: str, pid: str):
    try:
        path = S.approval_media_path(tok, pid)
    except PermissionError as e:
        raise HTTPException(404, str(e)) from e
    return FileResponse(path, media_type="video/mp4", headers=NOINDEX)


@router.post("/a/{tok}/decide")
def approval_decide(tok: str, payload: dict):
    try:
        return S.decide(tok, str(payload.get("pid") or ""), str(payload.get("decision") or ""),
                        payload.get("note") or "", payload.get("name") or "")
    except PermissionError as e:
        raise HTTPException(403, str(e)) from e
    except ValueError as e:
        _bad(e)


# ------------------------------------------------------------------ link in bio
@router.get("/api/social/bio/{ws}")
def bio_get(ws: str, user: User = Depends(current_user)):
    try:
        return S.get_bio(ws)
    except ValueError as e:
        _bad(e)


@router.put("/api/social/bio/{ws}")
def bio_save(ws: str, payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return S.save_bio(ws, payload)
    except ValueError as e:
        _bad(e)


@router.get("/api/social/bio/{ws}/export")
def bio_export(ws: str, user: User = Depends(current_user)):
    try:
        b = S.get_bio(ws)
    except ValueError as e:
        _bad(e)
    if b.get("new"):
        raise HTTPException(400, "Save the page first")
    page = S.bio_page(b["slug"], export=True)
    return Response(page, media_type="text/html",
                    headers={"Content-Disposition": f'attachment; filename="{b["slug"]}.html"'})


@router.get("/l/{slug}", response_class=HTMLResponse)
def bio_public(slug: str, request: Request):
    page = S.bio_page(slug, count=request.query_params.get("preview") != "1")
    if page is None:
        raise HTTPException(404, "Page not found")
    return HTMLResponse(page, headers={"Referrer-Policy": "no-referrer", "X-Content-Type-Options": "nosniff"})


@router.get("/l/{slug}/go/{key}")
def bio_go(slug: str, key: str):
    url = S.bio_click(slug, key)
    if not url:
        raise HTTPException(404, "Link not found")
    return RedirectResponse(url, status_code=302)
