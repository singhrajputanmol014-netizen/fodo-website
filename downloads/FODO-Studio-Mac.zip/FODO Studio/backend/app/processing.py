"""Job handlers: full analysis pipeline + export rendering."""
from __future__ import annotations

import copy
import re
import shutil
import time

import logging
from pathlib import Path

from .config import CLIP_DURATION_RANGES, EXPORTS_DIR, MUSIC_USER_DIR, WORK_DIR
from .database import SessionLocal
from .jobs import handler
from .models import Clip, Export, Topic, Video
from .pipeline import audio as audio_mod
from .pipeline import llm
from .pipeline.scenes import detect_scene_cuts
from .pipeline.topics import llm_review, score_topic, segment_topics
from .pipeline import transcribe as tr
from .pipeline.captions import build_ass, build_srt
from .pipeline.export import render_clip

log = logging.getLogger("clipforge.processing")


@handler("analyze")
def analyze_video(video_id: str, progress) -> None:
    db = SessionLocal()
    try:
        video = db.get(Video, video_id)
        if video is None:
            raise RuntimeError("Video not found")
        video.status = "analyzing"
        try:                                              # v0.14 tracking: when analysis started
            from .tracking import now_iso as _now_iso
            video.meta = {**(video.meta or {}), "analyze_started_at": _now_iso()}
        except Exception:
            pass
        db.commit()
        vpath = Path(video.path)
        work = WORK_DIR / video.id
        work.mkdir(parents=True, exist_ok=True)

        progress(0.05, "Extracting audio")
        log.info("analysis started: %s (%.0f min)", video.filename, (video.meta.get("duration") or 0) / 60)
        wav = audio_mod.extract_wav(vpath, work / "audio.wav")
        pcm = audio_mod.load_pcm(wav)
        global_energy = float((pcm**2).mean() ** 0.5)

        progress(0.15, "Transcribing")
        words = video.transcript
        if not words:
            if not tr.whisper_available():
                raise RuntimeError(
                    "faster-whisper is not installed and no transcript was imported. "
                    "Install faster-whisper or upload an SRT/JSON transcript."
                )
            words = tr.transcribe_whisper(
                wav, progress=lambda p: progress(0.15 + p * 0.5, "Transcribing")
            )
            video.transcript = words
            video.transcript_source = "whisper"
            video.meta = {**(video.meta or {}), "transcription": tr.last_transcription_info()}
            db.commit()
        if not words and not ((video.meta or {}).get("auto_mode") or {}).get("moment"):
            raise RuntimeError("Transcription produced no words — is there speech in this video?")
        words = words or []

        progress(0.72, "Detecting scene changes")
        cuts: list[float] | None
        try:
            vdur = float(video.meta.get("duration") or 0)
            cuts = detect_scene_cuts(
                vpath, vdur,
                progress=lambda f: progress(0.72 + f * 0.08, f"Detecting scene changes {f*100:.0f}%"))
        except Exception as e:  # noqa: BLE001
            log.warning("scene analysis skipped: %s", e)
            cuts = None
        video.meta = {**(video.meta or {}), "scene_cuts": cuts}
        db.commit()

        progress(0.82, "Finding complete topics")
        topic_spans = segment_topics(words)
        log.info("found %d topics", len(topic_spans))
        scored = [score_topic(t, pcm, global_energy, cuts) for t in topic_spans]

        if llm.status().get("model_installed") and scored:
            progress(0.85, f"AI reading {len(scored)} topics (local LLM)")
            n_rev = llm_review(scored, llm, progress=lambda f: progress(
                0.85 + f * 0.13, f"AI reading topics {f*100:.0f}%"))
            log.info("local LLM reviewed %d/%d topics", n_rev, len(scored))
        else:
            log.info("local LLM not available - using keyword titles (install Ollama for AI titles)")

        progress(0.98, "Saving topics")
        db.query(Topic).filter_by(video_id=video.id).delete()
        for t in scored:
            db.add(Topic(video_id=video.id, start=t["start"], end=t["end"], title=t["title"],
                         summary=t["summary"], text=t["text"][:20000], keywords=t["keywords"],
                         score=t["score"], breakdown={"factors": t["factors"], "reasons": t["reasons"]}))
        top = scored
        video.status = "analyzed"
        try:                                              # v0.14 tracking: when topics were ready
            from .tracking import now_iso as _now_iso
            video.meta = {**(video.meta or {}), "analyzed_at": _now_iso()}
        except Exception:
            pass
        db.commit()
        log.info("analysis done: %d topics for %s", len(top), video.filename)
        auto = (video.meta or {}).get("auto_mode")
        if auto and (scored or (isinstance(auto, dict) and auto.get("moment"))):
            from .api.extra import queue_topic_clips
            from .pipeline.edit import auto_plan
            rows = db.query(Topic).filter_by(video_id=video.id).all()
            plan = auto_plan([{"id": r.id, "score": r.score, "breakdown": r.breakdown} for r in rows],
                             float(video.meta.get("duration") or 0) / 60,
                             {**(video.meta or {}), "filename": video.filename})
            payload = {**(auto if isinstance(auto, dict) else {}),
                       "preset": (auto.get("preset") if isinstance(auto, dict) else None) or plan["preset"],
                       "aspect": (auto.get("aspect") if isinstance(auto, dict) else None) or plan["aspect"],
                       "framing": "auto"}
            chosen = [r for r in rows if r.id in set(plan["topic_ids"])]
            mo = payload.pop("moment", None)
            if isinstance(mo, dict):
                a_ = max(0.0, float(mo.get("start", 0)))
                b_ = min(float(video.meta.get("duration") or a_ + 60), float(mo.get("end", a_ + 60)))
                t_ = Topic(video_id=video.id, start=a_, end=b_, title=str(mo.get("title") or "Clip")[:200],
                           summary="", text=" ".join(w["w"].strip() for w in words if a_ <= w["s"] < b_)[:20000],
                           keywords=[], score=float(mo.get("score") or 70), breakdown={"factors": {}, "reasons": ["Chosen in smart scan"]})
                db.add(t_)
                db.commit()
                chosen = [t_]
                plan["reason"] = "smart scan moment"
            lv = payload.pop("live", None)
            if isinstance(lv, dict):          # part of a live stream: only moments that clear the bar
                chosen = sorted((r for r in rows if r.score >= float(lv.get("min_score", 60))),
                                key=lambda r: r.score, reverse=True)[:int(lv.get("max_clips", 2))]
                plan["reason"] = f"live watch: {len(chosen)} moment(s) scored {lv.get('min_score', 60):.0f}+"
            queued = queue_topic_clips(db, chosen, payload,
                                       origin="live" if isinstance(lv, dict) else ("scan" if isinstance(mo, dict) else "auto"))
            video.meta = {**video.meta, "auto_result": {"reason": plan["reason"], "clips": len(queued)}}
            db.commit()
            log.info("auto mode: queued %d clips (%s)", len(queued), plan["reason"])
        progress(1.0, "Done")
    except Exception:
        d = SessionLocal()
        try:
            v = d.get(Video, video_id)
            if v:
                v.status = "failed"
                d.commit()
        finally:
            d.close()
        raise
    finally:
        db.close()


@handler("export")
def export_clip(export_id: str, progress) -> None:
    db = SessionLocal()
    try:
        exp = db.get(Export, export_id)
        if exp is None:
            raise RuntimeError("Export not found")
        clip = exp.clip
        video = clip.video
        exp.status = "rendering"
        db.commit()

        p = exp.params or {}
        aspect = p.get("aspect", clip.settings.get("aspect", "9:16"))
        style = p.get("caption_style", clip.settings.get("caption_style", "fodo_orange"))
        resolution = p.get("resolution", "1080p")
        from .power import export_profile
        profile = p.get("profile") or export_profile()
        captions_on = p.get("captions", True)
        start = float(p.get("start", clip.start))
        end = float(p.get("end", clip.end))

        work = WORK_DIR / clip.id
        work.mkdir(parents=True, exist_ok=True)
        ass_path = None
        engine = p.get("engine", "speaker")
        if captions_on and video.transcript and engine != "speaker":
            from .config import ASPECT_RATIOS
            w, h = ASPECT_RATIOS.get(aspect, ASPECT_RATIOS["9:16"])
            progress(0.1, "Building captions")
            ass_path = build_ass(video.transcript, start, end, style, w, h, work / "caps.ass",
                                 placement=p.get("placement", "lower"),
                                 design=p.get("caption_design") or clip.settings.get("caption_design"))
            build_srt(video.transcript, start, end, work / "caps.srt")

        hw = None
        from .settings_store import get as _setting
        if p.get("hw_accel", True) and _setting("hw_encode"):
            from .system import detect_hardware
            hws = detect_hardware().get("hardware_encoders", [])
            hw = next((e for e in hws if e.startswith("h264_")), None)

        out = EXPORTS_DIR / f"{exp.id}_{aspect.replace(':', 'x')}_{resolution}.mp4"
        director_plan = None
        if engine == "speaker" and not p.get("segments") and video.transcript:
            from .pipeline import director
            from .pipeline.edit import content_kind
            kind = QUALITY_KIND.get(p.get("preset") or "", None) or \
                content_kind({**(video.meta or {}), "filename": video.filename})
            progress(0.03, "Editorial Director: planning the edit")
            director_plan = director.plan(video.transcript, start, end, p, kind, video.meta, video.path)
            p = {**p, **director_plan["overrides"]}
            start = float(p.get("start", start))
            log.info("export %s director: %s", exp.id,
                     [f"{d['what']}={d['choice']}" for d in director_plan["decisions"] if d["applied"]])
        if p.get("segments"):
            verification = _render_ranking(video, clip, exp, p, aspect, resolution, profile, hw, out,
                                           progress, captions_on=captions_on, caption_style=style)
        elif engine == "speaker":
            verification = _render_speaker_framed(video, clip, exp, p, start, end, aspect,
                                                  resolution, profile, None, hw, out, progress,
                                                  captions_on=captions_on, caption_style=style)
        else:
            progress(0.2, f"Rendering {resolution} {aspect} ({profile}{', ' + hw if hw else ''})")
            verification = render_clip(
                video.path, out, start, end,
                src_w=video.meta["width"], src_h=video.meta["height"],
                aspect=aspect, resolution=resolution, profile=profile,
                ass_path=ass_path, fps=p.get("fps"), codec=p.get("codec", "h264"),
                audio_normalize=p.get("audio_normalize", True), hw_encoder=hw,
                crop_x_frac=p.get("crop_x"),
            )
        if engine == "speaker" and not p.get("segments") and _setting("quality_check"):
            verification = _inspect_and_repair(video, clip, exp, p, start, end, aspect, resolution, profile,
                                               hw, out, progress, captions_on, style, verification)
        if resolution == "2160p" and video.meta.get("height", 0) < 2160 and video.meta.get("width", 0) < 3840:
            verification["note"] = "Upscaled from a lower-resolution source — not native 4K."
        base = out.with_name(out.stem + ".base.mp4")
        base.unlink(missing_ok=True)
        if p.get("text_overlays"):
            # the editor shows this clean copy and draws the text on top, so text stays editable
            progress(0.99, "Adding your text layers")
            shutil.copy(out, base)
            _burn_text_layers(out, p["text_overlays"], hw, profile, clip,
                              (p.get("caption_design") or {}).get("font", "Poppins ExtraBold"))
        exp.path = str(out)
        _make_thumb(out)
        import datetime as _dt
        verification["rendered_at"] = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
        if director_plan:
            verification["plan"] = director_plan
        exp.status = "done"
        exp.verification = verification
        db.commit()
        progress(1.0, "Done")
    except Exception as e:  # noqa: BLE001
        d = SessionLocal()
        try:
            x = d.get(Export, export_id)
            if x:
                x.status = "failed"
                x.error = str(e)
                d.commit()
        finally:
            d.close()
        raise
    finally:
        db.close()


def _watermark_param(w):
    """Validated watermark settings + the logo file path (None when not set or the logo was deleted)."""
    from .pipeline.fx import clean_watermark
    from . import watermarks
    wc = clean_watermark(w)
    p_ = watermarks.path_of(wc["id"]) if wc else None
    return {**wc, "path": str(p_)} if p_ else None


QUALITY_KIND = {"tv_clip": "tv", "sitcom": "tv", "meme": "tv", "comedy_skit": "tv", "clip_page": "tv",
                "stream_clip": "stream", "motivation": "montage"}


def _inspect_and_repair(video, clip, exp, p, start, end, aspect, resolution, profile, hw, out, progress,
                        captions_on, style, verification) -> dict:
    """Render -> inspect the actual file -> fix -> re-render -> re-inspect (bounded passes).
    Never raises: a failing inspector must not lose a finished export."""
    from .pipeline import quality, repair
    from .pipeline.edit import PRESETS
    from .settings_store import get as _setting
    try:
        kind = QUALITY_KIND.get(p.get("style_preset") or p.get("preset") or "", "talk")
        expect = {"width": verification.get("width") or (verification.get("output") or {}).get("width"),
                  "height": verification.get("height") or (verification.get("output") or {}).get("height"),
                  "captions": bool(captions_on)}
        base_cap = (PRESETS.get(p.get("style_preset") or "") or {}).get("caption") or {}
        progress(0.96, "Quality check: inspecting the rendered video")
        rep = quality.inspect(out, expect, kind=kind)
        history = [{"pass": 0, "scores": rep["scores"], "overall": rep["overall"],
                    "defects": rep["defects"]}]
        notes: list[str] = []
        passes = int(_setting("auto_repair_passes") or 0)
        cur_p = dict(p)
        for i in range(1, passes + 1):
            fix = repair.plan(rep, cur_p, base_cap)
            if not fix["params"]:
                break
            progress(0.96, f"Auto-repair pass {i}: " + "; ".join(fix["notes"])[:120])
            log.info("export %s repair pass %d: %s", exp.id, i, fix["notes"])
            tmp = out.with_name(out.stem + f".r{i}.mp4")
            cur_p = fix["params"]
            s2, e2 = float(cur_p.get("start", start)), float(cur_p.get("end", end))
            v2 = _render_speaker_framed(video, clip, exp, cur_p, s2, e2, aspect, resolution, profile,
                                        None, hw, tmp, lambda f, st="": progress(0.96, f"Repair render: {st}"),
                                        captions_on=captions_on, caption_style=style)
            rep2 = quality.inspect(tmp, expect, kind=kind)
            history.append({"pass": i, "scores": rep2["scores"], "overall": rep2["overall"],
                            "defects": rep2["defects"], "changes": fix["notes"]})
            if rep2["overall"] >= rep["overall"]:          # keep only real improvements
                shutil.move(str(tmp), str(out))
                rep, verification = rep2, v2
                notes += fix["notes"]
            else:
                tmp.unlink(missing_ok=True)
                notes.append(f"pass {i} rejected (score {rep2['overall']} < {rep['overall']})")
                break
        post = repair.plan(rep, cur_p, base_cap)["post"]
        if post:
            progress(0.98, "Auto-repair: audio")
            repair.apply_post(out, post, float(rep["probe"].get("duration") or 0))
            notes += [n for n in repair.plan(rep, cur_p, base_cap)["notes"] if "audio" in n or "fade" in n]
            rep = quality.inspect(out, expect, kind=kind)
            history.append({"pass": "audio", "scores": rep["scores"], "overall": rep["overall"],
                            "defects": rep["defects"], "changes": post})
        verification = dict(verification)
        verification["quality"] = {
            "overall": rep["overall"], "scores": rep["scores"], "approved": rep["approved"],
            "defects": rep["defects"], "measurements": rep["measurements"],
            "repairs": notes, "history": history, "note": rep["note"],
            "initial_overall": history[0]["overall"]}
    except Exception as e:  # noqa: BLE001
        log.exception("quality check failed for export %s", exp.id)
        verification = {**verification, "quality": {"error": str(e)[:300]}}
    return verification


def _render_ranking(video, clip, exp, p, aspect, resolution, profile, hw, out, progress,
                    captions_on=True, caption_style="fodo_orange") -> dict:
    """'TOP N' ranking video (IShowSpeed / xQc / Valorant compilation pages): the best moment of
    each chosen topic, counting down from #N to #1, with the numbered list filling in on top."""
    import subprocess as _sp
    from .pipeline import looks
    from .pipeline.compose import _encoder_args, verify_output
    segs = p["segments"]                       # play order: #N first ... #1 last
    work = WORK_DIR / clip.id
    work.mkdir(parents=True, exist_ok=True)
    parts, starts, t = [], [], 0.0
    sub = {**p, "hook_title": False, "segments": None,
           "look": {**(p.get("look") or {}), "cta": None, "intro": 0.0, "outro": 0.0, "end_hold": 0.3}}
    for i, seg in enumerate(segs):
        a, b = float(seg[0]), float(seg[1])
        part = work / f"rank_{i}.mp4"
        n = len(segs)
        _render_speaker_framed(video, clip, exp, sub, a, b, aspect, resolution, profile, None, hw, part,
                               lambda f, st="", i=i: progress(0.05 + 0.85 * (i + f) / n, f"#{n - i}: {st}"),
                               captions_on=captions_on, caption_style=caption_style)
        d = float(_sp.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0",
                           str(part)], capture_output=True, text=True).stdout.strip() or 0)
        parts.append(part)
        starts.append((t, d))
        t += d
    total = t
    (work / "rank_list.txt").write_text("".join(f"file '{x.name}'\n" for x in parts), encoding="utf-8")
    progress(0.92, "Ranking list + final encode")
    w_, h_ = [int(x) for x in _sp.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                                       "stream=width,height", "-of", "csv=p=0", str(parts[0])],
                                      capture_output=True, text=True).stdout.strip().split(",")[:2]]
    ass = looks.ranking_ass(p.get("ranking_title") or clip.title, [s_[2] for s_ in segs], starts,
                            w_, h_, total, work / "rank.ass",
                            accent=(p.get("caption_design") or {}).get("highlight", "#FFD400"))
    import shutil as _sh
    from .pipeline.compose import FONTS_DIR
    _sh.copytree(FONTS_DIR, work / "fonts", dirs_exist_ok=True)
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", "rank_list.txt",
           "-vf", "ass=rank.ass:fontsdir=fonts", *_encoder_args(hw, 20, "medium", True), "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k",
           *[x for k, v in _file_meta(video, clip, segs[0][0], segs[-1][1]).items() if v
             for x in ("-metadata", f"{k}={str(v)[:250]}")],
           "-movflags", "+faststart", str(Path(out).resolve())]
    r = _sp.run(cmd, cwd=str(work), capture_output=True, text=True)
    if r.returncode != 0 and hw:
        i0 = cmd.index("-c:v")
        cmd[i0:i0 + len(_encoder_args(hw, 20, "medium", True))] = _encoder_args(None, 20, "medium", True)
        r = _sp.run(cmd, cwd=str(work), capture_output=True, text=True)
    if r.returncode != 0:
        raise RuntimeError(f"ranking encode failed: {r.stderr[-400:]}")
    v = verify_output(out, expected_duration=total)
    v["output"] = {"width": w_, "height": h_, "duration": round(total, 2), "ranking": len(segs),
                   "preset": p.get("preset"), "encoder": hw or "libx264", "framing": f"ranking of {len(segs)}"}
    for x in parts:
        x.unlink(missing_ok=True)
    return v


def _video_title(video) -> str:
    return ((video.meta or {}).get("source_title") or Path(video.filename).stem or "video")


def _file_meta(video, clip, start, end) -> dict:
    """Written inside the MP4 so a downloaded clip can always be identified (Explorer → Properties)."""
    import datetime as _dt

    def hms(t):
        t = int(t)
        return f"{t // 3600}:{t % 3600 // 60:02d}:{t % 60:02d}"
    return {"title": clip.title or "FODO clip", "artist": "FODO ClipForge",
            "album": _video_title(video)[:120],
            "comment": f"From: {_video_title(video)[:120]} | {hms(start)}-{hms(end)} | "
                       f"rendered {_dt.datetime.now().strftime('%d %b %Y %H:%M')}"}


def _make_thumb(out: Path) -> None:
    import subprocess as _sp
    try:
        _sp.run(["ffmpeg", "-y", "-v", "error", "-ss", "1.2", "-i", str(out), "-frames:v", "1",
                 "-vf", "scale=360:-2", str(Path(out).with_suffix(".jpg"))], timeout=60)
    except Exception:  # noqa: BLE001
        pass


def _save_caption_words(clip, words: list[dict], start: float, end: float) -> None:
    """Keep the clip's caption words (source time) so the caption studio can show and edit them."""
    try:
        d = SessionLocal()
        try:
            c = d.get(Clip, clip.id)
            if c is not None:
                ws = [{"w": w["w"], "s": round(w["s"], 3), "e": round(w["e"], 3)}
                      for w in words if w["s"] >= start - 0.05 and w["e"] <= end + 3.5][:1500]
                c.settings = {**(c.settings or {}), "caption_words": ws}
                d.commit()
        finally:
            d.close()
    except Exception:  # noqa: BLE001
        log.exception("could not store caption words")


def settle_end(words: list[dict] | None, start: float, end: float, limit: float | None = None,
               hold: float = 0.45) -> float:
    """Never stop a clip mid-word or mid-sentence, and leave a short breath after the last
    word - an abrupt cut on the last syllable is what makes an ending feel wrong."""
    if not words:
        return end
    ws = [w for w in words if w["e"] > start]
    if not ws:
        return end
    new_end = end
    for w in ws:                                  # finish a word cut in half
        if w["s"] < new_end < w["e"]:
            new_end = w["e"]
    inside = [w for w in ws if w["e"] <= new_end + 0.02]
    if inside:
        last = inside[-1]
        txt = (last.get("w") or "").strip()
        if not txt.endswith((".", "?", "!", "\u0964", "...")):
            # sentence still running: finish it if it ends within 3 s
            for w in ws:
                if w["s"] >= new_end and w["e"] - end <= 3.0:
                    new_end = w["e"]
                    if (w.get("w") or "").strip().endswith((".", "?", "!", "\u0964")):
                        break
                elif w["s"] >= new_end:
                    break
        # a short line said right after (the punchline / pay-off) belongs to the ending
        follow = [w for w in ws if w["s"] > new_end + 0.01]
        if follow and follow[0]["s"] - new_end <= 0.8:
            stop = None
            for w in follow:
                if w["e"] - follow[0]["s"] > 3.0:
                    break
                if (w.get("w") or "").strip().endswith((".", "?", "!", "\u0964")):
                    stop = w["e"]
                    break
            if stop and stop - end <= 3.5:
                new_end = stop
        nxt = next((w["s"] for w in ws if w["s"] > new_end + 0.01), None)
        tail = hold if nxt is None else max(0.0, min(hold, nxt - new_end - 0.06))
        new_end += tail
    if limit:
        new_end = min(new_end, limit)
    return max(end, new_end) if new_end - end <= 3.5 else end


_TRACK_CACHE: dict = {}          # (video, start, end) -> speaker analysis; repair passes reuse it


def _cache_put(key, value) -> None:
    if len(_TRACK_CACHE) > 24:
        _TRACK_CACHE.pop(next(iter(_TRACK_CACHE)))
    _TRACK_CACHE[key] = value


def _render_speaker_framed(video, clip, exp, p, start, end, aspect, resolution, profile,
                           ass_path, hw, out, progress, captions_on=True,
                           caption_style="fodo_orange") -> dict:
    from .pipeline import compose as _cmp
    cap = p.get("zoom_cap")
    saved = (_cmp.MAX_UPSCALE, _cmp.MAX_TOTAL_UPSCALE)
    if cap:              # repair pass asked for a wider, sharper crop (one worker -> safe to swap)
        _cmp.MAX_UPSCALE = _cmp.MAX_TOTAL_UPSCALE = float(cap)
    try:
        return _render_speaker_framed_inner(video, clip, exp, p, start, end, aspect, resolution, profile,
                                            ass_path, hw, out, progress, captions_on, caption_style)
    finally:
        _cmp.MAX_UPSCALE, _cmp.MAX_TOTAL_UPSCALE = saved


def _render_speaker_framed_inner(video, clip, exp, p, start, end, aspect, resolution, profile,
                                 ass_path, hw, out, progress, captions_on=True,
                                 caption_style="fodo_orange") -> dict:
    """Speaker tracking -> shot plan -> dead-air cut -> per-piece render ->
    grade, captions, motion graphics, music and sound design."""
    from .config import ASPECT_RATIOS, PERFORMANCE_PROFILES
    from .pipeline import edit, speakers
    from .pipeline.compose import music_path, render_vertical
    from .pipeline.export import RESOLUTION_HEIGHTS

    sw, sh = int(video.meta["width"]), int(video.meta["height"])
    look = dict(p.get("look") or {})
    end = settle_end(video.transcript, start, end, float(video.meta.get("duration") or 0) or None,
                     hold=float(look.get("end_hold", 0.45)))
    bw, bh = ASPECT_RATIOS.get(aspect, ASPECT_RATIOS["9:16"])
    scale = RESOLUTION_HEIGHTS.get(resolution, 1080) / min(bw, bh)
    out_w, out_h = int(bw * scale) // 2 * 2, int(bh * scale) // 2 * 2
    dur = end - start
    framing = p.get("framing", "auto")
    work = WORK_DIR / clip.id
    work.mkdir(parents=True, exist_ok=True)

    keep = None
    level = p.get("dead_air", "off")
    if edit.DEAD_AIR.get(level):
        progress(0.08, "Finding pauses to cut (dead air)")
        keep = edit.keep_from_silences(edit.silences(video.path, start, end), dur, edit.DEAD_AIR[level])
        log.info("clip %s dead air (%s): keep %d ranges, %.1fs -> %.1fs", clip.id, level, len(keep),
                 dur, edit.kept_duration(keep))
    if p.get("remove_fillers", True) and video.transcript:
        k2 = edit.cut_fillers(keep, video.transcript, start, end)
        if k2 != keep:
            log.info("clip %s filler sounds removed: %d ranges", clip.id, len(k2 or []))
        keep = k2
    if p.get("cut_ranges"):
        rel = [(a - start, b - start) for a, b in p["cut_ranges"] if b > start and a < end]   # stored in video time
        k3 = edit.apply_cuts(keep, dur, rel)
        log.info("clip %s manual cuts: %d ranges removed", clip.id, len(p["cut_ranges"]))
        keep = k3
    new_dur = edit.kept_duration(keep) if keep else dur

    design = dict(p.get("caption_design") or clip.settings.get("caption_design") or {})
    graphics = None
    cap_src = None
    if captions_on and video.transcript:
        progress(0.1, "Building captions")
        from .pipeline.caption_lang import caption_words, script_of
        cap_src = caption_words(video, start, end, p.get("caption_lang", "auto"),
                                prompt=f"{clip.title}. {_video_title(video)}"[:220],
                                progress=lambda st: progress(0.1, st),
                                accurate=bool(p.get("accurate_captions", True)))
        from .pipeline.caption_library import auto_pick, preset_design
        deva = script_of(cap_src) == "devanagari"
        if design.get("preset") == "auto":     # Auto: pick a look from the clip's topic + language
            ctx = f"{clip.title} {_video_title(video)} " + " ".join(w.get("w", "") for w in (cap_src or [])[:120])
            pid = auto_pick(ctx, deva)
            keep_ = {k: design[k] for k in ("position",) if k in design}
            design = {**preset_design(pid), **keep_, "preset": pid}
            log.info("clip %s auto caption style: %s", clip.id, pid)
        # Devanagari captions keep the chosen look: build_ass swaps in a Hindi-capable font of the same feel
        log.info("clip %s captions: lang=%s spoken=%s script=%s words=%d", clip.id, p.get("caption_lang", "auto"),
                 (video.meta or {}).get("spoken_lang", "?"), "devanagari" if deva else "latin", len(cap_src or []))
        from .pipeline.captions import add_bilingual, apply_override, build_srt
        # manual corrections from the caption studio (source time) win over the AI transcript
        cap_src = apply_override(cap_src, (clip.settings or {}).get("caption_override"))
        _save_caption_words(clip, cap_src, start, end)
        words = edit.remap_words(cap_src, start, end, keep) if keep else cap_src
        c0, c1 = (0.0, new_dur) if keep else (start, end)
        ass_path = build_ass(words, c0, c1, caption_style, out_w, out_h, work / "caps.ass",
                             placement=p.get("placement", "lower"), design=design)
        if p.get("bilingual") and p.get("caption_lang") != "english":
            progress(0.11, "Bilingual captions: translating to English")
            try:
                eng = caption_words(video, start, end, "english", accurate=bool(p.get("accurate_captions", True)))
                norm = lambda ws: {re.sub(r"[^a-z0-9]", "", w["w"].lower()) for w in ws} - {""}   # noqa: E731
                a_, b_ = norm(cap_src), norm(eng)
                same = len(a_ & b_) / max(1, len(b_))
                if same > 0.6:
                    log.info("clip %s bilingual skipped: speech is already English (%.0f%% same words)", clip.id, same * 100)
                else:
                    eng_w = edit.remap_words(eng, start, end, keep) if keep else eng
                    add_bilingual(ass_path, eng_w, c0, c1, out_w, out_h,
                                  above=design.get("position") in ("lower", "low_subtitle"))
            except Exception:  # noqa: BLE001
                log.exception("bilingual captions failed - main captions kept")
        build_srt(words, c0, c1, work / "caps.srt")
        # subtitle files delivered next to the video (SRT / ASS; VTT is made on download)
        try:
            shutil.copy(work / "caps.srt", Path(out).with_suffix(".srt"))
            shutil.copy(ass_path, Path(out).with_suffix(".ass"))
        except OSError:
            pass
    p = {**p, "caption_design": design}
    # words in output time (for keyword pops), whether or not captions are shown
    from .pipeline import looks
    kw_words = []
    kw_src = cap_src if (captions_on and video.transcript) else (video.transcript or [])
    if (look.get("keyword_pop") or look.get("flash") or p.get("punch_zoom")) and kw_src:
        src = edit.remap_words(kw_src, start, end, keep) if keep else [
            {**w, "s": w["s"] - start, "e": w["e"] - start} for w in kw_src
            if w["s"] >= start - 0.05 and w["e"] <= end + 0.05]
        kw_words = src
    title = (p.get("hook_text") or clip.title) if p.get("hook_title") else None
    hook_style = p.get("hook_style") or "auto"
    kind = look.get("title_kind", "none") if hook_style == "auto" else "none"
    graphics = looks.build(kind, title, out_w, out_h, new_dur, work / "look.ass",
                           font=p.get("hook_font") or design.get("font", "Poppins ExtraBold"),
                           accent=p.get("hook_bg") or design.get("highlight", "#FF5900"),
                           cta=look.get("cta"), words=kw_words, keyword_pop=bool(look.get("keyword_pop")),
                           flash=bool(look.get("flash")))
    if title and hook_style != "auto":
        try:
            hook = edit.hook_title_ass(
                title, out_w, out_h, work / "hook.ass", font=p.get("hook_font") or design.get("font", "Anton"),
                accent=p.get("hook_bg") or design.get("highlight", "#FF5900"),
                text_color=p.get("hook_color") or "#FFFFFF", style=hook_style)
            graphics = looks.merge(hook, graphics) if graphics else hook
        except ValueError:
            pass

    cam_box = None
    pre_crop = None
    if p.get("hide_text", True) and look.get("frame") not in ("native", "letterbox", "cinema"):
        from .pipeline import textbands
        progress(0.11, "Checking for text already in the video")
        try:
            pre_crop = textbands.to_crop(textbands.detect(video.path, start, end), sw, sh)
        except Exception as e:  # noqa: BLE001
            log.warning("text band check failed: %s", e)
        if pre_crop:
            log.info("clip %s: burned-in text band found - cropping rows %d..%d of %d",
                     clip.id, pre_crop[0], pre_crop[0] + pre_crop[1], sh)
    if framing == "manual":
        cx = float(p.get("crop_x") if p.get("crop_x") is not None else 0.5)
        shots = [{"start": 0.0, "end": dur, "layout": "single", "tids": [0],
                  "boxes": [[max(0.0, cx - 0.05), 0.25, 0.1, 0.22]], "others": []}]
        log.info("clip %s: manual crop at x=%.2f", clip.id, cx)
    elif (out_w / out_h) >= (sw / sh) * 0.95 or look.get("frame") in ("native", "letterbox", "cinema"):
        shots = [{"start": 0.0, "end": dur, "layout": "wide", "tids": [], "boxes": []}]
        log.info("clip %s: target is as wide as the source - full frame", clip.id)
    else:
        ck = (str(video.path), round(start, 2), round(end, 2))
        ana = copy.deepcopy(_TRACK_CACHE.get(ck))       # plan/remap edit boxes in place
        if ana is None:
            progress(0.12, "Tracking faces, camera cuts and who is speaking")
            ana = speakers.analyse(video.path, start, end, sw, sh,
                                   progress=lambda f: progress(0.12 + f * 0.30,
                                                               f"Tracking speakers {f*100:.0f}%"))
            _cache_put(ck, copy.deepcopy(ana))
        else:
            progress(0.4, "Re-using the speaker tracking from the last render")
        shots = speakers.plan(ana, dur, None, mode=framing)
        if (p.get("layout", "auto") == "auto" and framing in ("auto", "smart", "speaker")
                and look.get("frame") in ("fill", "frame45", "frame65") and dur > 0):
            # no face on screen most of the time: gameplay, sport, screen recording, scenery.
            # A centre crop would throw the action away - use the facecam layout or the whole frame.
            no_face = sum(s_["end"] - s_["start"] for s_ in shots if s_["layout"] == "wide") / dur
            if no_face >= 0.6:
                fk = ck + ("facecam",)
                if fk not in _TRACK_CACHE:
                    progress(0.42, "Mostly no face on screen - looking for a streamer facecam")
                    _cache_put(fk, speakers.find_facecam(video.path, start, end, sw, sh))
                look["frame"] = "stream" if _TRACK_CACHE[fk] else "native"
                log.info("clip %s auto layout: %.0f%% without a face -> %s", clip.id, no_face * 100,
                         look["frame"])
        if look.get("frame") == "stream":
            fk = ck + ("facecam",)
            if fk not in _TRACK_CACHE:
                _cache_put(fk, speakers.find_facecam(video.path, start, end, sw, sh))
            fc = _TRACK_CACHE[fk]
            if fc:
                f_ = fc["face"]
                cam_box = fc["panel"] + [f_[0] + f_[2] / 2, f_[1] + f_[3] / 2]   # panel + face centre
            else:
                cam_box = speakers.facecam_box(ana)
            log.info("clip %s stream layout facecam: %s", clip.id, cam_box)
        log.info("clip %s framing (%s): %d shots, %d camera cuts - %s", clip.id, framing, len(shots),
                 len(ana.get("cuts", [])), speakers.summary(shots))
    rsh = sh
    if pre_crop:
        from .pipeline.textbands import remap_box
        y0, rsh = pre_crop
        for s_ in shots:
            s_["boxes"] = [remap_box(b, sh, y0, rsh) for b in s_.get("boxes") or []]
            s_["others"] = [remap_box(b, sh, y0, rsh) for b in s_.get("others") or []]
        if cam_box:
            extra = cam_box[4:]
            cam_box = remap_box(cam_box[:4], sh, y0, rsh)
            if extra:
                cam_box += [extra[0], max(0.0, min(1.0, (extra[1] * sh - y0) / rsh))]
    punch = []
    if p.get("punch_zoom") and kw_words:
        punch = [k["t"] for k in looks.keyword_moments(kw_words, new_dur, every=6.0)][:6]
    preset, crf = PERFORMANCE_PROFILES.get(profile, PERFORMANCE_PROFILES["balanced"])
    music = music_path(p.get("music"), MUSIC_USER_DIR) if p.get("music") else None
    m_start, m_end, beats = float(p.get("music_start") or 0.0), p.get("music_end"), None
    if music and (p.get("music_hook") in ("auto", "intro", "chorus", "drop") or p.get("beat_sync")):
        try:
            from .pipeline.music_analysis import analyze as _analyze
            ana = _analyze(music, WORK_DIR / "music_analysis")
            beats = ana["beats"] if p.get("beat_sync") else None
            want = {"auto": "chorus"}.get(p.get("music_hook"), p.get("music_hook"))
            hk = next((h for h in ana["hooks"] if h["type"] == want), None)
            if hk and p.get("music_start") is None:
                m_start, m_end = hk["start"], None        # play on from the hook (loops if needed)
                log.info("clip %s music hook %s at %.1fs (%s)", clip.id, want, hk["start"], hk["why"])
            if beats and m_start:                        # start exactly on a beat
                from .pipeline.music_analysis import snap_to_beat
                m_start = snap_to_beat(m_start, ana["downbeats"] or beats)
        except Exception:  # noqa: BLE001
            log.exception("music analysis failed - using the song from the start")
    v = render_vertical(
        video.path, out, start, end, sw, rsh, float(p.get("fps") or video.meta.get("fps") or 30), shots,
        out_w, out_h, work, edit_style=p.get("edit_style", "clean"),
        ass_path=ass_path, music=music, music_volume=float(p.get("music_volume", 18)) / 100,
        duck=bool(p.get("duck", True)), hw=hw, crf=crf, preset=preset,
        progress=lambda f, st: progress(0.42 + f * 0.56, st), keep=keep,
        jump_zoom=float(p.get("jump_zoom", 1.0)),
        sfx={"level": p.get("sfx", "off"), "hook": bool(title), "cta": bool(look.get("cta"))},
        graphics_ass=graphics, progress_bar=bool(p.get("progress_bar")),
        accent=(p.get("caption_design") or {}).get("highlight", "#FF5900"),
        slow_push=bool(p.get("slow_push")), music_mode=p.get("music_mode", "auto"),
        meta=_file_meta(video, clip, start, end),
        frame=("tv" if framing == "tv" else
               ("fill" if look.get("frame") == "stream" and not cam_box else look.get("frame", "fill"))),
        cam_box=cam_box, pre_crop=pre_crop, punch=punch,
        music_start=m_start, music_end=(float(m_end) if m_end else None),
        music_delay=float(p.get("music_delay") or 0.0),
        orig_volume=float(p.get("orig_volume", 100)) / 100, duck_level=p.get("duck_level") or "light",
        voice_enhance=bool(p.get("voice_enhance")), codec=p.get("codec", "h264"),
        bitrate_kbps=p.get("bitrate_kbps"), beats=beats,
        intro=float(look.get("intro", 0.0)), outro=float(look.get("outro", 0.35)),
        grain=bool(look.get("grain")), fx=p.get("fx"), watermark=_watermark_param(p.get("watermark")))
    sp = float(p.get("speed") or 1.0)
    if sp != 1.0:
        progress(0.99, f"Changing speed to {sp}x")
        _change_speed(Path(out), sp, hw, crf, preset)
        v["output"]["speed"] = sp
        if v["output"].get("duration"):
            v["output"]["duration"] = round(float(v["output"]["duration"]) / sp, 2)
    v["output"]["framing"] = speakers.summary(shots)
    v["output"]["text_band_cropped"] = bool(pre_crop)
    v["output"]["punch_zooms"] = len(punch)
    v["output"].pop("changes", None)
    v["output"]["preset"] = p.get("preset")
    v["output"]["source_end"] = round(end, 2)
    return v


def _burn_text_layers(out: Path, layers: list, hw, profile: str, clip, font: str) -> None:
    import json as _json
    import subprocess as _sp
    from .config import PERFORMANCE_PROFILES
    from .pipeline import edit
    from .pipeline.compose import FONTS_DIR, final_encoder_args
    pr = _sp.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries",
                  "stream=width,height:format=duration", "-of", "json", str(out)], capture_output=True, text=True)
    j = _json.loads(pr.stdout or "{}")
    w, h = int(j["streams"][0]["width"]), int(j["streams"][0]["height"])
    dur = float(j["format"]["duration"])
    wd = WORK_DIR / clip.id / "layers"
    shutil.rmtree(wd, ignore_errors=True)
    wd.mkdir(parents=True)
    if not edit.text_layers_ass(layers, w, h, dur, wd / "layers.ass", font=font):
        return
    shutil.copytree(FONTS_DIR, wd / "fonts", dirs_exist_ok=True)
    try:
        from .pipeline.captions import user_font_dir
        for f_ in user_font_dir().glob("*.[ot]tf"):
            shutil.copy(f_, wd / "fonts" / f_.name)
    except OSError:
        pass
    preset, crf = PERFORMANCE_PROFILES.get(profile, PERFORMANCE_PROFILES["balanced"])
    tmp = out.with_name(out.stem + ".txt.mp4")
    r = _sp.run(["ffmpeg", "-y", "-v", "error", "-i", str(out), "-vf", "ass=layers.ass:fontsdir=fonts",
                 *final_encoder_args(hw, crf, preset), "-pix_fmt", "yuv420p", "-c:a", "copy",
                 "-movflags", "+faststart", str(tmp)], capture_output=True, text=True, cwd=str(wd))
    if r.returncode != 0 or not tmp.exists():
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"text layers failed: {r.stderr[-300:]}")
    shutil.move(str(tmp), str(out))


def _change_speed(path: Path, speed: float, hw, crf: int, preset: str) -> None:
    """Whole-clip speed change (0.75x-1.5x). Pitch stays natural (atempo); burned captions and
    graphics speed up with the picture, so everything stays in sync."""
    import subprocess as _sp
    from .pipeline.compose import final_encoder_args
    tmp = path.with_name(path.stem + ".speed.mp4")
    r = _sp.run(["ffmpeg", "-y", "-v", "error", "-i", str(path), "-filter_complex",
                 f"[0:v]setpts=PTS/{speed}[v];[0:a]atempo={speed}[a]", "-map", "[v]", "-map", "[a]",
                 *final_encoder_args(hw, crf, preset), "-c:a", "aac", "-b:a", "192k",
                 "-movflags", "+faststart", str(tmp)], capture_output=True, text=True)
    if r.returncode != 0 or not tmp.exists():
        tmp.unlink(missing_ok=True)
        log.warning("speed change failed, keeping 1x: %s", r.stderr[-300:])
        return
    shutil.move(str(tmp), str(path))


BOT_RETRY_S = 600


def schedule_bot_retry(video_id: str, delay: float) -> None:
    import threading
    from .jobs import enqueue
    t = threading.Timer(max(1.0, delay), lambda: enqueue("import_url", video_id))
    t.daemon = True
    t.start()


def resume_bot_retries() -> int:
    """After a restart: downloads that were waiting out a YouTube bot check get their timer back."""
    db = SessionLocal()
    n = 0
    try:
        for v in db.query(Video).filter(Video.status == "queued").all():
            at = (v.meta or {}).get("bot_retry_at")
            if at:
                schedule_bot_retry(v.id, float(at) - time.time())
                n += 1
    finally:
        db.close()
    return n


@handler("import_url")
def import_url_job(video_id: str, progress) -> None:
    from .config import MAX_UPLOAD_MB, UPLOADS_DIR
    from .jobs import enqueue
    from .pipeline.metadata import extract_metadata
    from .pipeline.url_import import BotCheck, download, download_platform, is_direct_media

    db = SessionLocal()
    try:
        video = db.get(Video, video_id)
        url = video.meta.get("source_url")
        auto = video.meta.get("auto_analyze", True)
        video.status = "downloading"
        db.commit()
        max_bytes = MAX_UPLOAD_MB * 1024 * 1024
        try:
            if is_direct_media(url):
                progress(0.05, "Downloading file")
                dest = download(url, UPLOADS_DIR / f"{video.id}.mp4", max_bytes)
                info = {"title": None, "source_url": url, "extractor": "direct"}
            elif video.meta.get("live_rewind") and video.meta.get("section"):
                # a part of a stream that is still live: only its own pieces are fetched
                from .pipeline import live_rewind
                progress(0.02, "Fetching the earlier part of the live stream")
                sa, sb = video.meta["section"]
                dest, ra, rb = live_rewind.download_section(
                    url, sa, sb, UPLOADS_DIR / f"{video.id}.mp4",
                    progress=lambda p: progress(0.05 + p * 0.85, f"Downloading {p*100:.0f}%"))
                shift = sa - ra                                   # pieces start a little earlier
                am = dict(video.meta.get("auto_mode") or {})
                if isinstance(am.get("moment"), dict):
                    am["moment"] = {**am["moment"], "start": round(am["moment"]["start"] + shift, 2),
                                    "end": round(am["moment"]["end"] + shift, 2)}
                video.meta = {**video.meta, "section": [round(ra, 2), round(rb, 2)], "auto_mode": am}
                db.commit()
                info = {"title": None, "source_url": url, "extractor": "Youtube"}
            else:
                progress(0.02, "Fetching video info")
                sec = video.meta.get("section")
                dest, info = download_platform(
                    url, UPLOADS_DIR, video.id, max_bytes,
                    progress=lambda p: progress(0.05 + p * 0.85, f"Downloading {p*100:.0f}%"),
                    section=tuple(sec) if sec else None)
            progress(0.93, "Reading metadata")
            meta = extract_metadata(dest)
        except BotCheck:
            # YouTube's temporary "not a bot" check on this PC: try again by itself later (3 times, 10 min apart)
            n = int((video.meta or {}).get("bot_retries") or 0) + 1
            if n > 3:
                video.status = "failed"
                db.commit()
                raise
            video.status = "queued"
            video.meta = {**(video.meta or {}), "bot_retries": n, "bot_retry_at": time.time() + BOT_RETRY_S}
            db.commit()
            schedule_bot_retry(video.id, BOT_RETRY_S)
            progress(1.0, f"YouTube bot check - trying again by itself in {BOT_RETRY_S // 60} min (try {n} of 3)")
            log.warning("video %s: YouTube bot check - retry %d in %d s", video.id, n, BOT_RETRY_S)
            return
        except Exception:
            video.status = "failed"
            db.commit()
            raise
        meta.update({"source_url": info.get("source_url") or url, "source_title": info.get("title"),
                     "source_uploader": info.get("uploader"), "source_site": info.get("extractor")})
        try:                                              # v0.14 tracking: when the download finished
            from .tracking import now_iso as _now_iso
            meta["downloaded_at"] = _now_iso()
        except Exception:
            pass
        for k in ("section", "auto_mode", "scan_id", "moment", "live_rewind", "import_type", "source_title_hint"):
            if video.meta.get(k) is not None:
                meta[k] = video.meta[k]
        video.meta = meta
        video.path = str(dest)
        if info.get("title") and not video.meta.get("section"):
            video.filename = (info["title"][:200] + ".mp4")
        video.status = "uploaded"
        db.commit()
        if auto:
            video.meta = {**meta, "analyze_job": enqueue("analyze", video.id)}
            db.commit()
        progress(1.0, "Downloaded")
    finally:
        db.close()
