#!/bin/bash
# FODO Studio - one-time setup on this Mac (safe to run again). No Homebrew, no admin password.
# Everything goes into this folder (tools/): Python 3.12 (via uv), a static FFmpeg with captions
# (libass) and x264, Deno for YouTube links, and Ollama + a local AI model sized to the memory.
# Native builds for Apple chips (M1-M4) and Intel Macs. Needs macOS 15 Sequoia or newer.
set -e
cd "$(dirname "$0")"
HERE="$(pwd)"
exec > >(tee setup_log.txt) 2>&1
echo "FODO Studio setup for Mac"
echo "This takes 5-15 minutes the first time (downloads about 1-3 GB). Keep this window open."

OSV="$(sw_vers -productVersion)"; MAJOR="${OSV%%.*}"
ARCH="$(uname -m)"                                    # arm64 (Apple chip) | x86_64 (Intel)
RAM_GB=$(( $(sysctl -n hw.memsize) / 1073741824 ))
CHIP="$(sysctl -n machdep.cpu.brand_string)"
echo "This Mac: $CHIP ($ARCH), ${RAM_GB} GB memory, macOS $OSV"
if [ "$MAJOR" -lt 15 ]; then
  echo ""
  echo "FODO Studio needs macOS 15 Sequoia or newer (this Mac has $OSV)."
  echo "Update macOS in System Settings > General > Software Update, then run this again."
  exit 1
fi
if [ "$ARCH" = "arm64" ] && [ "$(sysctl -n sysctl.proc_translated 2>/dev/null || echo 0)" = "1" ]; then
  ARCH="arm64"                                      # Terminal running under Rosetta: still install native arm64
fi

mkdir -p tools/bin storage
export PATH="$HERE/tools/bin:$PATH"
fetch() { curl -fL --retry 3 --retry-delay 2 --progress-bar -o "$2" "$1"; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

# Stop FODO Studio from THIS folder if it is running (updates).
pkill -f "$HERE/.venv/bin/python -m uvicorn backend.app.main" 2>/dev/null || true

# --- FFmpeg: static build with libass (captions) + x264 --------------------------------------
# Source: github.com/vanloctech/ffmpeg-macos (GPL). The builds FODO tested are pinned by sha256.
ff_ok() { tools/bin/ffmpeg -hide_banner -filters 2>/dev/null | grep -qE '^ *[.TSC]+ +ass ' &&
          tools/bin/ffmpeg -hide_banner -encoders 2>/dev/null | grep -q ' libx264 '; }
if ! ff_ok; then
  echo ""; echo "==> FFmpeg (video engine, ~35 MB)"
  if [ "$ARCH" = "arm64" ]; then FF=ffmpeg-macos-arm64.tar.gz; PIN=26f5133f88d5ab1254cc03499acef42dae2dbc574dd26e0dade8c968420127e9
  else FF=ffmpeg-macos-x64.tar.gz; PIN=8317f17790749fd3502384201fd4d9d2a998ff9b8452d3b8b54b3b9af6a16e39; fi
  fetch "https://github.com/vanloctech/ffmpeg-macos/releases/latest/download/$FF" "$TMP/ff.tgz"
  GOT="$(shasum -a 256 "$TMP/ff.tgz" | cut -d' ' -f1)"
  [ "$GOT" = "$PIN" ] && echo "FFmpeg build verified." || echo "Note: a newer FFmpeg build than the one FODO tested ($GOT). Checking that it works..."
  tar -xzf "$TMP/ff.tgz" -C tools/bin ffmpeg ffprobe
  chmod +x tools/bin/ffmpeg tools/bin/ffprobe
  xattr -d com.apple.quarantine tools/bin/ffmpeg tools/bin/ffprobe 2>/dev/null || true
fi
ff_ok || { echo "FFmpeg does not have captions (libass) and x264. Send setup_log.txt to FODO."; exit 1; }
tools/bin/ffmpeg -hide_banner -version | head -1

# --- Python 3.12 (uv, portable, no admin) ------------------------------------------------------
echo ""; echo "==> Python"
if [ ! -x tools/bin/uv ]; then
  UVA=$([ "$ARCH" = "arm64" ] && echo aarch64 || echo x86_64)
  fetch "https://github.com/astral-sh/uv/releases/latest/download/uv-$UVA-apple-darwin.tar.gz" "$TMP/uv.tgz"
  tar -xzf "$TMP/uv.tgz" -C "$TMP"
  cp "$TMP/uv-$UVA-apple-darwin/uv" tools/bin/uv && chmod +x tools/bin/uv
fi
export UV_PYTHON_INSTALL_DIR="$HERE/tools/python"
tools/bin/uv python install --no-bin 3.12
[ -x .venv/bin/python ] || tools/bin/uv venv --python 3.12 --seed .venv
.venv/bin/python --version

# --- App packages (prefer ready-made wheels: never compile for an hour) -------------------------
echo ""; echo "==> App packages (first time 3-6 minutes)"
.venv/bin/python -m pip install --upgrade pip --quiet
.venv/bin/python -m pip uninstall -y opencv-python opencv-python-headless >/dev/null 2>&1 || true
.venv/bin/python -m pip install --prefer-binary -r requirements.txt --quiet
# scenedetect pulls plain opencv-python, which clashes with the contrib build: keep only contrib
.venv/bin/python -m pip uninstall -y opencv-python opencv-python-headless >/dev/null 2>&1 || true
.venv/bin/python -m pip install --prefer-binary --force-reinstall --no-deps --quiet opencv-contrib-python-headless

# --- Deno (yt-dlp needs a JS runtime for YouTube links) -----------------------------------------
if [ ! -x tools/bin/deno ]; then
  echo ""; echo "==> Deno (for importing YouTube links)"
  DA=$([ "$ARCH" = "arm64" ] && echo aarch64 || echo x86_64)
  if fetch "https://github.com/denoland/deno/releases/latest/download/deno-$DA-apple-darwin.zip" "$TMP/deno.zip"; then
    unzip -o -q "$TMP/deno.zip" -d tools/bin && chmod +x tools/bin/deno
  else echo "Deno download failed: YouTube link import may not work (run setup again later)."; fi
fi

# --- Local AI (Ollama) sized to memory ----------------------------------------------------------
if [ "$RAM_GB" -ge 16 ]; then LLM="qwen2.5:3b"; elif [ "$RAM_GB" -ge 8 ]; then LLM="qwen2.5:1.5b"; else LLM=""; fi
USE_LLM=false
if [ -n "$LLM" ]; then
  OLL="tools/ollama/ollama"
  if [ ! -x "$OLL" ] && [ -x /Applications/Ollama.app/Contents/Resources/ollama ]; then OLL=/Applications/Ollama.app/Contents/Resources/ollama; fi
  if [ ! -x "$OLL" ]; then
    echo ""; echo "==> Local AI engine (Ollama, ~190 MB)"
    mkdir -p tools/ollama
    if fetch "https://github.com/ollama/ollama/releases/latest/download/ollama-darwin.tgz" "$TMP/ollama.tgz"; then
      tar -xzf "$TMP/ollama.tgz" -C tools/ollama
    fi
  fi
  if [ -x "$OLL" ]; then
    curl -s -m 2 http://127.0.0.1:11434/api/tags >/dev/null || { "$OLL" serve >/dev/null 2>&1 & sleep 5; }
    echo ""; echo "==> Local AI model $LLM (one time download)"
    "$OLL" pull "$LLM" && USE_LLM=true
  fi
else
  echo "Less than 8 GB memory: local AI titles are switched off so clipping stays smooth."
fi
.venv/bin/python - "$LLM" "$USE_LLM" <<'PYEOF'
import json, sys, pathlib
p = pathlib.Path("storage/settings.json")
try:
    s = json.loads(p.read_text(encoding="utf-8-sig")) if p.exists() else {}
except ValueError:
    s = {}
if sys.argv[1]:
    s["llm_model"] = sys.argv[1]
s["use_llm"] = sys.argv[2] == "true"
p.write_text(json.dumps(s, indent=1), encoding="utf-8")
PYEOF

echo ""; echo "==> Checking"
.venv/bin/python -c "import fastapi, faster_whisper, cv2, scenedetect, yt_dlp; assert hasattr(cv2, 'FaceDetectorYN'); print('All parts OK')"
touch .setup_done
echo ""
echo "FODO Studio is ready. Open it from Applications > FODO Studio (or Launchpad / Spotlight)."
echo "It checks this Mac's chip and memory on first start and sets its power to match."
