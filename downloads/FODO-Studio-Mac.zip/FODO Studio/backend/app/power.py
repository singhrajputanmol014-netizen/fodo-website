"""Power engine: reads this PC's processor, memory and graphics card once, then picks how hard
FODO Studio works on it. A strong PC gets the bigger speech models, the best export quality and
the GPU encoder; a weak PC gets lighter models, faster encodes and runs below normal priority so the
computer stays smooth while clips render.

Mode (Control Panel ▸ Power): auto (default, picked from the hardware) | max | balanced | saver.
Explicit settings the owner chose in the Control Panel always win over the power profile.
"""
from __future__ import annotations

import json
import logging
import os
import platform
import subprocess
import threading
import time

from .config import STORAGE_DIR

log = logging.getLogger("clipforge.power")
CACHE = STORAGE_DIR / "hardware.json"
MODES = ("auto", "max", "balanced", "saver")
_NO_WIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_lock = threading.Lock()
_hw: dict | None = None

# What each mode uses. whisper = model that finds the clips, caption = model for "Accurate captions",
# export = x264 profile when no GPU encoder, threads = share of CPU threads the AI may use.
PLANS = {
    "max":      {"whisper": "small", "caption": "large-v3-turbo", "export": "quality", "threads": 1.0,
                 "priority": "normal", "label": "Maximum: best models and quality, uses the whole machine"},
    "balanced": {"whisper": "small", "caption": "medium", "export": "balanced", "threads": 0.75,
                 "priority": "normal", "label": "Balanced: good quality, leaves room for other apps"},
    "saver":    {"whisper": "base", "caption": "small", "export": "economy", "threads": 0.5,
                 "priority": "below_normal", "label": "Saver: light models, fast encodes, PC stays smooth"},
}


def _ps(cmd: str, timeout: int = 20) -> str:
    try:
        return subprocess.run(["powershell", "-NoProfile", "-Command", cmd], capture_output=True, text=True,
                              timeout=timeout, creationflags=_NO_WIN).stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _cmd(args: list[str], timeout: int = 10) -> str:
    try:
        return subprocess.run(args, capture_output=True, text=True, timeout=timeout, creationflags=_NO_WIN).stdout
    except (OSError, subprocess.TimeoutExpired):
        return ""


def _probe() -> dict:
    """Slow part (PowerShell, nvidia-smi, test encodes). Runs in a background thread."""
    from .system import detect_hardware, ram_gb
    cpu_name, phys, logical, gpus = platform.processor() or platform.machine(), None, os.cpu_count() or 2, []
    if os.name == "nt":
        raw = _ps("$c=Get-CimInstance Win32_Processor|Select-Object -First 1 Name,NumberOfCores,NumberOfLogicalProcessors;"
                  "$g=Get-CimInstance Win32_VideoController|Select-Object Name,AdapterRAM;"
                  "@{cpu=$c;gpu=@($g)}|ConvertTo-Json -Depth 3 -Compress")
        try:
            j = json.loads(raw or "{}")
            c = j.get("cpu") or {}
            cpu_name = (c.get("Name") or cpu_name).strip()
            phys = c.get("NumberOfCores") or None
            logical = c.get("NumberOfLogicalProcessors") or logical
            for g in j.get("gpu") or []:
                if g and g.get("Name") and "Basic Display" not in g["Name"] and "Remote" not in g["Name"]:
                    gpus.append({"name": g["Name"].strip(), "vram_gb": round((g.get("AdapterRAM") or 0) / 1e9, 1) or None})
        except ValueError:
            pass
    apple = False
    if platform.system() == "Darwin":
        cpu_name = _cmd(["sysctl", "-n", "machdep.cpu.brand_string"]).strip() or cpu_name
        phys = int(_cmd(["sysctl", "-n", "hw.perflevel0.physicalcpu"]).strip() or 0) or \
            int(_cmd(["sysctl", "-n", "hw.physicalcpu"]).strip() or 0) or None
        apple = cpu_name.startswith("Apple")
        if apple:
            gpus.append({"name": f"{cpu_name} GPU", "vram_gb": None})
    nv = _cmd(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"]).strip()
    nvidia = []
    for line in nv.splitlines():
        parts = [x.strip() for x in line.split(",")]
        if len(parts) == 2 and parts[1].replace(".", "").isdigit():
            nvidia.append({"name": parts[0], "vram_gb": round(float(parts[1]) / 1024, 1)})
    if nvidia:                                   # nvidia-smi knows the real VRAM (WMI caps it at 4 GB)
        gpus = nvidia + [g for g in gpus if "NVIDIA" not in g["name"].upper()]
    hw = detect_hardware()
    return {"cpu": cpu_name, "cores": phys or max(1, logical // 2), "threads": logical, "ram_gb": ram_gb(),
            "gpus": gpus, "nvidia_vram_gb": max([g["vram_gb"] for g in nvidia] or [0]),
            "gpu_encoders": hw.get("hardware_encoders", []), "whisper_cuda": hw.get("whisper_cuda", False),
            "apple_silicon": apple, "os": hw.get("os"), "checked": int(time.time())}


def tier_of(hw: dict) -> tuple[str, list[str]]:
    """high / medium / low, with the reasons in plain words."""
    ram, thr, vram = hw.get("ram_gb") or 0, hw.get("threads") or 2, hw.get("nvidia_vram_gb") or 0
    why = [f"{thr} CPU threads", f"{ram:g} GB RAM"]
    if vram:
        why.append(f"NVIDIA GPU with {vram:g} GB")
    elif hw.get("gpu_encoders"):
        why.append("GPU video encoder " + hw["gpu_encoders"][0].split("_")[-1].upper())
    if hw.get("apple_silicon"):                  # M1-M4: unified memory decides
        why.append("Apple chip (media engine)")
        return ("high" if ram >= 16 else "medium"), why
    if (vram >= 6 and ram >= 12) or (thr >= 16 and ram >= 16):
        return "high", why
    if (thr >= 8 and ram >= 8) or vram >= 4 or (hw.get("gpu_encoders") and thr >= 6 and ram >= 8):
        return "medium", why
    return "low", why


def hardware(wait: bool = False) -> dict:
    """Cached hardware facts. First call loads the file cache; a fresh probe runs in the background."""
    global _hw
    if _hw is None:
        try:
            _hw = json.loads(CACHE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            _hw = None
        if _hw is None:
            if wait:
                refresh()
            else:
                return {"os": platform.system(), "threads": os.cpu_count() or 2, "ram_gb": None, "gpus": [],
                        "gpu_encoders": [], "nvidia_vram_gb": 0, "pending": True}
    return _hw


def refresh() -> dict:
    global _hw
    with _lock:
        data = _probe()
        _hw = data
        try:
            CACHE.parent.mkdir(parents=True, exist_ok=True)
            CACHE.write_text(json.dumps(data, indent=1), encoding="utf-8")
        except OSError:
            pass
    log.info("power: %s", summary_line())
    return data


def refresh_async() -> None:
    threading.Thread(target=lambda: (refresh(), apply_priority()), daemon=True, name="power-probe").start()


def mode() -> str:
    from .settings_store import raw
    m = raw().get("power_mode")
    return m if m in MODES else "auto"


def effective_mode() -> str:
    m = mode()
    if m != "auto":
        return m
    return {"high": "max", "medium": "balanced", "low": "saver"}[tier_of(hardware())[0]]


def plan() -> dict:
    hw = hardware()
    em = effective_mode()
    p = dict(PLANS[em])
    if em == "max" and not hw.get("whisper_cuda") and (hw.get("threads") or 2) < 12:
        p["caption"] = "medium"                 # turbo on a mid CPU is too slow to feel good
    if em == "balanced" and hw.get("whisper_cuda"):
        p["caption"] = "large-v3-turbo"         # GPU makes the big caption model cheap
    p["cpu_threads"] = max(2, int((hw.get("threads") or 2) * p["threads"]))
    p["mode"], p["auto"] = em, mode() == "auto"
    p["encoder"] = next((e for e in hw.get("gpu_encoders") or [] if e.startswith("h264_")), "libx264 (CPU)")
    p["whisper_device"] = "GPU (CUDA)" if hw.get("whisper_cuda") else "CPU"
    return p


def cpu_threads() -> int:
    return plan()["cpu_threads"]


def export_profile() -> str:
    return plan()["export"]


def summary_line() -> str:
    hw = hardware()
    t, _ = tier_of(hw)
    g = ", ".join(x["name"] for x in hw.get("gpus") or []) or "no dedicated GPU"
    return f"{hw.get('cpu')} · {hw.get('threads')} threads · {hw.get('ram_gb')} GB · {g} → {t} → {effective_mode()}"


_PRIORITY = {"normal": 0x20, "below_normal": 0x4000}


def apply_priority() -> str:
    """Saver mode runs the server (and so every FFmpeg / AI child it starts) below normal priority,
    so the PC stays responsive. Children inherit the priority class on Windows."""
    want = plan()["priority"]
    try:
        if os.name == "nt":
            import ctypes
            k = ctypes.windll.kernel32
            k.SetPriorityClass(k.GetCurrentProcess(), _PRIORITY[want])
        else:
            cur = os.getpriority(os.PRIO_PROCESS, 0)
            target = 5 if want == "below_normal" else 0
            if target > cur:
                os.setpriority(os.PRIO_PROCESS, 0, target)
    except Exception:  # noqa: BLE001
        log.exception("could not set process priority")
    return want


def status() -> dict:
    hw = hardware()
    t, why = tier_of(hw)
    return {"hardware": hw, "tier": t, "reasons": why, "mode": mode(), "plan": plan(),
            "modes": {k: v["label"] for k, v in PLANS.items()}}
