#!/bin/bash
# Installs FODO Studio for this Mac user: files in ~/Applications/FODO Studio, the "FODO Studio" app
# in ~/Applications (Launchpad / Spotlight), then runs the one-time setup.
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Applications/FODO Studio"
echo "Installing FODO Studio into $DEST"
mkdir -p "$DEST"
rsync -a --exclude "Install FODO Studio.command" --exclude "FODO Studio.app" "$SRC/" "$DEST/"
chmod +x "$DEST/FODO Studio.command" "$DEST/setup.sh"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true

APP="$HOME/Applications/FODO Studio.app"
rm -rf "$APP"
cp -R "$SRC/FODO Studio.app" "$APP"
chmod +x "$APP/Contents/MacOS/FODO Studio"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true

bash "$DEST/setup.sh"
echo ""
echo "Done. Opening FODO Studio..."
open "$APP"
