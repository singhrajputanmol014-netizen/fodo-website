"""More legal music sources, each an independent adapter (one failing never breaks the others).

  * Internet Archive (archive.org)  - public-domain + Creative-Commons audio, open API, no key
  * ccMixter (ccmixter.org)         - Creative-Commons remixes / instrumentals, open API, no key
  * NCS - NoCopyrightSounds         - free for creators WITH credit (ncs.io/usage-policy); found on
                                      their official YouTube channel, audio fetched with yt-dlp

Only licences that allow use in monetised videos are offered: CC0 / Public Domain / CC BY /
CC BY-SA (and NCS under its creator policy). Non-commercial (NC) and no-derivatives (ND) tracks
are filtered out because a music bed under a video is a derivative, commercial use.
Copyrighted commercial songs (film / label music) are NOT fetched: add those inside Instagram /
YouTube with the platform's own licensed music picker (see `platform_music_note`).
"""
from __future__ import annotations

import json
import re
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from .music_online import MAX_MUSIC_SECONDS, UA, _download_audio, _safe_name
from .url_import import UnsafeURL

IA_SEARCH = "https://archive.org/advancedsearch.php"
IA_META = "https://archive.org/metadata/"
CCM_API = "https://ccmixter.org/api/query"
NCS_CHANNEL = ("NoCopyrightSounds", "NCS")
NCS_CHANNEL_ID = "UC_aEa8K-EOJ3D6gOs7HcyNg"          # official NoCopyrightSounds YouTube channel


def is_ncs(name: str | None = None, channel_id: str | None = None) -> bool:
    return channel_id == NCS_CHANNEL_ID or (name or "").strip().lower() in {c.lower() for c in NCS_CHANNEL}


def _json(url: str, timeout: int = 20):
    import http.client
    http.client._MAXLINE = max(http.client._MAXLINE, 1 << 20)   # some servers send very long header lines
    req = urllib.request.Request(url, headers={**UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


# A cover of someone else's song stays the songwriter's copyright, whatever licence the uploader picked.
_COVER = re.compile(r"\b(cover|karaoke|tribute|originally by)\b", re.I)


def licence_ok(url_or_name: str) -> tuple[bool, str]:
    """(allowed, short label) for a licence URL / name."""
    s = (url_or_name or "").lower()
    if not s:
        return False, "unknown"
    if "publicdomain" in s or "/zero/" in s or "cc0" in s or "public domain" in s:
        return True, "CC0 / Public domain"
    if "creativecommons" in s or s.startswith("cc") or "attribution" in s:
        if "-nc" in s or "noncommercial" in s or "/nc" in s:
            return False, "CC NC (non-commercial)"
        if "-nd" in s or "noderiv" in s or "/nd" in s:
            return False, "CC ND (no changes)"
        if "by-sa" in s or "sharealike" in s:
            return True, "CC BY-SA"
        if "/by/" in s or s.endswith("/by") or "cc-by" in s or s == "cc by" or "attribution" in s:
            return True, "CC BY"
    return False, "not verified"


# ------------------------------------------------------------------ Internet Archive --
def search_archive(q: str, rows: int = 12) -> list[dict]:
    # IA's search backend rejects wildcards containing "/", so match loosely here and apply the
    # exact licence rule (no NC / ND) on each result with licence_ok().
    query = (f"({q}) AND mediatype:audio AND (licenseurl:*by* OR licenseurl:*publicdomain* OR licenseurl:*zero*)"
             " AND (collection:netlabels OR subject:music OR subject:instrumental OR subject:soundtrack)"
             " AND -collection:librivoxaudio AND -collection:podcasts AND -collection:oldtimeradio")
    params = [("q", query), ("rows", str(rows * 3)), ("page", "1"), ("output", "json"),
              ("sort[]", "downloads desc")] + [("fl[]", f) for f in
                                               ("identifier", "title", "creator", "licenseurl", "downloads", "subject")]
    d = _json(IA_SEARCH + "?" + urllib.parse.urlencode(params))
    out = []
    for r in d.get("response", {}).get("docs", []):
        ok, lab = licence_ok(r.get("licenseurl", ""))
        if not ok or _COVER.search(str(r.get("title") or "")):
            continue
        creator = r.get("creator")
        creator = ", ".join(creator) if isinstance(creator, list) else (creator or "")
        out.append({"id": f"ia:{r['identifier']}", "title": r.get("title") or r["identifier"], "creator": creator,
                    "license": lab, "license_url": r.get("licenseurl"), "provider": "Internet Archive",
                    "page": f"https://archive.org/details/{r['identifier']}", "duration": None,
                    "preview": None, "downloads": r.get("downloads")})
        if len(out) >= rows:
            break
    return out


def _archive_file(identifier: str) -> tuple[str, dict]:
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,120}", identifier):
        raise UnsafeURL("Bad Internet Archive id")
    m = _json(IA_META + identifier)
    files = [f for f in m.get("files", []) if str(f.get("name", "")).lower().endswith((".mp3", ".ogg", ".flac"))]
    if not files:
        raise UnsafeURL("This Internet Archive item has no audio file.")

    def length(f):
        try:
            v = f.get("length") or "0"
            if ":" in str(v):
                p = [float(x) for x in str(v).split(":")]
                return p[-1] + 60 * p[-2] + (3600 * p[-3] if len(p) > 2 else 0)
            return float(v)
        except ValueError:
            return 0.0
    # first track that is a real song length (prefer VBR MP3 originals)
    files.sort(key=lambda f: (not (30 <= length(f) <= MAX_MUSIC_SECONDS), not str(f.get("format", "")).startswith("VBR MP3")))
    f = files[0]
    if length(f) and not (30 <= length(f) <= MAX_MUSIC_SECONDS):
        raise UnsafeURL("This Internet Archive item has no track between 30 s and 15 min.")
    md = m.get("metadata", {})
    return (f"https://archive.org/download/{identifier}/{urllib.parse.quote(f['name'])}",
            {"title": f.get("title") or md.get("title") or f["name"], "creator": md.get("creator"),
             "license_url": md.get("licenseurl"), "page": f"https://archive.org/details/{identifier}",
             "duration": round(length(f), 1)})


# ------------------------------------------------------------------ ccMixter --
def search_ccmixter(q: str, limit: int = 12) -> list[dict]:
    params = {"f": "json", "search": q, "search_type": "any", "limit": str(limit * 3), "sort": "rank"}
    d = _json(CCM_API + "?" + urllib.parse.urlencode(params))
    out = []
    for r in d if isinstance(d, list) else []:
        ok, lab = licence_ok(r.get("license_url", "") or r.get("license_name", ""))
        if not ok or _COVER.search(str(r.get("upload_name") or "")):
            continue
        files = [f for f in r.get("files", []) if str(f.get("download_url", "")).lower().endswith(".mp3")]
        if not files:
            continue
        out.append({"id": f"ccm:{r.get('upload_id')}", "title": r.get("upload_name") or "Untitled",
                    "creator": r.get("user_real_name") or r.get("user_name") or "", "license": lab,
                    "license_url": r.get("license_url"), "provider": "ccMixter",
                    "page": r.get("file_page_url"),
                    "preview": "/api/music/preview?url=" + urllib.parse.quote(files[0].get("download_url") or "", safe=""),
                    "duration": None, "tags": (r.get("upload_tags") or "").strip(",").split(",")[:6]})
        if len(out) >= limit:
            break
    return out


def _ccmixter_file(upload_id: str) -> tuple[str, dict]:
    if not re.fullmatch(r"\d{1,9}", upload_id):
        raise UnsafeURL("Bad ccMixter id")
    d = _json(CCM_API + "?" + urllib.parse.urlencode({"f": "json", "ids": upload_id}))
    if not d:
        raise UnsafeURL("ccMixter track not found")
    r = d[0]
    ok, lab = licence_ok(r.get("license_url", ""))
    if not ok:
        raise UnsafeURL(f"This ccMixter track's licence ({lab}) does not allow commercial video use.")
    files = [f for f in r.get("files", []) if str(f.get("download_url", "")).lower().endswith(".mp3")]
    if not files:
        raise UnsafeURL("No mp3 file on this ccMixter upload")
    return files[0]["download_url"], {"title": r.get("upload_name"), "creator": r.get("user_real_name") or r.get("user_name"),
                                      "license_url": r.get("license_url"), "page": r.get("file_page_url"), "license": lab}


# ------------------------------------------------------------------ NCS (official channel) --
def search_ncs(q: str, limit: int = 8) -> list[dict]:
    import yt_dlp
    opts = {"quiet": True, "no_warnings": True, "extract_flat": True, "skip_download": True,
            "js_runtimes": {"deno": {}, "node": {}}}
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(f"ytsearch{limit * 3}:NoCopyrightSounds {q}", download=False)
    out, seen = [], 0
    for e in (info or {}).get("entries", []) or []:
        seen += 1
        if not is_ncs(e.get("channel") or e.get("uploader"), e.get("channel_id") or e.get("uploader_id")):
            continue                           # only the official NCS channel - re-uploads are not covered
        dur = e.get("duration") or 0
        if dur and dur > MAX_MUSIC_SECONDS:
            continue
        out.append({"id": f"ncs:{e.get('id')}", "title": e.get("title") or "NCS track", "creator": "NoCopyrightSounds",
                    "license": "NCS creator licence (credit required)", "license_url": "https://ncs.io/usage-policy",
                    "provider": "NCS", "page": f"https://www.youtube.com/watch?v={e.get('id')}",
                    "duration": dur or None, "preview": None})
        if len(out) >= limit:
            break
    if not out:
        raise RuntimeError(f"YouTube returned {seen} videos but none from the official NCS channel" if seen
                           else "YouTube search returned nothing (yt-dlp may need an update)")
    return out


# ------------------------------------------------------------------ unified --
PROVIDERS = {"archive": ("Internet Archive (CC / public domain)", search_archive),
             "ccmixter": ("ccMixter (Creative Commons)", search_ccmixter),
             "ncs": ("NCS - NoCopyrightSounds", search_ncs)}


def search_all(q: str, providers: list[str] | None = None) -> dict:
    groups = []
    for key in (providers or list(PROVIDERS)):
        if key not in PROVIDERS:
            continue
        label, fn = PROVIDERS[key]
        try:
            res = fn(q or "instrumental")
            groups.append({"provider": key, "title": label, "results": res})
        except Exception as e:  # noqa: BLE001 - a provider being down must not break the search
            groups.append({"provider": key, "title": label, "results": [], "error": f"{type(e).__name__}: {str(e)[:160]}"})
    return {"query": q, "groups": groups, "note": platform_music_note()}


def platform_music_note() -> str:
    return ("Film / label songs (Bollywood, chart hits) are not downloaded: they are copyrighted and get "
            "videos muted or struck. Export the clip with music OFF (or with a free bed) and add the song in "
            "Instagram / YouTube's own music picker - those platforms hold the licence.")


def fetch(item_id: str, dest_dir: Path) -> dict:
    kind, _, ref = (item_id or "").partition(":")
    dest_dir.mkdir(parents=True, exist_ok=True)
    if kind == "ia":
        url, meta = _archive_file(ref)
        ok, lab = licence_ok(meta.get("license_url", ""))
        if not ok:
            raise UnsafeURL(f"Licence not usable for videos ({lab}).")
        meta["license"] = lab
    elif kind == "ccm":
        url, meta = _ccmixter_file(ref)
    elif kind == "ncs":
        if not re.fullmatch(r"[A-Za-z0-9_-]{6,20}", ref):
            raise UnsafeURL("Bad NCS id")
        from .music_online import from_link
        m = from_link(f"https://www.youtube.com/watch?v={ref}", dest_dir)
        if not is_ncs(m.get("creator"), m.get("channel_id")):
            Path(dest_dir / m["id"].split(":", 1)[1]).unlink(missing_ok=True)
            raise UnsafeURL("That video is not from the official NCS channel.")
        meta = {**m, "license": "NCS creator licence", "license_url": "https://ncs.io/usage-policy",
                "attribution": f"Music: {m.get('title')} [NCS Release] - provided by NoCopyrightSounds. "
                               f"Watch: {m.get('page')}", "from": "ncs"}
        p = dest_dir / m["id"].split(":", 1)[1]
        p.with_suffix(p.suffix + ".json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
        return {**m, **meta}
    else:
        raise UnsafeURL("Unknown music source")
    ext = Path(urllib.parse.urlparse(url).path).suffix.lower() or ".mp3"
    name = f"{_safe_name(meta.get('title'))}_{_safe_name(ref)[:10]}{ext}"
    # ccMixter refuses hot-linked downloads without a ccmixter.org Referer
    hdr = {"Referer": meta.get("page") or "https://ccmixter.org/"} if kind == "ccm" else None
    path = _download_audio(url, dest_dir / name, hdr)
    meta.update({"provider": {"ia": "Internet Archive", "ccm": "ccMixter"}[kind], "from": kind,
                 "attribution": f"\"{meta.get('title')}\" by {meta.get('creator') or 'unknown'} "
                                f"({meta.get('license')}) - {meta.get('page')}"})
    path.with_suffix(path.suffix + ".json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"id": f"user:{path.name}", "name": path.stem, **meta}
