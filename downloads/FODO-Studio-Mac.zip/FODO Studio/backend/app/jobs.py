"""Database-backed background job queue (thread worker, no Redis required).

Jobs persist in SQLite; a worker thread pulls queued jobs. Crash recovery:
on startup any 'running' job is reset to 'queued'.
"""
from __future__ import annotations

import logging
import threading
import traceback
from typing import Callable

from .database import SessionLocal
from .models import Job

log = logging.getLogger("clipforge.jobs")

_HANDLERS: dict[str, Callable[[str, Callable[[float, str], None]], None]] = {}
_wake = threading.Event()
_stop = threading.Event()
_cancelled: set[str] = set()


def handler(kind: str):
    def deco(fn):
        _HANDLERS[kind] = fn
        return fn

    return deco


def enqueue(kind: str, target_id: str) -> str:
    db = SessionLocal()
    try:
        job = Job(kind=kind, target_id=target_id, status="queued")
        db.add(job)
        db.commit()
        _wake.set()
        return job.id
    finally:
        db.close()


def cancel(job_id: str) -> bool:
    db = SessionLocal()
    try:
        job = db.get(Job, job_id)
        if job is None:
            return False
        if job.status == "queued":
            job.status = "cancelled"
            db.commit()
            _mark_target_cancelled(job.kind, job.target_id)   # else the export stays "queued" forever
            return True
        if job.status == "running":
            _cancelled.add(job_id)
            kill_children()          # stop FFmpeg / downloads right now, not at the next step
            return True
        return False
    finally:
        db.close()


def kill_children() -> None:
    """Terminate media child processes of this server (single worker thread, so every
    child FFmpeg/yt-dlp process belongs to the running job)."""
    import os
    import subprocess
    import sys
    pid = os.getpid()
    names = ("ffmpeg", "ffprobe", "yt-dlp", "deno")
    try:
        if sys.platform == "win32":
            flt = " -or ".join(f"$_.Name -like '{n}*'" for n in names)
            ps = (f"Get-CimInstance Win32_Process -Filter 'ParentProcessId={pid}' | "
                  f"Where-Object {{ {flt} }} | ForEach-Object {{ Stop-Process -Id $_.ProcessId -Force }}")
            subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, timeout=20,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        else:
            for n in names:
                subprocess.run(["pkill", "-P", str(pid), n], capture_output=True, timeout=10)
    except Exception:  # noqa: BLE001
        log.exception("could not stop child processes")


def _mark_target_cancelled(kind: str, target: str) -> None:
    from .models import Export, Video
    db = SessionLocal()
    try:
        if kind in ("analyze", "import_url"):
            v = db.get(Video, target)
            if v:
                v.status = "cancelled"
        elif kind == "export":
            e = db.get(Export, target)
            if e:
                e.status = "cancelled"
                e.error = "Cancelled by user"
        db.commit()
    finally:
        db.close()


_THREAD: threading.Thread | None = None


def worker_alive() -> bool:
    return bool(_THREAD and _THREAD.is_alive())


def is_cancelled(job_id: str) -> bool:
    return job_id in _cancelled


def _run_one() -> bool:
    db = SessionLocal()
    try:
        job = db.query(Job).filter_by(status="queued").order_by(Job.created_at).first()
        if job is None:
            return False
        job.status = "running"
        job.stage = "starting"
        db.commit()
        job_id, kind, target = job.id, job.kind, job.target_id
    finally:
        db.close()

    from . import activity
    activity.step(job_id, "starting")

    def progress(p: float, stage: str) -> None:
        activity.step(job_id, stage)
        d = SessionLocal()
        try:
            j = d.get(Job, job_id)
            if j:
                j.progress = round(min(max(p, 0), 1), 3)
                j.stage = stage
                d.commit()
        finally:
            d.close()
        if is_cancelled(job_id):
            raise JobCancelled()

    try:
        fn = _HANDLERS.get(kind)
        if fn is None:
            raise RuntimeError(f"No handler for job kind {kind!r}")
        fn(target, progress)
        _finish(job_id, "done")
    except JobCancelled:
        _finish(job_id, "cancelled")
        _mark_target_cancelled(kind, target)
    except Exception as e:  # noqa: BLE001
        if is_cancelled(job_id):             # killed process surfaces as an ordinary error
            _finish(job_id, "cancelled")
            _mark_target_cancelled(kind, target)
            return True
        log.error("Job %s failed: %s\n%s", job_id, e, traceback.format_exc())
        _finish(job_id, "failed", str(e))
    finally:
        activity.finish(job_id)
        _cancelled.discard(job_id)
    return True


class JobCancelled(Exception):
    pass


def _finish(job_id: str, status: str, error: str | None = None) -> None:
    db = SessionLocal()
    try:
        j = db.get(Job, job_id)
        if j:
            j.status = status
            j.error = error
            if status == "done":
                j.progress = 1.0
            db.commit()
    finally:
        db.close()


def _worker() -> None:
    while not _stop.is_set():
        try:
            if not _run_one():
                _wake.wait(timeout=1.0)
                _wake.clear()
        except Exception:  # noqa: BLE001
            log.exception("worker loop error")


def _repair_orphans(db) -> None:
    """Exports/videos still marked busy while no queued/running job works on them
    (e.g. a queued job cancelled by an older build) -> mark them cancelled."""
    from .models import Export, Video
    live = {j.target_id for j in db.query(Job).filter(Job.status.in_(("queued", "running"))).all()}
    n = 0
    for e in db.query(Export).filter(Export.status.in_(("queued", "rendering"))).all():
        if e.id not in live:
            e.status, e.error = "cancelled", "Stopped"
            n += 1
    for v in db.query(Video).filter(Video.status.in_(("queued", "analyzing", "downloading"))).all():
        if v.id not in live:
            v.status = "cancelled"
            n += 1
    db.commit()
    if n:
        log.info("repaired %d orphaned busy records", n)


def start_worker() -> None:
    # crash recovery
    db = SessionLocal()
    try:
        for j in db.query(Job).filter_by(status="running").all():
            j.status = "queued"
        db.commit()
        _repair_orphans(db)
    finally:
        db.close()
    global _THREAD
    t = threading.Thread(target=_worker, daemon=True, name="clipforge-worker")
    t.start()
    _THREAD = t
