#!/bin/bash
# Starts FODO Studio on this Mac and opens it in the browser. Close this window to stop it.
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
printf '\033]0;FODO Studio\007'
export PATH="$HERE/tools/bin:$PATH"
if [ ! -f .setup_done ]; then
  echo "FODO Studio is not set up yet on this Mac. Running setup first..."
  bash ./setup.sh || { echo "Setup did not finish. See setup_log.txt"; read -r -p "Press Enter to close"; exit 1; }
fi
if curl -s -m 2 http://127.0.0.1:8777/health >/dev/null; then open http://127.0.0.1:8777; exit 0; fi
OLL="$HERE/tools/ollama/ollama"; [ -x "$OLL" ] || OLL=/Applications/Ollama.app/Contents/Resources/ollama
if [ -x "$OLL" ] && ! curl -s -m 2 http://127.0.0.1:11434/api/tags >/dev/null; then ("$OLL" serve >/dev/null 2>&1 &); fi
echo "FODO Studio is running at http://127.0.0.1:8777"
echo "Keep this window open (you can minimise it). Close it to stop FODO Studio."
(sleep 6; open http://127.0.0.1:8777) &
"$HERE/.venv/bin/python" -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8777 >> run_log.txt 2>&1
echo "FODO Studio stopped. See run_log.txt"
