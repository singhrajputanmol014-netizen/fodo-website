"""Caption engine: word-timed ASS subtitles with styled presets + karaoke highlight.

Styles use libass (bundled with FFmpeg) and the default font family available on
the system (fontconfig picks the closest). SRT/VTT export included.
"""
from __future__ import annotations

from pathlib import Path

# name -> dict of ASS style params
CAPTION_STYLES: dict[str, dict] = {
    "minimal":      {"font": "Arial", "size": 64, "primary": "&H00FFFFFF", "highlight": "&H0000A5FF", "outline": 2, "bold": 0, "upper": False, "box": False},
    "bold_creator": {"font": "Arial Black", "size": 78, "primary": "&H00FFFFFF", "highlight": "&H000059FF", "outline": 4, "bold": 1, "upper": True,  "box": False},
    "luxury":       {"font": "Georgia", "size": 60, "primary": "&H00E6E6E6", "highlight": "&H0032C8FF", "outline": 1, "bold": 0, "upper": False, "box": False},
    "podcast":      {"font": "Arial", "size": 66, "primary": "&H00FFFFFF", "highlight": "&H0000D7FF", "outline": 0, "bold": 1, "upper": False, "box": True},
    "neon":         {"font": "Arial Black", "size": 72, "primary": "&H00FFF7F0", "highlight": "&H00FF80FF", "outline": 3, "bold": 1, "upper": True,  "box": False},
    "news":         {"font": "Arial", "size": 56, "primary": "&H00FFFFFF", "highlight": "&H0000C8FF", "outline": 0, "bold": 1, "upper": False, "box": True},
    "fodo_orange":  {"font": "Arial Black", "size": 74, "primary": "&H00FFFFFF", "highlight": "&H000059FF", "outline": 3, "bold": 1, "upper": True,  "box": False},
    "documentary":  {"font": "Georgia", "size": 54, "primary": "&H00F0F0F0", "highlight": "&H00B4E6FF", "outline": 1, "bold": 0, "upper": False, "box": True},
    "cinematic":    {"font": "Georgia", "size": 52, "primary": "&H00DCDCDC", "highlight": "&H0050B4FF", "outline": 0, "bold": 0, "upper": True,  "box": False},
    "gaming":       {"font": "Impact", "size": 84, "primary": "&H0000FF7F", "highlight": "&H00FFFFFF", "outline": 5, "bold": 1, "upper": True,  "box": False},
    "comedy":       {"font": "Comic Sans MS", "size": 76, "primary": "&H0000FFFF", "highlight": "&H00FFFFFF", "outline": 4, "bold": 1, "upper": False, "box": False},
    "motivational": {"font": "Impact", "size": 80, "primary": "&H00FFFFFF", "highlight": "&H0000D7FF", "outline": 4, "bold": 1, "upper": True,  "box": False},
    "educational":  {"font": "Verdana", "size": 60, "primary": "&H00FFFFFF", "highlight": "&H0000C8FF", "outline": 2, "bold": 1, "upper": False, "box": True},
    "corporate":    {"font": "Segoe UI", "size": 58, "primary": "&H00FFFFFF", "highlight": "&H00E6A532", "outline": 0, "bold": 1, "upper": False, "box": True},
    "retro":        {"font": "Courier New", "size": 66, "primary": "&H0080FFFF", "highlight": "&H004080FF", "outline": 3, "bold": 1, "upper": True,  "box": False},
    "modern_editorial": {"font": "Segoe UI", "size": 62, "primary": "&H00FFFFFF", "highlight": "&H000059FF", "outline": 0, "bold": 1, "upper": False, "box": True},
    "premium_social": {"font": "Arial", "size": 70, "primary": "&H00FFFFFF", "highlight": "&H0032C8FF", "outline": 3, "bold": 1, "upper": False, "box": False},
    "kinetic":      {"font": "Arial Black", "size": 88, "primary": "&H00FFFFFF", "highlight": "&H000059FF", "outline": 4, "bold": 1, "upper": True,  "box": False, "words_per_line": 2},
    "storytelling": {"font": "Georgia", "size": 64, "primary": "&H00FFFFFF", "highlight": "&H0080D0FF", "outline": 2, "bold": 0, "upper": False, "box": False},
}
# &HAABBGGRR — FODO orange #FF5900 -> BGR 0059FF


def _ass_time(t: float) -> str:
    h = int(t // 3600)
    m = int(t % 3600 // 60)
    s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def tidy_words(words: list[dict]) -> list[dict]:
    """Caption-safe word timing: sorted, no empty words, no overlaps, every word on screen long
    enough to read, tiny gaps closed so captions do not flicker between words."""
    ws = sorted(({**w, "w": str(w.get("w", "")).strip()} for w in words
                 if str(w.get("w", "")).strip() and w.get("e") is not None and w.get("s") is not None),
                key=lambda w: (float(w["s"]), float(w["e"])))
    out: list[dict] = []
    for w in ws:
        s, e = float(w["s"]), float(w["e"])
        if out and s < out[-1]["s"] + 0.02:
            s = out[-1]["s"] + 0.02                       # same start time: keep the order, never stack
        if out and s < out[-1]["e"]:
            out[-1]["e"] = max(out[-1]["s"] + 0.02, s)    # trim the previous word, never overlap
        e = max(e, s + 0.12)
        out.append({**w, "s": round(s, 3), "e": round(e, 3)})
    for i in range(len(out) - 1):
        gap = out[i + 1]["s"] - out[i]["e"]
        if gap < 0:
            out[i]["e"] = out[i + 1]["s"]
        elif gap < 0.25:
            out[i]["e"] = out[i + 1]["s"]                 # close tiny gaps
    return out


def group_words(words: list[dict], max_words: int = 4, max_gap: float = 0.6) -> list[list[dict]]:
    """Caption lines of up to max_words, split on pauses."""
    lines: list[list[dict]] = []
    cur: list[dict] = []
    for i, w in enumerate(words):
        cur.append(w)
        gap = (words[i + 1]["s"] - w["e"]) if i + 1 < len(words) else 99
        if len(cur) >= max_words or gap > max_gap:
            lines.append(cur)
            cur = []
    if cur:
        lines.append(cur)
    return lines


FONTS_DIR = Path(__file__).parent / "assets" / "fonts"
# display name -> family name inside the TTF (all bundled; SIL OFL / Apache 2.0)
from .caption_library import FONT_FILES as _FF, LIBRARY, preset_design  # noqa: E402
FONTS = {k: v[0] for k, v in _FF.items()}

ANIMATIONS = ("karaoke", "highlight_word", "pop_words", "static", "one_word", "subtitle",
              "word_box", "bounce", "fade", "slide_up", "typewriter", "underline", "punch")
MIN_SIZE = 60          # below this (at 1080 px width) captions are hard to read on a phone

POSITIONS = {"top": (8, 0.12), "middle": (5, 0.0), "center_low": (2, 0.34), "lower": (2, 0.17),
             "seam": (8, 0.385), "under_box": (8, 0.81), "low_subtitle": (2, 0.24)}


def hex_to_ass(hex_color: str, alpha: int = 0) -> str:
    h = hex_color.lstrip("#")
    if len(h) != 6 or any(c not in "0123456789abcdefABCDEF" for c in h):
        return "&H00FFFFFF"
    r, g, b = h[0:2], h[2:4], h[4:6]
    return f"&H{alpha:02X}{b}{g}{r}".upper()


def _light(ass_col: str) -> bool:
    """&HAABBGGRR -> is it a light colour?"""
    h = ass_col[-6:]
    try:
        b, g, r = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except ValueError:
        return False
    return (0.299 * r + 0.587 * g + 0.114 * b) > 165


def resolve_design(style: str, design: dict | None, placement: str = "lower") -> dict:
    """Preset style + user overrides -> concrete design."""
    st = dict(CAPTION_STYLES.get(style, CAPTION_STYLES["fodo_orange"]))
    d = {
        "font": st["font"], "size": st["size"], "primary": st["primary"],
        "highlight": st["highlight"], "outline": st["outline"], "bold": st["bold"],
        "upper": st["upper"], "box": st["box"], "words_per_line": st.get("words_per_line", 4),
        "animation": "karaoke", "position": placement if placement in POSITIONS else "lower",
        "outline_color": "&H00000000", "shadow": 1, "shadow_color": "&H96000000", "box_color": "&H80000000",
        "glow": 0, "italic": 0, "spacing": 0, "lower": False,
    }
    design = dict(design or {})
    pre = design.pop("preset", None)
    if pre in LIBRARY:     # library preset first, then whatever the user changed on top
        design = {**preset_design(pre), **design}
    for k, v in design.items():
        if v in (None, ""):
            continue
        if k == "font" and v in FONTS:
            d["font"] = FONTS[v]
        elif k == "font" and str(v) in user_fonts():
            d["font"] = user_fonts()[str(v)]
        elif k == "size":
            d["size"] = int(max(30, min(140, int(v))))
        elif k in ("color", "primary"):
            d["primary"] = hex_to_ass(str(v))
        elif k == "highlight":
            d["highlight"] = hex_to_ass(str(v))
        elif k == "outline":
            d["outline"] = int(max(0, min(8, int(v))))
        elif k in ("upper", "box", "bold"):
            d[k] = int(bool(v)) if k == "bold" else bool(v)
        elif k == "words_per_line":
            d["words_per_line"] = int(max(1, min(8, int(v))))
        elif k == "animation" and v in ANIMATIONS:
            d["animation"] = v
        elif k == "position" and v in POSITIONS:
            d["position"] = v
        elif k == "cycle":
            d["cycle"] = bool(v)
        elif k == "outline_color":
            d["outline_color"] = hex_to_ass(str(v))
        elif k == "shadow_color":
            d["shadow_color"] = hex_to_ass(str(v), 0x30)
        elif k == "box_color":
            d["box_color"] = hex_to_ass(str(v), 0x00)
        elif k == "shadow":
            d["shadow"] = int(max(0, min(10, int(v))))
        elif k == "glow":
            d["glow"] = int(max(0, min(12, int(v))))
        elif k == "spacing":
            d["spacing"] = int(max(0, min(12, int(v))))
        elif k == "italic":
            d["italic"] = int(bool(v))
        elif k == "lower":
            d["lower"] = bool(v)
    if d["box"] and d["outline"] > 0:
        d["outline_color"] = d["box_color"]     # outline merges into the box = padding around the text
    return d


_STOP = set("""a an the and or but so if then than that this is are was were be been am i you he she it we they me
him her us them my your his its our their to of in on at by for with from up as just very not no do does did have
has had will would can could should what who when where why how all some more like get got go yeah okay ok um uh
hai ka ki ke ko se me mein aur bhi toh to ye yeh woh wo na nahi kya ho tha thi hum main tum aap""".split())


def emphasis(words: list[dict], i: int) -> bool:
    """A word worth colouring: long, not a filler, or the speaker stresses it with a pause."""
    raw = (words[i].get("w") or "").strip()
    key = "".join(ch for ch in raw.lower() if ch.isalnum())
    if not key or key in _STOP:
        return False
    nxt = words[i + 1]["s"] if i + 1 < len(words) else words[i]["e"] + 1
    return len(key) >= 7 or (len(key) >= 4 and nxt - words[i]["e"] > 0.3) or raw.endswith("!")


def build_ass(words: list[dict], clip_start: float, clip_end: float,
              style: str, play_w: int, play_h: int, out_path: str | Path,
              placement: str = "lower", design: dict | None = None) -> Path:
    """Word-timed ASS captions for words inside [clip_start, clip_end], re-timed to 0."""
    d = resolve_design(style, design, placement)
    align, mfrac = POSITIONS[d["position"]]
    margin_v = int(play_h * mfrac)
    clip_words = tidy_words([
        {**w, "s": max(0.0, w["s"] - clip_start), "e": min(clip_end - clip_start, max(0.0, w["e"] - clip_start))}
        for w in words
        if w["e"] > clip_start + 0.02 and w["s"] < clip_end - 0.02
    ])
    if any("\u0900" <= ch <= "\u097f" for w in clip_words for ch in w["w"]):
        # Hindi captions: same look, in a font that has Devanagari letters (no empty boxes)
        from .caption_library import FONT_FILES, devanagari_font
        df = devanagari_font(d["font"])
        if FONT_FILES[df][0] != d["font"]:
            d["font"] = FONT_FILES[df][0]
            d["size"] = int(min(140, max(d["size"] * 1.1, 84)))
        d["upper"] = False
    size = max(d["size"], MIN_SIZE) if play_w >= 1000 else int(max(d["size"], MIN_SIZE) * play_w / 1080)
    back = d["box_color"] if d["box"] else d["shadow_color"]
    border_style = 4 if d["box"] else 1
    header = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {play_w}
PlayResY: {play_h}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,{d['font']},{size},{d['primary']},{d['primary']},{d['outline_color']},{back},{d['bold']},{d['italic']},0,0,100,100,{d['spacing']},0,{border_style},{d['outline']},{d['shadow']},{align},70,70,{margin_v},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    def clean(w: str) -> str:
        w = w.replace("{", "").replace("}", "").replace("\\", "")
        return w.upper() if d["upper"] else (w.lower() if d.get("lower") else w)

    glow = bool(d.get("glow"))

    def _write(evs: list[str]) -> Path:
        if glow:   # soft coloured glow underneath, crisp text on top
            g = d["glow"]
            under = [e.replace(",Cap,,0,0,0,,", f",Cap,,0,0,0,,{{\\blur{g}\\bord{d['outline'] + max(2, g // 2)}}}", 1)
                     for e in evs]
            top = [e.replace("Dialogue: 0,", "Dialogue: 1,", 1)
                   .replace(",Cap,,0,0,0,,", ",Cap,,0,0,0,,{\\3c&H00101010&\\bord1.5\\shad0}", 1) for e in evs]
            evs = under + top
        out = Path(out_path)
        out.write_text(header + "\n".join(evs) + "\n", encoding="utf-8")
        return out

    events: list[str] = []
    pop = "\\fscx80\\fscy80\\t(0,120,\\fscx100\\fscy100)"
    P, H = d["primary"], d["highlight"]
    if d["animation"] in ("one_word", "punch"):
        # stream / motivation edits: one word at a time, big, emphasis words in the accent colour
        cyc = [P, H, "&H00FFFF00"] if d.get("cycle") else None
        zoom = ("\\fscx70\\fscy70\\t(0,90,\\fscx106\\fscy106)\\t(90,160,\\fscx100\\fscy100)"
                if d["animation"] == "one_word" else
                "\\fscx145\\fscy145\\t(0,110,\\fscx94\\fscy94)\\t(110,190,\\fscx100\\fscy100)")
        for i, w in enumerate(clip_words):
            ws = w["s"]
            we = clip_words[i + 1]["s"] if i + 1 < len(clip_words) else w["e"] + 1.5
            we = min(we, ws + 1.2) if we - w["e"] > 0.6 else we
            if we <= ws:
                continue
            col = cyc[i % 3] if cyc else (H if emphasis(clip_words, i) else P)
            events.append(f"Dialogue: 0,{_ass_time(ws)},{_ass_time(we)},Cap,,0,0,0,,"
                          f"{{\\c{col}{zoom}}}{clean(w['w'])}")
        return _write(events)
    if d["animation"] == "subtitle":
        # TV / studio pages: plain sentence subtitles, broken on pauses and sentence ends
        lines, cur = [], []
        for i, w in enumerate(clip_words):
            cur.append(w)
            gap = (clip_words[i + 1]["s"] - w["e"]) if i + 1 < len(clip_words) else 99
            txt = (w.get("w") or "").strip()
            if gap > 0.5 or txt.endswith((".", "?", "!", "\u0964")) or len(" ".join(x["w"] for x in cur)) > 42:
                lines.append(cur)
                cur = []
        if cur:
            lines.append(cur)
        for li, line in enumerate(lines):
            ls, le = line[0]["s"], line[-1]["e"] + 0.25
            if li + 1 < len(lines):
                le = min(le, lines[li + 1][0]["s"])
            events.append(f"Dialogue: 0,{_ass_time(ls)},{_ass_time(le)},Cap,,0,0,0,,"
                          + " ".join(clean(w["w"]) for w in line))
        return _write(events)
    OC = d["outline_color"]
    bw = max(8, int(size * 0.16))
    BT = "&H00000000" if _light(H) else "&H00FFFFFF"     # text on the word box: black on light boxes
    mx = play_w // 2
    my = {8: margin_v, 5: play_h // 2}.get(align, play_h - margin_v)
    lines_ = group_words(clip_words, max_words=d["words_per_line"])
    total = max(0.0, clip_end - clip_start)
    for li, line in enumerate(lines_):
        ls = line[0]["s"]
        nxt = lines_[li + 1][0]["s"] if li + 1 < len(lines_) else total
        # keep the line up until the next one (short pauses) so captions never flash on and off
        le = nxt if nxt - line[-1]["e"] < 0.9 else line[-1]["e"] + 0.35
        le = max(le, min(ls + 0.6, nxt))                  # long enough to read, never over the next line
        if total > ls:
            le = min(le, total)
        if le <= ls:
            le = ls + 0.05
        anim = d["animation"]
        if anim == "karaoke":
            # \k: words not yet spoken use SecondaryColour (P), spoken ones switch to PrimaryColour (H).
            # Each word's \k runs until the NEXT word starts, so the colour sweep follows the voice.
            ks = [(line[j + 1]["s"] if j + 1 < len(line) else min(le, line[-1]["e"])) - w["s"] for j, w in enumerate(line)]
            lead = max(0, int(round((line[0]["s"] - ls) * 100)))
            parts = [f"{{\\k{max(1, int(round(k * 100)))}}}{clean(w['w'])}" for k, w in zip(ks, line)]
            if lead:
                parts[0] = f"{{\\k{lead}}}" + parts[0]
            events.append(f"Dialogue: 0,{_ass_time(ls)},{_ass_time(le)},Cap,,0,0,0,,{{{pop}\\1c{H}\\2c{P}}}"
                          + " ".join(parts))
        elif anim == "static":
            events.append(f"Dialogue: 0,{_ass_time(ls)},{_ass_time(le)},Cap,,0,0,0,,"
                          + " ".join(clean(w["w"]) for w in line))
        elif anim in ("fade", "slide_up"):
            gi = clip_words.index(line[0]) if line[0] in clip_words else 0
            txt = " ".join((f"{{\\c{H}}}{clean(w['w'])}{{\\c{P}}}" if emphasis(clip_words, gi + j) else clean(w["w"]))
                           for j, w in enumerate(line))
            tag = "\\fad(160,90)" if anim == "fade" else f"\\fad(120,60)\\move({mx},{my + 46},{mx},{my},0,190)"
            events.append(f"Dialogue: 0,{_ass_time(ls)},{_ass_time(le)},Cap,,0,0,0,,{{{tag}}}{txt}")
        else:
            for i, w in enumerate(line):
                ws = w["s"]
                we = line[i + 1]["s"] if i + 1 < len(line) else le
                if we <= ws:
                    continue
                if anim == "highlight_word":
                    txt = " ".join(
                        (f"{{\\c{H}\\fscx112\\fscy112}}{clean(x['w'])}{{\\c{P}\\fscx100\\fscy100}}"
                         if j == i else clean(x["w"])) for j, x in enumerate(line))
                elif anim == "word_box":
                    txt = " ".join(
                        (f"{{\\c{BT}\\3c{H}\\bord{bw}\\shad0}}{clean(x['w'])}{{\\c{P}\\3c{OC}\\bord{d['outline']}\\shad{d['shadow']}}}"
                         if j == i else clean(x["w"])) for j, x in enumerate(line))
                elif anim == "bounce":
                    txt = " ".join(
                        (f"{{\\c{H}\\fscx128\\fscy128\\t(0,90,\\fscx94\\fscy94)\\t(90,170,\\fscx100\\fscy100)}}"
                         f"{clean(x['w'])}{{\\c{P}\\fscx100\\fscy100}}" if j == i else clean(x["w"]))
                        for j, x in enumerate(line))
                elif anim == "underline":
                    txt = " ".join((f"{{\\c{H}\\u1}}{clean(x['w'])}{{\\u0\\c{P}}}" if j == i else clean(x["w"]))
                                   for j, x in enumerate(line))
                elif anim == "typewriter":
                    txt = " ".join(clean(x["w"]) for x in line[:i + 1])
                else:   # pop_words: words appear one by one, newest pops in highlighted
                    shown = [clean(x["w"]) for x in line[:i]]
                    txt = " ".join(shown + [f"{{\\c{H}{pop}}}{clean(w['w'])}"])
                events.append(f"Dialogue: 0,{_ass_time(ws)},{_ass_time(we)},Cap,,0,0,0,,{txt}")
    return _write(events)


def build_srt(words: list[dict], clip_start: float, clip_end: float, out_path: str | Path) -> Path:
    def ts(t: float) -> str:
        h = int(t // 3600); m = int(t % 3600 // 60); s = int(t % 60)
        ms = int((t - int(t)) * 1000)
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    clip_words = [
        {**w, "s": max(0.0, w["s"] - clip_start), "e": max(0.0, w["e"] - clip_start)}
        for w in words
        if w["s"] >= clip_start - 0.05 and w["e"] <= clip_end + 0.05
    ]
    blocks = []
    for i, line in enumerate(group_words(clip_words, max_words=7), 1):
        blocks.append(f"{i}\n{ts(line[0]['s'])} --> {ts(line[-1]['e'])}\n"
                      + " ".join(w["w"] for w in line))
    out = Path(out_path)
    out.write_text("\n\n".join(blocks) + "\n", encoding="utf-8")
    return out


# ---------------- caption studio: user fonts, subtitle files, bilingual line ----------------

def user_font_dir() -> Path:
    from ..config import STORAGE_DIR
    d = STORAGE_DIR / "fonts"
    d.mkdir(parents=True, exist_ok=True)
    return d


def user_fonts() -> dict:
    """display name -> family name for fonts the owner uploaded (storage/fonts)."""
    out = {}
    try:
        from PIL import ImageFont
    except ImportError:
        return out
    for f in sorted(user_font_dir().glob("*")):
        if f.suffix.lower() not in (".ttf", ".otf"):
            continue
        try:
            fam, style = ImageFont.truetype(str(f), 20).getname()
        except OSError:
            continue
        name = fam if style in ("Regular", "Normal", "") else f"{fam} {style}"
        out[f"{name} (uploaded)"] = fam
    return out


def srt_to_vtt(srt: str) -> str:
    import re as _re
    body = _re.sub(r"(\d{2}:\d{2}:\d{2}),(\d{3})", r"\1.\2", srt.replace("\r", ""))
    body = _re.sub(r"^\d+\n(?=\d{2}:)", "", body, flags=_re.M)
    return "WEBVTT\n\n" + body


def add_bilingual(ass_path: Path, words: list[dict], clip_start: float, clip_end: float,
                  play_w: int, play_h: int, above: bool = False) -> Path:
    """Second caption line (e.g. English translation under Hindi/Hinglish captions): smaller,
    sentence-grouped, timed by the translated words, placed just under (or over) the main line."""
    clip_words = [{**w, "s": max(0.0, w["s"] - clip_start), "e": max(0.0, w["e"] - clip_start)}
                  for w in words if w["s"] >= clip_start - 0.05 and w["e"] <= clip_end + 0.05]
    if not clip_words:
        return ass_path
    size = max(44, int(60 * play_w / 1080))
    margin = int(play_h * (0.10 if not above else 0.30))
    style = (f"Style: Sub2,Poppins SemiBold,{size},&H00E6E6E6,&H00E6E6E6,&H00000000,&H90000000,0,0,0,0,100,100,0,0,"
             f"4,2,0,2,80,80,{margin},1\n")
    text = Path(ass_path).read_text(encoding="utf-8")
    text = text.replace("\n[Events]", "\n" + style.rstrip("\n") + "\n\n[Events]", 1) if "Style: Sub2" not in text else text
    ev = []
    for line in group_words(clip_words, max_words=8, max_gap=0.7):
        t = " ".join((w["w"] or "").strip() for w in line).replace("{", "").replace("}", "")
        ev.append(f"Dialogue: 1,{_ass_time(line[0]['s'])},{_ass_time(line[-1]['e'] + 0.15)},Sub2,,0,0,0,,{t}")
    Path(ass_path).write_text(text.rstrip("\n") + "\n" + "\n".join(ev) + "\n", encoding="utf-8")
    return ass_path


def apply_override(words: list[dict], override: dict | None) -> list[dict]:
    """Manual caption corrections: each edited line replaces the words inside its time span;
    new words share the span's time evenly (word timing stays inside the original line)."""
    if not override or not override.get("lines"):
        return words
    out = list(words)
    for ln in override["lines"]:
        s0, s1, txt = float(ln["s"]), float(ln["e"]), str(ln.get("text") or "").strip()
        out = [w for w in out if not (w["s"] >= s0 - 0.01 and w["e"] <= s1 + 0.01)]
        toks = txt.split()
        if toks:
            step = (s1 - s0) / len(toks)
            out += [{"w": t, "s": round(s0 + i * step, 3), "e": round(s0 + (i + 1) * step - 0.02, 3)}
                    for i, t in enumerate(toks)]
    return sorted(out, key=lambda w: w["s"])
