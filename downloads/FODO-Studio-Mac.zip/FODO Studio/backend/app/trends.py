"""Trend registry: editing trends with evidence, dates and the recipe that implements them.

Seeded only from ClipForge's own frame-by-frame research of 129 real Reels/Shorts
(17 Nov 2026, docs/research-log-2026-11.md). Nothing is labelled "trending" without that
evidence; `last_verified` says when it was last seen. The owner can edit, disable or add
trends in the Control Panel. Saved projects are never changed when the registry changes.
"""
from __future__ import annotations

import json
import threading
from datetime import date

from .config import STORAGE_DIR

PATH = STORAGE_DIR / "trends.json"
_lock = threading.Lock()
RESEARCH = "ClipForge research log, 129 Reels/Shorts, 17 Nov 2026 (docs/research-log-2026-11.md)"

SEED = [
    {"id": "clip_page_black", "name": "Black clip-page template", "category": "layout",
     "platforms": ["Instagram Reels", "YouTube Shorts"],
     "description": "Black background, 2-line headline (white + one accent word), video in a rounded box, small captions under it.",
     "evidence": "Most common layout for podcast/motivation/education clip pages (Elon clip page, Think School, MKBHD fan, Best of Goggins, BBKV).",
     "recipe": "clip_page", "required_assets": ["fonts: Archivo Black"]},
    {"id": "stream_facecam_top", "name": "Stream clip: facecam top, gameplay bottom", "category": "layout",
     "platforms": ["YouTube Shorts", "Instagram Reels", "TikTok"],
     "description": "Facecam ~40-45 % on top, gameplay below, premise box first 2-3 s, one-word caps at the seam.",
     "evidence": "IShowSpeed, Kai Cenat, xQc, CarryMinati, Valorant clip channels (20 videos).", "recipe": "stream_clip",
     "required_assets": []},
    {"id": "one_word_motivation", "name": "One word at a time, cinema bars", "category": "captions",
     "platforms": ["Instagram Reels", "YouTube Shorts"],
     "description": "Big clean white caps one word at a time, one emphasis colour, teal-orange grade, letterbox, ends on black.",
     "evidence": "Motivation / gym edits (Goggins pages, 8 videos).", "recipe": "motivation", "required_assets": []},
    {"id": "big_hook_words", "name": "Huge 2-3 line hook words in the first seconds", "category": "hook",
     "platforms": ["YouTube Shorts", "Instagram Reels"],
     "description": "Huge white + accent hook words for 2-3 s, then normal captions.",
     "evidence": "Diary of a CEO, Chris Williamson clips.", "recipe": "clean_talk", "required_assets": []},
    {"id": "active_word_caps", "name": "2-3 word caps with ONE highlighted active word", "category": "captions",
     "platforms": ["Instagram Reels"],
     "description": "Short caps lines with a single yellow/green active word.",
     "evidence": "Indian podcast clip pages (Figuring Out / Shamani-style pages).", "recipe": "desi_reel",
     "required_assets": ["fonts: Hind Bold for Devanagari"]},
    {"id": "tiny_subtitles_tv", "name": "Tiny white subtitles, speaker-follow crop (TV/studio)", "category": "captions",
     "platforms": ["Instagram Reels", "YouTube Shorts"],
     "description": "Official TV/movie pages: crop follows the speaking actor, small subtitles or none, long uncut scenes, reaction close-up ending.",
     "evidence": "Peacock The Office / Brooklyn 99, Prime, Shemaroo, SAB (8+ videos).", "recipe": "sitcom",
     "required_assets": []},
    {"id": "ranking_top_n", "name": "TOP N ranking compilation", "category": "structure",
     "platforms": ["YouTube Shorts", "Instagram Reels"],
     "description": "\"TOP 5 ...\" title, numbered list filling in while clips play, ending on #1.",
     "evidence": "6 ranking videos (stream and sports pages).", "recipe": "ranking", "required_assets": []},
    {"id": "comment_keyword_cta", "name": "\"Comment 'WORD'\" keyword call-to-action", "category": "ending",
     "platforms": ["Instagram Reels"],
     "description": "Ending card asking viewers to comment a keyword (to receive a link/resource).",
     "evidence": "Very common among Indian IG creators in Nov 2026 research.", "recipe": "end_cta",
     "required_assets": []},
    {"id": "meme_white_top", "name": "Meme template: black text on white top", "category": "layout",
     "platforms": ["Instagram Reels"],
     "description": "Premise in black on a white top area, clip below, colour flash on punchlines.",
     "evidence": "Meme edit pages (6 videos).", "recipe": "meme", "required_assets": []},
    {"id": "reaction_ending", "name": "Comedy ends on a reaction shot", "category": "ending",
     "platforms": ["Instagram Reels", "YouTube Shorts"],
     "description": "Comedy clips end on the listener's reaction instead of the speaker.",
     "evidence": "Comedy / standup / sitcom clips (Samay, BBKV, The Office).", "recipe": "sitcom",
     "required_assets": []},
]


def _today() -> str:
    return date.today().isoformat()


def load() -> list[dict]:
    with _lock:
        try:
            data = json.loads(PATH.read_text(encoding="utf-8"))
            if isinstance(data, list) and data:
                return data
        except (OSError, ValueError):
            pass
    seeded = [{**t, "source": RESEARCH, "discovered": "2026-11-17", "last_verified": "2026-11-17",
               "status": "active", "compatibility": "see FODO_CLIPFORGE_COMPATIBILITY_MATRIX.md"} for t in SEED]
    save(seeded)
    return seeded


def save(items: list[dict]) -> None:
    with _lock:
        PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = PATH.with_suffix(".tmp")
        tmp.write_text(json.dumps(items, indent=1, ensure_ascii=False), encoding="utf-8")
        tmp.replace(PATH)


ALLOWED = {"name", "category", "platforms", "description", "evidence", "recipe", "required_assets",
           "source", "status", "last_verified", "compatibility"}


def update(trend_id: str, changes: dict) -> dict:
    items = load()
    for t in items:
        if t["id"] == trend_id:
            for k, v in changes.items():
                if k in ALLOWED:
                    t[k] = v
            if changes.get("status") not in (None, "active", "disabled", "retired"):
                t["status"] = "active"
            save(items)
            return t
    raise KeyError(trend_id)


def add(item: dict) -> dict:
    import re
    items = load()
    tid = re.sub(r"[^a-z0-9_]+", "_", (item.get("name") or "trend").lower())[:40] or "trend"
    while any(t["id"] == tid for t in items):
        tid += "_x"
    if not item.get("evidence") or not item.get("source"):
        raise ValueError("A trend needs evidence and a source (link or note) - nothing is called trending without proof.")
    t = {k: v for k, v in item.items() if k in ALLOWED}
    t.update({"id": tid, "discovered": _today(), "last_verified": item.get("last_verified") or _today(),
              "status": "active"})
    items.append(t)
    save(items)
    return t
