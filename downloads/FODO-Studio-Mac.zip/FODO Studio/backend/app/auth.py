"""Authentication: private-by-default, approved emails only, server-side sessions.

Real server-side RBAC: role lives on the User row, never trusted from the client.
Email *verification* (magic link / OTP) requires an SMTP account — not available
in this build environment — so first sign-up for an approved email sets the
password directly. This is documented as a pending item in docs/STATUS.md.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import secrets

from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session as DBSession

from . import config
from .config import APPROVED_EMAILS, SECRET_FILE, SESSION_TTL_HOURS
from .database import get_db
from .models import AuditLog, Session, User

_ITERATIONS = 200_000


def _secret() -> bytes:
    if not SECRET_FILE.exists():
        SECRET_FILE.write_bytes(secrets.token_bytes(32))
    return SECRET_FILE.read_bytes()


def hash_password(password: str, salt: bytes | None = None) -> str:
    salt = salt or secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, _ITERATIONS)
    return f"{salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        salt_hex, dk_hex = stored.split("$")
    except ValueError:
        return False
    dk = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), _ITERATIONS)
    return hmac.compare_digest(dk.hex(), dk_hex)


def audit(db: DBSession, user_id: str | None, action: str, detail: str = "") -> None:
    db.add(AuditLog(user_id=user_id, action=action, detail=detail))
    db.commit()


def create_session(db: DBSession, user: User) -> str:
    token = secrets.token_hex(32)
    db.add(
        Session(
            token=token,
            user_id=user.id,
            expires_at=dt.datetime.now(dt.timezone.utc) + dt.timedelta(hours=SESSION_TTL_HOURS),
        )
    )
    db.commit()
    return token


def register_or_login(db: DBSession, email: str, password: str) -> User:
    email = email.strip().lower()
    first_owner = False
    if email not in APPROVED_EMAILS:
        # Also allow users invited later (rows already in DB)
        existing = db.query(User).filter_by(email=email).first()
        if not existing:
            # A personal copy (installed from fodo.co.in): the first account on this PC owns it.
            first_owner = config.PERSONAL and db.query(User).count() == 0 and "@" in email and "." in email
            if not first_owner:
                raise HTTPException(403, "This application is private. Email not approved."
                                    if not config.PERSONAL else "Ask the owner of FODO Studio on this computer to invite you.")
    user = db.query(User).filter_by(email=email).first()
    if user is None:
        if len(password) < 8:
            raise HTTPException(400, "Password must be at least 8 characters.")
        # First approved user(s) become owner
        role = "owner" if (email in APPROVED_EMAILS or first_owner) else "editor"
        user = User(email=email, password_hash=hash_password(password), role=role)
        db.add(user)
        db.commit()
        audit(db, user.id, "user.created", email)
        return user
    if not user.is_active:
        raise HTTPException(403, "Account disabled.")
    if not verify_password(password, user.password_hash):
        audit(db, user.id, "auth.failed", email)
        raise HTTPException(401, "Invalid credentials.")
    return user


def current_user(request: Request, db: DBSession = Depends(get_db)) -> User:
    token = request.cookies.get("cf_session") or request.headers.get("x-session-token")
    if not token:
        raise HTTPException(401, "Not authenticated.")
    sess = db.query(Session).filter_by(token=token).first()
    if sess is None or sess.expires_at.replace(tzinfo=dt.timezone.utc) < dt.datetime.now(dt.timezone.utc):
        raise HTTPException(401, "Session expired.")
    user = db.get(User, sess.user_id)
    if user is None or not user.is_active:
        raise HTTPException(401, "Account unavailable.")
    return user


def require_role(*roles: str):
    def dep(user: User = Depends(current_user)) -> User:
        order = {"viewer": 0, "editor": 1, "admin": 2, "owner": 3}
        needed = min(order[r] for r in roles)
        if order.get(user.role, -1) < needed:
            raise HTTPException(403, "Insufficient permissions.")
        return user

    return dep
