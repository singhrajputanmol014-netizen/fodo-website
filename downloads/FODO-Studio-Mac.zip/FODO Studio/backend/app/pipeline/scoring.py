"""FODO Viral Intelligence Engine — candidate generation + transparent 0-100 scoring.

The score is an *editorial heuristic*, not a guaranteed virality probability.
Every candidate gets a per-factor breakdown with human-readable reasons.
Deterministic (no LLM required); an optional Ollama hook can re-rank later.
"""
from __future__ import annotations

import re

import numpy as np

from .audio import SAMPLE_RATE, mean_energy
from .transcribe import words_to_sentences

HOOK_PATTERNS = [
    (r"\?$", "ends with a question", 10),
    (r"^(what|why|how|when|who|did you|have you|imagine|listen|stop|wait|here'?s|this is)\b", "strong opening word", 12),
    (r"\b(secret|mistake|never|always|nobody|everyone|truth|warning|free|proven|shocking|crazy|insane|unbelievable)\b", "emotional/curiosity word", 8),
    (r"\b\d+(\.\d+)?%?\b", "contains a concrete number", 6),
    (r"\b(you|your)\b", "addresses the viewer directly", 5),
    (r"\b(but|however|actually|turns out|the problem is)\b", "tension/contrast marker", 6),
]

CONCLUSION_PATTERNS = r"\b(so|that'?s why|in the end|the lesson|remember|bottom line|finally|conclusion)\b"


def generate_candidates(words: list[dict], duration_ranges: list[tuple[int, int]],
                        video_duration: float) -> list[dict]:
    """Sentence-aligned sliding windows per duration range (overlapping)."""
    sentences = words_to_sentences(words)
    candidates: list[dict] = []
    seen: set[tuple[int, int]] = set()
    for lo, hi in duration_ranges:
        for i in range(len(sentences)):
            j = i
            while j < len(sentences) and sentences[j]["e"] - sentences[i]["s"] < hi:
                j += 1
            # try windows ending at j-1 and j (one just under, one just over)
            for jj in (j - 1, j):
                if jj < i or jj >= len(sentences):
                    continue
                s, e = sentences[i]["s"], sentences[jj]["e"]
                dur = e - s
                if not (lo <= dur <= hi * 1.15):
                    continue
                key = (int(s * 10), int(e * 10))
                if key in seen:
                    continue
                seen.add(key)
                candidates.append({
                    "start": round(max(0.0, s - 0.15), 3),
                    "end": round(min(video_duration, e + 0.25), 3),
                    "sentences": sentences[i : jj + 1],
                    "range": f"{lo}-{hi}",
                })
    return candidates


def score_candidate(cand: dict, pcm: np.ndarray, global_energy: float,
                    scene_cuts: list[float] | None = None) -> dict:
    """0-100 score with explainable breakdown."""
    sents = cand["sentences"]
    text = " ".join(s["text"] for s in sents)
    first_sentence = sents[0]["text"].lower().strip()
    dur = cand["end"] - cand["start"]
    words = [w for s in sents for w in s["words"]]
    reasons: list[str] = []
    breakdown: dict[str, float] = {}

    # 1. Opening hook (0-25)
    hook = 0.0
    for pat, why, pts in HOOK_PATTERNS:
        if re.search(pat, first_sentence):
            hook += pts
            reasons.append(f"Hook: {why}")
    hook = min(hook, 25.0)
    breakdown["hook"] = hook

    # 2. Narrative completeness (0-20): starts/ends on sentence bounds (by construction),
    #    bonus for a conclusion marker near the end.
    completeness = 12.0
    if re.search(CONCLUSION_PATTERNS, sents[-1]["text"].lower()):
        completeness += 8.0
        reasons.append("Completeness: ends with a concluding statement")
    else:
        reasons.append("Completeness: sentence-aligned boundaries")
    breakdown["completeness"] = min(completeness, 20.0)

    # 3. Emotional intensity / energy vs whole video (0-20)
    seg_energy = mean_energy(pcm, cand["start"], cand["end"]) if len(pcm) else 0.0
    ratio = seg_energy / global_energy if global_energy > 0 else 1.0
    energy_score = float(np.clip((ratio - 0.7) / 0.6, 0, 1)) * 20
    breakdown["energy"] = round(energy_score, 1)
    if ratio > 1.05:
        reasons.append(f"Energy: louder/more intense than video average (x{ratio:.2f})")
    elif ratio < 0.8:
        reasons.append("Energy: quieter than average — may feel flat")

    # 4. Pacing: words per second, sweet spot 2.2-3.5 (0-15)
    wps = len(words) / dur if dur > 0 else 0
    pacing = float(np.clip(1 - abs(wps - 2.8) / 2.2, 0, 1)) * 15
    breakdown["pacing"] = round(pacing, 1)
    reasons.append(f"Pacing: {wps:.1f} words/sec")

    # 5. Standalone comprehensibility: penalise dangling pronouns at start (0-10)
    standalone = 10.0
    if re.match(r"^(and|but|so|because|that|this|it|he|she|they)\b", first_sentence):
        standalone = 4.0
        reasons.append("Standalone: opens mid-thought (dangling reference)")
    breakdown["standalone"] = standalone

    # 6. Duration fit for short-form (0-10): 20-45s sweet spot
    dur_fit = float(np.clip(1 - abs(dur - 32) / 45, 0, 1)) * 10
    breakdown["duration_fit"] = round(dur_fit, 1)

    # 7. Visual engagement from scene-cut density (0-10); only when cuts were analysed
    raw_max = 100.0
    if scene_cuts is not None:
        n = sum(1 for c in scene_cuts if cand["start"] < c < cand["end"])
        per_10s = n / dur * 10 if dur > 0 else 0
        visual = float(np.clip(per_10s / 2.0, 0, 1)) * 10  # ~2 cuts / 10s = full marks
        breakdown["visual"] = round(visual, 1)
        reasons.append(f"Visual: {n} scene change(s) in clip")
        raw_max = 110.0

    total = round(sum(breakdown.values()) * 100.0 / raw_max, 1)
    return {
        **cand,
        "score": min(total, 100.0),
        "breakdown": breakdown,
        "reasons": reasons,
        "text": text,
        "title": suggest_title(sents),
    }


def suggest_title(sents: list[dict]) -> str:
    """Use the strongest hook sentence verbatim (never invent quotes)."""
    best, best_pts = sents[0]["text"], -1
    for s in sents[:3]:
        pts = sum(p for pat, _, p in HOOK_PATTERNS if re.search(pat, s["text"].lower()))
        if pts > best_pts:
            best, best_pts = s["text"], pts
    title = best.strip().rstrip(".")
    return title[:80] + ("…" if len(title) > 80 else "")


def dedupe_and_rank(scored: list[dict], top_n: int = 12, overlap_thresh: float = 0.5) -> list[dict]:
    """Greedy non-max suppression by score with temporal IoU."""
    ranked = sorted(scored, key=lambda c: c["score"], reverse=True)
    kept: list[dict] = []
    for c in ranked:
        ok = True
        for k in kept:
            inter = max(0.0, min(c["end"], k["end"]) - max(c["start"], k["start"]))
            union = max(c["end"], k["end"]) - min(c["start"], k["start"])
            if union > 0 and inter / union > overlap_thresh:
                ok = False
                break
        if ok:
            kept.append(c)
        if len(kept) >= top_n:
            break
    return kept


def trim_dead_space(cand: dict, silences: list[tuple[float, float]]) -> dict:
    """Pull clip edges inward past leading/trailing silence."""
    s, e = cand["start"], cand["end"]
    for a, b in silences:
        if a <= s < b:
            s = min(b, e - 1)
        if a < e <= b:
            e = max(a, s + 1)
    cand["start"], cand["end"] = round(s, 3), round(e, 3)
    return cand
