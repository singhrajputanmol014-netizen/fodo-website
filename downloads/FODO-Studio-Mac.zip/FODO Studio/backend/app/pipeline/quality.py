"""AI Video Quality Inspector — checks the ACTUAL rendered file, not the edit plan.

Everything here is measured from the decoded output:
  * technical: ffprobe stream facts, full decode (errors), black / frozen frames
  * audio:     EBU R128 loudness, true peak, silences, clipped start/end
  * visual:    faces cut off by the frame, frames with no person in a talking clip
  * captions:  text boxes overlapping faces, text outside the platform safe area,
               how much of the clip actually carries captions
  * editorial: slow opening (dead air before the first word), abrupt ending
               (cut while someone is still talking, no fade), long pauses, shot pacing

Scores are simple deductions from these measurements. They are labelled "measured"
(objective) or "heuristic" (a rule of thumb about editing) — never a human-taste score.
"""
from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

import numpy as np

# delivery targets for short-form social video
LUFS_TARGET, LUFS_TOL = -14.0, 2.5
TRUE_PEAK_MAX = -1.0
SAFE_X, SAFE_TOP, SAFE_BOTTOM = 0.04, 0.05, 0.13   # Reels/Shorts UI covers the bottom ~13 %
SAMPLE_W = 540
MIN_TEXT_H = 0.028        # caption line box vs frame height (~54 px on 1920); old exports 0.021-0.027,
                          # PC re-renders: size 105 -> 0.035, 108 -> 0.034 (Poppins)
SOFT_FACE = 100.0         # Laplacian variance of a 96x96 face crop (sharp 1080p sources: 300-1800)

SEV_POINTS = {"critical": 35, "high": 15, "medium": 7, "low": 3}


def _run(cmd: list[str], timeout: int = 900) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                          encoding="utf-8", errors="replace")


def probe(path: str | Path) -> dict:
    r = _run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path)], 60)
    if r.returncode != 0:
        return {"ok": False, "error": r.stderr.strip()[:300]}
    d = json.loads(r.stdout)
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), None)
    a = next((s for s in d.get("streams", []) if s.get("codec_type") == "audio"), None)
    fps = 0.0
    if v and v.get("avg_frame_rate", "0/0") != "0/0":
        n, dd = v["avg_frame_rate"].split("/")
        fps = float(n) / float(dd) if float(dd) else 0.0
    return {
        "ok": v is not None,
        "duration": float(d.get("format", {}).get("duration", 0) or 0),
        "size_mb": round(int(d.get("format", {}).get("size", 0) or 0) / 1e6, 1),
        "bitrate_kbps": round(int(d.get("format", {}).get("bit_rate", 0) or 0) / 1000),
        "width": int(v["width"]) if v else 0, "height": int(v["height"]) if v else 0,
        "vcodec": v.get("codec_name") if v else None, "fps": round(fps, 3),
        "pix_fmt": v.get("pix_fmt") if v else None,
        "acodec": a.get("codec_name") if a else None,
        "sample_rate": int(a.get("sample_rate", 0)) if a else 0,
        "channels": int(a.get("channels", 0)) if a else 0,
    }


def decode_pass(path: str | Path, has_audio: bool) -> dict:
    """One full decode with analysis filters: catches decode errors, black/frozen frames,
    cuts, loudness, true peak and silences."""
    vf = "blackdetect=d=0.2:pix_th=0.08,freezedetect=n=-60dB:d=1.5,scdet=threshold=14:sc_pass=0"
    cmd = ["ffmpeg", "-hide_banner", "-nostats", "-v", "info", "-i", str(path), "-vf", vf]
    if has_audio:
        cmd += ["-af", "ebur128=peak=true:framelog=quiet,silencedetect=n=-42dB:d=1.2"]
    cmd += ["-f", "null", "-"]
    r = _run(cmd)
    log = r.stderr
    out: dict = {"decode_errors": [], "black": [], "frozen": [], "cuts": [], "silences": []}
    for line in log.splitlines():
        if re.search(r"(error|corrupt|Invalid|non monotonically|missing picture)", line, re.I) \
                and "Error while" not in line and "ebur128" not in line:
            out["decode_errors"].append(line.strip()[:160])
    for m in re.finditer(r"black_start:([\d.]+) black_end:([\d.]+)", log):
        out["black"].append((float(m.group(1)), float(m.group(2))))
    fs = [float(x) for x in re.findall(r"freeze_start: ([\d.]+)", log)]
    fe = [float(x) for x in re.findall(r"freeze_end: ([\d.]+)", log)]
    out["frozen"] = list(zip(fs, fe + [None] * (len(fs) - len(fe))))
    out["cuts"] = [float(x) for x in re.findall(r"lavfi\.scd\.time: ([\d.]+)", log)]
    ss = [float(x) for x in re.findall(r"silence_start: ([\d.]+)", log)]
    se = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", log)]
    out["silences"] = list(zip(ss, se + [None] * (len(ss) - len(se))))
    summ = log[log.rfind("Summary:"):] if "Summary:" in log else ""
    m = re.search(r"I:\s*(-?[\d.]+) LUFS", summ)
    out["lufs"] = float(m.group(1)) if m else None
    m = re.search(r"LRA:\s*([\d.]+) LU", summ)
    out["lra"] = float(m.group(1)) if m else None
    m = re.search(r"Peak:\s*(-?[\d.]+|-inf) dBFS", summ)
    out["true_peak"] = (float(m.group(1)) if m.group(1) != "-inf" else -99.0) if m else None
    return out


def _edge_rms(path: str | Path, duration: float) -> dict:
    """RMS (dBFS) of the first/last 0.35 s vs the clip's median - spots hard audio cuts."""
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-ac", "1", "-ar", "16000",
                        "-f", "s16le", "-"], capture_output=True, timeout=300)
    pcm = np.frombuffer(r.stdout, np.int16).astype(np.float32) / 32768.0
    if pcm.size < 16000:
        return {}
    win = 1600
    n = pcm.size // win
    rms = np.sqrt(np.mean(pcm[: n * win].reshape(n, win) ** 2, axis=1) + 1e-12)
    db = 20 * np.log10(rms)
    k = max(1, int(0.35 * 10))
    speech = db[db > -45]
    first_voice = next((i / 10 for i, v in enumerate(db) if v > -38), None)
    return {"head_db": float(db[:k].mean()), "tail_db": float(db[-k:].mean()),
            "median_db": float(np.median(speech)) if speech.size else -90.0,
            "first_voice_s": first_voice}


def _text_boxes(gray) -> list[tuple[int, int, int, int]]:
    """Lines of burned-in text (captions, titles) as boxes, same detector as textbands."""
    import cv2
    h, w = gray.shape
    grad = cv2.morphologyEx(gray, cv2.MORPH_GRADIENT, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)))
    _, bw = cv2.threshold(grad, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    joined = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (max(9, w // 40), 3)))
    n, _lab, stats, _ = cv2.connectedComponentsWithStats(joined, connectivity=8)
    boxes = []
    for i in range(1, n):
        x, y, cw, ch, _a = stats[i]
        # caption lines are wide; a single big word (one-word / kinetic captions) is narrower but tall
        wide_line = cw >= w * 0.15 and cw >= 2.5 * ch and h * 0.015 <= ch <= h * 0.09
        big_word = cw >= w * 0.08 and cw >= 1.6 * ch and h * 0.025 <= ch <= h * 0.11
        if not (wide_line or big_word):
            continue
        fill = bw[y:y + ch, x:x + cw].mean() / 255
        if 0.18 <= fill <= 0.75:
            boxes.append((int(x), int(y), int(cw), int(ch)))
    return boxes


def frame_pass(path: str | Path, duration: float, step: float = 1.0) -> dict:
    """Sample ~1 frame/s: faces (YuNet) + text boxes -> overlap / safe-area / cut-off checks."""
    import cv2
    from .speakers import _detector
    h = int(SAMPLE_W * 16 / 9)
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-vf",
                        f"fps=1/{step},scale={SAMPLE_W}:-2", "-f", "rawvideo", "-pix_fmt", "bgr24", "-"],
                       capture_output=True, timeout=600)
    raw = r.stdout
    pr = probe(path)
    if pr.get("width"):
        h = int(round(SAMPLE_W * pr["height"] / pr["width"] / 2) * 2)
    fsz = SAMPLE_W * h * 3
    frames = [np.frombuffer(raw[i:i + fsz], np.uint8).reshape(h, SAMPLE_W, 3)
              for i in range(0, len(raw) - fsz + 1, fsz)]
    det = _detector(SAMPLE_W, h)
    res = {"samples": len(frames), "no_face": [], "face_cut": [], "overlap": [], "unsafe_text": [],
           "with_text": 0, "faces_per_frame": [], "frame_h": h, "text_h": [], "empty": [], "sharp": []}
    for i, img in enumerate(frames):
        t = round(i * step, 1)
        _, faces = det.detect(img)
        fb = [] if faces is None else [tuple(map(float, f[:4])) for f in faces if f[-1] > 0.75]
        fb = [f for f in fb if f[3] > h * 0.045]                    # ignore tiny background faces
        res["faces_per_frame"].append(len(fb))
        if not fb:
            res["no_face"].append(t)
        for (x, y, fw, fh) in fb:
            # forehead/chin cut: box leaves the frame or hugs an edge with most of the head outside
            if y < -0.12 * fh or y + fh > h + 0.12 * fh or x < -0.2 * fw or x + fw > SAMPLE_W + 0.2 * fw:
                res["face_cut"].append(t)
                break
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        tb = _text_boxes(gray)
        if tb:
            res["with_text"] += 1
            res["text_h"].append(max(tb, key=lambda b: b[1])[3] / h)   # lowest text line = the caption
        # screen usage: rows that are one flat colour (bars, empty pads)
        row_std = gray.std(axis=1)
        res["empty"].append(float((row_std < 3.0).mean()))
        # sharpness of the main face (soft = heavy upscale / out of focus)
        if fb:
            x, y, fw, fh = max(fb, key=lambda f: f[2] * f[3])
            x0, y0 = max(0, int(x)), max(0, int(y))
            roi = gray[y0:int(y + fh), x0:int(x + fw)]
            if roi.size > 400:
                roi = cv2.resize(roi, (96, 96))
                res["sharp"].append(float(cv2.Laplacian(roi, cv2.CV_64F).var()))
        for (x, y, tw, th) in tb:
            if x < SAFE_X * SAMPLE_W or x + tw > (1 - SAFE_X) * SAMPLE_W or y < SAFE_TOP * h \
                    or y + th > (1 - SAFE_BOTTOM) * h:
                res["unsafe_text"].append(t)
                break
        hit = False
        for (x, y, tw, th) in tb:
            for (fx, fy, fw, fh) in fb:
                # only the core of the face (eyes-mouth) matters; hair/neck may sit under a caption
                cx0, cy0, cx1, cy1 = fx + fw * 0.15, fy + fh * 0.2, fx + fw * 0.85, fy + fh * 0.95
                ix = max(0, min(x + tw, cx1) - max(x, cx0))
                iy = max(0, min(y + th, cy1) - max(y, cy0))
                if ix * iy > 0.12 * (cx1 - cx0) * (cy1 - cy0):
                    hit = True
        if hit:
            res["overlap"].append(t)
    return res


def _spans(ts: list[float], step: float = 1.0) -> list[tuple[float, float]]:
    out = []
    for t in sorted(ts):
        if out and t - out[-1][1] <= step + 0.01:
            out[-1] = (out[-1][0], t)
        else:
            out.append((t, t))
    return out


def inspect(path: str | Path, expect: dict | None = None, kind: str = "talk") -> dict:
    """Full inspection of one rendered file. `expect` may hold width/height/duration/captions/
    music; `kind` = talk | tv | stream | montage (relaxes face rules for non-talk footage)."""
    expect = expect or {}
    path = Path(path)
    defects: list[dict] = []

    def add(cat, sev, code, msg, at=None, fix=None, objective=True):
        defects.append({"category": cat, "severity": sev, "code": code, "message": msg,
                        "at": at, "fix": fix, "objective": objective})

    pr = probe(path)
    if not pr.get("ok"):
        add("technical", "critical", "unreadable", f"File cannot be read: {pr.get('error')}")
        return _finish(path, pr, {}, {}, {}, defects)
    if expect.get("width") and (pr["width"], pr["height"]) != (expect["width"], expect["height"]):
        add("technical", "high", "wrong_size", f"{pr['width']}x{pr['height']} instead of "
            f"{expect['width']}x{expect['height']}")
    if expect.get("duration") and abs(pr["duration"] - expect["duration"]) > max(0.5, 0.03 * expect["duration"]):
        add("technical", "medium", "wrong_duration",
            f"duration {pr['duration']:.1f}s, plan said {expect['duration']:.1f}s")
    if not pr.get("acodec"):
        add("audio", "high", "no_audio", "No audio stream")
    if pr.get("pix_fmt") not in ("yuv420p", "yuvj420p", None):
        add("technical", "medium", "pix_fmt", f"pixel format {pr['pix_fmt']} may not play on phones",
            fix="pix_fmt")

    dp = decode_pass(path, bool(pr.get("acodec")))
    if dp["decode_errors"]:
        add("technical", "high", "decode_errors", f"{len(dp['decode_errors'])} decode errors: "
            f"{dp['decode_errors'][0]}")
    dur = pr["duration"]
    for s, e in dp["black"]:
        fade_zone = s < 0.6 or e > dur - 0.8
        if (e - s) >= 0.4 and not fade_zone:
            add("visual", "high", "black_frames", f"black screen {s:.1f}-{e:.1f}s", at=s)
    for s, e in dp["frozen"]:
        e = e if e is not None else dur
        if e - s >= 2.5 and kind != "tv":
            add("visual", "medium", "frozen", f"picture frozen {s:.1f}-{e:.1f}s", at=s)

    au: dict = {}
    if pr.get("acodec"):
        lufs, tp = dp.get("lufs"), dp.get("true_peak")
        if lufs is not None and abs(lufs - LUFS_TARGET) > LUFS_TOL:
            sev = "high" if abs(lufs - LUFS_TARGET) > 6 else "medium"
            add("audio", sev, "loudness", f"loudness {lufs:.1f} LUFS (target {LUFS_TARGET:.0f} ±{LUFS_TOL})",
                fix="loudnorm")
        if tp is not None and tp > TRUE_PEAK_MAX:
            add("audio", "high" if tp > 0 else "medium", "true_peak",
                f"true peak {tp:+.1f} dBTP (max {TRUE_PEAK_MAX:+.0f}) - risk of distortion", fix="loudnorm")
        au = _edge_rms(path, dur)
        for s, e in dp["silences"]:
            e = e if e is not None else dur
            if s > 0.8 and e < dur - 0.8 and e - s >= 1.6 and kind in ("talk", "tv"):
                add("editorial", "low" if e - s < 2.5 else "medium", "dead_air",
                    f"{e - s:.1f}s of silence at {s:.1f}s", at=s, fix="tighten", objective=True)
        if au:
            if au.get("first_voice_s") is not None and au["first_voice_s"] > 1.2:
                add("editorial", "medium", "slow_open", f"first sound only at {au['first_voice_s']:.1f}s",
                    at=0, fix="trim_head", objective=False)
            if au["tail_db"] > au["median_db"] - 4:
                add("editorial", "medium", "abrupt_end",
                    f"audio still at full level in the last 0.35s ({au['tail_db']:.0f} dBFS) - "
                    "cut mid-sound, no fade", at=dur, fix="extend_end", objective=False)

    fp = frame_pass(path, dur)
    n = max(1, fp["samples"])
    if kind == "talk":
        nf = len(fp["no_face"])
        if nf / n > 0.35:
            add("visual", "medium", "no_person", f"no face visible in {nf}/{n} sampled seconds",
                fix="reframe", objective=False)
    for s, e in _spans(fp["face_cut"]):
        if e - s >= 1:
            add("visual", "high", "face_cut", f"face cut off by the frame {s:.0f}-{e:.0f}s", at=s, fix="reframe")
    for s, e in _spans(fp["overlap"]):
        add("captions", "high" if e - s >= 2 else "medium", "text_on_face",
            f"text covers a face {s:.0f}-{e:.0f}s", at=s, fix="move_captions")
    us = len(fp["unsafe_text"])
    if us / n > 0.15:
        add("captions", "medium", "unsafe_text", f"text outside the safe area in {us}/{n} sampled seconds "
            "(platform buttons/caption may cover it)", fix="move_captions")
    if expect.get("captions") and fp["with_text"] / n < 0.4:
        add("captions", "high", "captions_missing", f"captions expected but text found in only "
            f"{fp['with_text']}/{n} sampled seconds", fix="captions")

    if fp["text_h"]:
        th = float(np.median(fp["text_h"]))
        if expect.get("captions") and th < MIN_TEXT_H:
            add("captions", "medium", "small_text", f"caption lines are {th * 100:.1f}% of the screen height "
                f"(~{th * pr['height']:.0f}px) - hard to read on a phone (want >= {MIN_TEXT_H * 100:.1f}%)",
                fix="bigger_captions", objective=True)
    if fp["empty"]:
        em = float(np.median(fp["empty"]))
        if em > 0.33:
            add("visual", "medium" if em > 0.4 else "low", "empty_screen",
                f"{em * 100:.0f}% of the screen is flat bars/padding - the picture is small on a phone",
                fix="bigger_picture", objective=True)
    if len(fp["sharp"]) >= 5:
        sh = float(np.median(fp["sharp"]))
        if sh < SOFT_FACE:
            add("visual", "low", "soft_picture", f"faces look soft (detail {sh:.0f} < {SOFT_FACE:.0f}) - "
                "low-quality source or the crop zooms past the source resolution", fix="less_zoom", objective=False)
    cuts = dp["cuts"]
    pacing = {"cuts": len(cuts), "avg_shot_s": round(dur / (len(cuts) + 1), 1)}
    if kind == "montage" and pacing["avg_shot_s"] > 4:
        add("editorial", "low", "slow_pacing", f"average shot {pacing['avg_shot_s']}s for a montage",
            objective=False)
    return _finish(path, pr, dp, fp, {"edges": au, "pacing": pacing}, defects)


def _finish(path, pr, dp, fp, extra, defects) -> dict:
    cats = ["technical", "visual", "audio", "captions", "editorial"]
    scores = {}
    for c in cats:
        pts = sum(SEV_POINTS[d["severity"]] for d in defects if d["category"] == c)
        scores[c] = max(0, 100 - pts)
    w = {"technical": 0.25, "visual": 0.2, "audio": 0.2, "captions": 0.15, "editorial": 0.2}
    overall = round(sum(scores[c] * w[c] for c in cats))
    if any(d["severity"] == "critical" for d in defects):
        overall = min(overall, 40)
    return {
        "file": str(path), "probe": pr,
        "measurements": {
            "lufs": dp.get("lufs"), "true_peak": dp.get("true_peak"), "lra": dp.get("lra"),
            "black": dp.get("black"), "frozen": dp.get("frozen"), "silences": dp.get("silences"),
            "decode_errors": len(dp.get("decode_errors", [])),
            "frames_sampled": fp.get("samples"), "frames_with_text": fp.get("with_text"),
            "frames_without_face": len(fp.get("no_face", [])),
            "caption_line_h": round(float(np.median(fp["text_h"])), 4) if fp.get("text_h") else None,
            "empty_screen": round(float(np.median(fp["empty"])), 3) if fp.get("empty") else None,
            "face_detail": round(float(np.median(fp["sharp"])), 1) if fp.get("sharp") else None,
            **extra},
        "defects": defects, "scores": scores, "overall": overall,
        "approved": not any(d["severity"] in ("critical", "high") for d in defects),
        "note": "Scores are deductions from measured defects (objective=True) and editing "
                "rules of thumb (objective=False). They are not a human-taste rating.",
    }
