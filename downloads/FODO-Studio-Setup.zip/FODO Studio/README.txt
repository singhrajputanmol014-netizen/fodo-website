FODO Studio (personal edition)

Open it from the 'FODO Studio' icon on your desktop. The first start asks you to create your account:
you become the owner of FODO Studio on this PC, with your own Control Panel.

Power: FODO Studio reads this PC's processor, memory and graphics card and picks Maximum, Balanced or
Saver by itself (Control Panel > Power to change it).

Everything runs on this computer with its own power. Schedule and post your clips from
https://www.fodo.co.in/studio/ on any device.

Built-in music beds and sound effects are FODO originals. Fonts are under the SIL Open Font Licence
(backend/app/pipeline/assets/fonts/OFL.txt).
