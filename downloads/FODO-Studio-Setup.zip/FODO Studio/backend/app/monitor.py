"""Live hardware telemetry for the admin Control Panel.

CPU / RAM come straight from the OS (Windows kernel32 via ctypes, Mach host_statistics + vm_stat on macOS, /proc on Linux) - no extra
packages (Smart App Control blocks unsigned native wheels). GPU comes from nvidia-smi:
utilisation, NVENC encoder / decoder load, VRAM, temperature, power and the processes holding
GPU memory. Sampled every 2 s in a background thread; the last 5 minutes are kept for charts.
"""
from __future__ import annotations

import collections
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request

from .config import STORAGE_DIR

HISTORY = collections.deque(maxlen=150)        # 150 x 2 s = 5 minutes
_latest: dict = {}
_started = False
_NO_WIN = getattr(subprocess, "CREATE_NO_WINDOW", 0)


# ------------------------------------------------------------------ CPU / RAM ----
if sys.platform == "win32":
    import ctypes
    from ctypes import wintypes

    class _FT(ctypes.Structure):
        _fields_ = [("lo", wintypes.DWORD), ("hi", wintypes.DWORD)]

    class _MEM(ctypes.Structure):
        _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD),
                    ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

    def _cpu_times():
        idle, kern, user = _FT(), _FT(), _FT()
        ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(user))
        f = lambda t: (t.hi << 32) | t.lo  # noqa: E731
        return f(idle), f(kern) + f(user)          # kernel time includes idle

    def _ram():
        m = _MEM()
        m.dwLength = ctypes.sizeof(_MEM)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        return m.ullTotalPhys, m.ullTotalPhys - m.ullAvailPhys
elif sys.platform == "darwin":
    import ctypes

    _libc = ctypes.CDLL("/usr/lib/libSystem.B.dylib")
    _libc.mach_host_self.restype = ctypes.c_uint
    _libc.host_statistics.argtypes = [ctypes.c_uint, ctypes.c_int, ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint)]

    def _cpu_times():
        """host_statistics(HOST_CPU_LOAD_INFO): ticks user, system, idle, nice (all cores)."""
        info = (ctypes.c_uint * 4)()
        count = ctypes.c_uint(4)
        _libc.host_statistics(_libc.mach_host_self(), 3, info, ctypes.byref(count))
        user, system, idle, nice = info
        return idle, user + system + idle + nice

    _MEMSIZE: list[int] = []

    def _ram():
        if not _MEMSIZE:
            _MEMSIZE.append(int(subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True,
                                               timeout=5).stdout.strip() or 0))
        total = _MEMSIZE[0]
        return total, mac_used_ram(subprocess.run(["vm_stat"], capture_output=True, text=True, timeout=5).stdout, total)
else:
    def _cpu_times():
        with open("/proc/stat") as f:
            vals = [int(x) for x in f.readline().split()[1:]]
        idle = vals[3] + (vals[4] if len(vals) > 4 else 0)
        return idle, sum(vals)

    def _ram():
        info = {}
        with open("/proc/meminfo") as f:
            for line in f:
                k, v = line.split(":")
                info[k] = int(v.split()[0]) * 1024
        return info["MemTotal"], info["MemTotal"] - info.get("MemAvailable", info.get("MemFree", 0))


def mac_used_ram(vm_stat: str, total: int) -> int:
    """Used memory from `vm_stat` like Activity Monitor: total minus free, inactive and speculative pages."""
    import re
    m = re.search(r"page size of (\d+) bytes", vm_stat)
    page = int(m.group(1)) if m else 4096
    pages = {k.strip().lower(): int(v.strip().rstrip(".") or 0)
             for k, v in re.findall(r"^([^:\n]+):\s+(\d+)\.?$", vm_stat, re.M)}
    free = sum(pages.get(k, 0) for k in ("pages free", "pages inactive", "pages speculative"))
    return max(0, min(total, total - free * page))


def _gpu() -> dict | None:
    if not shutil.which("nvidia-smi"):
        return None
    q = "name,utilization.gpu,utilization.encoder,utilization.decoder,memory.used,memory.total,temperature.gpu,power.draw,driver_version"
    try:
        r = subprocess.run(["nvidia-smi", f"--query-gpu={q}", "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=5, creationflags=_NO_WIN)
        parts = [p.strip() for p in r.stdout.strip().splitlines()[0].split(",")]
        num = lambda x: float(x) if x.replace(".", "", 1).isdigit() else None  # noqa: E731
        g = {"name": parts[0], "util": num(parts[1]), "enc": num(parts[2]), "dec": num(parts[3]),
             "mem_used": num(parts[4]), "mem_total": num(parts[5]), "temp": num(parts[6]),
             "power": num(parts[7]), "driver": parts[8]}
        r2 = subprocess.run(["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory",
                             "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=5,
                            creationflags=_NO_WIN)
        apps = []
        for line in r2.stdout.strip().splitlines():
            bits = [b.strip() for b in line.split(",")]
            if len(bits) >= 3:
                name = os.path.basename(bits[1])
                who = ("ClipForge (Whisper AI)" if bits[0] == str(os.getpid())
                       else "Ollama (local AI)" if "ollama" in name.lower() else name)
                apps.append({"pid": bits[0], "name": who, "mem": num(bits[2])})
        g["apps"] = apps
        return g
    except Exception:  # noqa: BLE001
        return None


def _ollama() -> dict:
    try:
        with urllib.request.urlopen("http://127.0.0.1:11434/api/ps", timeout=1.5) as r:
            d = json.loads(r.read().decode())
        models = [{"name": m.get("name"), "vram": m.get("size_vram", 0), "size": m.get("size", 0)}
                  for m in d.get("models", [])]
        return {"running": True, "loaded": models}
    except Exception:  # noqa: BLE001
        return {"running": False, "loaded": []}


def _loop():
    try:
        prev = _cpu_times()
    except Exception:  # noqa: BLE001 - unknown OS: keep sampling disk / GPU anyway
        prev = (0, 0)
    n = 0
    while True:
        time.sleep(2)
        try:
            try:
                cur = _cpu_times()
            except Exception:  # noqa: BLE001
                cur = prev
            di, dt = cur[0] - prev[0], cur[1] - prev[1]
            prev = cur
            cpu = max(0.0, min(100.0, 100.0 * (1 - di / dt))) if dt > 0 else 0.0
            try:
                tot, used = _ram()
            except Exception:  # noqa: BLE001
                tot, used = 0, 0
            du = shutil.disk_usage(str(STORAGE_DIR))
            g = _gpu()
            sample = {"t": time.time(), "cpu": round(cpu, 1), "ram_used": used, "ram_total": tot,
                      "ram": round(100 * used / tot, 1) if tot else None,
                      "disk_free": du.free, "disk_total": du.total, "gpu": g}
            if n % 5 == 0:
                sample["ollama"] = _ollama()
            else:
                sample["ollama"] = _latest.get("ollama")
            _latest.clear()
            _latest.update(sample)
            HISTORY.append({"t": sample["t"], "cpu": sample["cpu"], "ram": sample["ram"],
                            "gpu": (g or {}).get("util"), "enc": (g or {}).get("enc"),
                            "vram": round(100 * g["mem_used"] / g["mem_total"], 1) if g and g.get("mem_total") else None})
            n += 1
        except Exception:  # noqa: BLE001
            time.sleep(5)


def start() -> None:
    global _started
    if _started:
        return
    _started = True
    threading.Thread(target=_loop, daemon=True, name="clipforge-monitor").start()


def snapshot() -> dict:
    return dict(_latest)


def history() -> list[dict]:
    return list(HISTORY)
