"""Per-user saved styles ("save my style") and favourite presets. Small JSON file, atomic writes."""
from __future__ import annotations

import json
import threading
import time
import uuid

from .config import STORAGE_DIR

PATH = STORAGE_DIR / "my_styles.json"
MAX_STYLES = 40
_lock = threading.Lock()


def _read() -> dict:
    try:
        return json.loads(PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _write(d: dict) -> None:
    PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(PATH)


def get(user_id: str) -> dict:
    u = _read().get(user_id) or {}
    return {"styles": u.get("styles", []), "favourites": u.get("favourites", [])}


def add(user_id: str, name: str, opts: dict) -> dict:
    name = (name or "").strip()[:60]
    if not name:
        raise ValueError("Give the style a name")
    if not isinstance(opts, dict) or len(json.dumps(opts)) > 20000:
        raise ValueError("Bad style settings")
    opts = {k: v for k, v in opts.items() if k not in ("music_start", "music_end", "cut_ranges", "start", "end")}
    with _lock:
        d = _read()
        u = d.setdefault(user_id, {"styles": [], "favourites": []})
        u["styles"] = [s for s in u.get("styles", []) if s["name"].lower() != name.lower()]   # same name = update
        st = {"id": uuid.uuid4().hex[:10], "name": name, "opts": opts, "created": int(time.time())}
        u["styles"].insert(0, st)
        u["styles"] = u["styles"][:MAX_STYLES]
        _write(d)
    return st


def delete(user_id: str, sid: str) -> bool:
    with _lock:
        d = _read()
        u = d.get(user_id) or {}
        before = len(u.get("styles", []))
        u["styles"] = [s for s in u.get("styles", []) if s["id"] != sid]
        if len(u["styles"]) == before:
            return False
        d[user_id] = u
        _write(d)
    return True


def set_favourites(user_id: str, favs: list) -> list:
    favs = [str(f)[:60] for f in (favs or []) if isinstance(f, str)][:100]
    with _lock:
        d = _read()
        u = d.setdefault(user_id, {"styles": [], "favourites": []})
        u["favourites"] = list(dict.fromkeys(favs))
        _write(d)
    return u["favourites"]
