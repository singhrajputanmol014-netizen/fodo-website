"""FODO CLIPFORGE AI — FastAPI application."""
from __future__ import annotations

import datetime
import re

import logging
import shutil
import subprocess
import uuid
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session as DBSession

from . import processing  # noqa: F401  (registers job handlers)
from .auth import audit, create_session, current_user, register_or_login, require_role
from .config import (
    ALLOWED_VIDEO_EXT,
    ASPECT_RATIOS,
    BASE_DIR,
    EXPORTS_DIR,
    MAX_UPLOAD_MB,
    PERFORMANCE_PROFILES,
    UPLOADS_DIR,
)
from .database import get_db, init_db
from .jobs import cancel, enqueue, start_worker
from .models import AuditLog, Clip, Export, Job, Project, User, Video
from .pipeline.captions import CAPTION_STYLES
from .pipeline.caption_library import LIBRARY as CAPTION_LIBRARY
from .pipeline.templates import BUILTIN_TEMPLATES
from .pipeline.metadata import extract_metadata
from .pipeline.transcribe import parse_transcript_file

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
from contextlib import asynccontextmanager


@asynccontextmanager
async def lifespan(_app):
    from .activity import install_log_capture
    install_log_capture()
    init_db()
    start_worker()
    from . import power as _power
    _power.apply_priority()          # cached plan first (saver = below-normal), then re-check this PC
    _power.refresh_async()
    from . import live as _live
    _live.mark_interrupted()
    try:
        from .processing import resume_bot_retries
        resume_bot_retries()
    except Exception:  # noqa: BLE001
        logging.getLogger("clipforge").exception("could not resume bot-check retries")
    from . import monitor
    monitor.start()
    try:
        from . import publish
        publish.start()
    except Exception:  # noqa: BLE001
        logging.getLogger("clipforge").exception("could not start the publish desk")
    yield
    _live.stop_all()


app = FastAPI(title="FODO Studio", version="0.15.0", lifespan=lifespan)
from .api.extra import router as extra_router, snapshot  # noqa: E402
app.include_router(extra_router)
from .api.admin_panel import router as admin_panel_router  # noqa: E402
app.include_router(admin_panel_router)
from .api.publish_api import router as publish_router  # noqa: E402
from .api.growth_api import router as growth_router  # noqa: E402
app.include_router(growth_router)
from .api.social_api import router as social_router  # noqa: E402
app.include_router(social_router)
app.include_router(publish_router)


# ---------------------------------------------------------------- auth ----
@app.post("/api/auth/login")
def login(email: str = Form(...), password: str = Form(...), db: DBSession = Depends(get_db)):
    user = register_or_login(db, email, password)
    token = create_session(db, user)
    audit(db, user.id, "auth.login", user.email)
    resp = JSONResponse({"email": user.email, "role": user.role})
    resp.set_cookie("cf_session", token, httponly=True, samesite="lax", max_age=7 * 86400)
    return resp


@app.get("/api/auth/edition")
def auth_edition(db: DBSession = Depends(get_db)):
    from . import config as _cfg
    return {"edition": _cfg.EDITION, "needs_owner": _cfg.PERSONAL and db.query(User).count() == 0}


@app.post("/api/auth/logout")
def logout(request: Request, db: DBSession = Depends(get_db)):
    resp = JSONResponse({"ok": True})
    resp.delete_cookie("cf_session")
    return resp


@app.get("/api/auth/me")
def me(user: User = Depends(current_user)):
    return {"email": user.email, "role": user.role}


# ------------------------------------------------------------ projects ----
@app.get("/api/projects")
def list_projects(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    rows = db.query(Project).order_by(Project.created_at.desc()).all()
    return [
        {"id": p.id, "name": p.name, "created_at": p.created_at.isoformat(),
         "videos": len(p.videos)}
        for p in rows
    ]


@app.post("/api/projects")
def create_project(name: str = Form(...), user: User = Depends(require_role("editor")),
                   db: DBSession = Depends(get_db)):
    p = Project(name=name.strip()[:255] or "Untitled", owner_id=user.id)
    db.add(p)
    db.commit()
    audit(db, user.id, "project.create", p.name)
    return {"id": p.id, "name": p.name}


# -------------------------------------------------------------- videos ----
@app.get("/api/videos")
def list_videos(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    from sqlalchemy import func as _f
    from .models import Topic
    counts = dict(db.query(Topic.video_id, _f.count(Topic.id)).group_by(Topic.video_id).all())
    rows = db.query(Video).order_by(Video.created_at.desc()).all()
    from .tracking import source_info
    pnames = {p.id: p.name for p in db.query(Project).all()}
    return [{"id": v.id, "filename": (v.meta or {}).get("source_title") or v.filename, "status": v.status,
             "project_id": v.project_id, "clips": len(v.clips), "topics": counts.get(v.id, 0),
             "created_at": v.created_at.isoformat(), "duration": (v.meta or {}).get("duration"),
             "source": source_info(v, pnames.get(v.project_id))}
            for v in rows]


@app.post("/api/projects/{project_id}/videos")
async def upload_video(project_id: str, file: UploadFile = File(...),
                       user: User = Depends(require_role("editor")),
                       db: DBSession = Depends(get_db)):
    project = db.get(Project, project_id)
    if project is None:
        raise HTTPException(404, "Project not found")
    ext = Path(file.filename or "video.mp4").suffix.lower()
    if ext not in ALLOWED_VIDEO_EXT:
        raise HTTPException(400, f"Unsupported file type {ext}. Allowed: {sorted(ALLOWED_VIDEO_EXT)}")

    video = Video(project_id=project_id, filename=Path(file.filename).name, path="")
    db.add(video)
    db.commit()
    dest = UPLOADS_DIR / f"{video.id}{ext}"
    size = 0
    max_bytes = MAX_UPLOAD_MB * 1024 * 1024
    with dest.open("wb") as f:
        while chunk := await file.read(1024 * 1024):
            size += len(chunk)
            if size > max_bytes:
                f.close()
                dest.unlink(missing_ok=True)
                db.delete(video)
                db.commit()
                raise HTTPException(413, f"File exceeds {MAX_UPLOAD_MB} MB limit")
            f.write(chunk)
    try:
        meta = extract_metadata(dest)
    except Exception as e:  # noqa: BLE001
        dest.unlink(missing_ok=True)
        db.delete(video)
        db.commit()
        raise HTTPException(400, f"Not a valid video file: {e}")
    video.path = str(dest)
    video.meta = meta
    video.status = "uploaded"
    db.commit()
    audit(db, user.id, "video.upload", f"{video.filename} ({meta['duration']:.0f}s)")
    return {"id": video.id, "meta": meta}


@app.post("/api/videos/{video_id}/transcript")
async def import_transcript(video_id: str, file: UploadFile = File(...),
                            user: User = Depends(require_role("editor")),
                            db: DBSession = Depends(get_db)):
    video = db.get(Video, video_id)
    if video is None:
        raise HTTPException(404, "Video not found")
    tmp = UPLOADS_DIR / f"{video_id}_transcript{Path(file.filename or 't.srt').suffix}"
    tmp.write_bytes(await file.read())
    try:
        words = parse_transcript_file(tmp)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"Could not parse transcript: {e}")
    finally:
        tmp.unlink(missing_ok=True)
    if not words:
        raise HTTPException(400, "Transcript contained no words")
    video.transcript = words
    video.transcript_source = "imported"
    db.commit()
    return {"words": len(words)}


@app.post("/api/videos/{video_id}/analyze")
def analyze(video_id: str, auto_mode: bool = False, aspect: str = "9:16",
            user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    video = db.get(Video, video_id)
    if video is None:
        raise HTTPException(404, "Video not found")
    meta = dict(video.meta or {})
    meta["auto_mode"] = {"aspect": aspect if aspect in ASPECT_RATIOS else "9:16"} if auto_mode else None
    video.meta = meta
    video.status = "analyzing" if video.path else video.status
    db.commit()
    job_id = enqueue("analyze", video_id)
    audit(db, user.id, "video.analyze", video_id)
    return {"job_id": job_id}


@app.get("/api/videos/{video_id}")
def get_video(video_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    v = db.get(Video, video_id)
    if v is None:
        raise HTTPException(404, "Video not found")
    from .tracking import source_info
    return {
        "id": v.id, "filename": v.filename, "status": v.status, "meta": v.meta,
        "created_at": v.created_at.isoformat() if v.created_at else None,
        "source": source_info(v, v.project.name if v.project else None),
        "transcript_source": v.transcript_source,
        "has_transcript": bool(v.transcript),
        "clips": [_clip_json(c) for c in sorted(v.clips, key=lambda c: -c.score)],
    }


@app.get("/api/videos/{video_id}/file")
def video_file(video_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    v = db.get(Video, video_id)
    if v is None or not Path(v.path).exists():
        raise HTTPException(404, "Video not found")
    return FileResponse(v.path, media_type="video/mp4")


# --------------------------------------------------------------- clips ----
def _quality_summary(v: dict | None) -> dict | None:
    q = (v or {}).get("quality")
    if not q or "overall" not in q:
        return None
    return {"overall": q["overall"], "initial": q.get("initial_overall"), "scores": q.get("scores"),
            "approved": q.get("approved"), "repairs": q.get("repairs", []),
            "defects": [{"severity": d["severity"], "message": d["message"], "category": d["category"]}
                        for d in q.get("defects", [])][:8]}


def _clip_json(c: Clip) -> dict:
    from .tracking import clip_times, export_times
    return {
        "created_at": c.created_at.isoformat() if c.created_at else None, "times": clip_times(c),
        "id": c.id, "start": c.start, "end": c.end, "duration": round(c.end - c.start, 1),
        "score": c.score, "breakdown": c.score_breakdown, "title": c.title,
        "text": c.text[:400], "settings": c.settings, "label": c.label,
        "topic_id": c.settings.get("topic_id"),
        "exports": [
            {"id": e.id, "status": e.status, "params": e.params, "output": (e.verification or {}).get("output"),
             "verified": bool(e.verification and e.verification.get("ok")),
             "error": e.error, "created_at": e.created_at.isoformat(),
             "rendered_at": (e.verification or {}).get("rendered_at"),
             "quality": _quality_summary(e.verification),
             "plan": [{"what": d["what"], "choice": d["choice"], "why": d["why"], "applied": d["applied"]}
                      for d in ((e.verification or {}).get("plan") or {}).get("decisions", [])],
             "filename": export_filename(e) if e.path else None, "times": export_times(e),
             "has_thumb": bool(e.path and Path(e.path).with_suffix(".jpg").exists())}
            for e in c.exports
        ],
    }


@app.patch("/api/clips/{clip_id}")
def update_clip(clip_id: str, payload: dict, user: User = Depends(require_role("editor")),
                db: DBSession = Depends(get_db)):
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    if any(k in payload for k in ("start", "end", "title", "settings")):
        snapshot(db, c, "manual", "edit " + ",".join(k for k in payload if k != "label"))
    if "start" in payload:
        c.start = max(0.0, float(payload["start"]))
    if "end" in payload:
        c.end = float(payload["end"])
    if c.end <= c.start:
        raise HTTPException(400, "end must be after start")
    if "title" in payload:
        c.title = str(payload["title"])[:512]
    if "label" in payload and payload["label"] in ("successful", "unsuccessful", None):
        c.label = payload["label"]
    if "settings" in payload and isinstance(payload["settings"], dict):
        s = dict(c.settings)
        for k in ("aspect", "caption_style", "resolution", "profile", "placement"):
            if k in payload["settings"]:
                s[k] = payload["settings"][k]
        s.update(_render_options({k: v for k, v in payload["settings"].items()
                                  if k in ("framing", "edit_style", "music", "music_volume",
                                           "duck", "caption_design", "engine")}, s))
        if s.get("aspect") not in ASPECT_RATIOS:
            raise HTTPException(400, "Bad aspect ratio")
        if s.get("caption_style") not in CAPTION_STYLES:
            raise HTTPException(400, "Bad caption style")
        c.settings = s
    db.commit()
    return _clip_json(c)


@app.post("/api/clips/{clip_id}/export")
def start_export(clip_id: str, payload: dict | None = None,
                 user: User = Depends(require_role("editor")), db: DBSession = Depends(get_db)):
    c = db.get(Clip, clip_id)
    if c is None:
        raise HTTPException(404, "Clip not found")
    p = payload or {}
    params = {
        "aspect": p.get("aspect", c.settings.get("aspect", "9:16")),
        "caption_style": p.get("caption_style", c.settings.get("caption_style", "fodo_orange")),
        "resolution": p.get("resolution", c.settings.get("resolution", "1080p")),
        "profile": p.get("profile", "balanced"),
        "captions": p.get("captions", True),
        "placement": p.get("placement", c.settings.get("placement", "lower")),
        "audio_normalize": p.get("audio_normalize", c.settings.get("audio_normalize", True)),
        **_render_options(p, c.settings),
        "start": p.get("start", c.start),
        "end": p.get("end", c.end),
    }
    if params["aspect"] not in ASPECT_RATIOS:
        raise HTTPException(400, "Bad aspect")
    if params["profile"] not in PERFORMANCE_PROFILES:
        raise HTTPException(400, "Bad profile")
    exp = Export(clip_id=clip_id, params=params)
    db.add(exp)
    db.commit()
    job_id = enqueue("export", exp.id)
    audit(db, user.id, "export.start", f"clip={clip_id} {params['aspect']} {params['resolution']}")
    return {"export_id": exp.id, "job_id": job_id}


LAYOUTS = {
    "auto":      {"label": "Auto (AI picks)", "frame": None},
    "style":     {"label": "Style default", "frame": None},
    "fill":      {"label": "Full screen, follow the speaker", "frame": "fill"},
    "split":     {"label": "Podcast split (2 people stacked)", "frame": "fill", "framing": "split"},
    "stream":    {"label": "Gaming / stream: facecam on top", "frame": "stream"},
    "fit":       {"label": "Whole frame + blurred background", "frame": "native"},
    "letterbox": {"label": "Whole frame on black", "frame": "letterbox"},
    "cinema":    {"label": "Cinema band", "frame": "cinema"},
    "boxed":     {"label": "Clip-page box", "frame": "boxed"},
    "frame45":   {"label": "4:5 card on blur", "frame": "frame45"},
    "tv":        {"label": "TV / film scene (no zoom)", "frame": "tv", "framing": "tv"},
}


def _clean_overlays(v) -> list[dict]:
    """Editor text layers: [{text, start, end, pos, size, color, bg}] in clip time (seconds)."""
    out = []
    for t in (v or [])[:12] if isinstance(v, list) else []:
        if not isinstance(t, dict):
            continue
        text = str(t.get("text") or "").strip()[:160]
        if not text:
            continue
        try:
            a, b = max(0.0, float(t.get("start") or 0)), float(t.get("end") or 0)
        except (TypeError, ValueError):
            continue
        col = str(t.get("color") or "#FFFFFF")
        bg = str(t.get("bg") or "")
        try:
            x = min(0.98, max(0.02, float(t["x"]))) if t.get("x") is not None else None
            y = min(0.98, max(0.02, float(t["y"]))) if t.get("y") is not None else None
        except (TypeError, ValueError):
            x = y = None
        out.append({"text": text, "start": round(a, 2), "end": round(b, 2) if b > a else None,
                    "x": None if x is None else round(x, 4), "y": None if y is None else round(y, 4),
                    "pos": t.get("pos") if t.get("pos") in ("top", "middle", "bottom") else "top",
                    "size": max(36, min(140, int(t.get("size") or 72))),
                    "color": col if re.fullmatch(r"#[0-9A-Fa-f]{6}", col) else "#FFFFFF",
                    "bg": bg if re.fullmatch(r"#[0-9A-Fa-f]{6}", bg) else ""})
    return out


def _render_options(p: dict, settings: dict) -> dict:
    """Edit options (validated). A preset fills every option the user did not set."""
    from .pipeline.captions import FONTS, ANIMATIONS, POSITIONS
    from .pipeline.compose import EDIT_STYLES
    from .pipeline.edit import DEAD_AIR, MUSIC_MOODS, PRESETS, SFX_LEVEL
    keys = ("framing", "edit_style", "music", "music_volume", "duck", "caption_design", "engine",
            "preset", "dead_air", "sfx", "hook_title", "progress_bar", "jump_zoom", "hook_text",
            "slow_push", "music_mode", "caption_lang", "accurate_captions", "hook_style", "hook_bg",
            "hook_color", "hook_font", "clip_length", "end_cta", "ending",
            "hide_text", "remove_fillers", "punch_zoom", "crop_x", "cut_ranges", "fx", "watermark",
            "layout", "speed", "text_overlays")
    o = {**{k: settings.get(k) for k in keys if k in settings}, **p}
    preset = o.get("preset") if o.get("preset") in PRESETS else None
    base = PRESETS.get(preset, {})

    def pick(k, default):
        v = o.get(k)
        return v if v not in (None, "") else base.get(k, default)

    music = o.get("music")
    if music in (None, "") and preset:
        music = MUSIC_MOODS.get(base.get("music_mood", "none"))
    if music == "none" or not (isinstance(music, str) and ":" in music):
        music = None
    out = {"engine": o.get("engine") if o.get("engine") in ("speaker", "classic") else "speaker",
           "preset": preset,
           "framing": (o.get("framing") if o.get("framing") in ("auto", "speaker", "smart", "split", "wide", "tv", "manual") else "auto"),
           "edit_style": pick("edit_style", "clean") if pick("edit_style", "clean") in EDIT_STYLES else "clean",
           "music": music,
           "music_volume": max(0, min(100, int(pick("music_volume", 18) or 0))),
           "duck": bool(o.get("duck", True)),
           "dead_air": pick("dead_air", "off") if (pick("dead_air", "off") in DEAD_AIR or pick("dead_air", "off") == "auto") else "off",
           "sfx": pick("sfx", "off") if pick("sfx", "off") in SFX_LEVEL else "off",
           "hook_title": bool(pick("hook_title", False)),
           "progress_bar": bool(pick("progress_bar", False)),
           "jump_zoom": max(1.0, min(1.2, float(pick("jump_zoom", 1.0) or 1.0))),
           "slow_push": bool(pick("slow_push", False)),
           "music_mode": o.get("music_mode") if o.get("music_mode") in ("auto", "bed", "sting") else "auto",
           "caption_lang": o.get("caption_lang") if o.get("caption_lang") in ("auto", "original", "hindi", "hinglish", "english") else "auto",
           "accurate_captions": bool(o.get("accurate_captions", True)),
           "hook_style": o.get("hook_style") if o.get("hook_style") in ("auto", "box", "outline", "colour", "minimal") else "auto",
           "clip_length": str(o.get("clip_length")) if str(o.get("clip_length")) in ("30", "60", "90", "180") else "full"}
    if out["framing"] == "auto" and base.get("framing"):
        out["framing"] = base["framing"]
    # the style's look: framing, title graphics, ending (researched creator families)
    ending = o.get("ending") if o.get("ending") in ("auto", "fade", "quick") else "auto"
    outro = float(base.get("outro", 0.35))
    if ending == "fade":
        outro = max(outro, 0.8)
    elif ending == "quick":
        outro = 0.3
    cta = o.get("end_cta")
    if isinstance(cta, str) and cta.strip():
        cta = None if cta.strip().lower() in ("none", "off", "-") else cta.strip()[:40]
    else:
        cta = base.get("cta")
    out["look"] = {"frame": base.get("frame", "fill"), "title_kind": base.get("title_kind", "none"),
                   "keyword_pop": bool(base.get("keyword_pop")), "grain": bool(base.get("grain")),
                   "intro": float(base.get("intro", 0.0)), "outro": outro, "cta": cta,
                   "flash": bool(base.get("flash")), "end_hold": float(base.get("end_hold", 0.45))}
    out["ending"] = ending
    # layout: any style with any frame. "auto" keeps the style's frame but lets the renderer
    # switch to stream / blurred-fit when the video turns out to be gameplay or sport.
    lay = o.get("layout") if o.get("layout") in LAYOUTS else "auto"
    out["layout"] = lay
    if lay not in ("auto", "style"):
        out["look"]["frame"] = LAYOUTS[lay]["frame"]
        if LAYOUTS[lay].get("framing"):
            out["framing"] = LAYOUTS[lay]["framing"]
    try:
        sp = float(o.get("speed") or 1.0)
    except (TypeError, ValueError):
        sp = 1.0
    out["speed"] = sp if sp in (0.75, 1.0, 1.1, 1.25, 1.5) else 1.0
    out["text_overlays"] = _clean_overlays(o.get("text_overlays"))
    # music section (waveform selector / auto hook) + sync, audio and delivery options
    mh = o.get("music_hook")
    out["music_hook"] = mh if mh in ("auto", "intro", "chorus", "drop", "custom", "start") else "start"
    def _f(v):
        try:
            return None if v in (None, "") else max(0.0, float(v))
        except (TypeError, ValueError):
            return None
    out["music_start"] = _f(o.get("music_start"))
    out["music_end"] = _f(o.get("music_end"))
    out["music_delay"] = min(_f(o.get("music_delay")) or 0.0, 120.0)     # music starts this many s into the clip
    try:
        out["orig_volume"] = max(0, min(200, int(float(o.get("orig_volume", 100)))))   # clip's own sound, 0 = muted
    except (TypeError, ValueError):
        out["orig_volume"] = 100
    out["duck_level"] = o.get("duck_level") if o.get("duck_level") in ("light", "strong") else "light"
    if out["music_start"] is not None and out["music_end"] is not None and out["music_end"] <= out["music_start"] + 1:
        out["music_end"] = None
    out["beat_sync"] = bool(o.get("beat_sync", False))
    out["voice_enhance"] = bool(o.get("voice_enhance", base.get("voice_enhance", False)))
    out["codec"] = o.get("codec") if o.get("codec") in ("h264", "h265", "vp9", "av1") else "h264"
    try:
        br = int(o.get("bitrate_kbps") or 0)
    except (TypeError, ValueError):
        br = 0
    out["bitrate_kbps"] = max(500, min(80000, br)) if br else None
    try:
        fr = float(o.get("fps") or 0)
    except (TypeError, ValueError):
        fr = 0
    out["fps"] = fr if fr in (24.0, 25.0, 30.0, 50.0, 60.0) else None
    out["bilingual"] = bool(o.get("bilingual", False))
    cuts = []
    for r in (o.get("cut_ranges") or [])[:40] if isinstance(o.get("cut_ranges"), list) else []:
        try:
            x, y = float(r[0]), float(r[1])
        except (TypeError, ValueError, IndexError):
            continue
        if 0 <= x < y:
            cuts.append([round(x, 2), round(y, 2)])
    out["cut_ranges"] = cuts
    from .pipeline.fx import clean, clean_watermark
    out["fx"] = clean(o.get("fx"))
    out["watermark"] = clean_watermark(o.get("watermark"))
    out["hide_text"] = bool(o.get("hide_text", True))
    out["remove_fillers"] = bool(o.get("remove_fillers", True))
    pz = o.get("punch_zoom")
    out["punch_zoom"] = bool(base.get("punch")) if pz is None else bool(pz)
    try:
        out["crop_x"] = None if o.get("crop_x") in (None, "") else max(0.0, min(1.0, float(o["crop_x"])))
    except (TypeError, ValueError):
        out["crop_x"] = None
    if out["crop_x"] is not None and out["framing"] == "auto":
        out["framing"] = "manual"
    if out["framing"] == "wide":
        out["look"]["frame"] = "native"
    for k in ("hook_bg", "hook_color"):
        v = o.get(k)
        if isinstance(v, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", v):
            out[k] = v
    if o.get("hook_font") in FONTS:
        out["hook_font"] = o["hook_font"]
    if isinstance(o.get("hook_text"), str) and o["hook_text"].strip():
        out["hook_text"] = o["hook_text"].strip()[:80]
    d = dict(o.get("caption_design") or {})
    for k in ("font", "animation", "highlight"):
        if k not in d and base.get(k):
            d[k] = base[k]
    for k, v in (base.get("caption") or {}).items():
        d.setdefault(k, v)
    from .pipeline.captions import user_fonts
    ufonts = user_fonts()
    out["caption_design"] = {
        k: v for k, v in d.items()
        if (k == "font" and (v in FONTS or v in ufonts)) or (k == "animation" and v in ANIMATIONS)
        or (k == "position" and v in POSITIONS)
        or (k in ("color", "highlight") and isinstance(v, str) and len(v) <= 7)
        or (k in ("size", "outline", "words_per_line") and str(v).lstrip("-").isdigit())
        or (k in ("upper", "box", "cycle", "italic", "lower") and isinstance(v, bool))
        or (k in ("shadow", "glow", "spacing") and str(v).isdigit())
        or (k in ("outline_color", "shadow_color", "box_color") and isinstance(v, str)
            and re.fullmatch(r"#[0-9a-fA-F]{6}", v))
        or (k == "preset" and (v == "auto" or v in CAPTION_LIBRARY))}
    return out


@app.get("/api/exports/{export_id}")
def get_export(export_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    e = db.get(Export, export_id)
    if e is None:
        raise HTTPException(404, "Export not found")
    return {"id": e.id, "status": e.status, "params": e.params, "error": e.error,
            "verification": e.verification}


@app.get("/api/exports/{export_id}/download")
def download_export(export_id: str, user: User = Depends(current_user),
                    db: DBSession = Depends(get_db)):
    e = db.get(Export, export_id)
    if e is None or not e.path or not Path(e.path).exists():
        raise HTTPException(404, "Export not ready")
    try:                                              # v0.14 tracking: first / last download time
        from .tracking import now_iso
        ver = dict(e.verification or {})
        t = now_iso()
        ver.setdefault("downloaded_at", t)
        ver["last_downloaded_at"] = t
        ver["downloads"] = int(ver.get("downloads") or 0) + 1
        e.verification = ver
        db.commit()
    except Exception:
        db.rollback()
    return FileResponse(e.path, media_type="video/mp4", filename=export_filename(e))


@app.get("/api/exports/{export_id}/base")
def export_base(export_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """The render without the editor's text layers (the editor draws those live on top)."""
    e = db.get(Export, export_id)
    if e is None or not e.path or not Path(e.path).exists():
        raise HTTPException(404, "Export not ready")
    b = Path(e.path).with_name(Path(e.path).stem + ".base.mp4")
    return FileResponse(b if b.exists() else e.path, media_type="video/mp4")


@app.get("/api/videos/{video_id}/frame")
def video_frame(video_id: str, t: float = 0.0, h: int = 90, user: User = Depends(current_user),
                db: DBSession = Depends(get_db)):
    """One small JPEG frame of the source video (editor timeline filmstrip)."""
    from .config import WORK_DIR
    v = db.get(Video, video_id)
    if v is None or not Path(v.path).exists():
        raise HTTPException(404, "Video not found")
    h = max(40, min(360, int(h)))
    t = max(0.0, float(t))
    d = WORK_DIR / "frames" / video_id
    d.mkdir(parents=True, exist_ok=True)
    f = d / f"{t:.1f}_{h}.jpg"
    if not f.exists():
        tmp = f.with_name(f"{f.stem}.{uuid.uuid4().hex[:6]}.jpg")
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", v.path, "-frames:v", "1",
                        "-vf", f"scale=-2:{h}", "-q:v", "5", str(tmp)], capture_output=True)
        if not tmp.exists():
            raise HTTPException(404, "No frame at that time")
        try:
            tmp.replace(f)
        except OSError:                      # another request wrote it first (Windows)
            tmp.unlink(missing_ok=True)
    return FileResponse(f, media_type="image/jpeg", headers={"Cache-Control": "max-age=86400"})


def _slug(s: str, n: int) -> str:
    s = re.sub(r"[^\w\- ]+", "", s or "", flags=re.UNICODE).strip()
    return re.sub(r"\s+", "-", s)[:n].strip("-") or "clip"


def export_filename(e: Export) -> str:
    """e.g. 2026-11-17_1432_Psychology-Of-Billionaires_Smart-People-Who-Quit_9x16.mp4"""
    c = e.clip
    v = c.video
    vt = (v.meta or {}).get("source_title") or Path(v.filename).stem
    when = e.created_at
    try:
        when = datetime.datetime.fromtimestamp(Path(e.path).stat().st_mtime)
    except (OSError, TypeError):
        pass
    return f"{when:%Y-%m-%d_%H%M}_{_slug(vt, 40)}_{_slug(c.title, 40)}_{(e.params or {}).get('aspect', '9:16').replace(':', 'x')}.mp4"


def _export_info(e: Export) -> dict:
    c = e.clip
    v = c.video
    out = (e.verification or {}).get("output") or {}
    thumb = Path(e.path).with_suffix(".jpg") if e.path else None
    size = None
    try:
        size = Path(e.path).stat().st_size if e.path else None
    except OSError:
        pass
    return {"id": e.id, "status": e.status, "clip_id": c.id, "clip_title": c.title, "video_id": v.id,
            "video_title": (v.meta or {}).get("source_title") or Path(v.filename).stem,
            "source_range": [round(c.start, 1), round(c.end, 1)], "created_at": e.created_at.isoformat(),
            "rendered_at": (e.verification or {}).get("rendered_at"), "duration": out.get("duration"),
            "aspect": (e.params or {}).get("aspect"), "resolution": (e.params or {}).get("resolution"),
            "preset": (e.params or {}).get("preset"), "size": size, "encoder": out.get("encoder"),
            "has_thumb": bool(thumb and thumb.exists()), "filename": export_filename(e) if e.path else None,
            "error": e.error, **_track_export(e)}


def _track_export(e: Export) -> dict:
    """v0.14: source kind / project / clip times for the Exports page (never fails the list)."""
    try:
        from .tracking import clip_times, export_times, source_info
        v = e.clip.video
        return {"source": source_info(v, v.project.name if v.project else None),
                "clip_times": clip_times(e.clip), "times": export_times(e)}
    except Exception:
        return {}


@app.get("/api/exports")
def list_exports(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    """Every render with what it is, where it came from and when it was made."""
    rows = db.query(Export).order_by(Export.created_at.desc()).limit(500).all()
    return [_export_info(e) for e in rows if e.clip and e.clip.video]


@app.get("/api/exports/{export_id}/thumb")
def export_thumb(export_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    e = db.get(Export, export_id)
    p = Path(e.path).with_suffix(".jpg") if e and e.path else None
    if not p or not p.exists():
        raise HTTPException(404, "No thumbnail")
    return FileResponse(p, media_type="image/jpeg")


@app.get("/api/exports/{export_id}/srt")
def download_srt(export_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    e = db.get(Export, export_id)
    if e is None:
        raise HTTPException(404, "Export not found")
    from .config import WORK_DIR
    srt = WORK_DIR / e.clip_id / "caps.srt"
    if not srt.exists():
        raise HTTPException(404, "No SRT for this export")
    return FileResponse(srt, media_type="text/plain", filename=f"{e.clip_id}.srt")


# ---------------------------------------------------------------- jobs ----
@app.get("/api/jobs/{job_id}")
def job_status(job_id: str, user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    j = db.get(Job, job_id)
    if j is None:
        raise HTTPException(404, "Job not found")
    return {"id": j.id, "kind": j.kind, "status": j.status, "progress": j.progress,
            "stage": j.stage, "error": j.error}


@app.post("/api/jobs/{job_id}/cancel")
def job_cancel(job_id: str, user: User = Depends(require_role("editor"))):
    return {"cancelled": cancel(job_id)}


# --------------------------------------------------------------- admin ----
@app.get("/api/admin/system")
def system_status(user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    du = shutil.disk_usage(EXPORTS_DIR)
    ffmpeg_v = subprocess.run(["ffmpeg", "-version"], capture_output=True, text=True).stdout.splitlines()[0]
    jobs = db.query(Job).order_by(Job.created_at.desc()).limit(20).all()
    return {
        "disk": {"total_gb": round(du.total / 1e9, 1), "free_gb": round(du.free / 1e9, 1)},
        "ffmpeg": ffmpeg_v,
        "queue": [{"id": j.id, "kind": j.kind, "status": j.status, "stage": j.stage,
                   "progress": j.progress} for j in jobs],
    }


@app.get("/api/admin/users")
def list_users(user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    return [{"id": u.id, "email": u.email, "role": u.role, "active": u.is_active}
            for u in db.query(User).all()]


@app.post("/api/admin/users/invite")
def invite_user(email: str = Form(...), role: str = Form("editor"),
                user: User = Depends(require_role("owner")), db: DBSession = Depends(get_db)):
    if role not in ("admin", "editor", "viewer"):
        raise HTTPException(400, "Role must be admin/editor/viewer")
    email = email.strip().lower()
    if db.query(User).filter_by(email=email).first():
        raise HTTPException(409, "User already exists")
    import secrets
    temp = secrets.token_urlsafe(9)
    from .auth import hash_password
    db.add(User(email=email, password_hash=hash_password(temp), role=role))
    db.commit()
    audit(db, user.id, "user.invite", f"{email} role={role}")
    # No SMTP available: return the temp password to the owner to hand over securely.
    return {"email": email, "role": role, "temp_password": temp}


@app.post("/api/admin/users/{user_id}/revoke")
def revoke_user(user_id: str, user: User = Depends(require_role("owner")),
                db: DBSession = Depends(get_db)):
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(404, "User not found")
    if target.role == "owner":
        raise HTTPException(403, "The primary owner cannot be removed.")
    target.is_active = False
    db.query  # keep sessions table clean:
    from .models import Session as Sess
    db.query(Sess).filter_by(user_id=user_id).delete()
    db.commit()
    audit(db, user.id, "user.revoke", target.email)
    return {"ok": True}


@app.get("/api/admin/audit")
def audit_logs(user: User = Depends(require_role("admin")), db: DBSession = Depends(get_db)):
    rows = db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(100).all()
    return [{"user": r.user_id, "action": r.action, "detail": r.detail,
             "at": r.created_at.isoformat()} for r in rows]


# ------------------------------------------------------------ metadata ----
@app.get("/api/options")
def options():
    return {
        "aspect_ratios": list(ASPECT_RATIOS.keys()),
        "caption_styles": list(CAPTION_STYLES.keys()),
        "resolutions": ["720p", "1080p", "1440p", "2160p"],
        "templates": list(BUILTIN_TEMPLATES),
        "profiles": list(PERFORMANCE_PROFILES.keys()),
    }


# ------------------------------------------------------------ frontend ----
STATIC = BASE_DIR / "backend" / "static"
app.mount("/assets", StaticFiles(directory=STATIC), name="assets")


@app.get("/")
def index() -> Response:
    return FileResponse(STATIC / "index.html")


_FODO_SITES = {"https://www.fodo.co.in", "https://fodo.co.in"}


def _site_cors(request: Request, resp: Response) -> Response:
    """Only fodo.co.in may see that this app is running (used by fodo.co.in/studio/ to find the app). Nothing else is exposed."""
    origin = request.headers.get("origin", "")
    if origin in _FODO_SITES:
        resp.headers["Access-Control-Allow-Origin"] = origin
        resp.headers["Access-Control-Allow-Private-Network"] = "true"
        resp.headers["Vary"] = "Origin"
    return resp


@app.get("/health")
def health(request: Request):
    body = {"ok": True, "app": "FODO Studio", "version": app.version}
    if request.headers.get("origin", "") in _FODO_SITES:      # only fodo.co.in sees the power mode
        try:
            from . import power as _p
            body.update({"power": _p.effective_mode(), "tier": _p.tier_of(_p.hardware())[0]})
        except Exception:  # noqa: BLE001
            pass
    return _site_cors(request, JSONResponse(body))


@app.options("/health")
def health_preflight(request: Request):
    r = _site_cors(request, Response(status_code=204))
    r.headers["Access-Control-Allow-Methods"] = "GET"
    return r
