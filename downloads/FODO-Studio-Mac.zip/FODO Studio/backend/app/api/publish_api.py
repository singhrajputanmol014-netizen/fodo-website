"""Publish desk API: /api/publish/* (see app/publish.py)."""
from __future__ import annotations

import datetime as dt
import html
import shutil
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from sqlalchemy.orm import Session as DBSession

from .. import publish as P
from ..auth import current_user, require_role
from ..config import ALLOWED_VIDEO_EXT
from ..database import get_db
from ..models import Export, User

router = APIRouter(prefix="/api/publish")


def _bad(e: Exception):
    raise HTTPException(400, str(e)) from e


def _ready(db: DBSession) -> list[dict]:
    """Finished renders that can be posted, newest first, with where each one already went."""
    posted = P.posted_map()
    rows = db.query(Export).filter(Export.status == "done").order_by(Export.created_at.desc()).limit(300).all()
    out = []
    for e in rows:
        if not e.path or not Path(e.path).exists() or not e.clip:
            continue
        o = (e.verification or {}).get("output") or {}
        v = e.clip.video
        out.append({"id": e.id, "name": e.clip.title or "Clip", "clip_id": e.clip_id,
                    "video": ((v.meta or {}).get("source_title") or Path(v.filename).stem) if v else "",
                    "duration": o.get("duration"), "width": o.get("width"), "height": o.get("height"),
                    "aspect": (e.params or {}).get("aspect"), "created_at": e.created_at.isoformat(),
                    "has_thumb": Path(e.path).with_suffix(".jpg").exists(), "posted": posted.get(e.id, {})})
    return out


@router.get("/state")
def state(user: User = Depends(current_user), db: DBSession = Depends(get_db)):
    d = P.load()
    return {"platforms": {k: {**v, "spec": P.SPECS[k]} for k, v in P.PLATFORMS.items()},
            "accounts": P.accounts_status(), "campaigns": d["campaigns"],
            "posts": list(reversed(d["posts"][-400:])), "uploads": list(reversed(d["uploads"])),
            "overview": P.overview(), "ready": _ready(db), "settings": P.settings(),
            "can_admin": user.role in ("admin", "owner"), "workspaces": P.workspaces_summary()}


@router.get("/posted")
def posted(user: User = Depends(current_user)):
    return P.posted_map()


@router.get("/marks")
def marks(user: User = Depends(current_user)):
    """Where each export / clip has been posted (for the badges on every page)."""
    return {"exports": P.posted_map(), "clips": P.posted_by_clip()}


@router.post("/preflight")
def preflight(payload: dict, user: User = Depends(current_user)):
    return P.preflight(payload)


@router.post("/posts")
def create_post(payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return P.create_post(payload, user.email)
    except ValueError as e:
        _bad(e)


@router.post("/posts/bulk")
def bulk(payload: dict, user: User = Depends(require_role("editor"))):
    """Schedule many clips with the same platforms/campaign, `gap_min` apart from `start_at`."""
    sources = payload.get("sources") or []
    if not sources:
        raise HTTPException(400, "Select some clips first")
    start = P._parse(payload.get("start_at"))
    gap = max(1, int(payload.get("gap_min") or 45))
    made, failed = [], []
    for i, src in enumerate(sources[:100]):
        body = {**payload, "source": src}
        if start:
            body["scheduled_at"] = (start + dt.timedelta(minutes=gap * i)).isoformat()
        elif i:
            body["scheduled_at"] = (P._now() + dt.timedelta(minutes=gap * i)).isoformat()
        info = P.source_info(src) or {}
        tmpl = payload.get("caption") or ""
        body["caption"] = tmpl.replace("{title}", info.get("name") or "")
        body["title"] = (payload.get("title") or "{title}").replace("{title}", info.get("name") or "")[:100]
        try:
            made.append(P.create_post(body, user.email)["id"])
        except ValueError as e:
            failed.append({"source": src, "name": info.get("name"), "error": str(e)})
    return {"created": made, "failed": failed}


@router.patch("/posts/{pid}")
def patch_post(pid: str, payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return P.update_post(pid, payload)
    except KeyError:
        raise HTTPException(404, "Post not found")
    except ValueError as e:
        _bad(e)


@router.post("/posts/{pid}/cancel")
def cancel(pid: str, user: User = Depends(require_role("editor"))):
    try:
        return P.cancel_post(pid)
    except ValueError as e:
        _bad(e)


@router.post("/posts/{pid}/retry")
def retry(pid: str, payload: dict | None = None, user: User = Depends(require_role("editor"))):
    try:
        return P.retry_post(pid, (payload or {}).get("platforms"))
    except KeyError:
        raise HTTPException(404, "Post not found")
    except ValueError as e:
        _bad(e)


@router.post("/posts/{pid}/now")
def post_now(pid: str, user: User = Depends(require_role("editor"))):
    """Send a scheduled or missed post right away."""
    with P._lock:
        d = P.load()
        p = next((x for x in d["posts"] if x["id"] == pid), None)
        if not p or p["status"] not in ("scheduled", "missed"):
            raise HTTPException(400, "Only scheduled or missed posts can be sent now")
        p["status"] = "queued"
        P.save(d)
    P.enqueue(pid)
    return {"ok": True}


@router.delete("/posts/{pid}")
def delete_post(pid: str, user: User = Depends(require_role("editor"))):
    try:
        P.delete_post(pid)
    except ValueError as e:
        _bad(e)
    return {"ok": True}


@router.get("/posts/{pid}/file")
def post_file(pid: str, user: User = Depends(current_user)):
    p = next((x for x in P.load()["posts"] if x["id"] == pid), None)
    info = P.source_info(p["source"]) if p else None
    if not info:
        raise HTTPException(404, "File not found")
    return FileResponse(info["path"], media_type="video/mp4", filename=Path(info["path"]).name)


@router.post("/views/sync")
def views_sync(user: User = Depends(require_role("editor"))):
    out = P.sync_views()
    try:
        out["youtube_status"] = P.check_youtube_status()
    except Exception as e:  # noqa: BLE001
        out.setdefault("errors", []).append(f"YouTube status: {e}")
    return out


@router.get("/music/{kind}/{sid}")
def music(kind: str, sid: str, user: User = Depends(current_user)):
    info = P.source_info({"type": kind, "id": sid})
    if not info:
        raise HTTPException(404, "File not found")
    return P.music_risk(info["path"]) or {"level": "unknown"}


# ---- campaigns
@router.post("/campaigns")
def save_campaign(payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return P.save_campaign(payload)
    except ValueError as e:
        _bad(e)


@router.delete("/campaigns/{cid}")
def delete_campaign(cid: str, user: User = Depends(require_role("admin"))):
    P.delete_campaign(cid)
    return {"ok": True}


# ---- outside clips (made somewhere else)
@router.post("/uploads")
async def upload(file: UploadFile = File(...), campaign_id: str = Form(""), workspace: str = Form(""),
                 user: User = Depends(require_role("editor"))):
    ext = Path(file.filename or "").suffix.lower()
    if ext not in ALLOWED_VIDEO_EXT:
        raise HTTPException(400, "Video files only (mp4, mov, webm…)")
    P.UPLOADS.mkdir(parents=True, exist_ok=True)
    tmp = P.UPLOADS / f".part-{uuid.uuid4().hex}{ext}"
    with tmp.open("wb") as f:
        shutil.copyfileobj(file.file, f, 1024 * 1024)
    if workspace and workspace != P.MAIN and not P.workspace(workspace):
        tmp.unlink(missing_ok=True)
        raise HTTPException(400, "Client project not found")
    return P.add_upload(file.filename or "clip.mp4", tmp, campaign_id or None, workspace or None)


@router.get("/uploads/{uid}/file")
def upload_file(uid: str, user: User = Depends(current_user)):
    u = next((x for x in P.load()["uploads"] if x["id"] == uid), None)
    if not u or not Path(u["path"]).exists():
        raise HTTPException(404, "File not found")
    return FileResponse(u["path"], media_type="video/mp4")


@router.delete("/uploads/{uid}")
def delete_upload(uid: str, user: User = Depends(require_role("editor"))):
    try:
        P.delete_upload(uid)
    except ValueError as e:
        _bad(e)
    return {"ok": True}


# ---- accounts & settings (admin)
@router.get("/settings")
def get_settings(user: User = Depends(require_role("admin"))):
    return P.masked_secrets()


@router.put("/settings")
def put_settings(payload: dict, user: User = Depends(require_role("admin"))):
    try:
        return P.update_secrets(payload)
    except ValueError as e:
        _bad(e)


@router.get("/connect/{kind}")
def connect(kind: str, ws: str = "", replies: int = 0, user: User = Depends(require_role("admin"))):
    try:
        return {"url": P.auth_url(kind, ws or None, bool(replies)), "redirect_uri": P.redirect_uri(kind)}
    except ValueError as e:
        _bad(e)


@router.post("/disconnect/{kind}")
def disconnect(kind: str, ws: str = "", user: User = Depends(require_role("admin"))):
    if kind not in ("meta", "google", "tiktok"):
        raise HTTPException(400, "unknown")
    if ws and ws != P.MAIN and not P.workspace(ws):
        raise HTTPException(404, "Client project not found")
    P.disconnect(kind, ws or None)
    return {"ok": True}


@router.post("/meta/page")
def meta_page(payload: dict, user: User = Depends(require_role("admin"))):
    ws = str(payload.get("workspace") or "") or None
    try:
        P.choose_page(str(payload.get("page_id") or ""), ws)
    except ValueError as e:
        _bad(e)
    return P.accounts_status(ws)


# ---- client projects (one set of accounts per client)
@router.get("/workspaces")
def ws_list(user: User = Depends(current_user)):
    return P.workspaces_summary()


@router.post("/workspaces")
def ws_save(payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return P.save_workspace(payload)
    except ValueError as e:
        _bad(e)


@router.delete("/workspaces/{wid}")
def ws_delete(wid: str, user: User = Depends(require_role("admin"))):
    try:
        P.delete_workspace(wid)
    except ValueError as e:
        _bad(e)
    return {"ok": True}


@router.get("/workspaces/{wid}")
def ws_dashboard(wid: str, refresh: bool = False, user: User = Depends(current_user)):
    try:
        return P.workspace_dashboard(wid, refresh)
    except ValueError as e:
        raise HTTPException(404, str(e)) from e


@router.post("/workspaces/{wid}/manual")
def ws_manual(wid: str, payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return P.save_manual_account(wid, payload)
    except (ValueError, TypeError) as e:
        _bad(e)


@router.delete("/workspaces/{wid}/manual/{mid}")
def ws_manual_delete(wid: str, mid: str, user: User = Depends(require_role("editor"))):
    try:
        P.delete_manual_account(wid, mid)
    except ValueError as e:
        _bad(e)
    return {"ok": True}


def _page(ok: bool, msg: str) -> HTMLResponse:
    col = "#059669" if ok else "#dc2626"
    body = f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>ClipForge</title></head>
<body style="font:15px system-ui;background:#f6f7fb;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
<div style="background:#fff;border-radius:18px;padding:28px 34px;box-shadow:0 10px 30px rgba(0,0,0,.08);max-width:460px">
<div style="font-size:30px">{'✅' if ok else '⚠️'}</div><h2 style="color:{col};margin:8px 0">{'Connected' if ok else 'Not connected'}</h2>
<p>{html.escape(msg)}</p><p style="color:#666;font-size:13px">You can close this tab. The ClipForge Publish page updates by itself.</p>
<a href="http://127.0.0.1:8777/#publish">ClipForge kholo</a></div>
<script>try{{window.opener&&window.opener.postMessage({{cfPublish:'connected'}},'*')}}catch(e){{}}</script></body></html>"""
    return HTMLResponse(body, status_code=200 if ok else 400)


@router.get("/oauth/{kind}")
def oauth_callback(kind: str, code: str = "", state: str = "", error: str = "", error_description: str = "",
                   error_message: str = ""):
    """Provider redirect. No session cookie needed (the browser may be on localhost vs 127.0.0.1):
    the one-time `state` we issued is what proves this login was started from ClipForge."""
    if kind not in ("meta", "google", "tiktok"):
        return _page(False, "Unknown provider")
    if error or not code:
        return _page(False, error_description or error_message or error or "Login was cancelled")
    try:
        return _page(True, P.finish_oauth(kind, code, state))
    except Exception as e:  # noqa: BLE001
        return _page(False, str(e)[:300])


@router.get("/preview/{kind}/{sid}")
def preview(kind: str, sid: str, user: User = Depends(current_user)):
    """The exact file that will be posted (does not count as a download)."""
    info = P.source_info({"type": kind, "id": sid})
    if not info:
        raise HTTPException(404, "File not found")
    return FileResponse(info["path"], media_type="video/mp4")
