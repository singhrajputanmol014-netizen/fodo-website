"""YouTube music search with an Instagram-style hook.

- Search any song on YouTube (metadata only). Results are labelled:
    "cc"   - the uploader published it under Creative Commons (reuse allowed)  -> MP3 allowed
    "ncs"  - official NoCopyrightSounds channel (free with credit)            -> MP3 allowed
    "copyrighted" - everything else                                            -> preview + hook time only
- The hook comes from YouTube's public "Most replayed" graph (heatmap), so it also works for songs
  we never download: the user hears it in the YouTube player and adds the song inside Instagram /
  TikTok's own music picker at that second (those apps hold the licence).
- MP3 download is only offered for cc / ncs tracks, verified again on the full video page.
"""
from __future__ import annotations

import json
import re
import time
import urllib.parse
from pathlib import Path

from .music_online import MAX_MUSIC_BYTES, MAX_MUSIC_SECONDS, _safe_name
from .music_providers import is_ncs
from .url_import import UnsafeURL

CC_FILTER = "EgIwAQ%3D%3D"            # YouTube search filter: "Creative Commons"
_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")
_cache: dict[str, tuple[float, dict]] = {}


def _ydl(extra: dict | None = None):
    import yt_dlp
    opts = {"quiet": True, "no_warnings": True, "skip_download": True, "noplaylist": True,
            "js_runtimes": {"deno": {}, "node": {}}, "retries": 2, "socket_timeout": 25}
    opts.update(extra or {})
    return yt_dlp.YoutubeDL(opts)


def _thumb(vid: str) -> str:
    return f"https://i.ytimg.com/vi/{vid}/mqdefault.jpg"


def search(q: str, free_only: bool = True, limit: int = 12) -> dict:
    q = (q or "").strip()[:120]
    if not q:
        return {"query": q, "free_only": free_only, "results": []}
    url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote_plus(q)
    if free_only:
        url += "&sp=" + CC_FILTER
    try:
        with _ydl({"extract_flat": True, "playlistend": limit * 2}) as y:
            info = y.extract_info(url, download=False)
    except Exception as e:  # noqa: BLE001
        raise UnsafeURL(f"YouTube search failed: {str(e).replace('ERROR: ', '')[:200]}") from e
    out = []
    for e in (info or {}).get("entries") or []:
        vid = e.get("id") or ""
        if not _ID.match(vid) or e.get("live_status") in ("is_live", "is_upcoming"):
            continue
        dur = e.get("duration") or 0
        if dur and dur > MAX_MUSIC_SECONDS:
            continue
        ch = e.get("channel") or e.get("uploader") or ""
        ncs = is_ncs(ch, e.get("channel_id"))
        out.append({"id": vid, "title": e.get("title") or "Untitled", "channel": ch, "duration": dur or None,
                    "views": e.get("view_count"), "thumb": _thumb(vid),
                    # the CC search filter is YouTube's own; it is re-checked on the video page before any download
                    "status": "ncs" if ncs else ("cc" if free_only else "unknown")})
        if len(out) >= limit:
            break
    return {"query": q, "free_only": free_only, "results": out}


def hook_from_heatmap(heatmap: list[dict] | None, duration: float | None, length: float = 15.0) -> dict | None:
    """Best `length`-second window of YouTube's Most-replayed graph (skipping the very start)."""
    if not heatmap or not duration or duration < length + 2:
        return None
    pts = [(float(h["start_time"]), float(h["end_time"]), float(h.get("value") or 0)) for h in heatmap
           if h.get("start_time") is not None and h.get("end_time") is not None]
    if not pts:
        return None

    def score(s: float) -> float:
        e, tot = s + length, 0.0
        for a, b, v in pts:
            ov = min(b, e) - max(a, s)
            if ov > 0:
                tot += ov * v
        return tot / length

    skip = min(8.0, duration * 0.04)          # people often replay the very first second - ignore it
    best, best_s = -1.0, skip
    s = skip
    while s + length <= duration:
        sc = score(s)
        if sc > best:
            best, best_s = sc, s
        s += 0.5
    return {"start": round(best_s, 1), "end": round(best_s + length, 1), "score": round(best, 3), "source": "most_replayed"}


def details(vid: str) -> dict:
    if not _ID.match(vid or ""):
        raise UnsafeURL("Bad YouTube id")
    hit = _cache.get(vid)
    if hit and time.time() - hit[0] < 3600:
        return hit[1]
    try:
        with _ydl() as y:
            info = y.extract_info(f"https://www.youtube.com/watch?v={vid}", download=False)
    except Exception as e:  # noqa: BLE001
        raise UnsafeURL(f"YouTube: {str(e).replace('ERROR: ', '')[:200]}") from e
    lic = info.get("license") or ""
    ch = info.get("channel") or info.get("uploader") or ""
    ncs = is_ncs(ch, info.get("channel_id"))
    cc = "creative commons" in lic.lower()
    dur = info.get("duration") or 0
    heat = [{"start_time": h.get("start_time"), "end_time": h.get("end_time"), "value": h.get("value")}
            for h in (info.get("heatmap") or [])]
    d = {"id": vid, "title": info.get("title"), "channel": ch, "channel_id": info.get("channel_id"),
         "duration": dur, "thumb": _thumb(vid), "views": info.get("view_count"),
         "page": info.get("webpage_url") or f"https://www.youtube.com/watch?v={vid}",
         "license": lic or "Standard YouTube licence",
         "status": "ncs" if ncs else ("cc" if cc else "copyrighted"),
         "downloadable": bool((ncs or cc) and dur and dur <= MAX_MUSIC_SECONDS and not info.get("is_live")),
         "heatmap": heat, "hook": hook_from_heatmap(heat, dur),
         "chapters": [{"title": c.get("title"), "start": c.get("start_time")} for c in (info.get("chapters") or [])][:20]}
    if not d["downloadable"]:
        d["why_not"] = ("Live streams can't be used." if info.get("is_live") else
                        "Longer than 15 minutes." if dur and dur > MAX_MUSIC_SECONDS else
                        "Copyrighted - preview and hook time only. Add this song inside Instagram / TikTok's "
                        "music picker at the hook time; those apps hold the licence.")
    _cache[vid] = (time.time(), d)
    return d


def download_mp3(vid: str, dest_dir: Path) -> dict:
    """MP3 of a Creative-Commons or official-NCS YouTube track (re-verified first)."""
    d = details(vid)
    if not d["downloadable"]:
        raise UnsafeURL(d.get("why_not") or "This track can't be downloaded.")
    dest_dir.mkdir(parents=True, exist_ok=True)
    stem = f"{_safe_name(d['title'])}_yt{vid[:6]}"
    opts = {"skip_download": False, "format": "bestaudio/best", "outtmpl": str(dest_dir / f"{stem}.%(ext)s"),
            "max_filesize": MAX_MUSIC_BYTES,
            "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}]}
    try:
        with _ydl(opts) as y:
            y.extract_info(d["page"], download=True)
    except Exception as e:  # noqa: BLE001
        raise UnsafeURL(f"YouTube download failed: {str(e).replace('ERROR: ', '')[:200]}") from e
    path = dest_dir / f"{stem}.mp3"
    if not path.exists():
        raise UnsafeURL("No MP3 was produced (is ffmpeg installed?)")
    if d["status"] == "ncs":
        lic, url = "NCS creator licence", "https://ncs.io/usage-policy"
        attr = f"Music: {d['title']} [NCS Release] - provided by NoCopyrightSounds. Watch: {d['page']}"
    else:
        lic, url = "CC BY (YouTube)", "https://creativecommons.org/licenses/by/3.0/"
        attr = f"Music: \"{d['title']}\" by {d['channel']} (CC BY) - {d['page']}"
    meta = {"title": d["title"], "creator": d["channel"], "channel_id": d["channel_id"], "page": d["page"],
            "license": lic, "license_url": url, "attribution": attr, "provider": "YouTube", "from": "youtube",
            "yt_hook": d.get("hook")}
    path.with_suffix(path.suffix + ".json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"id": f"user:{path.name}", "name": path.stem, **meta}
