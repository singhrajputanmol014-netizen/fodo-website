"""FODO CLIPFORGE AI backend."""
import os

# Windows Smart App Control / WDAC can block unsigned compiled extensions.
# SQLAlchemy 2.0 runs fully in pure Python with this flag — no functional change.
os.environ.setdefault("DISABLE_SQLALCHEMY_CEXT_RUNTIME", "1")
