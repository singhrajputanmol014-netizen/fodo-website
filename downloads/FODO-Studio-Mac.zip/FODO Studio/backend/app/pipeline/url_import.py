"""URL import.

Two routes:
1. Video platform pages (YouTube, Kick, Twitch VODs, Vimeo, X, Facebook, ...)
   -> yt-dlp. Public/unlisted videos only: no cookies, no login, no DRM bypass
   (DRM-protected services like Netflix are refused). The owner confirms they
   have the right to use the video.
2. Direct media file links -> SSRF-safe streaming download.

Both: http/https only; host resolved and private/loopback/link-local/reserved
IPs rejected (SSRF protection); size capped.
"""
from __future__ import annotations

import ipaddress
import logging
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

log = logging.getLogger("clipforge.url_import")

# DRM streaming services: never downloadable.
DRM_SERVICES = ("netflix.com", "primevideo.com", "amazon.com", "hotstar.com", "disneyplus.com",
                "jiocinema.com", "sonyliv.com", "zee5.com", "hulu.com", "max.com", "apple.com",
                "spotify.com")


class UnsafeURL(ValueError):
    pass


def _check_host(host: str) -> None:
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror as e:
        raise UnsafeURL(f"Cannot resolve host {host}") from e
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if (ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast
                or ip.is_reserved or ip.is_unspecified):
            raise UnsafeURL("URL points to a private/internal network address — blocked.")


def validate_url(url: str) -> urllib.parse.ParseResult:
    p = urllib.parse.urlparse(url.strip())
    if p.scheme not in ("http", "https"):
        raise UnsafeURL("Only http/https URLs are allowed.")
    if not p.hostname:
        raise UnsafeURL("URL has no host.")
    if p.username or p.password:
        raise UnsafeURL("Credentials in URLs are not allowed.")
    host = p.hostname.lower()
    if any(host == d or host.endswith("." + d) for d in DRM_SERVICES):
        raise UnsafeURL("This is a DRM-protected streaming service — it can't be imported.")
    _check_host(host)
    return p


def is_direct_media(url: str) -> bool:
    path = urllib.parse.urlparse(url).path.lower()
    return path.endswith((".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"))


def ytdlp_supported(url: str) -> bool:
    """True if a specific (non-generic) yt-dlp extractor handles this URL."""
    try:
        from yt_dlp.extractor import gen_extractor_classes
    except ImportError:
        return False
    for ie in gen_extractor_classes():
        if ie.IE_NAME != "generic" and ie.suitable(url):
            return True
    return False



class BotCheck(UnsafeURL):
    """YouTube's 'Sign in to confirm you're not a bot': this PC made many requests in a short time.
    It is not about the video - it lifts by itself after a while."""


BOT_MSG = ("YouTube asked this PC to prove it is not a bot (too many YouTube requests in a short time - "
           "live recording, scans and downloads all count). It is not a problem with this video. "
           "ClipForge tries other YouTube apps first, then tries again by itself in 10 minutes.")
# other YouTube player apps; each has its own checks, so one is often still allowed
FALLBACK_CLIENTS = (["mweb"], ["android_vr"], ["tv_simply"])


def is_bot_check(msg: str) -> bool:
    m = (msg or "").lower()
    return "not a bot" in m or "confirm you" in m and "bot" in m


def is_login_wall(msg: str) -> bool:
    m = (msg or "").lower()
    if is_bot_check(m):
        return False
    return ("sign in to confirm your age" in m or "private video" in m or "members-only" in m
            or "members only" in m or "join this channel" in m or "this video is private" in m)


def ydl_extract(opts: dict, url: str, download: bool = False):
    """yt-dlp extract_info that steps through other YouTube player apps when YouTube shows its bot check."""
    import yt_dlp
    last = None
    for clients in (None, *FALLBACK_CLIENTS):
        o = dict(opts)
        if clients:
            o["extractor_args"] = {**(o.get("extractor_args") or {}), "youtube": {"player_client": clients}}
        try:
            with yt_dlp.YoutubeDL(o) as ydl:
                return ydl.extract_info(url, download=download)
        except yt_dlp.utils.DownloadError as e:
            last = e
            if not is_bot_check(str(e)):
                raise
            log.warning("YouTube bot check%s - trying another YouTube app", f" ({clients[0]})" if clients else "")
    raise BotCheck(BOT_MSG) from last


def download_platform(url: str, dest_dir: Path, file_stem: str, max_bytes: int,
                      progress=None, max_height: int = 1080,
                      section: tuple[float, float] | None = None) -> tuple[Path, dict]:
    """Download one public video via yt-dlp. Returns (path, info subset)."""
    import yt_dlp

    validate_url(url)

    def hook(d):
        if progress and d.get("status") == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            if total:
                progress(min(d.get("downloaded_bytes", 0) / total, 1.0))

    def reject_live(info, *, incomplete):
        if info.get("is_live"):
            return "This is a live stream — wait until it ends and use the VOD/replay link."
        if info.get("duration") and info["duration"] > 4 * 3600 and not section:
            return "Video is longer than 4 hours."
        return None

    opts = {
        "outtmpl": str(dest_dir / f"{file_stem}.%(ext)s"),
        "format": (f"bv*[height<={max_height}][ext=mp4]+ba[ext=m4a]/"
                   f"bv*[height<={max_height}]+ba/b[height<={max_height}]/b"),
        "merge_output_format": "mp4",
        "noplaylist": True,
        "max_filesize": max_bytes,
        "match_filter": reject_live,
        "progress_hooks": [hook],
        "quiet": True,
        "no_warnings": True,
        "restrictfilenames": True,
        "js_runtimes": {"deno": {}, "node": {}},
        "retries": 10,
        "fragment_retries": 15,
        "extractor_retries": 3,
        "retry_sleep_functions": {"http": lambda n: min(2 ** n, 30), "fragment": lambda n: min(2 ** n, 30)},
        "continuedl": True,          # a retry resumes the .part file / keeps the finished video stream
        "socket_timeout": 30,
    }
    if section:
        # only this part of the video is fetched (smart scan); cuts are re-encoded at the edges
        opts["download_ranges"] = yt_dlp.utils.download_range_func(None, [(float(section[0]), float(section[1]))])
        opts["force_keyframes_at_cuts"] = True
    info = None
    for attempt in range(1, 5):
        # each attempt re-extracts -> fresh signed media URLs (YouTube returns 403 on stale/flagged ones);
        # already-finished streams and partial files are reused, so only the missing part is downloaded again
        if True:
            try:
                info = ydl_extract(opts, url, download=True)
                break
            except yt_dlp.utils.DownloadError as e:
                msg = str(e).replace("ERROR: ", "")
                if is_login_wall(msg):
                    msg = "This video needs a login (private/age-restricted/members-only) — download it yourself and upload the file."
                    raise UnsafeURL(msg[:400]) from e
                transient = any(k in msg for k in ("403", "Forbidden", "timed out", "Connection", "reset", "Read timed", "IncompleteRead", "503", "502"))
                if not transient or attempt == 4:
                    if transient:
                        msg = (f"{msg[:250]} — the site kept refusing the download after {attempt} tries. "
                               "Try again in a few minutes (Control Panel -> Update yt-dlp helps), or download the file yourself and upload it.")
                    raise UnsafeURL(msg[:400]) from e
                log.warning("download attempt %d failed (%s) - retrying with fresh links", attempt, msg[:120])
                time.sleep(5 * attempt)
    if info is None:
        raise UnsafeURL("Video was skipped (live stream or too long).")
    files = sorted(dest_dir.glob(f"{file_stem}.*"), key=lambda f: f.stat().st_size, reverse=True)
    files = [f for f in files if f.suffix.lower() in (".mp4", ".mkv", ".webm", ".mov")]
    if not files:
        raise UnsafeURL("Download finished but no video file was produced.")
    return files[0], {"title": info.get("title"), "uploader": info.get("uploader"),
                      "source_url": info.get("webpage_url") or url,
                      "extractor": info.get("extractor_key")}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def download(url: str, dest: Path, max_bytes: int) -> Path:
    opener = urllib.request.build_opener(_NoRedirect)
    current = url
    for _ in range(6):
        validate_url(current)
        req = urllib.request.Request(current, headers={"User-Agent": "FODO-ClipForge/0.2"})
        try:
            resp = opener.open(req, timeout=30)
        except urllib.error.HTTPError as e:
            if e.code in (301, 302, 303, 307, 308) and e.headers.get("Location"):
                current = urllib.parse.urljoin(current, e.headers["Location"])
                continue
            raise UnsafeURL(f"Server returned HTTP {e.code}") from e
        ctype = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if not (ctype.startswith("video/") or ctype == "application/octet-stream"):
            raise UnsafeURL(f"URL is not a direct video file (Content-Type: {ctype or 'unknown'}).")
        clen = resp.headers.get("Content-Length")
        if clen and int(clen) > max_bytes:
            raise UnsafeURL("File exceeds the upload size limit.")
        total = 0
        with dest.open("wb") as f:
            while chunk := resp.read(1024 * 1024):
                total += len(chunk)
                if total > max_bytes:
                    f.close()
                    dest.unlink(missing_ok=True)
                    raise UnsafeURL("File exceeds the upload size limit.")
                f.write(chunk)
        return dest
    raise UnsafeURL("Too many redirects.")
