"""FODO CLIPFORGE AI — central configuration."""
from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[2]
STORAGE_DIR = Path(os.environ.get("CLIPFORGE_STORAGE", BASE_DIR / "storage"))
UPLOADS_DIR = STORAGE_DIR / "uploads"
WORK_DIR = STORAGE_DIR / "work"
EXPORTS_DIR = STORAGE_DIR / "exports"
DB_PATH = STORAGE_DIR / "clipforge.db"

MUSIC_USER_DIR = STORAGE_DIR / "music"
for d in (UPLOADS_DIR, WORK_DIR, EXPORTS_DIR, MUSIC_USER_DIR):
    d.mkdir(parents=True, exist_ok=True)

# --- Edition --------------------------------------------------------------
# "fodo" = FODO's own copy. "personal" = a copy installed from fodo.co.in on someone's PC
# (edition.json written by the installer): the first account made on that PC becomes its owner.
def _edition() -> str:
    try:
        import json as _json
        return _json.loads((BASE_DIR / "edition.json").read_text(encoding="utf-8")).get("edition", "fodo")
    except (OSError, ValueError):
        return "fodo"


EDITION = _edition()
PERSONAL = EDITION == "personal"

# --- Auth ---------------------------------------------------------------
# Private by default. Only these emails may register/sign in initially (a personal copy: nobody
# until the PC's owner creates the first account).
APPROVED_EMAILS = {
    e.strip().lower()
    for e in os.environ.get(
        "CLIPFORGE_APPROVED_EMAILS",
        "" if PERSONAL else "anmol@fodo.co.in,singhrajputanmol04@gmail.com",
    ).split(",")
    if e.strip()
}
PUBLIC_REGISTRATION = False  # per security spec, disabled initially
SESSION_TTL_HOURS = 24 * 7
SECRET_FILE = STORAGE_DIR / ".secret_key"

# --- Processing ----------------------------------------------------------
WHISPER_MODEL = os.environ.get("CLIPFORGE_WHISPER_MODEL", "small")
# bigger model used only for "Accurate captions" on a clip (much better Hindi / Hinglish)
WHISPER_CAPTION_MODEL = os.environ.get("CLIPFORGE_WHISPER_CAPTION_MODEL", "large-v3-turbo")
WHISPER_DEVICE = os.environ.get("CLIPFORGE_WHISPER_DEVICE", "auto")  # auto = GPU if usable, else CPU
WHISPER_COMPUTE = os.environ.get("CLIPFORGE_WHISPER_COMPUTE", "int8")  # CPU compute type
MAX_UPLOAD_MB = int(os.environ.get("CLIPFORGE_MAX_UPLOAD_MB", "4096"))
ALLOWED_VIDEO_EXT = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
MIN_FREE_DISK_GB = 2

# Performance profiles: preset -> (x264 preset, crf)
PERFORMANCE_PROFILES = {
    "economy": ("veryfast", 28),
    "balanced": ("medium", 23),
    "quality": ("slow", 20),
    "max": ("slower", 18),
}
DEFAULT_PROFILE = "balanced"

ASPECT_RATIOS = {
    "9:16": (1080, 1920),
    "16:9": (1920, 1080),
    "1:1": (1080, 1080),
    "4:5": (1080, 1350),
    "21:9": (2560, 1080),
}

CLIP_DURATION_RANGES = {
    "5-15": (5, 15),
    "15-30": (15, 30),
    "30-60": (30, 60),
    "60-90": (60, 90),
}
