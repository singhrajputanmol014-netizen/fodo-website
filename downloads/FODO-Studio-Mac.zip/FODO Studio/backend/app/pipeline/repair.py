"""Automatic repair: turn Quality Inspector defects into concrete corrections.

Two kinds of fix:
  * post-fixes  - applied to the finished file without re-rendering the picture
                  (loudness/true-peak normalisation, a short audio fade on a hard end)
  * re-render   - changed export parameters for another render pass
                  (caption position/size, a trimmed dead opening)

The original source file is never touched; every pass writes a new file.
"""
from __future__ import annotations

import copy
import shutil
import subprocess
from pathlib import Path

from .quality import LUFS_TARGET

ORDER_UP = {"lower": "top", "low_subtitle": "top", "center_low": "lower", "middle": "lower",
            "seam": "lower", "under_box": "top", "top": "lower"}


def plan(report: dict, p: dict, base_caption: dict | None = None) -> dict:
    """-> {"post": [codes], "params": new params or None, "notes": [human text]}"""
    codes = {d["code"]: d for d in report.get("defects", [])}
    post, notes = [], []
    if "loudness" in codes or "true_peak" in codes:
        post.append("loudnorm")
        notes.append(f"audio normalised to {LUFS_TARGET:.0f} LUFS / -1.5 dBTP "
                     f"({codes.get('loudness', codes.get('true_peak'))['message']})")
    if "abrupt_end" in codes:
        post.append("tail_fade")
        notes.append("added a 0.3 s audio fade so the clip does not end on a hard cut")

    newp = copy.deepcopy(p)
    rer = False
    design = dict(newp.get("caption_design") or {})
    cur_pos = design.get("position") or (base_caption or {}).get("position") or "lower"
    # a 1-second touch is not worth changing the style's caption position (medium); 2 s+ is (high)
    if "text_on_face" in codes and codes["text_on_face"].get("severity") == "high" and newp.get("captions", True):
        tgt = ORDER_UP.get(cur_pos, "lower")
        design["position"] = tgt
        rer = True
        notes.append(f"captions covered a face ({codes['text_on_face']['message']}) - moved {cur_pos} -> {tgt}")
    if "small_text" in codes and newp.get("captions", True):
        size = int(design.get("size") or (base_caption or {}).get("size") or 64)
        new_size = min(120, max(size + 10, int(size * 1.25)))
        if new_size > size:          # already at the cap -> a re-render would change nothing
            design["size"] = new_size
            rer = True
            notes.append(f"captions too small to read on a phone - size {size} -> {new_size}")
    if "soft_picture" in codes and float(newp.get("zoom_cap") or 9) > 1.7:
        newp["zoom_cap"] = 1.7
        newp["jump_zoom"] = 1.0
        newp["punch_zoom"] = False
        rer = True
        notes.append("faces looked soft - wider crop (max 1.7x enlargement), punch-in zooms off")
    if "slow_open" in codes:
        fv = (report.get("measurements", {}).get("edges") or {}).get("first_voice_s")
        if fv and fv > 1.2 and newp.get("start") is not None:
            newp["start"] = round(float(newp["start"]) + fv - 0.25, 3)
            rer = True
            notes.append(f"opening had {fv:.1f}s before the first sound - trimmed to start 0.25 s before it")
    if rer:
        newp["caption_design"] = design
        newp["_repair_pass"] = int(newp.get("_repair_pass", 0)) + 1
    return {"post": post, "params": newp if rer else None, "notes": notes}


def apply_post(path: Path, fixes: list[str], duration: float) -> Path:
    """Audio-only corrections; the video stream is copied bit-for-bit."""
    if not fixes:
        return path
    af = []
    if "loudnorm" in fixes:
        af.append(f"loudnorm=I={LUFS_TARGET:.0f}:TP=-1.5:LRA=11")
    if "tail_fade" in fixes and duration > 1:
        af.append(f"afade=t=out:st={max(0.0, duration - 0.3):.3f}:d=0.3")
    tmp = path.with_name(path.stem + ".fix.mp4")
    r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(path), "-map", "0", "-c:v", "copy",
                        "-af", ",".join(af), "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
                        "-movflags", "+faststart", str(tmp)], capture_output=True, text=True)
    if r.returncode != 0 or not tmp.exists():
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"audio repair failed: {r.stderr[-300:]}")
    shutil.move(str(tmp), str(path))
    return path
