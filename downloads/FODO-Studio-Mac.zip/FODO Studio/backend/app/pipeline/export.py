"""FFmpeg export pipeline: cut + reframe + burn captions + encode + verify."""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from ..config import ASPECT_RATIOS, DEFAULT_PROFILE, PERFORMANCE_PROFILES
from .metadata import verify_output
from .reframe import crop_filter, detect_face_center

RESOLUTION_HEIGHTS = {"720p": 720, "1080p": 1080, "1440p": 1440, "2160p": 2160}


def disk_free_gb(path: Path) -> float:
    return shutil.disk_usage(path).free / 1e9


def render_clip(
    video_path: str | Path,
    out_path: str | Path,
    start: float,
    end: float,
    src_w: int,
    src_h: int,
    aspect: str = "9:16",
    resolution: str = "1080p",
    fps: float | None = None,
    profile: str = DEFAULT_PROFILE,
    ass_path: str | Path | None = None,
    face_track: bool = True,
    crop_x_frac: float | None = None,
    audio_normalize: bool = True,
    codec: str = "h264",
    hw_encoder: str | None = None,  # e.g. "h264_nvenc" / "h264_qsv"; falls back to software
) -> dict:
    """Render one clip; returns verification dict. Raises on encode failure."""
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    if disk_free_gb(out.parent) < 1:
        raise RuntimeError("Not enough disk space to render (need >= 1 GB free).")

    base_w, base_h = ASPECT_RATIOS.get(aspect, ASPECT_RATIOS["9:16"])
    # "1080p" means the SHORT side is 1080 px (vertical 9:16 -> 1080x1920,
    # 16:9 -> 1920x1080, 1:1 -> 1080x1080), matching industry convention.
    target_short = RESOLUTION_HEIGHTS.get(resolution, 1080)
    scale = target_short / min(base_w, base_h)
    out_w = int(base_w * scale) // 2 * 2
    out_h = int(base_h * scale) // 2 * 2

    cx = crop_x_frac
    if cx is None and face_track and (src_w / src_h) > (out_w / out_h):
        try:
            cx = detect_face_center(video_path, start, end)
        except Exception:  # noqa: BLE001  face tracking must never block an export
            cx = None

    vf = crop_filter(src_w, src_h, out_w, out_h, cx)
    run_cwd = None
    if ass_path:
        # Run FFmpeg inside the caption file's folder and reference it by bare name:
        # avoids filter-graph escaping of Windows drive letters (C:\...) entirely.
        run_cwd = str(Path(ass_path).parent)
        vf += f",ass={Path(ass_path).name}"

    preset, crf = PERFORMANCE_PROFILES.get(profile, PERFORMANCE_PROFILES[DEFAULT_PROFILE])
    sw_codec = {"h264": "libx264", "h265": "libx265", "av1": "libaom-av1"}.get(codec, "libx264")

    def build(vcodec: str) -> list[str]:
        cmd = ["ffmpeg", "-y", "-v", "error",
               "-ss", f"{start:.3f}", "-to", f"{end:.3f}", "-i", str(Path(video_path).resolve()),
               "-vf", vf, "-c:v", vcodec]
        if vcodec.endswith("_nvenc"):
            cmd += ["-preset", "p5", "-cq", str(crf)]
        elif vcodec.endswith("_qsv"):
            cmd += ["-global_quality", str(crf)]
        elif vcodec.endswith("_amf"):
            cmd += ["-quality", "quality", "-rc", "cqp", "-qp_i", str(crf), "-qp_p", str(crf)]
        elif vcodec.endswith("_videotoolbox"):
            from .compose import vt_quality
            cmd += ["-q:v", str(vt_quality(crf)), "-allow_sw", "1"]
        elif vcodec == "libaom-av1":
            cmd += ["-crf", str(crf + 8), "-b:v", "0", "-cpu-used", "6"]
        else:
            cmd += ["-preset", preset, "-crf", str(crf)]
        cmd += ["-pix_fmt", "yuv420p"]
        if fps:
            cmd += ["-r", str(fps)]
        if audio_normalize:
            cmd += ["-af", "loudnorm=I=-16:TP=-1.5:LRA=11"]
        cmd += ["-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", str(out.resolve())]
        return cmd

    attempts = []
    if hw_encoder and codec in ("h264", "h265"):
        attempts.append(hw_encoder.replace("h264", codec.replace("h265", "hevc")))
    attempts.append(sw_codec)
    vcodec, last_err = sw_codec, ""
    for vcodec in attempts:
        r = subprocess.run(build(vcodec), capture_output=True, text=True, cwd=run_cwd)
        if r.returncode == 0:
            break
        last_err = r.stderr[-800:]
    else:
        raise RuntimeError(f"FFmpeg render failed: {last_err}")

    verification = verify_output(out, expected_duration=end - start)
    if not verification["ok"]:
        raise RuntimeError(f"Output failed verification: {verification}")
    verification["output"] = {"width": out_w, "height": out_h, "codec": vcodec, "profile": profile}
    return verification
