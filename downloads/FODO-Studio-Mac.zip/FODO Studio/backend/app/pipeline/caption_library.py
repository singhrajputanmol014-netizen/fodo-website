"""Caption style library: 100+ ready-made caption looks grouped into sections,
plus the bundled fonts they use and an "Auto" picker.

Every preset is a plain caption_design dict (the same keys the editor sends), so a
preset is just a starting point the user can tweak. All fonts are bundled TTFs under
SIL Open Font License or Apache 2.0 (see assets/fonts/licenses).
"""
from __future__ import annotations

import re

# display name -> (family name libass asks fontconfig for, file, css font-weight, has Devanagari)
FONT_FILES: dict[str, tuple[str, str, int, bool]] = {
    "Anton": ("Anton", "Anton-Regular.ttf", 400, False),
    "Bebas Neue": ("Bebas Neue", "BebasNeue-Regular.ttf", 400, False),
    "Bangers": ("Bangers", "Bangers-Regular.ttf", 400, False),
    "Poppins ExtraBold": ("Poppins ExtraBold", "Poppins-ExtraBold.ttf", 800, False),
    "Poppins SemiBold": ("Poppins SemiBold", "Poppins-SemiBold.ttf", 600, False),
    "Archivo Black": ("Archivo Black", "ArchivoBlack-Regular.ttf", 400, False),
    "Lilita One": ("Lilita One", "LilitaOne-Regular.ttf", 400, False),
    "Righteous": ("Righteous", "Righteous-Regular.ttf", 400, False),
    "Montserrat Alt ExtraBold": ("Montserrat Alternates ExtraBold", "MontserratAlternates-ExtraBold.ttf", 800, False),
    "Playfair Display SC": ("Playfair Display SC", "PlayfairDisplaySC-Bold.ttf", 700, False),
    "Hind Bold (Hindi)": ("Hind", "Hind-Bold.ttf", 700, True),
    "Kalam Bold (Hindi)": ("Kalam", "Kalam-Bold.ttf", 700, True),
    "Montserrat Black": ("Montserrat Black", "Montserrat_900Black.ttf", 900, False),
    "Montserrat ExtraBold": ("Montserrat ExtraBold", "Montserrat_800ExtraBold.ttf", 800, False),
    "Montserrat Bold": ("Montserrat", "Montserrat_700Bold.ttf", 700, False),
    "Luckiest Guy": ("Luckiest Guy", "LuckiestGuy_400Regular.ttf", 400, False),
    "Permanent Marker": ("Permanent Marker", "PermanentMarker_400Regular.ttf", 400, False),
    "Rubik Black": ("Rubik Black", "Rubik_900Black.ttf", 900, False),
    "Barlow Condensed": ("Barlow Condensed ExtraBold", "BarlowCondensed_800ExtraBold.ttf", 800, False),
    "Outfit Black": ("Outfit Black", "Outfit_900Black.ttf", 900, False),
    "Space Grotesk": ("Space Grotesk", "SpaceGrotesk_700Bold.ttf", 700, False),
    "Syne ExtraBold": ("Syne ExtraBold", "Syne_800ExtraBold.ttf", 800, False),
    "Pacifico": ("Pacifico", "Pacifico_400Regular.ttf", 400, False),
    "Caveat": ("Caveat", "Caveat_700Bold.ttf", 700, False),
    "Dancing Script": ("Dancing Script", "DancingScript_700Bold.ttf", 700, False),
    "Lobster": ("Lobster", "Lobster_400Regular.ttf", 400, False),
    "DM Serif Display": ("DM Serif Display", "DMSerifDisplay_400Regular.ttf", 400, False),
    "Playfair Display Black": ("Playfair Display Black", "PlayfairDisplay_900Black.ttf", 900, False),
    "Cinzel Black": ("Cinzel Black", "Cinzel_900Black.ttf", 900, False),
    "Bungee": ("Bungee", "Bungee_400Regular.ttf", 400, False),
    "Press Start 2P": ("Press Start 2P", "PressStart2P_400Regular.ttf", 400, False),
    "Orbitron Black": ("Orbitron Black", "Orbitron_900Black.ttf", 900, False),
    "Teko (Hindi)": ("Teko", "Teko_700Bold.ttf", 700, True),
    "Fredoka": ("Fredoka", "Fredoka_700Bold.ttf", 700, False),
    "Baloo 2 (Hindi)": ("Baloo 2 ExtraBold", "Baloo2_800ExtraBold.ttf", 800, True),
    "Mukta (Hindi)": ("Mukta ExtraBold", "Mukta_800ExtraBold.ttf", 800, True),
    "Yatra One (Hindi)": ("Yatra One", "YatraOne_400Regular.ttf", 400, True),
    "Rajdhani (Hindi)": ("Rajdhani", "Rajdhani_700Bold.ttf", 700, True),
    "Inter Black": ("Inter Black", "Inter_900Black.ttf", 900, False),
    "Kanit Black": ("Kanit Black", "Kanit_900Black.ttf", 900, False),
    "Chakra Petch": ("Chakra Petch", "ChakraPetch_700Bold.ttf", 700, False),
    "Black Ops One": ("Black Ops One", "BlackOpsOne_400Regular.ttf", 400, False),
    "Titan One": ("Titan One", "TitanOne_400Regular.ttf", 400, False),
    "Shrikhand": ("Shrikhand", "Shrikhand_400Regular.ttf", 400, False),
    "Monoton": ("Monoton", "Monoton_400Regular.ttf", 400, False),
    "Oswald": ("Oswald", "Oswald_700Bold.ttf", 700, False),
    "Sora ExtraBold": ("Sora ExtraBold", "Sora_800ExtraBold.ttf", 800, False),
    "League Spartan Black": ("League Spartan Black", "LeagueSpartan_900Black.ttf", 900, False),
}

FONT_GROUPS = {
    "Bold & Impact": ["Montserrat Black", "Anton", "Bebas Neue", "Archivo Black", "Inter Black", "League Spartan Black",
                      "Rubik Black", "Outfit Black", "Kanit Black", "Oswald", "Barlow Condensed", "Montserrat ExtraBold"],
    "Modern & Clean": ["Montserrat Bold", "Poppins ExtraBold", "Poppins SemiBold", "Space Grotesk", "Sora ExtraBold",
                       "Syne ExtraBold", "Montserrat Alt ExtraBold"],
    "Fun & Cartoon": ["Luckiest Guy", "Bangers", "Lilita One", "Titan One", "Fredoka", "Bungee", "Righteous"],
    "Elegant & Serif": ["Playfair Display Black", "Playfair Display SC", "DM Serif Display", "Cinzel Black"],
    "Handwritten & Script": ["Permanent Marker", "Caveat", "Pacifico", "Dancing Script", "Lobster", "Shrikhand"],
    "Tech & Retro": ["Orbitron Black", "Press Start 2P", "Chakra Petch", "Black Ops One", "Monoton"],
    "Hindi / Devanagari": ["Hind Bold (Hindi)", "Baloo 2 (Hindi)", "Mukta (Hindi)", "Teko (Hindi)",
                           "Rajdhani (Hindi)", "Yatra One (Hindi)", "Kalam Bold (Hindi)"],
}

DEVANAGARI_FONTS = tuple(k for k, v in FONT_FILES.items() if v[3])

SECTIONS = [
    ("trending", "Trending now"), ("viral", "Bold & viral"), ("podcast", "Podcast & talk"),
    ("gaming", "Gaming & stream"), ("minimal", "Clean & minimal"), ("cinematic", "Cinematic & luxury"),
    ("neon", "Neon & glow"), ("fun", "Fun & comedy"), ("motivation", "Motivation & gym"),
    ("news", "News & docs"), ("story", "Handwritten & story"), ("retro", "Retro & Y2K"),
    ("desi", "Hindi / Desi"),
]


def _p(pid, name, sec, font, color, hl, anim, **kw):
    d = {"id": pid, "name": name, "section": sec, "font": font, "color": color, "highlight": hl,
         "animation": anim, "upper": kw.pop("upper", True), "box": kw.pop("box", False),
         "outline": kw.pop("outline", 4), "words_per_line": kw.pop("wpl", 3), "size": kw.pop("size", 82)}
    d.update(kw)
    return d


W, K, Y, O = "#ffffff", "#000000", "#ffd400", "#ff5900"
G, C, P, R, B = "#22ee66", "#22d3ee", "#ff3ea5", "#ff2d2d", "#3b82f6"

PRESETS: list[dict] = [
    # ---- trending now: the looks dominating Reels / Shorts / TikTok -------------------------
    _p("clean_pop", "Clean Pop", "trending", "Montserrat Black", W, Y, "highlight_word", tags=["popular"]),
    _p("dynamic_minimal", "Dynamic Minimal", "trending", "Montserrat ExtraBold", W, W, "bounce", upper=False,
       outline=0, shadow=3, wpl=3, size=76, tags=["new"]),
    _p("word_pill_green", "Word Pill Green", "trending", "Montserrat Black", W, G, "word_box"),
    _p("word_pill_purple", "Word Pill Purple", "trending", "Montserrat Black", W, "#8b5cf6", "word_box"),
    _p("hormozi_yellow", "Hormozi Yellow", "trending", "Montserrat Black", W, Y, "highlight_word", outline=5, wpl=2, size=90),
    _p("hormozi_green", "Hormozi Green", "trending", "Montserrat Black", W, G, "highlight_word", outline=5, wpl=2, size=90),
    _p("beast_mode", "Beast Mode", "trending", "Luckiest Guy", W, Y, "bounce", outline=6, shadow=4, wpl=2, size=92),
    _p("karaoke_glow", "Karaoke Glow", "trending", "Poppins ExtraBold", W, C, "karaoke", upper=False, glow=6,
       outline_color=C),
    _p("one_word_punch", "One Word Punch", "trending", "Anton", W, Y, "punch", size=120, wpl=1),
    _p("soft_shadow", "Soft Shadow", "trending", "Poppins ExtraBold", W, W, "fade", upper=False, outline=0, shadow=4,
       size=74),
    _p("tiktok_classic", "TikTok Classic", "trending", "Montserrat Bold", W, W, "static", upper=False, box=True,
       box_color="#000000", outline=10, size=66, wpl=5),
    _p("underline_pop", "Underline Pop", "trending", "Inter Black", W, O, "underline", upper=False, size=78),
    # ---- bold & viral -----------------------------------------------------------------------
    _p("bold_yellow", "Bold Yellow", "viral", "Anton", W, Y, "highlight_word"),
    _p("fodo_orange", "FODO Orange", "viral", "Anton", W, O, "highlight_word"),
    _p("green_pop", "Green Pop", "viral", "Bebas Neue", W, G, "pop_words", size=96),
    _p("red_alert", "Red Alert", "viral", "Archivo Black", W, R, "highlight_word"),
    _p("ice_blue", "Ice Blue", "viral", "Inter Black", W, C, "bounce"),
    _p("hot_pink", "Hot Pink", "viral", "Rubik Black", W, P, "highlight_word"),
    _p("big_bold_two", "Big Bold Two", "viral", "League Spartan Black", W, Y, "pop_words", wpl=2, size=98),
    _p("stacked_impact", "Stacked Impact", "viral", "Anton", W, R, "punch", wpl=1, size=124, outline=6),
    _p("black_box_yellow", "Black Box Yellow", "viral", "Archivo Black", W, Y, "highlight_word", box=True,
       box_color="#000000", outline=12),
    _p("yellow_text", "All Yellow", "viral", "Montserrat Black", Y, W, "highlight_word"),
    _p("shadow_stack", "Shadow Stack", "viral", "Outfit Black", W, Y, "bounce", outline=3, shadow=7, shadow_color="#ff5900"),
    _p("orange_pill", "Orange Pill", "viral", "Montserrat Black", W, O, "word_box"),
    _p("yellow_pill", "Yellow Pill", "viral", "Montserrat Black", W, Y, "word_box"),
    _p("red_pill", "Red Pill", "viral", "Kanit Black", W, R, "word_box"),
    # ---- podcast & talk -------------------------------------------------------------------
    _p("podcast_clean", "Podcast Clean", "podcast", "Poppins SemiBold", W, Y, "karaoke", upper=False, outline=0,
       box=True, box_color="#000000", wpl=5, size=64),
    _p("podcast_bold", "Podcast Bold", "podcast", "Poppins ExtraBold", W, C, "highlight_word", upper=False, size=72),
    _p("interview_box", "Interview Box", "podcast", "Montserrat Bold", W, W, "static", upper=False, box=True,
       box_color="#111111", outline=12, wpl=6, size=60),
    _p("talk_green", "Talk Green", "podcast", "Montserrat ExtraBold", W, G, "karaoke", upper=False, wpl=4, size=70),
    _p("talk_blue", "Talk Blue", "podcast", "Space Grotesk", W, B, "highlight_word", upper=False, wpl=4, size=70),
    _p("quote_card", "Quote Card", "podcast", "DM Serif Display", W, Y, "fade", upper=False, outline=0, shadow=3,
       wpl=5, size=72),
    _p("guest_spotlight", "Guest Spotlight", "podcast", "Sora ExtraBold", W, O, "underline", upper=False, wpl=4, size=70),
    _p("white_pill", "White Pill", "podcast", "Poppins ExtraBold", W, W, "word_box", upper=False, size=72),
    _p("calm_subtitle", "Calm Subtitle", "podcast", "Poppins SemiBold", W, W, "subtitle", upper=False, outline=2,
       size=58, wpl=6),
    # ---- gaming & stream ------------------------------------------------------------------
    _p("gamer_green", "Gamer Green", "gaming", "Bungee", G, W, "punch", wpl=1, size=104, outline=6),
    _p("clutch_red", "Clutch Red", "gaming", "Black Ops One", W, R, "highlight_word", size=90),
    _p("arcade", "Arcade", "gaming", "Press Start 2P", Y, W, "typewriter", size=60, outline=5),
    _p("cyber_cyan", "Cyber Cyan", "gaming", "Orbitron Black", W, C, "bounce", glow=5, outline_color=C),
    _p("stream_pop", "Stream Pop", "gaming", "Luckiest Guy", W, "#a855f7", "pop_words", outline=6),
    _p("headshot", "Headshot", "gaming", "Chakra Petch", W, R, "punch", wpl=1, size=110),
    _p("rage_mode", "Rage Mode", "gaming", "Anton", R, Y, "punch", wpl=1, size=126, outline=7, cycle=True),
    _p("victory", "Victory", "gaming", "Bungee", Y, W, "bounce", outline=6, shadow=4),
    _p("twitch_purple", "Twitch Purple", "gaming", "Rubik Black", W, "#9146ff", "word_box"),
    _p("glitch_green", "Glitch Green", "gaming", "Chakra Petch", G, W, "typewriter", glow=4, outline_color=G),
    # ---- clean & minimal ------------------------------------------------------------------
    _p("minimal", "Minimal", "minimal", "Poppins SemiBold", W, W, "static", upper=False, outline=2, size=64, wpl=5),
    _p("minimal_shadow", "Minimal Shadow", "minimal", "Montserrat Bold", W, W, "fade", upper=False, outline=0,
       shadow=3, size=66, wpl=5),
    _p("clean_box", "Clean Box", "minimal", "Poppins SemiBold", W, W, "static", upper=False, box=True,
       box_color="#000000", outline=10, size=62, wpl=5),
    _p("white_box_dark", "White Box", "minimal", "Poppins ExtraBold", K, K, "static", upper=False, box=True,
       box_color="#ffffff", outline=10, size=64, wpl=5),
    _p("lowercase_soft", "lowercase soft", "minimal", "Space Grotesk", W, W, "fade", upper=False, outline=0, shadow=2,
       size=66, wpl=4, lower=True),
    _p("thin_line", "Thin Line", "minimal", "Montserrat Bold", W, "#a3e635", "karaoke", upper=False, outline=1,
       size=62, wpl=5),
    _p("apple_style", "Keynote", "minimal", "Inter Black", W, "#a1a1aa", "karaoke", upper=False, outline=0, shadow=2,
       size=72, wpl=4),
    _p("mono_accent", "Mono Accent", "minimal", "Sora ExtraBold", W, O, "highlight_word", upper=False, outline=2,
       size=68, wpl=4),
    _p("slide_clean", "Slide Clean", "minimal", "Montserrat ExtraBold", W, W, "slide_up", upper=False, outline=0,
       shadow=3, size=70, wpl=4),
    _p("gray_karaoke", "Gray Karaoke", "minimal", "Poppins ExtraBold", "#9ca3af", W, "karaoke", upper=False,
       outline=0, shadow=2, size=70, wpl=4),
    # ---- cinematic & luxury ---------------------------------------------------------------
    _p("cinematic", "Cinematic", "cinematic", "Cinzel Black", "#e7e2d8", "#f5c26b", "fade", outline=0, shadow=2,
       size=62, wpl=5, spacing=4),
    _p("luxury_gold", "Luxury Gold", "cinematic", "Playfair Display Black", W, "#d4af37", "karaoke", upper=False,
       outline=1, size=70, wpl=4),
    _p("film_subtitle", "Film Subtitle", "cinematic", "DM Serif Display", "#f5f5f4", W, "subtitle", upper=False,
       outline=1, size=60, italic=True),
    _p("royal_serif", "Royal Serif", "cinematic", "Playfair Display SC", W, "#f5c26b", "highlight_word", outline=2,
       size=66, wpl=4),
    _p("noir", "Noir", "cinematic", "Oswald", "#e5e5e5", W, "slide_up", outline=0, shadow=4, size=70, spacing=3, wpl=4),
    _p("trailer", "Trailer", "cinematic", "Cinzel Black", W, W, "punch", wpl=2, size=92, outline=0, glow=6,
       outline_color="#ffffff", spacing=6),
    _p("elegant_italic", "Elegant Italic", "cinematic", "DM Serif Display", W, "#fcd34d", "fade", upper=False,
       outline=0, shadow=3, italic=True, size=74, wpl=4),
    _p("champagne", "Champagne", "cinematic", "Playfair Display Black", "#f7e7ce", "#ffffff", "bounce", upper=False,
       outline=0, shadow=3, size=74),
    # ---- neon & glow ----------------------------------------------------------------------
    _p("neon_pink", "Neon Pink", "neon", "Montserrat Black", W, P, "highlight_word", glow=8, outline_color=P, outline=3),
    _p("neon_cyan", "Neon Cyan", "neon", "Montserrat Black", W, C, "highlight_word", glow=8, outline_color=C, outline=3),
    _p("neon_green", "Neon Green", "neon", "Outfit Black", W, G, "bounce", glow=8, outline_color=G, outline=3),
    _p("neon_purple", "Neon Purple", "neon", "Syne ExtraBold", W, "#c084fc", "karaoke", glow=8,
       outline_color="#a855f7", outline=3),
    _p("neon_sign", "Neon Sign", "neon", "Monoton", P, C, "fade", glow=10, outline_color=P, outline=2, size=78),
    _p("miami", "Miami Nights", "neon", "Righteous", "#ff77e9", C, "pop_words", glow=7, outline_color="#ff2fd1", outline=3),
    _p("electric_blue", "Electric Blue", "neon", "Orbitron Black", W, B, "punch", wpl=1, size=104, glow=9,
       outline_color=B, outline=3),
    _p("acid_lime", "Acid Lime", "neon", "Kanit Black", "#d9f99d", "#84cc16", "highlight_word", glow=7,
       outline_color="#65a30d", outline=3),
    _p("sunset_glow", "Sunset Glow", "neon", "Rubik Black", "#ffedd5", O, "bounce", glow=8, outline_color=O, outline=3),
    _p("ice_glow", "Ice Glow", "neon", "Inter Black", W, "#bae6fd", "karaoke", glow=9, outline_color="#38bdf8", outline=3),
    # ---- fun & comedy ---------------------------------------------------------------------
    _p("comic_pop", "Comic Pop", "fun", "Bangers", Y, W, "bounce", outline=6, shadow=4, size=96, spacing=2),
    _p("cartoon", "Cartoon", "fun", "Luckiest Guy", W, "#fb923c", "pop_words", outline=7, shadow=5, size=92),
    _p("bubble", "Bubble", "fun", "Titan One", W, P, "bounce", outline=7, outline_color="#7c3aed", size=90),
    _p("candy", "Candy", "fun", "Fredoka", "#fdf2f8", P, "word_box", upper=False, size=84),
    _p("lol_yellow", "LOL Yellow", "fun", "Lilita One", Y, W, "punch", wpl=1, size=118, outline=7),
    _p("meme_classic", "Meme Classic", "fun", "Anton", W, W, "static", outline=6, size=96, wpl=4),
    _p("sticker", "Sticker", "fun", "Titan One", K, K, "bounce", outline=10, outline_color="#ffffff", size=90),
    _p("rainbow_cycle", "Rainbow Cycle", "fun", "Luckiest Guy", W, Y, "punch", wpl=1, size=118, cycle=True, outline=7),
    _p("silly_wiggle", "Silly", "fun", "Bangers", W, G, "pop_words", outline=6, size=96, spacing=3),
    _p("comedy_box", "Comedy Box", "fun", "Lilita One", K, K, "static", box=True, box_color="#ffd400", outline=10,
       upper=False, size=80, wpl=4),
    # ---- motivation & gym -----------------------------------------------------------------
    _p("grind", "Grind", "motivation", "Anton", W, R, "punch", wpl=1, size=122, outline=6),
    _p("discipline", "Discipline", "motivation", "Bebas Neue", W, Y, "highlight_word", size=104, spacing=3),
    _p("alpha_gold", "Alpha Gold", "motivation", "Oswald", W, "#f59e0b", "bounce", size=90, spacing=2),
    _p("success_white", "Success", "motivation", "Montserrat Black", W, W, "punch", wpl=1, size=116, outline=0,
       shadow=5),
    _p("gym_red", "Gym Red", "motivation", "Black Ops One", W, R, "word_box", size=86),
    _p("mindset", "Mindset", "motivation", "Barlow Condensed", W, C, "highlight_word", size=104, spacing=2),
    _p("fire_orange", "Fire", "motivation", "Anton", "#fff7ed", O, "punch", wpl=1, size=122, glow=6, outline_color=O),
    _p("stoic", "Stoic", "motivation", "Cinzel Black", W, "#e5e7eb", "fade", outline=0, shadow=3, size=70, wpl=4,
       spacing=3),
    _p("hustle_green", "Hustle", "motivation", "League Spartan Black", W, G, "word_box", size=88),
    # ---- news & docs ----------------------------------------------------------------------
    _p("news", "News Bar", "news", "Montserrat Bold", W, W, "static", upper=False, box=True, box_color="#b91c1c",
       outline=12, size=60, wpl=6),
    _p("breaking", "Breaking", "news", "Oswald", W, Y, "highlight_word", box=True, box_color="#000000", outline=12,
       size=68, wpl=5),
    _p("documentary", "Documentary", "news", "DM Serif Display", "#f0f0f0", W, "subtitle", upper=False, outline=1,
       box=True, box_color="#000000", size=56),
    _p("explainer", "Explainer", "news", "Space Grotesk", W, Y, "karaoke", upper=False, outline=2, size=66, wpl=5),
    _p("facts", "Facts", "news", "Inter Black", W, C, "underline", upper=False, outline=2, size=68, wpl=4),
    _p("report_blue", "Report Blue", "news", "Montserrat Bold", W, W, "static", upper=False, box=True,
       box_color="#1d4ed8", outline=12, size=60, wpl=6),
    _p("edu_highlight", "Edu Highlight", "news", "Poppins ExtraBold", W, "#fde047", "word_box", upper=False, size=70,
       wpl=4),
    _p("tv_subtitle", "TV Subtitle", "news", "Poppins SemiBold", "#fffde7", W, "subtitle", upper=False, outline=3,
       size=58),
    # ---- handwritten & story --------------------------------------------------------------
    _p("marker", "Marker", "story", "Permanent Marker", W, Y, "highlight_word", upper=False, size=84),
    _p("diary", "Diary", "story", "Caveat", W, "#fda4af", "fade", upper=False, outline=0, shadow=3, size=92, wpl=4),
    _p("script_gold", "Script Gold", "story", "Dancing Script", W, "#fcd34d", "karaoke", upper=False, outline=2,
       size=90, wpl=4),
    _p("retro_script", "Retro Script", "story", "Lobster", W, O, "bounce", upper=False, outline=3, size=88),
    _p("cute_script", "Cute Script", "story", "Pacifico", "#fff1f2", P, "fade", upper=False, outline=3, size=80, wpl=3),
    _p("storybook", "Storybook", "story", "Playfair Display Black", W, "#93c5fd", "typewriter", upper=False, outline=2,
       size=72, wpl=5),
    _p("love_note", "Love Note", "story", "Dancing Script", "#ffe4e6", "#fb7185", "slide_up", upper=False, outline=0,
       shadow=3, size=92, wpl=4),
    _p("sketch", "Sketch", "story", "Permanent Marker", K, K, "static", upper=False, box=True, box_color="#ffffff",
       outline=10, size=80, wpl=4),
    _p("chalk", "Chalk", "story", "Caveat", "#f8fafc", "#fde68a", "typewriter", upper=False, outline=0, glow=2,
       outline_color="#ffffff", size=94, wpl=4),
    # ---- retro & y2k ----------------------------------------------------------------------
    _p("retro", "Retro 80s", "retro", "Monoton", "#fde68a", P, "fade", outline=2, glow=5, outline_color=P, size=74),
    _p("y2k_chrome", "Y2K Chrome", "retro", "Syne ExtraBold", "#e5e7eb", C, "bounce", outline=4,
       outline_color="#6b7280", shadow=3, size=84),
    _p("vhs", "VHS", "retro", "Press Start 2P", W, R, "typewriter", outline=4, shadow=4, shadow_color="#22d3ee", size=56),
    _p("disco", "Disco", "retro", "Shrikhand", "#fbcfe8", Y, "bounce", upper=False, outline=5,
       outline_color="#9d174d", size=86),
    _p("pixel", "Pixel", "retro", "Press Start 2P", G, W, "pop_words", outline=4, size=58),
    _p("groovy", "Groovy", "retro", "Shrikhand", O, Y, "pop_words", upper=False, outline=5, outline_color="#7c2d12",
       size=86),
    _p("tape", "Tape Label", "retro", "Righteous", K, K, "static", upper=True, box=True, box_color="#fde047",
       outline=10, size=72, wpl=4),
    _p("vapor", "Vaporwave", "retro", "Righteous", "#f0abfc", "#67e8f9", "karaoke", outline=3,
       outline_color="#7e22ce", glow=4, size=80, spacing=4),
    # ---- hindi / desi ---------------------------------------------------------------------
    _p("desi_bold", "Desi Bold", "desi", "Hind Bold (Hindi)", W, Y, "highlight_word", upper=False, size=96),
    _p("desi_pill", "Desi Pill", "desi", "Baloo 2 (Hindi)", W, O, "word_box", upper=False, size=96),
    _p("desi_karaoke", "Desi Karaoke", "desi", "Mukta (Hindi)", W, G, "karaoke", upper=False, size=96),
    _p("bollywood", "Bollywood", "desi", "Yatra One (Hindi)", "#fde68a", R, "bounce", upper=False, outline=5,
       outline_color="#7f1d1d", size=96),
    _p("desi_news", "Desi News", "desi", "Mukta (Hindi)", W, W, "static", upper=False, box=True,
       box_color="#b91c1c", outline=12, size=84, wpl=5),
    _p("desi_comedy", "Desi Comedy", "desi", "Baloo 2 (Hindi)", Y, W, "punch", upper=False, wpl=1, size=118, outline=7),
    _p("desi_handwritten", "Desi Handwritten", "desi", "Kalam Bold (Hindi)", W, "#fda4af", "fade", upper=False,
       outline=3, size=96, wpl=4),
    _p("desi_gamer", "Desi Gamer", "desi", "Teko (Hindi)", G, W, "punch", upper=False, wpl=1, size=124, outline=6),
    _p("desi_motivation", "Desi Motivation", "desi", "Rajdhani (Hindi)", W, O, "highlight_word", upper=False,
       size=100),
    _p("desi_podcast", "Desi Podcast", "desi", "Hind Bold (Hindi)", W, C, "karaoke", upper=False, box=True,
       box_color="#000000", outline=10, size=88, wpl=5),
]

# Colour variants of the most-used looks, so every section has plenty of choice.
_VARIANTS = [
    ("clean_pop", [("Clean Pop Green", G), ("Clean Pop Cyan", C), ("Clean Pop Pink", P), ("Clean Pop Orange", O)]),
    ("word_pill_green", [("Word Pill Blue", B), ("Word Pill Pink", P), ("Word Pill Yellow", Y)]),
    ("karaoke_glow", [("Karaoke Glow Pink", P), ("Karaoke Glow Lime", "#a3e635")]),
    ("one_word_punch", [("One Word Red", R), ("One Word Cyan", C)]),
    ("bold_yellow", [("Bold Lime", "#a3e635"), ("Bold Sky", "#38bdf8")]),
    ("podcast_bold", [("Podcast Bold Yellow", Y), ("Podcast Bold Pink", P)]),
    ("desi_bold", [("Desi Bold Orange", O), ("Desi Bold Green", G), ("Desi Bold Cyan", C)]),
    ("comic_pop", [("Comic Pop Pink", P)]),
    ("neon_pink", [("Neon Orange", O), ("Neon Red", R)]),
]
_by_id = {p["id"]: p for p in PRESETS}
for _base, _vs in _VARIANTS:
    for _name, _hl in _vs:
        _v = dict(_by_id[_base])
        _v["id"] = re.sub(r"[^a-z0-9]+", "_", _name.lower()).strip("_")
        _v["name"] = _name
        _v["highlight"] = _hl
        _v.pop("tags", None)
        if _v.get("outline_color") and _v.get("glow"):
            _v["outline_color"] = _hl
        PRESETS.append(_v)
del _by_id

LIBRARY: dict[str, dict] = {p["id"]: p for p in PRESETS}
assert len(LIBRARY) == len(PRESETS), "duplicate preset id"

DESIGN_KEYS = ("font", "color", "highlight", "animation", "upper", "box", "outline", "words_per_line", "size",
               "outline_color", "shadow", "shadow_color", "box_color", "glow", "italic", "spacing", "cycle", "lower")


def preset_design(pid: str) -> dict:
    p = LIBRARY.get(pid)
    if not p:
        return {}
    return {k: p[k] for k in DESIGN_KEYS if k in p}


# ------------------------------------------------------------------ auto pick --------
_NICHE = [
    ("gaming", r"\b(game|gaming|gamer|valorant|minecraft|fortnite|gta|bgmi|pubg|cod|clutch|stream|twitch|kill|headshot)\b"),
    ("fun", r"\b(funny|comedy|prank|lol|laugh|meme|roast|joke|stand.?up|hilarious|fail)\b"),
    ("motivation", r"\b(motivation|discipline|gym|workout|success|mindset|grind|hustle|money|rich|millionaire)\b"),
    ("news", r"\b(news|breaking|report|explained|facts|history|documentary|science|update)\b"),
    ("podcast", r"\b(podcast|interview|episode|conversation|ep\.?|guest|show)\b"),
    ("cinematic", r"\b(movie|film|cinematic|trailer|luxury|travel|wedding|fashion)\b"),
    ("story", r"\b(story|storytime|diary|love|relationship|vlog)\b"),
]
_AUTO_FOR = {"gaming": "gamer_green", "fun": "comic_pop", "motivation": "grind", "news": "explainer",
             "podcast": "podcast_bold", "cinematic": "luxury_gold", "story": "marker"}
_AUTO_DESI = {"gaming": "desi_gamer", "fun": "desi_comedy", "motivation": "desi_motivation", "news": "desi_news",
              "podcast": "desi_podcast", "story": "desi_handwritten"}


def niche_of(text: str) -> str | None:
    t = (text or "").lower()
    best, hits = None, 0
    for name, rx in _NICHE:
        n = len(re.findall(rx, t))
        if n > hits:
            best, hits = name, n
    return best


def auto_pick(text: str = "", devanagari: bool = False) -> str:
    """Preset id for a clip: by niche (title + words) and script."""
    n = niche_of(text)
    if devanagari:
        return _AUTO_DESI.get(n or "", "desi_bold")
    return _AUTO_FOR.get(n or "", "clean_pop")


def suggest(text: str = "", devanagari: bool = False, k: int = 5) -> list[str]:
    """The Auto pick plus a few strong alternatives — shown next to Auto in the UI."""
    first = auto_pick(text, devanagari)
    pool = (["desi_bold", "desi_pill", "desi_karaoke", "desi_comedy", "bollywood"] if devanagari else
            ["clean_pop", "word_pill_green", "hormozi_yellow", "dynamic_minimal", "karaoke_glow", "beast_mode"])
    out = [first] + [p for p in pool if p != first]
    return out[:k]


def library_json() -> dict:
    return {
        "sections": [{"id": s, "name": n, "presets": [p for p in PRESETS if p["section"] == s]} for s, n in SECTIONS],
        "count": len(PRESETS),
        "fonts": [{"name": k, "file": v[1], "weight": v[2], "hindi": v[3]} for k, v in FONT_FILES.items()],
        "font_groups": FONT_GROUPS,
    }


# A Hindi-capable font that keeps the feel of the chosen one (Latin display fonts have no Devanagari)
_DEVA_LIKE = {
    "Kalam Bold (Hindi)": ("Permanent Marker", "Caveat", "Dancing Script", "Pacifico", "Lobster", "Shrikhand"),
    "Teko (Hindi)": ("Anton", "Bebas Neue", "Oswald", "Barlow Condensed", "Black Ops One", "League Spartan Black"),
    "Baloo 2 (Hindi)": ("Luckiest Guy", "Bangers", "Lilita One", "Titan One", "Fredoka", "Bungee", "Righteous"),
    "Yatra One (Hindi)": ("Playfair Display Black", "Playfair Display SC", "DM Serif Display", "Cinzel Black", "Monoton"),
    "Rajdhani (Hindi)": ("Orbitron Black", "Press Start 2P", "Chakra Petch"),
    "Hind Bold (Hindi)": ("Poppins SemiBold", "Montserrat Bold", "Space Grotesk"),
}


def devanagari_font(name: str) -> str:
    """Display name of a Hindi-capable font for `name` (display or family name)."""
    if name in DEVANAGARI_FONTS:
        return name
    disp = name if name in FONT_FILES else next((k for k, v in FONT_FILES.items() if v[0] == name), name)
    if disp in DEVANAGARI_FONTS:
        return disp
    for deva, likes in _DEVA_LIKE.items():
        if disp in likes:
            return deva
    return "Mukta (Hindi)"          # heavy modern sans: the closest match for the bold caption fonts
