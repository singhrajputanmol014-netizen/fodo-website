"""Style previews: one still frame showing how a clip will look in each edit style.

Rendered with the same building blocks as the real export (crop / frame layout, colour grade,
title graphics and caption design), from a frame of the user's own video - or, when no video is
chosen, from a drawn studio mock-up (two people), so the cards never show someone else's content.
"""
from __future__ import annotations

import hashlib
import shutil
import subprocess
from pathlib import Path

import threading

PREVIEW_VER = "3"
_LOCK = threading.Lock()          # base frames are shared by all style cards: build each one once
PW, PH = 540, 960                       # preview size (9:16)


def _publish(im, path: Path) -> None:
    if path.exists():
        return                                   # same picture every time; it may be open in FFmpeg right now
    tmp = path.with_name(path.stem + ".tmp.png")
    im.save(tmp)
    try:
        tmp.replace(path)
    except PermissionError:
        tmp.unlink(missing_ok=True)


def mock_frame(path: Path) -> tuple[Path, list[list[float]]]:
    """1920x1080 studio mock-up: warm gradient, two stylised people. Returns (png, face boxes)."""
    with _LOCK:
        return _mock_frame(path)


def _mock_frame(path: Path) -> tuple[Path, list[list[float]]]:
    from PIL import Image, ImageDraw, ImageFilter
    W, H = 1920, 1080
    im = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):                                   # warm studio gradient
        t = y / H
        d.line([(0, y), (W, y)], fill=(int(40 + 50 * (1 - t)), int(28 + 30 * (1 - t)), int(30 + 20 * (1 - t))))
    for x0, col in ((180, (90, 60, 40)), (1500, (60, 70, 90))):          # soft background lights
        d.ellipse([x0, 80, x0 + 380, 460], fill=col)
    im = im.filter(ImageFilter.GaussianBlur(60))
    d = ImageDraw.Draw(im)
    boxes = []
    for cx, shirt in ((560, (30, 30, 34)), (1360, (110, 40, 30))):
        d.rounded_rectangle([cx - 230, 560, cx + 230, 1180], radius=160, fill=shirt)       # body
        d.rectangle([cx - 45, 470, cx + 45, 600], fill=(196, 150, 120))                       # neck
        d.ellipse([cx - 115, 250, cx + 115, 520], fill=(214, 168, 136))                        # head
        d.chord([cx - 122, 230, cx + 122, 420], 180, 360, fill=(35, 25, 22))                   # hair
        d.ellipse([cx - 60, 360, cx - 36, 382], fill=(40, 30, 28))
        d.ellipse([cx + 36, 360, cx + 60, 382], fill=(40, 30, 28))
        d.arc([cx - 45, 400, cx + 45, 460], 20, 160, fill=(120, 60, 50), width=6)
        boxes.append([(cx - 115) / W, 250 / H, 230 / W, 270 / H])
    d.rounded_rectangle([860, 640, 1060, 1080], radius=30, fill=(18, 18, 20))                 # desk mic
    _publish(im, path)
    return path, boxes


def mock_stream(path: Path) -> tuple[Path, list[list[float]]]:
    """Gameplay-like scene with a small facecam in the bottom-left corner."""
    with _LOCK:
        return _mock_stream(path)


def _mock_stream(path: Path) -> tuple[Path, list[list[float]]]:
    from PIL import Image, ImageDraw, ImageFilter
    W, H = 1920, 1080
    im = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):
        t = y / H
        col = (int(70 + 60 * t), int(130 + 40 * t), int(200 - 80 * t)) if y < 560 else (int(60 + 30 * t), int(110 + 30 * t), 50)
        d.line([(0, y), (W, y)], fill=col)
    for x, h in ((300, 260), (720, 340), (1180, 220), (1560, 300)):
        d.rectangle([x, 560 - h, x + 180, 560], fill=(90, 90, 110))
    d.polygon([(860, 1080), (960, 760), (1060, 1080)], fill=(40, 40, 46))                 # weapon
    im = im.filter(ImageFilter.GaussianBlur(2))
    d = ImageDraw.Draw(im)
    fx, fy, fw, fh = 40, 640, 420, 400                                                   # facecam
    d.rectangle([fx, fy, fx + fw, fy + fh], fill=(32, 30, 36), outline=(255, 210, 0), width=6)
    cx = fx + fw // 2
    d.rounded_rectangle([cx - 120, fy + 250, cx + 120, fy + fh], radius=80, fill=(30, 60, 140))
    d.ellipse([cx - 60, fy + 90, cx + 60, fy + 230], fill=(214, 168, 136))
    d.chord([cx - 64, fy + 80, cx + 64, fy + 170], 180, 360, fill=(35, 25, 22))
    _publish(im, path)
    return path, [[(cx - 60) / W, (fy + 90) / H, 120 / W, 140 / H]]


def frame_from_video(video, t: float, path: Path) -> Path | None:
    with _LOCK:
        if path.exists():
            return path
        tmp = path.with_name(path.stem + ".tmp.png")
        r = subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", str(video.path), "-frames:v", "1",
                            "-vf", "scale=1920:-2", str(tmp)], capture_output=True)
        if r.returncode != 0 or not tmp.exists():
            return None
        tmp.replace(path)
        return path


def faces_in_image(path: Path) -> list[list[float]]:
    import cv2

    from .speakers import _detector
    img = cv2.imread(str(path))
    if img is None:
        return []
    h, w = img.shape[:2]
    sc = 640 / w
    small = cv2.resize(img, (640, int(h * sc)))
    det = _detector(small.shape[1], small.shape[0])
    _, faces = det.detect(small)
    out = []
    for f in (faces if faces is not None else []):
        x, y, fw, fh = (float(v) for v in f[:4])
        if fw * fh < small.shape[0] * small.shape[1] * 0.002:
            continue
        out.append([x / small.shape[1], y / small.shape[0], fw / small.shape[1], fh / small.shape[0]])
    return sorted(out, key=lambda b: -b[3])


SAMPLE = ["This", "is", "how", "your", "captions", "will", "look", "today"]


def render(preset_key: str, src: Path, boxes: list[list[float]], out: Path, title: str,
           crop_x: float | None = None) -> Path:
    from PIL import Image

    from . import compose, looks
    from .captions import build_ass
    from .edit import PRESETS
    p = PRESETS[preset_key]
    sw, sh = Image.open(src).size
    W, H = PW, PH
    frame = p.get("frame", "fill")
    import uuid
    work = out.parent / (out.stem + "_w" + uuid.uuid4().hex[:6])
    work.mkdir(parents=True, exist_ok=True)
    main = boxes[0] if boxes else None
    if crop_x is not None:
        main = [max(0.0, min(1.0, crop_x)) - 0.05, 0.25, 0.1, 0.22]
    others = boxes[1:] if boxes else []
    cam = None
    if frame == "stream":
        cam = next((b for b in boxes if b[3] < 0.24 and min(b[0] + b[2] / 2, 1 - b[0] - b[2] / 2) < 0.3), None)
    if frame == "native" or frame in ("letterbox", "cinema"):
        vf = compose._wide(W, H) if frame == "native" else compose._letterbox(sw, sh, W, H, frame)
    elif frame == "stream" and cam:
        vf = compose._stream(cam, sw, sh, W, H)
    elif frame in ("boxed", "white_top"):
        if frame == "boxed":
            _, _, iw, ih = compose.box_rect(W, H)
        else:
            iw, ih = W, W
        inner = compose._single_crop(main, sw, sh, iw, ih, 1.0, others) if main else compose._fill(sw, sh, iw, ih)
        vf = compose._boxed(inner, W, H) if frame == "boxed" else compose._white_top(inner, W, H, ih)
    elif frame in ("frame45", "frame65"):
        inner_h = min(H, compose._even(W * (5 / 4 if frame == "frame45" else 5 / 6)))
        inner = compose._single_crop(main, sw, sh, W, inner_h, 1.0, others) if main else compose._fill(sw, sh, W, inner_h)
        vf = compose._framed(inner, W, H, inner_h, dark=(frame == "frame45"))
    elif main:
        vf = compose._single_crop(main, sw, sh, W, H, 1.0, others, tv=(frame == "tv"))
    else:
        vf = compose._fill(sw, sh, W, H)
    style = compose.EDIT_STYLES.get(p.get("edit_style", "clean"), compose.EDIT_STYLES["clean"])
    chain = [x for x in [style["vf"]] if x]
    if p.get("grain"):
        chain.append("noise=alls=6:allf=t")
    # graphics: same look file as the export (title shown so the template is visible)
    words = [{"w": w, "s": 0.2 + i * 0.25, "e": 0.42 + i * 0.25} for i, w in enumerate(SAMPLE)]
    t_show = 0.95                                   # 'your' / 'captions' on screen, hooks still up
    ass_files = []
    g = looks.build(p.get("title_kind", "none"), title, W, H, 6.0, work / "look.ass",
                    font=p.get("font", "Poppins ExtraBold"), accent=p.get("highlight", "#FF5900"),
                    cta=None, words=[{"w": "captions", "s": 0.9, "e": 1.3}], keyword_pop=bool(p.get("keyword_pop")))
    if g:
        ass_files.append(g)
    if p.get("captions", True):
        cap = dict(p.get("caption") or {})
        design = {**cap, "font": p.get("font"), "animation": p.get("animation", "static"),
                  "highlight": p.get("highlight", "#FFD400")}
        ass_files.append(build_ass(words, 0, 6, "fodo_orange", W, H, work / "caps.ass", design=design))
    fonts = Path(shutil.copytree(compose.FONTS_DIR, work / "fonts", dirs_exist_ok=True)).name
    for a in ass_files:
        chain.append(f"ass={a.name}:fontsdir={fonts}")
    inputs = ["-loop", "1", "-framerate", "10", "-t", "1.5", "-i", str(src.resolve())]
    graph = f"[0:v]{vf},setsar=1[base];[base]{','.join(chain) if chain else 'null'}[o]"
    if frame == "boxed":
        mask = compose.round_mask(W, H, compose.box_rect(W, H), work / "mask.png", radius=18)
        inputs += ["-loop", "1", "-i", str(mask.resolve())]
        graph = (f"[0:v]{vf},setsar=1[base];[base][1:v]overlay=0:0[m];"
                 f"[m]{','.join(chain) if chain else 'null'}[o]")
    cmd = ["ffmpeg", "-y", "-v", "error", *inputs, "-filter_complex", graph, "-map", "[o]",
           "-ss", f"{t_show}", "-frames:v", "1", "-q:v", "3", str((work / "out.jpg").resolve())]
    r = subprocess.run(cmd, cwd=str(work), capture_output=True, text=True)
    if r.returncode != 0:
        shutil.rmtree(work, ignore_errors=True)
        raise RuntimeError(r.stderr[-300:])
    (work / "out.jpg").replace(out)
    shutil.rmtree(work, ignore_errors=True)
    return out


def cache_key(*parts) -> str:
    return hashlib.sha1("|".join(str(x) for x in (PREVIEW_VER, *parts)).encode()).hexdigest()[:16]
