"""Background music from the internet - legally.

1. Openverse (api.openverse.org, free, no key): Creative-Commons / public-domain music from
   Jamendo, Freesound, Wikimedia Commons... Only licences that allow commercial use are
   offered; the attribution line is saved next to the file so it can go in the description.
2. Any link (YouTube Audio Library, NCS, SoundCloud, a direct .mp3 ...) via yt-dlp, audio only.
   The owner confirms they have the right to use the track - same rule as video import.
Files land in storage/music and appear in the music list like an upload.
"""
from __future__ import annotations

import json
import re
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from .url_import import UnsafeURL, validate_url

API = "https://api.openverse.org/v1/audio/"
UA = {"User-Agent": "FODO-ClipForge/0.6 (local video editor)"}
MAX_MUSIC_BYTES = 60 * 1024 * 1024
MAX_MUSIC_SECONDS = 15 * 60
AUDIO_EXT = (".mp3", ".m4a", ".wav", ".aac", ".ogg", ".flac", ".opus", ".webm")


def _get_json(url: str, timeout: int = 20) -> dict:
    req = urllib.request.Request(url, headers={**UA, "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:      # fixed host: api.openverse.org
        return json.loads(r.read().decode("utf-8"))


def _safe_name(s: str) -> str:
    s = re.sub(r"[^\w\- ]+", "", s or "track", flags=re.UNICODE).strip().replace(" ", "_")
    return (s or "track")[:60]


def search_openverse(q: str, page: int = 1, page_size: int = 12) -> dict:
    # by / by-sa / cc0 / pdm only: NC is not commercial, ND forbids putting the track under a video
    params = {"q": q or "background music", "category": "music", "license": "by,by-sa,cc0,pdm",
              "page": max(1, min(int(page), 20)), "page_size": max(1, min(int(page_size), 20)),
              "mature": "false"}
    try:
        d = _get_json(API + "?" + urllib.parse.urlencode(params))
    except urllib.error.HTTPError as e:
        raise UnsafeURL(f"Openverse returned HTTP {e.code}") from e
    except OSError as e:
        raise UnsafeURL("Could not reach Openverse - check the internet connection.") from e
    out = []
    for r in d.get("results", []):
        if (r.get("license") or "").lower() not in ("by", "by-sa", "cc0", "pdm"):
            continue
        dur = (r.get("duration") or 0) / 1000.0
        if dur and dur > MAX_MUSIC_SECONDS:
            continue
        out.append({"id": r.get("id"), "title": r.get("title") or "Untitled",
                    "creator": r.get("creator") or "", "license": (r.get("license") or "").upper(),
                    "license_version": r.get("license_version") or "", "license_url": r.get("license_url"),
                    "duration": round(dur, 1), "source": r.get("source") or r.get("provider"),
                    "preview": r.get("url"), "page": r.get("foreign_landing_url"),
                    "attribution": r.get("attribution") or "", "tags": [t.get("name") for t in (r.get("tags") or [])][:6]})
    return {"results": out, "count": d.get("result_count", len(out)), "page": params["page"],
            "pages": d.get("page_count", 1)}


def _download_audio(url: str, dest: Path, headers: dict | None = None) -> Path:
    validate_url(url)
    req = urllib.request.Request(url, headers={**UA, **(headers or {})})
    try:
        resp = urllib.request.urlopen(req, timeout=40)
    except urllib.error.HTTPError as e:
        raise UnsafeURL(f"Music server returned HTTP {e.code}") from e
    validate_url(resp.geturl())                                     # redirects must stay public
    ctype = (resp.headers.get("Content-Type") or "").split(";")[0].strip().lower()
    if not (ctype.startswith("audio/") or ctype in ("application/octet-stream", "application/ogg", "video/ogg")):
        raise UnsafeURL(f"Not an audio file (Content-Type: {ctype or 'unknown'}).")
    total = 0
    with dest.open("wb") as f:
        while chunk := resp.read(1024 * 256):
            total += len(chunk)
            if total > MAX_MUSIC_BYTES:
                f.close()
                dest.unlink(missing_ok=True)
                raise UnsafeURL("Music file is larger than 60 MB.")
            f.write(chunk)
    return dest


def fetch_openverse(item_id: str, dest_dir: Path) -> dict:
    if not re.fullmatch(r"[0-9a-fA-F-]{36}", item_id or ""):
        raise UnsafeURL("Bad track id")
    r = _get_json(f"{API}{item_id}/")
    lic = (r.get("license") or "").lower()
    if lic.startswith("by-nc") or lic in ("nc", "nc-sa", "nc-nd") or "nc" in lic.split("-"):
        raise UnsafeURL("This track does not allow commercial use.")
    url = r.get("url")
    if not url:
        raise UnsafeURL("Track has no downloadable file.")
    ext = Path(urllib.parse.urlparse(url).path).suffix.lower()
    ext = ext if ext in AUDIO_EXT else ".mp3"
    dest_dir.mkdir(parents=True, exist_ok=True)
    name = f"{_safe_name(r.get('title'))}_{item_id[:8]}{ext}"
    path = _download_audio(url, dest_dir / name)
    meta = {"title": r.get("title"), "creator": r.get("creator"), "license": r.get("license"),
            "license_version": r.get("license_version"), "license_url": r.get("license_url"),
            "source": r.get("source") or r.get("provider"), "page": r.get("foreign_landing_url"),
            "attribution": r.get("attribution") or f"\"{r.get('title')}\" by {r.get('creator')} "
                                                     f"({(r.get('license') or '').upper()} {r.get('license_version') or ''})",
            "from": "openverse"}
    path.with_suffix(path.suffix + ".json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"id": f"user:{path.name}", "name": path.stem, **meta}


def from_link(url: str, dest_dir: Path) -> dict:
    """Audio-only download of a track the owner has rights to (YouTube Audio Library, NCS, ...)."""
    import yt_dlp
    validate_url(url)
    dest_dir.mkdir(parents=True, exist_ok=True)

    def too_long(info, *, incomplete):
        if info.get("is_live"):
            return "Live streams can't be used as music."
        if info.get("duration") and info["duration"] > MAX_MUSIC_SECONDS:
            return "Track is longer than 15 minutes."
        return None

    stem = "link_" + re.sub(r"\W+", "", urllib.parse.urlparse(url).path)[-24:]
    opts = {"outtmpl": str(dest_dir / f"{stem}.%(ext)s"), "format": "bestaudio/best", "noplaylist": True,
            "max_filesize": MAX_MUSIC_BYTES, "match_filter": too_long, "quiet": True, "no_warnings": True,
            "js_runtimes": {"deno": {}, "node": {}}, "retries": 3, "socket_timeout": 30,
            "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "m4a"}]}
    with yt_dlp.YoutubeDL(opts) as ydl:
        try:
            info = ydl.extract_info(url, download=True)
        except yt_dlp.utils.DownloadError as e:
            raise UnsafeURL(str(e).replace("ERROR: ", "")[:300]) from e
    files = [f for f in dest_dir.glob(f"{stem}.*") if f.suffix.lower() in AUDIO_EXT]
    if not info or not files:
        raise UnsafeURL("No audio was downloaded from that link.")
    f = max(files, key=lambda p: p.stat().st_size)
    final = f.with_name(f"{_safe_name(info.get('title'))}_{stem[-6:]}{f.suffix}")
    f.replace(final)
    meta = {"title": info.get("title"), "creator": info.get("uploader"), "channel_id": info.get("channel_id"), "page": info.get("webpage_url") or url,
            "license": "owner-confirmed", "attribution": f"\"{info.get('title')}\" - {info.get('uploader') or ''}",
            "from": "link"}
    final.with_suffix(final.suffix + ".json").write_text(json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"id": f"user:{final.name}", "name": final.stem, **meta}


# ------------------------------------------------------------------ discovery ----
# What creators use per video type (researched Nov 2026). "trending" marks the styles that are
# currently the most used on Reels / Shorts / TikTok for that kind of video - it describes the
# STYLE, Openverse has no play counts, so no individual track is claimed to be a chart hit.
CATALOG: dict[str, dict] = {
    "podcast":     {"label": "Podcast / interview", "icon": "🎙", "keys": ["podcast", "interview", "talk", "baatcheet"],
                    "recommended": "lofi chill instrumental", "trending": ["chillhop", "lofi hip hop"],
                    "genres": ["ambient", "soft piano", "chillhop", "lofi hip hop", "acoustic"]},
    "story":       {"label": "Storytelling / history / crime", "icon": "📜", "keys": ["story", "history", "crime", "mystery", "kahani", "itihas"],
                    "recommended": "dark ambient cinematic", "trending": ["dark ambient"],
                    "genres": ["suspense", "dark ambient", "cinematic tension", "documentary"]},
    "motivation":  {"label": "Motivational / self-help", "icon": "🔥", "keys": ["motivation", "motivational", "inspire", "success", "self help"],
                    "recommended": "inspiring cinematic piano", "trending": ["epic cinematic"],
                    "genres": ["inspiring piano", "epic cinematic", "uplifting", "emotional strings"]},
    "gaming":      {"label": "Gaming", "icon": "🎮", "keys": ["gaming", "game", "gamer", "esports", "bgmi", "minecraft"],
                    "recommended": "phonk instrumental", "trending": ["drift phonk", "phonk"],
                    "genres": ["phonk", "drift phonk", "trap", "edm", "synthwave", "chiptune"]},
    "fitness":     {"label": "Gym / fitness / sports", "icon": "💪", "keys": ["gym", "fitness", "workout", "sports", "cricket"],
                    "recommended": "phonk workout", "trending": ["drift phonk", "drill beat"],
                    "genres": ["phonk", "trap", "drill beat", "edm", "rock"]},
    "vlog":        {"label": "Vlog / lifestyle / travel", "icon": "✈", "keys": ["vlog", "travel", "lifestyle", "fashion", "beauty", "food"],
                    "recommended": "upbeat acoustic happy", "trending": ["latin", "tropical house"],
                    "genres": ["acoustic", "upbeat pop", "latin", "tropical house", "chill"]},
    "tech":        {"label": "Tech / tutorial / business", "icon": "💻", "keys": ["tech", "tutorial", "business", "finance", "startup", "explainer"],
                    "recommended": "corporate electronic minimal", "trending": ["ambient electronic"],
                    "genres": ["corporate", "minimal electronic", "ambient electronic", "lofi"]},
    "comedy":      {"label": "Comedy / fun", "icon": "😂", "keys": ["comedy", "funny", "meme", "fun", "prank"],
                    "recommended": "funny quirky ukulele", "trending": ["quirky"],
                    "genres": ["quirky", "ukulele", "cartoon", "comedic"]},
    "indian":      {"label": "Indian / devotional", "icon": "🪔", "keys": ["indian", "devotional", "bhajan", "spiritual", "desi", "bollywood", "mantra"],
                    "recommended": "indian flute instrumental", "trending": ["indian lofi"],
                    "genres": ["indian flute", "sitar", "tabla", "indian lofi", "meditation"]},
    "cinematic":   {"label": "Cinematic / documentary", "icon": "🎬", "keys": ["cinematic", "documentary", "film", "trailer", "emotional"],
                    "recommended": "cinematic emotional orchestral", "trending": ["epic cinematic"],
                    "genres": ["orchestral", "ambient", "emotional piano", "epic cinematic"]},
}
TRENDING_STYLES = {"phonk", "drift phonk", "lofi hip hop", "chillhop", "hyperpop", "drill beat", "ambient electronic",
                   "latin", "tropical house", "epic cinematic", "indian lofi", "dark ambient", "quirky"}
_cache: dict[tuple, tuple[float, dict]] = {}


def _cached_search(q: str, page: int = 1) -> dict:
    import time
    k = (q.lower().strip(), page)
    hit = _cache.get(k)
    if hit and time.time() - hit[0] < (3600 if hit[1].get("results") else 300):
        return hit[1]
    r = search_openverse(q, page)
    _cache[k] = (time.time(), r)
    return r


_FILLER = {"instrumental", "music", "background", "beat", "beats", "track", "song", "style", "the", "and", "for"}


def _wide_search(query: str, need: int) -> list[dict]:
    """Openverse matches every word, so 'drift phonk instrumental' often finds nothing.
    Try the full query, then without filler words, then each keyword, then a broad fallback."""
    tries = [query]
    words = [w for w in re.findall(r"[a-z0-9]+", query.lower()) if w not in _FILLER]
    if words and " ".join(words) != query.lower():
        tries.append(" ".join(words))
    tries += [w for w in words if len(w) >= 4]
    tries.append("instrumental")
    out, ids, last_err = [], set(), None
    for q in dict.fromkeys(tries):
        try:
            res = _cached_search(q)["results"]
        except UnsafeURL as e:
            last_err = e
            continue
        for r in res:
            if r["id"] not in ids:
                ids.add(r["id"]); out.append(r)
        if sum(1 for r in out if _good(r)) >= need:
            break
    if not out and last_err:
        raise last_err
    return out


def detect_category(q: str) -> str | None:
    low = (q or "").lower()
    for key, c in CATALOG.items():
        if key in low or any(k in low for k in c["keys"]):
            return key
    return None


_VOCAL = re.compile(r"\b(vocal|vocals|lyrics?|song|singing|sung|rap|feat\.?|remix)\b", re.I)


def _good(r: dict) -> bool:
    text = f"{r['title']} {' '.join(t or '' for t in r.get('tags') or [])}"
    return not _VOCAL.search(text) and (r.get("duration") or 0) >= 45


def discover(q: str = "", category: str | None = None, genre: str | None = None) -> dict:
    """Search by video type and/or genre. Returns ⭐ recommended, 🔥 trending-style and more."""
    cat = category if category in CATALOG else detect_category(q)
    c = CATALOG.get(cat or "", None)
    groups, seen = [], set()

    def add(title: str, icon: str, query: str, tag: str, limit: int = 6):
        try:
            res = _wide_search(query, limit)
        except UnsafeURL as e:
            groups.append({"title": title, "icon": icon, "query": query, "error": str(e), "results": []})
            return
        picked = []
        for r in sorted(res, key=lambda r: (not _good(r), -(r.get("duration") or 0) if (r.get("duration") or 0) < 240 else 0)):
            if r["id"] in seen:
                continue
            seen.add(r["id"])
            picked.append({**r, "badge": tag, "instrumental": _good(r)})
            if len(picked) >= limit:
                break
        groups.append({"title": title, "icon": icon, "query": query, "results": picked})

    if genre:
        add(f"{genre.title()}", "🔥" if genre.lower() in TRENDING_STYLES else "🎵", f"{genre} instrumental",
            "trending" if genre.lower() in TRENDING_STYLES else "")
    if c:
        add(f"Recommended for {c['label']}", "⭐", c["recommended"], "recommended")
        for t in c["trending"][:1]:
            add(f"Trending style: {t}", "🔥", f"{t} instrumental", "trending")
    raw = (q or "").strip()
    if raw and (not c or raw.lower() not in c["keys"] + [cat]):
        add(f"Results for “{raw}”", "🎵", raw, "")
    if not groups:
        add("Recommended for talking videos", "⭐", "lofi chill instrumental", "recommended")
    cats = [{"id": k, "label": v["label"], "icon": v["icon"],
             "genres": [{"name": g, "trending": g in TRENDING_STYLES} for g in v["genres"]]} for k, v in CATALOG.items()]
    return {"category": cat, "groups": groups, "categories": cats}
