"""Per-style motion graphics: titles, lower thirds, keyword pops and ending cards.

Each edit style ("look") copies how a real creator family packages a clip (researched on
Instagram / YouTube Shorts, Nov 2026):

  top_box     Hormozi 2026 - persistent black headline box at the top; it turns into the
              call-to-action for the last seconds ("COMMENT 'X'", "FOLLOW FOR MORE").
  open_box    Diary of a CEO - white box, black caps, big statement for the first seconds.
  center      Official TV-show pages (TMKOC, SAB) - one line of white text with a soft shadow
              in the lower middle, on screen the whole clip.
  lower_third Documentary (Dhruv Rathee style) - accent label sliding in from the left.
  premise     Comedy skits - small white pill with the relatable premise, whole clip.
  spaced      Vlogs - big letter-spaced title at the top for the opening, "WATCH FULL VIDEO" end.
Keyword pop (Figuring Out style): now and then one key word appears huge and glowing yellow.
"""
from __future__ import annotations

from pathlib import Path

TITLE_KINDS = {
    "top_box": "Headline box on top (turns into a call-to-action at the end)",
    "open_box": "White statement box for the first seconds",
    "center": "TV-page title line, whole clip",
    "lower_third": "Documentary name label (slides in)",
    "premise": "Small premise pill on top, whole clip",
    "spaced": "Big spaced title + end card",
    "clip_page": "Clip-page headline above the video box (white + accent key word)",
    "big_hook": "Huge 2-line hook words for the first seconds",
    "premise_box": "White rounded premise box for the first seconds (stream / meme)",
    "white_top": "Black premise text on the white top area (meme template)",
    "versus": "Persistent 2-colour title on top (gameplay)",
    "cinema_label": "Small label in the cinema bar",
    "none": "No title",
}

_STOP = set("""a an the and or but so if then than that this those these there here is are was were be
been being am i you he she it we they me him her us them my your his its our their to of in on at by
for with from up down out over into about as just very really also too not no yes do does did done
have has had will would can could should may might must shall what which who whom whose when where why
how all any some more most much many such only own same other each both few again once ever even still
like get got going go gonna wanna yeah okay ok um uh hmm actually basically literally thing things
because something anything everything nothing someone everyone people time""".split())


def _t(t: float) -> str:
    t = max(0.0, t)
    return f"{int(t // 3600)}:{int(t % 3600 // 60):02d}:{t % 60:05.2f}"


def _clean(text: str) -> str:
    t = (text or "").replace("{", "").replace("}", "").replace("\\", "").replace("\n", " ")
    # emoji / pictographs: the bundled fonts have no glyphs for them (they would render as boxes)
    t = "".join(ch for ch in t if ord(ch) < 0x2190 or 0x0900 <= ord(ch) <= 0x097F)
    return " ".join(t.split()).strip()


def _accent_word(words: list[str]) -> int:
    """Index of the word to colour in a headline: a name / proper noun, else the longest word."""
    best, score = 0, -1
    for i, w in enumerate(words):
        k = "".join(ch for ch in w.lower() if ch.isalnum())
        if not k or k in _STOP:
            continue
        sc = len(k) + (4 if i > 0 and w[:1].isupper() else 0) + (3 if any(c.isdigit() for c in k) else 0)
        if sc > score:
            best, score = i, sc
    return best


def _wrap(text: str, max_chars: int) -> str:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if cur and len(cur) + 1 + len(w) > max_chars:
            lines.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return "\\N".join(lines[:3])


def _wrap_tagged(text: str, max_chars: int) -> str:
    """_wrap for text that contains {\\c...} colour tags (tags do not count as characters)."""
    import re as _re
    words, lines, cur, cur_len = text.split(" "), [], [], 0
    for w in words:
        n = len(_re.sub(r"\{[^}]*\}", "", w))
        if cur and cur_len + 1 + n > max_chars:
            lines.append(" ".join(cur))
            cur, cur_len = [w], n
        else:
            cur.append(w)
            cur_len += n + (1 if cur_len else 0)
    if cur:
        lines.append(" ".join(cur))
    return "\\N".join(lines[:3])


def keyword_moments(words: list[dict], total: float, every: float = 11.0) -> list[dict]:
    """Pick at most one 'strong' word per ~11 s (long, not a filler word, prefer words the
    speaker stressed by pausing after them)."""
    out, last = [], -every * 0.6
    for i, w in enumerate(words):
        raw = (w.get("w") or "").strip()
        key = "".join(ch for ch in raw.lower() if ch.isalnum())
        if len(key) < 5 or key in _STOP or not key.isalpha():
            continue
        if w["s"] - last < every or w["s"] < 1.2 or w["e"] > total - 2.5:
            continue
        nxt = words[i + 1]["s"] if i + 1 < len(words) else w["e"] + 1
        stress = (nxt - w["e"]) + len(key) * 0.03
        if stress < 0.18:
            continue
        out.append({"t": w["s"], "w": "".join(ch for ch in raw if ch.isalnum() or ch in "'-")})
        last = w["s"]
    return out


def build(kind: str, title: str | None, play_w: int, play_h: int, total: float, out_path: Path,
          font: str = "Poppins ExtraBold", accent: str = "#FF5900", cta: str | None = None,
          words: list[dict] | None = None, keyword_pop: bool = False,
          keyword_color: str = "#FFE600", flash: bool = False) -> Path | None:
    """ASS file with the look's graphics; None when the look has nothing to draw."""
    from .captions import FONTS, hex_to_ass
    fam = FONTS.get(font, font)
    title = _clean(title or "")
    cta = _clean(cta or "")
    W, H = play_w, play_h
    acc = hex_to_ass(accent)
    kc = hex_to_ass(keyword_color)
    styles, ev = [], []

    def style(name, fnt, size, prim, outl, back, bold, italic, border, outline, shadow, align, ml, mr, mv, spacing=0):
        styles.append(f"Style: {name},{fnt},{int(size)},{prim},{prim},{outl},{back},{bold},{italic},0,0,"
                      f"100,100,{spacing},0,{border},{outline},{shadow},{align},{ml},{mr},{int(mv)},1")

    white, black = "&H00FFFFFF", "&H00000000"
    end_cta = total - 2.4 if cta and total > 8 else total
    if kind == "top_box" and title:
        style("TB", "Poppins ExtraBold", W * 0.062, white, black, black, 1, 1, 3, 18, 0, 8, 70, 70, H * 0.12)
        txt = _wrap(title.upper(), 20)
        ev.append(f"Dialogue: 2,{_t(0)},{_t(end_cta)},TB,,0,0,0,,{{\\fad(120,150)\\fscx70\\fscy70"
                  f"\\t(0,160,\\fscx104\\fscy104)\\t(160,260,\\fscx100\\fscy100)}}{txt}")
    elif kind == "open_box" and title:
        style("OB", "Archivo Black", W * 0.058, black, white, white, 1, 0, 3, 16, 0, 2, 90, 90, H * 0.30)
        txt = _wrap(title.upper(), 20)
        ev.append(f"Dialogue: 2,{_t(0)},{_t(min(3.4, total - 0.5))},OB,,0,0,0,,{{\\fad(80,250)\\fscx60\\fscy60"
                  f"\\t(0,150,\\fscx106\\fscy106)\\t(150,260,\\fscx100\\fscy100)}}{txt}")
    elif kind == "center" and title:
        style("TC", "Poppins ExtraBold", W * 0.074, white, "&H64000000", black, 1, 0, 1, 2, 3, 2, 70, 70, H * 0.30)
        txt = _wrap(title, 18)
        ev.append(f"Dialogue: 2,{_t(0)},{_t(total)},TC,,0,0,0,,{{\\fad(250,400)\\blur0.6}}{txt}")
    elif kind == "lower_third" and title:
        style("LT", fam if fam else "Archivo Black", W * 0.046, white, acc, acc, 1, 0, 3, 14, 0, 1, 60, 60, H * 0.30)
        txt = _wrap(title.upper(), 22)
        y = int(H * 0.70)
        ev.append(f"Dialogue: 2,{_t(0.6)},{_t(min(5.2, total - 0.6))},LT,,0,0,0,,"
                  f"{{\\an1\\move(-{W},{y},70,{y},0,320)\\fad(0,300)}}{txt}")
    elif kind == "premise" and title:
        style("PR", "Poppins ExtraBold", W * 0.054, black, white, white, 1, 0, 3, 14, 0, 8, 80, 80, H * 0.15)
        txt = _wrap(title, 26)
        ev.append(f"Dialogue: 2,{_t(0)},{_t(total)},PR,,0,0,0,,{{\\fad(200,300)}}{txt}")
    elif kind == "spaced" and title:
        style("SP", "Archivo Black", W * 0.085, white, "&H50000000", black, 1, 0, 1, 0, 4, 8, 60, 60, H * 0.12, spacing=8)
        txt = _wrap(title.upper(), 14)
        ev.append(f"Dialogue: 2,{_t(0)},{_t(min(3.6, total - 0.5))},SP,,0,0,0,,{{\\fad(300,400)}}{txt}")
    elif kind == "clip_page" and title:
        # black clip-page template: headline above the video box, one accent word
        style("CP", "Archivo Black", W * 0.07, white, black, black, 1, 0, 1, 0, 0, 2, 60, 60, H - H * 0.215)
        ws_ = title.split()
        k = _accent_word(ws_)
        txt = " ".join((f"{{\\c{acc}}}{w}{{\\c{white}}}" if i == k else w) for i, w in enumerate(ws_))
        ev.append(f"Dialogue: 2,{_t(0)},{_t(total)},CP,,0,0,0,,{{\\fad(200,0)\\q0}}{_wrap_tagged(txt, 22)}")
    elif kind == "big_hook" and title:
        # DOAC / Chris Williamson: huge hook words, last line in the accent colour
        style("BH", "Archivo Black", W * 0.1, white, black, black, 1, 0, 1, 5, 2, 5, 40, 40, 0)
        short = " ".join(title.split()[:6])
        lines = _wrap(short.upper(), 14).split("\\N")
        txt = "\\N".join((f"{{\\c{acc}}}{l}" if i == len(lines) - 1 and len(lines) > 1 else l)
                          for i, l in enumerate(lines))
        ev.append(f"Dialogue: 3,{_t(0)},{_t(min(2.6, total - 0.5))},BH,,0,0,0,,{{\\fad(0,180)\\pos({W // 2},{int(H * 0.36)})"
                  f"\\fscx130\\fscy130\\t(0,140,\\fscx100\\fscy100)}}{txt}")
    elif kind == "premise_box" and title:
        style("PB", "Poppins ExtraBold", W * 0.05, black, white, white, 1, 0, 3, 16, 0, 8, 90, 90, H * 0.05)
        ev.append(f"Dialogue: 3,{_t(0)},{_t(min(3.2, total - 0.5))},PB,,0,0,0,,{{\\fad(100,220)\\fscx85\\fscy85"
                  f"\\t(0,140,\\fscx100\\fscy100)}}{_wrap(title, 26)}")
    elif kind == "white_top" and title:
        style("WT", "Poppins ExtraBold", W * 0.068, black, white, white, 1, 0, 1, 0, 0, 5, 70, 70, 0)
        ev.append(f"Dialogue: 2,{_t(0)},{_t(total)},WT,,0,0,0,,{{\\pos({W // 2},{int(H * 0.12)})}}{_wrap(title, 22)}")
    elif kind == "versus" and title:
        style("VS", "Archivo Black", W * 0.072, white, black, black, 1, 0, 1, 5, 2, 8, 60, 60, H * 0.07)
        ws_ = title.upper().split()
        half = (len(ws_) + 1) // 2
        txt = " ".join(ws_[:half]) + "\\N" + f"{{\\c{kc}}}" + " ".join(ws_[half:]) if len(ws_) > 2 else " ".join(ws_)
        ev.append(f"Dialogue: 2,{_t(0)},{_t(total)},VS,,0,0,0,,{{\\fad(150,0)}}{txt}")
    elif kind == "cinema_label" and title:
        style("CL", "Poppins SemiBold", W * 0.036, "&H00DDDDDD", black, black, 1, 0, 1, 0, 0, 8, 60, 60, H * 0.27)
        ev.append(f"Dialogue: 2,{_t(0)},{_t(total)},CL,,0,0,0,,{{\\fad(400,0)}}{title.upper()[:48]}")
    # colour flash on the strongest moments (stream / meme edits)
    if flash and words:
        for k in keyword_moments(words, total, every=7.0)[:4]:
            ev.append(f"Dialogue: 1,{_t(k["t"])},{_t(k["t"] + 0.16)},FL,,0,0,0,,"
                      f"{{\\an7\\pos(0,0)\\1c{acc}\\1a&HA8&\\bord0\\shad0\\fad(0,180)\\p1}}m 0 0 l {W} 0 {W} {H} 0 {H}{{\\p0}}")
        style("FL", "Arial", 20, white, black, black, 0, 0, 1, 0, 0, 7, 0, 0, 0)
    # call-to-action / end card
    if cta and total > 8:
        if kind == "top_box":
            style("CTA", "Poppins ExtraBold", W * 0.062, white, black, black, 1, 1, 3, 18, 0, 8, 70, 70, H * 0.12)
        elif kind == "spaced":
            style("CTA", "Archivo Black", W * 0.075, white, "&H50000000", black, 1, 0, 1, 0, 4, 5, 60, 60, 0, spacing=8)
        else:
            style("CTA", "Poppins ExtraBold", W * 0.05, black, white, white, 1, 0, 3, 16, 0, 5, 90, 90, 0)
        ev.append(f"Dialogue: 3,{_t(end_cta)},{_t(total)},CTA,,0,0,0,,{{\\fad(100,0)\\fscx60\\fscy60"
                  f"\\t(0,160,\\fscx106\\fscy106)\\t(160,260,\\fscx100\\fscy100)}}{_wrap(cta.upper(), 22)}")
    # keyword pops
    if keyword_pop and words:
        style("KW", "Archivo Black", W * 0.15, kc, "&H3000B4FF", black, 1, 0, 1, 9, 0, 2, 40, 40, H * 0.30)
        for k in keyword_moments(words, total):
            txt = k["w"][:14]
            if len(txt) > 9:
                txt = f"{{\\fs{int(W * 0.15 * 9 / len(txt))}}}" + txt
            ev.append(f"Dialogue: 4,{_t(k['t'])},{_t(k['t'] + 1.25)},KW,,0,0,0,,{{\\fad(60,200)\\blur9"
                      f"\\fscx50\\fscy50\\t(0,140,\\fscx108\\fscy108)\\t(140,240,\\fscx100\\fscy100)}}{txt}")
            # sharp copy on top of the glow
            ev.append(f"Dialogue: 5,{_t(k['t'])},{_t(k['t'] + 1.25)},KW,,0,0,0,,{{\\fad(60,200)\\bord0"
                      f"\\fscx50\\fscy50\\t(0,140,\\fscx108\\fscy108)\\t(140,240,\\fscx100\\fscy100)}}{txt}")
    if not ev:
        return None
    ass = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 0

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
{chr(10).join(styles)}

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
{chr(10).join(ev)}
"""
    out_path = Path(out_path)
    out_path.write_text(ass, encoding="utf-8")
    return out_path


def merge(a: Path, b: Path | None) -> Path:
    """Append b's styles and events to a (both are our own ASS files)."""
    if not b:
        return a
    ta, tb = Path(a).read_text(encoding="utf-8"), Path(b).read_text(encoding="utf-8")
    sb = [l for l in tb.splitlines() if l.startswith("Style:")]
    eb = [l for l in tb.splitlines() if l.startswith("Dialogue:")]
    head, events = ta.split("[Events]", 1)
    head = head.rstrip("\n") + "\n" + "\n".join(sb) + "\n\n"
    Path(a).write_text(head + "[Events]" + events.rstrip("\n") + "\n" + "\n".join(eb) + "\n", encoding="utf-8")
    return Path(a)


def ranking_ass(title: str, labels: list[str], starts: list[tuple[float, float]], W: int, H: int,
                total: float, out_path: Path, accent: str = "#FFD400") -> Path:
    """'TOP N' title + a numbered list that fills in as each entry plays (counting down to #1)."""
    from .captions import hex_to_ass
    n = len(labels)
    acc = hex_to_ass(accent)
    white, black = "&H00FFFFFF", "&H00000000"
    head = _clean(title)
    words = head.split()
    t1 = f"TOP {n}"
    t2 = " ".join(words[:5]).upper()
    lines = [
        f"Style: RT,Archivo Black,{int(W * 0.085)},{white},{white},{black},{black},1,1,0,0,100,100,0,0,1,6,2,7,50,50,{int(H * 0.04)},1",
        f"Style: RN,Archivo Black,{int(W * 0.052)},{acc},{acc},{black},{black},1,0,0,0,100,100,0,0,1,4,1,7,50,50,0,1",
        f"Style: RL,Poppins ExtraBold,{int(W * 0.042)},{white},{white},{black},{black},1,0,0,0,100,100,0,0,1,4,1,7,50,50,0,1",
    ]
    ev = [f"Dialogue: 5,{_t(0)},{_t(total)},RT,,0,0,0,,{t1}\\N{{\\c{acc}\\fs{int(W * 0.06)}}}{t2}"]
    y0, step = int(H * 0.17), int(W * 0.068)
    for r in range(1, n + 1):
        y = y0 + (r - 1) * step
        ev.append(f"Dialogue: 5,{_t(0)},{_t(total)},RN,,0,0,0,,{{\\pos({int(W * 0.05)},{y})}}{r}.")
    for k, (lab, (st, _d)) in enumerate(zip(labels, starts)):
        r = n - k                                      # first entry played is #N
        y = y0 + (r - 1) * step
        txt = _clean(lab)[:26]
        ev.append(f"Dialogue: 5,{_t(st)},{_t(total)},RL,,0,0,0,,{{\\pos({int(W * 0.13)},{y})\\fad(150,0)"
                  f"\\fscx70\\fscy70\\t(0,150,\\fscx100\\fscy100)}}{txt}")
    ass = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
{chr(10).join(lines)}

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
{chr(10).join(ev)}
"""
    out_path = Path(out_path)
    out_path.write_text(ass, encoding="utf-8")
    return out_path
