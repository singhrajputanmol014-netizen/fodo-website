"""Smart auto-reframing: face-aware crop with smooth interpolation.

Samples frames in the clip range, detects faces (OpenCV Haar cascade — no
model download needed), takes the temporal median of face centres, and
produces a single stable crop window (no sudden jumps). If no face is found,
falls back to centre crop. Manual override supported via crop_x_frac.
"""
from __future__ import annotations

import subprocess
import tempfile
from pathlib import Path

import cv2
import numpy as np


_CASCADE_VENDORED = Path(__file__).parent / "assets" / "haarcascade_frontalface_default.xml"


def _load_cascade() -> "cv2.CascadeClassifier | None":
    """Vendored cascade first (OpenCV 5 no longer bundles data), else cv2.data."""
    candidates = [_CASCADE_VENDORED]
    data_dir = getattr(getattr(cv2, "data", None), "haarcascades", None)
    if data_dir:
        candidates.append(Path(data_dir) / "haarcascade_frontalface_default.xml")
    # OpenCV 5 moved Haar cascades to the contrib build (cv2 or cv2.xobjdetect).
    ctor = getattr(cv2, "CascadeClassifier", None) or getattr(
        getattr(cv2, "xobjdetect", None), "CascadeClassifier", None)
    if ctor is None:
        return None
    for c in candidates:
        if c.exists():
            try:
                cascade = ctor(str(c))
            except Exception:  # noqa: BLE001
                continue
            if not cascade.empty():
                return cascade
    return None


def detect_face_center(video_path: str | Path, start: float, end: float,
                       samples: int = 7) -> float | None:
    """Return median horizontal face-centre as fraction of width, or None."""
    cascade = _load_cascade()
    if cascade is None:
        return None  # graceful fallback to centre crop
    centers: list[float] = []
    with tempfile.TemporaryDirectory() as td:
        for i in range(samples):
            t = start + (end - start) * (i + 0.5) / samples
            frame_path = Path(td) / f"f{i}.jpg"
            r = subprocess.run(
                ["ffmpeg", "-y", "-v", "error", "-ss", f"{t:.3f}", "-i", str(video_path),
                 "-frames:v", "1", "-q:v", "4", str(frame_path)],
                capture_output=True,
            )
            if r.returncode != 0 or not frame_path.exists():
                continue
            img = cv2.imread(str(frame_path))
            if img is None:
                continue
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            faces = cascade.detectMultiScale(gray, 1.1, 5, minSize=(40, 40))
            if len(faces):
                # largest face
                x, y, w, h = max(faces, key=lambda f: f[2] * f[3])
                centers.append((x + w / 2) / img.shape[1])
    if not centers:
        return None
    return float(np.median(centers))


def crop_filter(src_w: int, src_h: int, out_w: int, out_h: int,
                center_x_frac: float | None) -> str:
    """Build an ffmpeg crop+scale filter string for the target aspect."""
    target_ar = out_w / out_h
    src_ar = src_w / src_h
    cx = 0.5 if center_x_frac is None else float(np.clip(center_x_frac, 0.0, 1.0))
    if src_ar > target_ar:
        # crop width
        crop_w = int(src_h * target_ar) // 2 * 2
        max_x = src_w - crop_w
        x = int(np.clip(cx * src_w - crop_w / 2, 0, max_x))
        crop = f"crop={crop_w}:{src_h}:{x}:0"
    else:
        # crop height (keep top-biased framing for faces)
        crop_h = int(src_w / target_ar) // 2 * 2
        max_y = src_h - crop_h
        y = int(np.clip(src_h * 0.4 - crop_h / 2, 0, max_y))
        crop = f"crop={src_w}:{crop_h}:0:{y}"
    return f"{crop},scale={out_w}:{out_h}:flags=lanczos,setsar=1"
