"""Social growth API: /api/growth/* — posting slots, planner ideas, Autopilot rules (see app/growth.py)."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from .. import growth as G
from .. import publish as P
from ..auth import current_user, require_role
from ..models import User

router = APIRouter(prefix="/api/growth")


def _bad(e: Exception):
    raise HTTPException(400, str(e)) from e


@router.get("/state")
def state(user: User = Depends(current_user)):
    return G.state()


@router.get("/slots/{ws}")
def slots(ws: str, user: User = Depends(current_user)):
    return {**G.get_slots(ws), "next": G.upcoming_slots(ws, 10, include_taken=True)}


@router.put("/slots/{ws}")
def set_slots(ws: str, payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return G.set_slots(ws, payload.get("times") or {})
    except ValueError as e:
        _bad(e)


@router.post("/ideas")
def save_idea(payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return G.save_idea(payload)
    except ValueError as e:
        _bad(e)


@router.delete("/ideas/{iid}")
def delete_idea(iid: str, user: User = Depends(require_role("editor"))):
    G.delete_idea(iid)
    return {"ok": True}


@router.post("/ideas/ai")
def ai_ideas(payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return {"ideas": G.ai_ideas(payload.get("workspace"), str(payload.get("topic") or ""),
                                    max(3, min(12, int(payload.get("n") or 8))))}
    except ValueError as e:
        _bad(e)


@router.post("/rules")
def save_rule(payload: dict, user: User = Depends(require_role("editor"))):
    try:
        return G.save_rule(payload)
    except (ValueError, TypeError) as e:
        _bad(e)


@router.delete("/rules/{rid}")
def delete_rule(rid: str, user: User = Depends(require_role("editor"))):
    G.delete_rule(rid)
    return {"ok": True}


@router.post("/rules/{rid}/run")
def run_rule(rid: str, user: User = Depends(require_role("editor"))):
    try:
        return G.run_rule(rid, force=True)
    except ValueError as e:
        _bad(e)


@router.post("/posts/{pid}/approve")
def approve(pid: str, user: User = Depends(require_role("editor"))):
    try:
        return P.approve_post(pid)
    except ValueError as e:
        _bad(e)
