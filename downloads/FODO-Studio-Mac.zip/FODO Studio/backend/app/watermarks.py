"""Watermark / logo library: upload, list, delete, background removal.

Files: storage/watermarks/<id>.png (always RGBA PNG) + <id>.json (name, created, source).
Background removal:
  * "flat"  - the logo sits on a plain colour (white, black, any solid): flood-fill from the
              border with a colour tolerance, then a 1-px soft edge. Exact for most logos.
  * "ai"    - U²-Net (u2netp, Apache-2.0, 4.7 MB ONNX from the rembg project) run with OpenCV DNN,
              for photos / gradients. Downloaded once to storage/models on first use.
  * "auto"  - "flat" when the border is one colour, else "ai".
"""
from __future__ import annotations

import io
import json
import time
import urllib.request
import uuid
from pathlib import Path

from .config import STORAGE_DIR

DIR = STORAGE_DIR / "watermarks"
MODEL_DIR = STORAGE_DIR / "models"
U2NETP_URL = "https://github.com/danielgatis/rembg/releases/download/v0.0.0/u2netp.onnx"
MAX_BYTES = 10 * 1024 * 1024


def _meta_path(wid: str) -> Path:
    return DIR / f"{wid}.json"


def list_all() -> list[dict]:
    out = []
    if DIR.exists():
        for j in sorted(DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                m = json.loads(j.read_text(encoding="utf-8"))
            except ValueError:
                continue
            if (DIR / f"{m['id']}.png").exists():
                out.append(m)
    return out


def path_of(wid: str) -> Path | None:
    p = DIR / f"{wid}.png"
    return p if len(wid) == 12 and wid.isalnum() and p.exists() else None


def save(data: bytes, name: str, source: str = "upload") -> dict:
    from PIL import Image
    if len(data) > MAX_BYTES:
        raise ValueError("Logo file is larger than 10 MB")
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception as e:  # noqa: BLE001
        raise ValueError("That file is not an image (use PNG, JPG or WebP)") from e
    im = im.convert("RGBA")
    if max(im.size) > 2000:
        im.thumbnail((2000, 2000))
    DIR.mkdir(parents=True, exist_ok=True)
    wid = uuid.uuid4().hex[:12]
    im.save(DIR / f"{wid}.png")
    m = {"id": wid, "name": (name or "Logo").strip()[:60], "w": im.width, "h": im.height,
         "created": int(time.time()), "source": source, "transparent": _has_alpha(im)}
    _meta_path(wid).write_text(json.dumps(m, ensure_ascii=False), encoding="utf-8")
    return m


def delete(wid: str) -> bool:
    p = path_of(wid)
    if not p:
        return False
    p.unlink(missing_ok=True)
    _meta_path(wid).unlink(missing_ok=True)
    return True


def _has_alpha(im) -> bool:
    return im.mode == "RGBA" and im.getchannel("A").getextrema()[0] < 250


# ------------------------------------------------------------------ background removal --
def _border_is_flat(im, tol: int = 28) -> tuple[bool, tuple]:
    import numpy as np
    a = np.asarray(im.convert("RGB")).astype(int)
    b = np.concatenate([a[0], a[-1], a[:, 0], a[:, -1]])
    med = np.median(b, axis=0)
    close = (np.abs(b - med).max(axis=1) <= tol).mean()
    return close >= 0.85, tuple(int(x) for x in med)


def _flood(im, tol: int):
    import numpy as np
    rgba = np.asarray(im.convert("RGBA")).copy()
    rgb = rgba[..., :3].astype(int)
    _, bg = _border_is_flat(im, tol)
    diff = np.abs(rgb - np.array(bg)).max(axis=2)
    cand = diff <= tol
    # keep only the background-coloured regions that touch the border
    import cv2
    n, lab = cv2.connectedComponents(cand.astype("uint8"), connectivity=4)
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    seen = np.isin(lab, list(border)) & cand
    alpha = rgba[..., 3].astype(float)
    # soft edge: pixels close to the background colour but not connected stay; near-bg edge pixels fade
    soft = np.clip((diff - tol * 0.5) / (tol * 0.5 + 1e-6), 0, 1)
    alpha = np.where(seen, 0, alpha)
    edge = np.zeros_like(seen)
    edge[1:, :] |= seen[:-1, :]
    edge[:-1, :] |= seen[1:, :]
    edge[:, 1:] |= seen[:, :-1]
    edge[:, :-1] |= seen[:, 1:]
    edge &= ~seen
    alpha = np.where(edge, alpha * soft, alpha)
    rgba[..., 3] = alpha.astype("uint8")
    from PIL import Image
    return Image.fromarray(rgba, "RGBA")


def _model() -> Path:
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    p = MODEL_DIR / "u2netp.onnx"
    if not p.exists() or p.stat().st_size < 1_000_000:
        tmp = p.with_suffix(".part")
        req = urllib.request.Request(U2NETP_URL, headers={"User-Agent": "FODO-ClipForge"})
        with urllib.request.urlopen(req, timeout=60) as r, tmp.open("wb") as f:
            while chunk := r.read(1 << 16):
                f.write(chunk)
        tmp.replace(p)
    return p


def remove_ai(im):
    import cv2
    import numpy as np
    from PIL import Image
    net = cv2.dnn.readNetFromONNX(str(_model()))
    rgb = np.asarray(im.convert("RGB")).astype(np.float32) / 255.0
    x = cv2.resize(rgb, (320, 320), interpolation=cv2.INTER_AREA)
    x = (x / max(float(x.max()), 1e-6) - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
    blob = x.transpose(2, 0, 1)[None].astype(np.float32)
    net.setInput(blob)
    pred = net.forward()[0, 0]
    pred = (pred - pred.min()) / max(float(pred.max() - pred.min()), 1e-6)
    mask = cv2.resize(pred, (im.width, im.height), interpolation=cv2.INTER_LINEAR)
    rgba = np.asarray(im.convert("RGBA")).copy()
    rgba[..., 3] = (np.minimum(rgba[..., 3] / 255.0, mask) * 255).astype("uint8")
    return Image.fromarray(rgba, "RGBA")


def remove_background(wid: str, method: str = "auto", tol: int = 40) -> dict:
    from PIL import Image
    p = path_of(wid)
    if not p:
        raise ValueError("Logo not found")
    im = Image.open(p).convert("RGBA")
    flat, bg = _border_is_flat(im)
    used = method
    if method == "auto":
        used = "flat" if flat else "ai"
    if used == "flat":
        out = _flood(im, max(5, min(120, int(tol))))
        note = f"plain background rgb{bg} removed"
    else:
        try:
            out = remove_ai(im)
            note = "AI background removal (U²-Net)"
        except Exception as e:  # noqa: BLE001 - no internet for the model, unsupported op ...
            if not flat:
                raise ValueError(f"AI background removal is not available: {e}") from e
            out, used, note = _flood(im, tol), "flat", "AI unavailable - plain background removed"
    buf = io.BytesIO()
    out.save(buf, "PNG")
    old = json.loads(_meta_path(wid).read_text(encoding="utf-8"))
    m = save(buf.getvalue(), f"{old.get('name', 'Logo')} (no bg)", source=f"bg-removed:{used}")
    m["note"] = note
    return m
