"""Visual analysis: scene cuts with FFmpeg's scene filter, streamed with progress.

No proxy file and no full re-encode: FFmpeg decodes the original at a low
sample rate (2 fps, 320 px) and prints frames whose scene score exceeds the
threshold. Long videos (> 20 min) decode keyframes only, which is several
times faster and still catches camera/angle switches.
"""
from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path

log = logging.getLogger("clipforge.scenes")
_PTS = re.compile(r"pts_time:([0-9.]+)")
_OUT = re.compile(r"out_time_us=(\d+)")


def detect_scene_cuts(video_path: str | Path, duration: float, threshold: float = 0.3,
                      progress=None) -> list[float]:
    keyframes_only = duration > 20 * 60
    cmd = ["ffmpeg", "-hide_banner", "-nostats", "-v", "info"]
    if keyframes_only:
        cmd += ["-skip_frame", "nokey"]
    cmd += ["-i", str(video_path), "-an", "-sn",
            "-vf", f"fps=2,scale=320:-2,select='gt(scene,{threshold})',showinfo",
            "-f", "null", "-", "-progress", "pipe:1"]
    cuts: list[float] = []
    try:
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                text=True, errors="replace")
    except OSError as e:
        log.warning("scene detection unavailable: %s", e)
        return []
    import threading

    def read_stderr():
        for line in proc.stderr:
            if "showinfo" in line and "pts_time:" in line:
                m = _PTS.search(line)
                if m:
                    cuts.append(round(float(m.group(1)), 3))
    t = threading.Thread(target=read_stderr, daemon=True)
    t.start()
    last = -1
    for line in proc.stdout:
        m = _OUT.match(line.strip())
        if m and progress and duration > 0:
            frac = min(int(m.group(1)) / 1e6 / duration, 1.0)
            pct = int(frac * 100)
            if pct != last:
                progress(frac)
                last = pct
    proc.wait()
    t.join(timeout=5)
    log.info("scene detection: %d cuts in %.0fs of video (%s)", len(cuts), duration,
             "keyframes" if keyframes_only else "2 fps")
    return sorted(cuts)


def cuts_in_range(cuts: list[float], start: float, end: float) -> int:
    return sum(1 for c in cuts if start < c < end)


def snap_to_cut(t: float, cuts: list[float], tol: float = 0.6) -> float:
    near = [c for c in cuts if abs(c - t) <= tol]
    return min(near, key=lambda c: abs(c - t)) if near else t
