"""Speaker-aware framing plan for vertical clips.

For a clip [start, end] of a landscape video:
1. Sample frames at SAMPLE_FPS (FFmpeg -> raw BGR pipe, 640 px wide, no temp files).
2. Detect CAMERA CUTS inside the clip from the same frames (colour-histogram jump).
   Multi-camera podcasts switch angles constantly; a shot must never span a cut,
   otherwise a face position from one camera gets applied to another camera.
3. Detect faces with YuNet (OpenCV, MIT-licensed model bundled); tracks are reset
   at every cut, so a track always belongs to one camera angle.
4. Estimate who is talking: motion energy in each face's mouth region.
5. Per camera segment choose a layout:
     single - one person (or, in "speaker" mode, whoever is talking) -> face centred
     split  - 2-3 people in the same frame -> equal stacked panels, every face centred
     wide   - 4+ people or no faces -> whole frame over a blurred fill
   Inside a segment a decision is held for at least MIN_HOLD seconds.
Output: list of shots [{start, end, layout, tids, boxes:[[x,y,w,h] normalised]}] in clip time.
"""
from __future__ import annotations

import logging
import subprocess
from pathlib import Path

import cv2
import numpy as np

log = logging.getLogger("clipforge.speakers")
MODEL = Path(__file__).parent / "assets" / "face_detection_yunet_2023mar.onnx"
SAMPLE_FPS = 5.0
ANALYSIS_W = 640
MIN_HOLD = 2.5           # seconds a layout/target must hold before switching (within a camera shot)
TALK_RATIO = 1.5         # active speaker must move mouth this much more than others
CUT_THRESHOLD = 0.42     # Bhattacharyya distance between consecutive frame histograms
MAX_SPLIT = 3            # up to 3 stacked panels


def _frames(video: str | Path, start: float, end: float, src_w: int, src_h: int):
    h = int(round(src_h * ANALYSIS_W / src_w / 2) * 2)
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{end - start:.3f}",
           "-i", str(video), "-an", "-vf", f"fps={SAMPLE_FPS},scale={ANALYSIS_W}:{h}",
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    size = ANALYSIS_W * h * 3
    i = 0
    try:
        while True:
            buf = proc.stdout.read(size)
            if len(buf) < size:
                break
            yield i / SAMPLE_FPS, np.frombuffer(buf, np.uint8).reshape(h, ANALYSIS_W, 3)
            i += 1
    finally:
        proc.stdout.close()
        proc.wait()


def _detector(w: int, h: int):
    return cv2.FaceDetectorYN.create(str(MODEL), "", (w, h), 0.75, 0.3, 50)


def _iou(a, b) -> float:
    ax, ay, aw, ah = a
    bx, by, bw, bh = b
    ix = max(0, min(ax + aw, bx + bw) - max(ax, bx))
    iy = max(0, min(ay + ah, by + bh) - max(ay, by))
    inter = ix * iy
    union = aw * ah + bw * bh - inter
    return inter / union if union > 0 else 0.0


def _hist(frame) -> np.ndarray:
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    h = cv2.calcHist([hsv], [0, 1, 2], None, [12, 6, 6], [0, 180, 0, 256, 0, 256])
    return cv2.normalize(h, h).flatten()


def frame_cut(prev_hist, hist, prev_gray, gray) -> bool:
    """Hard camera cut between two consecutive samples?"""
    if prev_hist is None:
        return False
    d = cv2.compareHist(prev_hist.astype(np.float32), hist.astype(np.float32), cv2.HISTCMP_BHATTACHARYYA)
    if d >= CUT_THRESHOLD:
        return True
    # dark studio footage: colours barely change between angles, structure does
    small_a = cv2.resize(prev_gray, (64, 36)).astype(np.float32)
    small_b = cv2.resize(gray, (64, 36)).astype(np.float32)
    return d >= CUT_THRESHOLD * 0.45 and float(np.abs(small_a - small_b).mean()) > 18.0


def analyse(video: str | Path, start: float, end: float, src_w: int, src_h: int,
            progress=None) -> dict:
    """Per-sample faces (normalised boxes) with talk activity, plus camera cuts (clip time)."""
    det = None
    tracks: list[dict] = []
    samples: list[dict] = []
    cuts: list[float] = []
    prev_gray = prev_hist = None
    total = max(1, int((end - start) * SAMPLE_FPS))
    next_id = 0
    for k, (t, frame) in enumerate(_frames(video, start, end, src_w, src_h)):
        h, w = frame.shape[:2]
        if det is None:
            det = _detector(w, h)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        hist = _hist(frame)
        is_cut = frame_cut(prev_hist, hist, prev_gray, gray)
        if is_cut:
            cuts.append(t)
            tracks = []                  # new camera angle -> new identities
            prev_gray = None             # no mouth-motion across a cut
        _, faces = det.detect(frame)
        found = []
        if faces is not None:
            for f in faces:
                x, y, fw, fh = (float(v) for v in f[:4])
                if fw * fh < (w * h) * 0.002:      # ignore tiny background faces
                    continue
                nose_y, mr_y, ml_y = f[9], f[11], f[13]
                mx0 = int(max(0, min(f[10], f[12]) - fw * 0.12))
                mx1 = int(min(w, max(f[10], f[12]) + fw * 0.12))
                my0 = int(max(0, nose_y + fh * 0.05))
                my1 = int(min(h, max(mr_y, ml_y) + fh * 0.18))
                act = 0.0
                if prev_gray is not None and mx1 > mx0 and my1 > my0:
                    d = cv2.absdiff(gray[my0:my1, mx0:mx1], prev_gray[my0:my1, mx0:mx1])
                    act = float(d.mean())
                    fy0, fy1 = int(max(0, y)), int(max(0, min(h, y + fh * 0.45)))
                    fx0, fx1 = int(max(0, x)), int(min(w, x + fw))
                    if fy1 > fy0 and fx1 > fx0:
                        g = cv2.absdiff(gray[fy0:fy1, fx0:fx1], prev_gray[fy0:fy1, fx0:fx1])
                        act = max(0.0, act - float(g.mean()) * 0.8)
                found.append(((x, y, fw, fh), act))
        used = set()
        entries = []
        for box, act in found:
            best, best_i = None, 0.25
            for tr in tracks:
                if tr["id"] in used:
                    continue
                iou = _iou(box, tr["box"])
                cdist = abs((box[0] + box[2] / 2) - (tr["box"][0] + tr["box"][2] / 2)) / w
                score = iou if iou > 0 else (0.3 - cdist if cdist < 0.08 else 0)
                if score > best_i:
                    best, best_i = tr, score
            if best is None:
                best = {"id": next_id, "box": box, "hits": 0}
                next_id += 1
                tracks.append(best)
            best["box"] = box
            best["hits"] += 1
            used.add(best["id"])
            entries.append({"tid": best["id"], "act": act,
                            "box": (box[0] / w, box[1] / h, box[2] / w, box[3] / h)})
        samples.append({"t": t, "faces": entries, "cut": is_cut})
        prev_gray, prev_hist = gray, hist
        if progress and k % 10 == 0:
            progress(min(1.0, k / total))
    hits: dict[int, int] = {}
    for s in samples:
        for f in s["faces"]:
            hits[f["tid"]] = hits.get(f["tid"], 0) + 1
    return {"samples": samples, "tracks": hits, "cuts": cuts}


def _segments(samples: list[dict], duration: float, cuts: list[float]) -> list[tuple[float, float]]:
    pts = sorted({0.0, duration, *[round(c, 3) for c in cuts if 0.05 < c < duration - 0.05]})
    segs = []
    for a, b in zip(pts, pts[1:]):
        if segs and b - a < 0.25:          # flash frame: glue to previous segment
            segs[-1] = (segs[-1][0], b)
        else:
            segs.append((a, b))
    return segs


def _people(seg_samples: list[dict]) -> dict[int, dict]:
    """Which face tracks in one camera segment are real people.

    Posters, statues, logos and photos on the wall get detected as faces too. They are
    small, perfectly still and never 'talk'. The largest face of a segment is always kept;
    any other face must be reasonably large AND show life (mouth / head movement)."""
    tr: dict[int, list] = {}
    for s in seg_samples:
        for f in s["faces"]:
            tr.setdefault(f["tid"], []).append(f)
    if not tr:
        return {}
    n = max(1, len(seg_samples))
    stats = {}
    for tid, fs in tr.items():
        b = np.array([f["box"] for f in fs])
        a = np.array([f["act"] for f in fs])
        stats[tid] = {"n": len(fs), "h": float(np.median(b[:, 3])),
                      "cx_std": float((b[:, 0] + b[:, 2] / 2).std()), "h_std": float(b[:, 3].std()),
                      "p90": float(np.percentile(a, 90)), "mean": float(a.mean())}
    present = {t: st for t, st in stats.items() if st["n"] >= max(2, n * 0.3)}
    if not present:
        return {}
    big = max(present, key=lambda t: present[t]["h"])
    keep = {}
    for t, st in present.items():
        if t == big:
            if st["h"] >= 0.08:
                keep[t] = st
            continue
        still = st["cx_std"] < 0.0015 and st["h_std"] < 0.003
        alive = st["p90"] >= 0.45 and not still
        if st["h"] >= 0.5 * present[big]["h"] and st["h"] >= 0.08 and alive:
            keep[t] = st
    return keep


def _decide(visible: list[dict], acts: dict, mode: str, talkers: set | None = None) -> tuple[str, list[int]]:
    ids = sorted(acts, key=lambda i: next(f["box"][0] for f in visible if f["tid"] == i))  # left->right
    if mode == "wide" or not ids:
        return ("wide", [])
    if len(ids) == 1:
        return ("single", ids)
    ranked = sorted(ids, key=lambda i: -acts[i])
    top, second = acts[ranked[0]], acts[ranked[1]]
    talker = top > 0.4 and top >= second * TALK_RATIO
    if mode == "speaker":
        return ("single", [ranked[0]])
    if mode == "split" and len(ids) <= MAX_SPLIT:
        return ("split", ids)
    if mode in ("smart", "auto") and talker:
        return ("single", [ranked[0]])
    # split only when this camera angle really holds a conversation (both people talk in it)
    if len(ids) <= MAX_SPLIT and (mode != "auto" or talkers is None
                                  or sum(1 for i in ids if i in talkers) >= 2):
        return ("split", ids)
    # nobody clearly talking right now: stay on whoever talks most in this shot
    if talkers:
        best = max(ids, key=lambda i: (i in talkers, acts[i]))
        return ("single", [best])
    return ("single", [ranked[0]])


def plan(analysis: dict, duration: float, scene_cuts: list[float] | None = None,
         mode: str = "auto") -> list[dict]:
    """Turn per-sample analysis into stable shots. mode: auto|split|speaker|smart|wide.

    auto/split - 2-3 people in frame are shown in equal stacked panels
    speaker    - always the person talking, full frame
    smart      - the talker when one clearly talks, otherwise panels
    """
    samples = analysis["samples"]
    cuts = list(analysis.get("cuts") or []) + list(scene_cuts or [])
    segs = _segments(samples, duration, cuts)
    hits = analysis.get("tracks") or {}
    win = max(1, int(SAMPLE_FPS * 0.6))

    shots: list[dict] = []
    for a, b in segs:
        seg_samples = [s for s in samples if a - 1e-6 <= s["t"] < b - 1e-6]
        # tracks that are a real presence in THIS camera segment
        cnt: dict[int, int] = {}
        for s in seg_samples:
            for f in s["faces"]:
                cnt[f["tid"]] = cnt.get(f["tid"], 0) + 1
        people = _people(seg_samples)
        good = set(people)
        # who actually talks in this camera segment (mouth clearly moving in >= 20% of samples)
        talk_n: dict[int, int] = {}
        for s in seg_samples:
            vis = [f for f in s["faces"] if f["tid"] in good]
            if len(vis) >= 1:
                top = max(vis, key=lambda f: f["act"])
                if top["act"] > 1.0:
                    talk_n[top["tid"]] = talk_n.get(top["tid"], 0) + 1
        talkers = {t for t, k in talk_n.items() if k >= max(2, 0.2 * len(seg_samples))}
        if mode in ("auto", "tv"):
            # one stable decision per camera shot: no needless switching inside a shot
            if not people:
                shots.append({"start": a, "end": b, "layout": "wide", "tids": []})
                continue
            ordered = sorted(people, key=lambda t: -people[t]["h"])
            tk = [t for t in ordered if t in talkers]
            if len(tk) >= 2:
                ids = sorted(tk[:MAX_SPLIT], key=lambda t: next(
                    (f["box"][0] for s_ in seg_samples for f in s_["faces"] if f["tid"] == t), 0))
                shots.append({"start": a, "end": b, "layout": "split", "tids": ids})
            else:
                main = tk[0] if tk else max(people, key=lambda t: (people[t]["mean"], people[t]["h"]))
                shots.append({"start": a, "end": b, "layout": "single", "tids": [main]})
            continue
        act_hist: dict[int, list[float]] = {}
        decisions = []
        for s in seg_samples:
            vis = [f for f in s["faces"] if f["tid"] in good]
            for f in vis:
                act_hist.setdefault(f["tid"], []).append(f["act"])
            acts = {f["tid"]: float(np.mean(act_hist[f["tid"]][-win:])) for f in vis}
            decisions.append((s["t"], _decide(vis, acts, mode, talkers)))
        if not decisions:
            shots.append({"start": a, "end": b, "layout": "wide", "tids": []})
            continue
        cur, cur_start, last_switch = decisions[0][1], a, a
        for t, dec in decisions[1:]:
            if dec != cur and t - last_switch >= MIN_HOLD:
                shots.append({"start": cur_start, "end": t, "layout": cur[0], "tids": list(cur[1])})
                cur, cur_start, last_switch = dec, t, t
        shots.append({"start": cur_start, "end": b, "layout": cur[0], "tids": list(cur[1])})

    if not shots:
        shots = [{"start": 0.0, "end": duration, "layout": "wide", "tids": []}]
    shots[0]["start"] = 0.0
    shots[-1]["end"] = duration

    # stable box per face: median over the shot (shots never cross a camera cut)
    out = []
    for s in shots:
        if s["end"] - s["start"] <= 0.02:
            continue
        boxes, tids = [], []
        for tid in s["tids"]:
            bs = [f["box"] for smp in samples if s["start"] - 1e-6 <= smp["t"] < s["end"]
                  for f in smp["faces"] if f["tid"] == tid]
            if bs:
                boxes.append([float(v) for v in np.median(np.array(bs), axis=0)])
                tids.append(tid)
        # every other real person in this shot: lets a single crop hold two people when they fit
        others = []
        seg_people = _people([smp for smp in samples if s["start"] - 1e-6 <= smp["t"] < s["end"]])
        for tid in seg_people:
            if tid in tids:
                continue
            bs = [f["box"] for smp in samples if s["start"] - 1e-6 <= smp["t"] < s["end"]
                  for f in smp["faces"] if f["tid"] == tid]
            if bs:
                others.append([float(v) for v in np.median(np.array(bs), axis=0)])
        layout = s["layout"]
        if layout == "split" and len(boxes) >= 2:
            # both panels need a real face most of the time (not a back of the head)
            n_all = max(1, sum(1 for smp in samples if s["start"] - 1e-6 <= smp["t"] < s["end"]))
            seen = [sum(1 for smp in samples if s["start"] - 1e-6 <= smp["t"] < s["end"]
                        and any(f["tid"] == t for f in smp["faces"])) / n_all for t in tids]
            if min(seen) < 0.6:
                keep_i = max(range(len(tids)), key=lambda i: seen[i])
                others = [b for i, b in enumerate(boxes) if i != keep_i] + others
                boxes, tids, layout = [boxes[keep_i]], [tids[keep_i]], "single"
        if layout == "split" and len(boxes) < 2:
            layout = "single" if boxes else "wide"
        if layout == "single" and not boxes:
            layout = "wide"
        out.append({"start": round(s["start"], 3), "end": round(s["end"], 3), "layout": layout,
                    "tids": tids, "boxes": boxes, "others": others})
    # merge neighbours with identical framing (same camera, same people, similar boxes)
    merged: list[dict] = []
    for s in out:
        m = merged[-1] if merged else None
        if (m and m["layout"] == s["layout"] and len(m["boxes"]) == len(s["boxes"])
                and all(abs(p[0] - q[0]) < 0.03 and abs(p[1] - q[1]) < 0.03
                        for p, q in zip(m["boxes"], s["boxes"]))):
            m["end"] = s["end"]
        else:
            merged.append(dict(s))
    merged[0]["start"] = 0.0
    merged[-1]["end"] = round(duration, 3)
    return stabilize(merged, duration, mode)


SPLIT_MIN = 3.0          # a split shorter than this flashes - show the talker instead
SPLIT_SHARE = 0.5        # split must be the clip's main look, otherwise the clip stays single


def _to_single(s: dict) -> dict:
    boxes = s.get("boxes") or []
    if not boxes:
        return {**s, "layout": "wide"}
    main = max(range(len(boxes)), key=lambda i: boxes[i][3])        # biggest face
    return {**s, "layout": "single", "boxes": [boxes[main]], "tids": [s["tids"][main]] if s.get("tids") else [],
            "others": [b for i, b in enumerate(boxes) if i != main] + list(s.get("others") or [])}


def stabilize(shots: list[dict], duration: float, mode: str = "auto") -> list[dict]:
    """One consistent look per clip.

    Top podcast and TV-clip pages never flip between full-screen and split every few seconds.
    In auto mode a split survives only when it is long enough to read AND it is the clip's
    main layout; otherwise those moments become a single crop (which still holds both people
    when they stand close - see compose.group crop)."""
    if mode not in ("auto", "tv") or not shots:
        return shots
    if mode == "tv":
        return [_to_single(s) if s["layout"] == "split" else s for s in shots]
    split_t = sum(s["end"] - s["start"] for s in shots
                  if s["layout"] == "split" and s["end"] - s["start"] >= SPLIT_MIN)
    allow = split_t >= SPLIT_SHARE * duration
    out = []
    for s in shots:
        if s["layout"] == "split" and (not allow or s["end"] - s["start"] < SPLIT_MIN):
            s = _to_single(s)
        out.append(s)
    return out


def summary(shots: list[dict]) -> str:
    c = {"single": 0.0, "split": 0.0, "wide": 0.0}
    for s in shots:
        c[s["layout"]] += s["end"] - s["start"]
    return ", ".join(f"{k} {v:.0f}s" for k, v in c.items() if v > 0)


def facecam_box(analysis: dict) -> list[float] | None:
    """The streamer's facecam: a small face that sits in the same place in most samples.
    Grouped by position, not by track (gameplay cuts reset tracks but the facecam never moves).
    A big face means a talking-head shot, which is not a stream layout."""
    samples = analysis.get("samples") or []
    if not samples:
        return None
    groups: list[dict] = []
    for i, s in enumerate(samples):
        for f in s["faces"]:
            b = f["box"]
            if b[3] >= 0.24:
                continue
            cx, cy = b[0] + b[2] / 2, b[1] + b[3] / 2
            g = next((g for g in groups if abs(g["cx"] - cx) < 0.1 and abs(g["cy"] - cy) < 0.1), None)
            if g is None:
                g = {"cx": cx, "cy": cy, "boxes": [], "seen": set()}
                groups.append(g)
            g["boxes"].append(b)
            g["seen"].add(i)
    # a facecam sits towards an edge / corner; gameplay or scene faces move around the middle
    edge = [g for g in groups if min(g["cx"], 1 - g["cx"]) < 0.3]
    if not edge:
        return None
    for g in sorted(edge, key=lambda g: -len(g["seen"])):
        # side-on / low-light facecams are detected only part of the time - 8 % of samples is plenty
        if len(g["seen"]) < max(6, 0.08 * len(samples)):
            break
        bx = np.array(g["boxes"])
        hs = bx[:, 3]
        steady = ((bx[:, 0] + bx[:, 2] / 2).std() < 0.035 and (bx[:, 1] + bx[:, 3] / 2).std() < 0.035
                  and hs.std() < 0.25 * hs.mean())
        # a facecam survives the gameplay's / scene's camera cuts; an actor at the edge of one shot does not
        cuts = sorted(analysis.get("cuts") or [])
        if cuts:
            times = [samples[i]["t"] for i in g["seen"]]
            spans = len({sum(1 for c in cuts if c <= t_) for t_ in times})
            if spans < 2:
                continue
        if steady:
            return [float(v) for v in np.median(bx, axis=0)]
    return None


# ------------------------------------------------------------------ facecam panel (live streams) --
PANEL_W = 1280          # facecams are small: detect at full 720p/1080p width, not the 640 px analysis size
PANEL_SAMPLES = 36


def _panel_frames(video, start: float, end: float, src_w: int, src_h: int, n: int):
    w = min(PANEL_W, src_w - src_w % 2)
    h = int(round(src_h * w / src_w / 2) * 2)
    dur = max(1.0, end - start)
    cmd = ["ffmpeg", "-v", "error", "-ss", f"{start:.3f}", "-t", f"{dur:.3f}", "-i", str(video), "-an",
           "-vf", f"fps={n / dur:.5f},scale={w}:{h}", "-frames:v", str(n), "-f", "rawvideo", "-pix_fmt", "bgr24", "-"]
    out = subprocess.run(cmd, capture_output=True, timeout=300).stdout
    size = w * h * 3
    return [np.frombuffer(out[i:i + size], np.uint8).reshape(h, w, 3) for i in range(0, len(out) - size + 1, size)], w, h


def _edge_faces(det, frame, w: int, h: int) -> list[list[float]]:
    """Faces in the frame, plus a 2x look at the left / right strips where facecams live."""
    out = []
    _, f = det.detect(frame)
    for r in (f if f is not None else []):
        out.append([r[0] / w, r[1] / h, r[2] / w, r[3] / h, float(r[-1])])
    sw_ = int(w * 0.36)
    for x0 in (0, w - sw_):
        strip = cv2.resize(frame[:, x0:x0 + sw_], (sw_ * 2, h * 2), interpolation=cv2.INTER_CUBIC)
        d2 = cv2.FaceDetectorYN.create(str(MODEL), "", (sw_ * 2, h * 2), 0.6, 0.3, 20)
        _, f2 = d2.detect(strip)
        for r in (f2 if f2 is not None else []):
            b = [(x0 + r[0] / 2) / w, r[1] / 2 / h, r[2] / 2 / w, r[3] / 2 / h, float(r[-1])]
            if all(_iou(b[:4], o[:4]) < 0.3 for o in out):
                out.append(b)
    return out


def _longest_run(a: np.ndarray) -> int:
    best = cur = 0
    for v in a:
        cur = cur + 1 if v else 0
        best = max(best, cur)
    return best


def _snap_to_border(edges: np.ndarray, box: list[float], face: list[float],
                    std: np.ndarray | None = None) -> list[float]:
    """Find the real overlay rectangle around the face.
    Main signal: the overlay is still while the game keeps moving, so the per-pixel change over
    the clip jumps from low (inside) to high (outside) right at the overlay border. Dark, still
    gameplay next to the panel can hide that jump; then the overlay's drawn frame (a straight edge
    present in every frame) is used, and failing both the rough 'static region' box is kept."""
    eh, ew = edges.shape
    pe = edges > 0.55
    pv = cv2.dilate(pe.astype(np.uint8), np.ones((1, 2), np.uint8)) > 0
    ph_ = cv2.dilate(pe.astype(np.uint8), np.ones((2, 1), np.uint8)) > 0
    x0, y0 = int(box[0] * ew), int(box[1] * eh)
    x1, y1 = int((box[0] + box[2]) * ew), int((box[1] + box[3]) * eh)
    fx0, fy0 = int(face[0] * ew), int(face[1] * eh)
    fx1, fy1 = int((face[0] + face[2]) * ew), int((face[1] + face[3]) * eh)
    STILL, MOVE = 8.0, 20.0

    def edge_of(profile, start, inward, outward_limit):
        """Border position on one side. `inward` is -1 for a right/bottom side, +1 for left/top.
        From the rough edge: if the game moves there, walk inwards to the first still lines;
        if it is still, walk outwards to the first moving lines (or the frame edge)."""
        n = len(profile)
        c = min(max(start, 0), n - 1)
        if profile[c] > STILL:
            while 0 <= c + inward < n and not (profile[c] <= STILL and profile[c + inward] <= STILL):
                c += inward
            return c if inward > 0 else c + 1
        out = -inward
        while 0 <= c + out < n and not (profile[c] > MOVE and profile[c + out] > MOVE):
            c += out
        if profile[c] > MOVE:
            return c + 1 if out < 0 else c
        return 0 if out < 0 else n

    def best_line(lines, length, lo, hi, outer_first):
        cand = []
        for c in range(max(0, lo), min(len(lines), hi)):
            # a border can be broken by a name banner or logo: count the line, not only its longest run
            run = max(_longest_run(lines[c]), int(0.8 * np.count_nonzero(lines[c])))
            if run >= 0.5 * length:
                cand.append(c)
        if not cand:
            return None
        return min(cand) if outer_first else max(cand)

    if std is not None:
        colp = np.median(std[max(0, y0):max(y0 + 1, y1), :], axis=0)
        nx0 = edge_of(colp, x0, +1, 0)
        nx1 = edge_of(colp, x1 - 1, -1, ew)
        rowp = np.median(std[:, nx0:max(nx0 + 1, nx1)], axis=1)
        ny0 = edge_of(rowp, y0, +1, 0)
        ny1 = edge_of(rowp, y1 - 1, -1, eh)
        good = (nx0 <= fx0 and nx1 >= fx1 and ny0 <= fy0 and ny1 >= fy1)
    else:
        good = False
    if not good:                                    # no clear motion border: use the drawn frame
        cols = [pv[max(0, y0):y1, c] for c in range(ew)]
        mx = max(2, (x1 - x0) // 3)
        nx0 = best_line(cols, max(1, y1 - y0), x0 - mx, fx0 - 2, True)
        nx1 = best_line(cols, max(1, y1 - y0), fx1 + 2, x1 + mx + 1, False)
        nx0 = x0 if nx0 is None else nx0
        nx1 = x1 if nx1 is None else nx1
        rows = [ph_[r, nx0:nx1] for r in range(eh)]
        my = max(2, (y1 - y0) // 4)
        ny0 = best_line(rows, max(1, nx1 - nx0), y0 - my, fy0 - 2, True)
        ny1 = best_line(rows, max(1, nx1 - nx0), fy1 + 2, y1 + my + 1, False)
        ny0 = y0 if ny0 is None else ny0
        ny1 = y1 if ny1 is None else ny1
    if nx1 - nx0 < (fx1 - fx0) * 1.6 or ny1 - ny0 < (fy1 - fy0) * 1.6:
        return box
    return [nx0 / ew, ny0 / eh, (nx1 - nx0) / ew, (ny1 - ny0) / eh]


def _panel_around(frames: list, face: list[float], w: int, h: int) -> list[float] | None:
    """The facecam overlay box around the face: the region that stays put while the game changes."""
    sw_ = 320
    sh_ = int(round(h * sw_ / w))
    g = np.stack([cv2.resize(cv2.cvtColor(f, cv2.COLOR_BGR2GRAY), (sw_, sh_), interpolation=cv2.INTER_AREA)
                  for f in frames]).astype(np.float32)
    std = g.std(axis=0)
    edges = np.mean([cv2.Canny(x.astype(np.uint8), 60, 140) > 0 for x in g], axis=0)
    static = ((std < 22) | (edges > 0.6)).astype(np.uint8)
    static = cv2.morphologyEx(static, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    static = cv2.morphologyEx(static, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    fx, fy, fw, fh = face[0] * sw_, face[1] * sh_, face[2] * sw_, face[3] * sh_
    # the person moves a little: count the face area itself as part of the panel
    static[int(max(0, fy)):int(min(sh_, fy + fh)), int(max(0, fx)):int(min(sw_, fx + fw))] = 1
    n, lab, stats, _ = cv2.connectedComponentsWithStats(static, connectivity=4)
    k = lab[int(min(sh_ - 1, fy + fh / 2)), int(min(sw_ - 1, fx + fw / 2))]
    if k == 0:
        return None
    x, y, bw, bh, _ = stats[k]

    def ok(b):
        return (b[2] <= 0.5 and b[3] <= 0.65 and b[2] >= 1.6 * face[2] and b[3] >= 1.6 * face[3]
                and b[2] * b[3] <= 0.22)

    rough = [x / sw_, y / sh_, bw / sw_, bh / sh_]
    for start in (rough, _box_round_face(face)):        # dark, still gameplay can swallow the panel
        box = _snap_to_border(edges, start, face, std)
        if ok(box):
            return box
    return rough if ok(rough) else None


def _box_round_face(face: list[float]) -> list[float]:
    pw, ph = min(0.4, face[2] * 3.4), min(0.55, face[3] * 3.0)
    cx, cy = face[0] + face[2] / 2, face[1] + face[3] / 2
    return [max(0.0, min(1 - pw, cx - pw / 2)), max(0.0, min(1 - ph, cy - ph * 0.45)), pw, ph]


def _text_lines(gray: np.ndarray) -> list[tuple[float, float, float, float]]:
    """Lines of printed text (name banners, channel tags, badges) in a still image, as
    (top, bottom, left, right) shares. Letters are found as MSER blobs of letter shape; a line
    is 4+ letters side by side with the same height. No OCR model needed."""
    big = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    H, W = big.shape
    ms = cv2.MSER_create(5, 30, max(60, int(H * W * 0.01)))
    _, boxes = ms.detectRegions(big)
    cb = sorted({(int(x), int(y), int(bw), int(bh)) for x, y, bw, bh in boxes
                 if H * 0.035 <= bh <= H * 0.16 and 0.15 <= bw / max(1, bh) <= 1.6})
    out = set()
    for x, y, bw, bh in cb:
        cy = y + bh / 2
        g = [b for b in cb if abs((b[1] + b[3] / 2) - cy) < bh * 0.35 and 0.6 < b[3] / bh < 1.6]
        cols = {b[0] // max(1, int(bh * 0.4)) for b in g}
        if len(cols) >= 4:
            out.add((round(min(b[1] for b in g) / H, 3), round(max(b[1] + b[3] for b in g) / H, 3),
                     round(min(b[0] for b in g) / W, 3), round(max(b[0] + b[2] for b in g) / W, 3)))
    return sorted(out)


def _trim_overlay_text(frames: list, panel: list[float], face: list[float]) -> list[float]:
    """Cut the streamer's own name banner / channel badge off the top and bottom of the facecam
    panel, so no half-cut text from the source shows in the clip. The face always stays in."""
    h, w = frames[0].shape[:2]
    x0, x1 = int(panel[0] * w), int((panel[0] + panel[2]) * w)
    # look a little above and below the panel too: badges often sit across its border
    ext = panel[3] * 0.12
    ey0, ey1 = max(0.0, panel[1] - ext), min(1.0, panel[1] + panel[3] + ext)
    y0, y1 = int(ey0 * h), int(ey1 * h)
    if x1 - x0 < 40 or y1 - y0 < 40:
        return panel
    crops = [cv2.cvtColor(f[y0:y1, x0:x1], cv2.COLOR_BGR2GRAY) for f in frames[::2]]
    med = np.median(np.stack(crops), axis=0).astype(np.uint8)       # the person blurs away, text stays sharp
    span = ey1 - ey0
    ph = panel[3]
    # text lines in panel shares (can be < 0 or > 1 when they stick out of the panel)
    lines = [((ey0 + a * span - panel[1]) / ph, (ey0 + b * span - panel[1]) / ph, l, r)
             for a, b, l, r in _text_lines(med)]
    f_top = (face[1] - panel[1]) / ph                                 # face, in panel shares
    f_bot = (face[1] + face[3] - panel[1]) / ph
    top, bot = 0.0, 1.0
    for a, b, _, _ in lines:
        if b <= 0.3 and b > 0 and b + 0.02 < f_top - 0.15:                      # badge above the head
            top = max(top, b + 0.02)
        elif a >= 0.7 and a < 1 and a - 0.09 > f_bot + 0.1:                     # banner under the face
            bot = min(bot, a - 0.09)                                  # its plate/pill sits a little above the letters
    # overlay frames carry badges / name pills on their top edge (often in a script font MSER
    # cannot read): with enough room above the head, always drop the top strip of the frame
    if top == 0.0 and f_top > 0.3:
        top = min(0.09, f_top - 0.2)
    if (top, bot) == (0.0, 1.0) or bot - top < 0.45:
        return panel
    log.info("facecam: overlay text cut off - keeping %.0f%%..%.0f%% of the panel height", top * 100, bot * 100)
    return [panel[0], panel[1] + top * ph, panel[2], (bot - top) * ph]


def find_facecam(video, start: float, end: float, src_w: int, src_h: int) -> dict | None:
    """Streamer facecam for the stream layout: {'face': box, 'panel': box} (normalised) or None.
    Looks for a small face that stays at the same edge spot across the clip (gameplay cuts and all)."""
    try:
        frames, w, h = _panel_frames(video, start, end, src_w, src_h, PANEL_SAMPLES)
    except Exception:  # noqa: BLE001
        log.exception("facecam: could not read frames")
        return None
    if len(frames) < 8:
        return None
    det = cv2.FaceDetectorYN.create(str(MODEL), "", (w, h), 0.6, 0.3, 50)
    groups: list[dict] = []
    for i, fr in enumerate(frames):
        for b in _edge_faces(det, fr, w, h):
            if b[3] >= 0.3:
                continue
            cx, cy = b[0] + b[2] / 2, b[1] + b[3] / 2
            if min(cx, 1 - cx) >= 0.36 and min(cy, 1 - cy) >= 0.25:
                continue                                      # middle of the screen: gameplay / scene
            g = next((g for g in groups if abs(g["cx"] - cx) < 0.06 and abs(g["cy"] - cy) < 0.08), None)
            if g is None:
                g = {"cx": cx, "cy": cy, "boxes": [], "seen": set()}
                groups.append(g)
            g["boxes"].append(b[:4])
            g["seen"].add(i)
    if not groups:
        log.info("facecam: no small edge faces in %d frames", len(frames))
        return None
    best = max(groups, key=lambda g: len(g["seen"]))
    share = len(best["seen"]) / len(frames)
    bx = np.array(best["boxes"])
    steady = (bx[:, 0] + bx[:, 2] / 2).std() < 0.03 and (bx[:, 1] + bx[:, 3] / 2).std() < 0.04
    log.info("facecam: best edge face at (%.2f, %.2f) in %.0f %% of %d frames, steady=%s",
             best["cx"], best["cy"], share * 100, len(frames), steady)
    if share < 0.25 or not steady:
        return None
    face = [float(v) for v in np.median(bx, axis=0)]
    panel = _panel_around(frames, face, w, h)
    if panel is None:                                         # fall back to a generous box round the face
        panel = _box_round_face(face)
        log.info("facecam: overlay edge not found - using a box around the face")
    try:
        panel = _trim_overlay_text(frames, panel, face)
    except Exception:  # noqa: BLE001
        log.exception("facecam: text check failed - panel kept")
    return {"face": face, "panel": [float(v) for v in panel]}
