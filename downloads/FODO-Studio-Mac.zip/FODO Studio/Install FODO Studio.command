#!/bin/bash
# Installs FODO Studio for this Mac user: files in ~/Applications/FODO Studio, the "FODO Studio" app
# in ~/Applications (Launchpad / Spotlight), then runs the one-time setup. No admin password needed.
set -e
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/Applications/FODO Studio"
APP="$HOME/Applications/FODO Studio.app"
echo "Installing FODO Studio into $DEST"
mkdir -p "$DEST"
# copy the app files (keeps storage/, .venv and tools/ of an earlier install)
for item in "$SRC"/* "$SRC"/.[!.]*; do
  [ -e "$item" ] || continue
  name="$(basename "$item")"
  case "$name" in "Install FODO Studio.command"|"FODO Studio.app"|storage|.venv|tools) continue;; esac
  rm -rf "${DEST:?}/${name:?}"
  ditto "$item" "$DEST/$name"
done
chmod +x "$DEST/FODO Studio.command" "$DEST/setup.sh"
xattr -dr com.apple.quarantine "$DEST" 2>/dev/null || true

rm -rf "$APP"
ditto "$SRC/FODO Studio.app" "$APP"
chmod +x "$APP/Contents/MacOS/FODO Studio"
xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true

bash "$DEST/setup.sh"
echo ""
echo "Done. Opening FODO Studio..."
open "$APP"
