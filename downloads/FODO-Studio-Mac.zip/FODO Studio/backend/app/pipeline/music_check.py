"""Background-music check before posting (numpy only, no paid API, no fingerprint service).

Why: YouTube Content ID blocks Shorts that carry a label's song for too long (19 Nov 2026:
"Missing Person Alert" was blocked for Faith Evans - "Love Like This", WMG). In stream clips the
song comes from the streamer's own background music, so ClipForge cannot know it from settings.

How: music keeps the same notes ringing (stable spectral peaks that last hundreds of ms) and has a
steady beat; speech changes pitch every few frames and game sound effects are noisy. Each 3-second
window gets two measures:
  persistence - how many stable tonal peaks (80-2500 Hz) last >= ~190 ms, on average
  rhythm      - strongest onset autocorrelation between 60 and 200 BPM
Measured on real ClipForge stream clips (speech + gameplay) persistence stayed < 2 with rhythm
< 0.3; synthetic music mixed 18 dB under speech still gave persistence > 3 and rhythm > 0.35.
This is an estimate, not a copyright lookup: it can miss quiet music and can flag a hummed tune.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import numpy as np

SR = 16000
N = 1024
HOP = 256
WIN = 3.0


def _load(path: str | Path) -> np.ndarray:
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-vn", "-ac", "1", "-ar", str(SR), "-f", "f32le", "-"],
                       capture_output=True, timeout=600)
    return np.frombuffer(r.stdout, np.float32)


def windows(y: np.ndarray) -> list[dict]:
    """Per 3-second window: start, persistence, rhythm, music (bool)."""
    if y.size < N * 4:
        return []
    w = np.hanning(N)
    n = 1 + (y.size - N) // HOP
    idx = np.arange(N)[None, :] + HOP * np.arange(n)[:, None]
    S = np.abs(np.fft.rfft(y[idx] * w, axis=1))
    f = np.fft.rfftfreq(N, 1 / SR)
    L = np.log(S[:, (f >= 80) & (f <= 2500)] + 1e-6)
    pk = (L[:, 1:-1] > L[:, :-2]) & (L[:, 1:-1] > L[:, 2:]) & (L[:, 1:-1] > np.median(L, axis=1, keepdims=True) + 2.0)
    near = pk | np.roll(pk, 1, axis=1) | np.roll(pk, -1, axis=1)
    run = np.zeros(pk.shape[1])
    pers = np.zeros(len(pk))
    for i in range(len(pk)):
        run = np.where(near[i], run + 1, 0)
        pers[i] = np.sum((run >= 12) & pk[i])
    flux = np.r_[0, np.maximum(0, np.diff(L, axis=0)).sum(1)]
    fpw = int(WIN * SR / HOP)
    lo, hi = int(0.3 * SR / HOP), int(1.0 * SR / HOP)
    out = []
    for s in range(0, len(pk) - fpw + 1, fpw):
        p = float(pers[s:s + fpw].mean())
        o = flux[s:s + fpw] - flux[s:s + fpw].mean()
        ac = np.correlate(o, o, "full")[fpw - 1:]
        ac = ac / (ac[0] + 1e-9)
        r = float(ac[lo:hi].max()) if hi < len(ac) else 0.0
        out.append({"start": round(s * HOP / SR, 1), "persistence": round(p, 2), "rhythm": round(r, 2),
                    "music": bool((p >= 1.2 and r >= 0.3) or p >= 2.5)})
    return out


def summarize(ws: list[dict]) -> dict:
    segs, cur = [], None
    for w in ws:
        if w["music"]:
            if cur and abs(cur[1] - w["start"]) < 0.3:
                cur[1] = w["start"] + WIN
            else:
                cur = [w["start"], w["start"] + WIN]
                segs.append(cur)
    secs = sum(b - a for a, b in segs)
    longest = max((b - a for a, b in segs), default=0.0)
    level = "likely" if longest >= 2 * WIN or secs >= 4 * WIN else ("possible" if segs else "none")
    return {"level": level, "music_seconds": round(secs, 1), "longest": round(longest, 1),
            "segments": [[round(a, 1), round(b, 1)] for a, b in segs], "windows": len(ws)}


def check(path: str | Path, cache_dir: Path | None = None) -> dict:
    """Cached per file (path + size + mtime)."""
    p = Path(path)
    key = None
    if cache_dir:
        st = p.stat()
        key = cache_dir / f"{p.stem}_{st.st_size}_{int(st.st_mtime)}.json"
        if key.exists():
            try:
                return json.loads(key.read_text(encoding="utf-8"))
            except ValueError:
                pass
    res = summarize(windows(_load(p)))
    if key:
        key.parent.mkdir(parents=True, exist_ok=True)
        key.write_text(json.dumps(res), encoding="utf-8")
    return res


def fmt(t: float) -> str:
    return f"{int(t // 60)}:{int(t % 60):02d}"
