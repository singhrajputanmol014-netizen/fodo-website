"""Music structure analysis + three-hook selector (numpy only - no paid API, no heavy deps).

Pipeline (all measured from the actual audio file):
  1. STFT -> 40 log-spaced bands, 12-bin chroma, bass / vocal-band energy
  2. onset strength -> tempo (autocorrelation with a ~110 BPM prior) -> beats (dynamic
     programming beat tracker, Ellis 2007) -> downbeats (bar phase with the strongest onsets)
  3. beat-synchronous features -> self-similarity matrix -> novelty curve (checkerboard kernel)
     -> section boundaries
  4. sections compared with each other: repeated + loud + vocal-rich = chorus candidate
  5. hooks:  intro (opening section) · chorus / main hook (most repeated strong section)
             · drop / emotional peak (largest energy + bass rise into a section)
Every hook carries start, end, duration, type, a confidence and the measured reasons.
These are estimates from signal analysis, not ground truth; the user can drag any range.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
from pathlib import Path

import numpy as np

SR = 22050
N_FFT = 2048
HOP = 512


def load(path: str | Path, max_seconds: float = 600) -> np.ndarray:
    r = subprocess.run(["ffmpeg", "-v", "error", "-t", str(max_seconds), "-i", str(path), "-ac", "1",
                        "-ar", str(SR), "-f", "f32le", "-"], capture_output=True, timeout=300)
    if r.returncode != 0:
        raise RuntimeError(r.stderr.decode(errors="replace")[-300:])
    return np.frombuffer(r.stdout, np.float32).copy()


def _stft_mag(y: np.ndarray) -> np.ndarray:
    if y.size < N_FFT:
        y = np.pad(y, (0, N_FFT - y.size))
    n = 1 + (y.size - N_FFT) // HOP
    idx = np.arange(N_FFT)[None, :] + HOP * np.arange(n)[:, None]
    win = np.hanning(N_FFT).astype(np.float32)
    frames = y[idx] * win
    return np.abs(np.fft.rfft(frames, axis=1)).astype(np.float32)        # (frames, bins)


def _bands(mag: np.ndarray, n_bands: int = 40) -> np.ndarray:
    freqs = np.fft.rfftfreq(N_FFT, 1 / SR)
    edges = np.geomspace(40, SR / 2, n_bands + 1)
    out = np.zeros((mag.shape[0], n_bands), np.float32)
    for i in range(n_bands):
        m = (freqs >= edges[i]) & (freqs < edges[i + 1])
        if m.any():
            out[:, i] = mag[:, m].mean(axis=1)
    return np.log1p(out * 10)


def _chroma(mag: np.ndarray) -> np.ndarray:
    freqs = np.fft.rfftfreq(N_FFT, 1 / SR)
    ok = (freqs > 55) & (freqs < 4200)
    pc = (np.round(12 * np.log2(freqs[ok] / 440.0)) % 12).astype(int)
    ch = np.zeros((mag.shape[0], 12), np.float32)
    sub = mag[:, ok] ** 2
    for k in range(12):
        ch[:, k] = sub[:, pc == k].sum(axis=1)
    return ch / (ch.max(axis=1, keepdims=True) + 1e-9)


def _band_energy(mag: np.ndarray, lo: float, hi: float) -> np.ndarray:
    freqs = np.fft.rfftfreq(N_FFT, 1 / SR)
    m = (freqs >= lo) & (freqs < hi)
    return np.sqrt((mag[:, m] ** 2).mean(axis=1) + 1e-12)


def tempo_and_beats(onset: np.ndarray) -> tuple[float, np.ndarray]:
    fps = SR / HOP
    o = onset - onset.mean()
    ac = np.correlate(o, o, mode="full")[o.size - 1:]
    lags = np.arange(ac.size)
    bpm = np.where(lags > 0, 60 * fps / np.maximum(lags, 1), 0)
    ok = (bpm >= 60) & (bpm <= 190)
    prior = np.exp(-0.5 * (np.log2(np.maximum(bpm, 1) / 110) / 0.9) ** 2)
    score = np.where(ok, ac * prior, -np.inf)
    lag = int(np.argmax(score))
    tempo = 60 * fps / lag
    # dynamic-programming beat tracker
    period = lag
    alpha = 100.0
    n = onset.size
    cum = onset.astype(np.float64).copy()
    back = -np.ones(n, int)
    lo, hi = int(period / 2), int(period * 2)
    for t in range(hi, n):
        prev = np.arange(t - hi, t - lo)
        pen = -alpha * (np.log((t - prev) / period)) ** 2
        cand = cum[prev] + pen
        k = int(np.argmax(cand))
        cum[t] = onset[t] + cand[k]
        back[t] = prev[k]
    t = int(np.argmax(cum[-hi:]) + n - hi) if n > hi else int(np.argmax(cum))
    beats = []
    while t >= 0:
        beats.append(t)
        t = back[t]
        if t < 0:
            break
    beats = np.array(sorted(beats))
    return float(tempo), beats


def _novelty(S: np.ndarray, k: int) -> np.ndarray:
    n = S.shape[0]
    g = np.outer(np.hanning(2 * k), np.hanning(2 * k))
    sign = np.ones((2 * k, 2 * k))
    sign[:k, k:] = -1
    sign[k:, :k] = -1
    ker = g * sign
    Sp = np.pad(S, k, mode="edge")
    nov = np.array([(Sp[i:i + 2 * k, i:i + 2 * k] * ker).sum() for i in range(n)])
    nov = np.maximum(nov, 0)
    return nov / (nov.max() + 1e-9)


def analyze(path: str | Path, cache_dir: Path | None = None) -> dict:
    path = Path(path)
    key = hashlib.sha1(f"{path.resolve()}|{path.stat().st_size}|{path.stat().st_mtime_ns}|v1".encode()).hexdigest()[:16]
    if cache_dir:
        cf = cache_dir / f"{key}.json"
        if cf.exists():
            return json.loads(cf.read_text(encoding="utf-8"))
    y = load(path)
    dur = y.size / SR
    if dur < 6:
        raise RuntimeError("Song too short to analyse (< 6 s)")
    mag = _stft_mag(y)
    fps = SR / HOP
    bands = _bands(mag)
    onset = np.maximum(np.diff(bands, axis=0, prepend=bands[:1]), 0).sum(axis=1)
    onset = onset / (onset.max() + 1e-9)
    tempo, beat_f = tempo_and_beats(onset)
    if beat_f.size < 16:
        beat_f = np.arange(0, mag.shape[0], int(fps * 60 / max(tempo, 60)))
    beat_t = beat_f / fps
    # downbeats: which of the 4 phases carries the strongest onsets
    phase = int(np.argmax([onset[beat_f[p::4]].sum() for p in range(4)]))
    down_t = beat_t[phase::4]
    # beat-synchronous features
    rms = np.sqrt((y[: (y.size // HOP) * HOP].reshape(-1, HOP) ** 2).mean(axis=1) + 1e-12)
    rms = rms[: mag.shape[0]] if rms.size >= mag.shape[0] else np.pad(rms, (0, mag.shape[0] - rms.size))
    chroma = _chroma(mag)
    bass = _band_energy(mag, 30, 150)
    vocal = _band_energy(mag, 300, 3400)
    edges = np.append(beat_f, mag.shape[0])
    feats, e_b, bass_b, voc_b = [], [], [], []
    for a, b in zip(edges[:-1], edges[1:]):
        b = max(b, a + 1)
        feats.append(np.concatenate([chroma[a:b].mean(0), bands[a:b].mean(0) / (bands.max() + 1e-9)]))
        e_b.append(rms[a:b].mean())
        bass_b.append(bass[a:b].mean())
        voc_b.append(vocal[a:b].mean())
    F = np.array(feats)
    F = F / (np.linalg.norm(F, axis=1, keepdims=True) + 1e-9)
    S = F @ F.T
    nb = len(F)
    k = 8 if nb > 64 else max(2, nb // 8)
    nov = _novelty(S, k)
    # boundaries: novelty peaks, >= 8 beats apart, snapped to downbeats
    peaks = [i for i in range(1, nb - 1) if nov[i] >= nov[i - 1] and nov[i] >= nov[i + 1] and nov[i] > 0.25]
    bnds = [0]
    for i in sorted(peaks, key=lambda i: -nov[i]):
        if all(abs(i - b) >= 8 for b in bnds):
            bnds.append(i)
    bnds = sorted(bnds) + [nb]
    down_set = set(np.searchsorted(beat_t, down_t))
    bnds = sorted({min(down_set, key=lambda d: abs(d - b)) if b not in (0, nb) and down_set else b for b in bnds})
    e_db = 20 * np.log10(np.array(e_b) + 1e-9)
    bb = np.array(bass_b)
    bass_db = np.maximum(20 * np.log10(bb / (bb.max() + 1e-12) + 1e-6), -60.0)   # dB vs the loudest bass
    voc_ratio = np.array(voc_b) / (np.array(e_b) * 0 + np.array(bass_b) + np.array(voc_b) + 1e-9)
    secs = []
    for a, b in zip(bnds[:-1], bnds[1:]):
        if b - a < 2:
            continue
        t0 = 0.0 if a == 0 else float(beat_t[a])
        t1 = float(beat_t[b]) if b < nb else dur
        secs.append({"start": round(t0, 2), "end": round(t1, 2), "beats": int(b - a),
                     "energy_db": round(float(e_db[a:b].mean()), 1),
                     "bass_db": round(float(bass_db[a:b].mean()), 1),
                     "vocal_share": round(float(voc_ratio[a:b].mean()), 2),
                     "feat": F[a:b].mean(0)})
    # repetition: how many other sections look alike
    for s in secs:
        s["repeats"] = int(sum(1 for o in secs if o is not s and
                               float(np.dot(s["feat"], o["feat"]) / (np.linalg.norm(s["feat"]) * np.linalg.norm(o["feat"]) + 1e-9)) > 0.97))
    e_all = np.array([s["energy_db"] for s in secs])
    e_lo, e_hi = float(e_all.min()), float(e_all.max())
    hooks = []
    # 1) intro / opening
    s0 = secs[0]
    i_end = min(s0["end"], s0["start"] + 15.0)
    hooks.append({"type": "intro", "label": "Opening / intro", "start": s0["start"], "end": round(i_end, 2),
                  "confidence": 0.9 if s0["energy_db"] < np.median(e_all) else 0.6,
                  "why": f"first section of the song ({s0['end'] - s0['start']:.0f}s, energy "
                         f"{s0['energy_db']:.0f} dB vs loudest {e_hi:.0f} dB)"})
    # 2) chorus / main hook: repeated, loud, vocal-rich - not the opening
    cand = secs[1:] or secs

    def chorus_score(s):
        loud = (s["energy_db"] - e_lo) / (e_hi - e_lo + 1e-9)
        return 1.0 * s["repeats"] + 2.0 * loud + 1.0 * s["vocal_share"]
    top = max(chorus_score(s) for s in cand)
    ch = next(s for s in cand if chorus_score(s) >= top - 0.15)      # first occurrence of the best
    c_end = min(ch["end"], ch["start"] + 20.0)
    conf = min(0.95, 0.35 + 0.15 * ch["repeats"] + 0.3 * (ch["energy_db"] - e_lo) / (e_hi - e_lo + 1e-9))
    hooks.append({"type": "chorus", "label": "Chorus / main hook", "start": ch["start"], "end": round(c_end, 2),
                  "confidence": round(conf, 2),
                  "why": f"repeats {ch['repeats']}x in the song, energy {ch['energy_db']:.0f} dB "
                         f"(range {e_lo:.0f}..{e_hi:.0f}), vocal-band share {ch['vocal_share']:.2f}"})
    # 3) drop / emotional peak: biggest rise in energy + bass into a section
    best, rise = None, -1e9
    for prev, s in zip(secs, secs[1:]):
        r = (s["energy_db"] - prev["energy_db"]) + 0.5 * (s["bass_db"] - prev["bass_db"])
        if r > rise and s is not ch:
            best, rise = (prev, s), r
    if best is None:
        best, rise = (secs[0], max(secs, key=lambda s: s["energy_db"])), 0.0
    prev, s = best
    d_end = min(s["end"], s["start"] + 15.0)
    hooks.append({"type": "drop", "label": "Beat drop / emotional peak", "start": s["start"], "end": round(d_end, 2),
                  "confidence": round(float(min(0.95, max(0.2, rise / 12))), 2),
                  "why": f"energy +{s['energy_db'] - prev['energy_db']:.1f} dB and bass "
                         f"{s['bass_db'] - prev['bass_db']:+.1f} dB vs the section before (at {s['start']:.1f}s)"})
    # waveform for the UI (peak per bucket)
    nbk = 800
    seg = max(1, y.size // nbk)
    wf = np.abs(y[: seg * nbk]).reshape(nbk, seg).max(axis=1) if y.size >= nbk else np.abs(y)
    out = {"duration": round(dur, 2), "tempo": round(tempo, 1),
           "beats": [round(float(t), 3) for t in beat_t],
           "downbeats": [round(float(t), 3) for t in down_t],
           "sections": [{k: v for k, v in s.items() if k != "feat"} for s in secs],
           "hooks": [{**h, "duration": round(h["end"] - h["start"], 2)} for h in hooks],
           "waveform": [round(float(v), 3) for v in (wf / (wf.max() + 1e-9))],
           "method": "numpy STFT + DP beat tracking + self-similarity novelty (estimates, not ground truth)"}
    if cache_dir:
        cache_dir.mkdir(parents=True, exist_ok=True)
        (cache_dir / f"{key}.json").write_text(json.dumps(out), encoding="utf-8")
    return out


def snap_to_beat(t: float, beats: list[float]) -> float:
    if not beats:
        return t
    return min(beats, key=lambda b: abs(b - t))
