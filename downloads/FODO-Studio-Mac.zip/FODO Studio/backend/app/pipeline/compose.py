"""Speaker-framed clip composer.

shots (from speakers.plan) -> one FFmpeg render per shot (video only, crop /
split-screen / wide-with-blur) -> lossless-ish concat -> final pass that adds
the editing style, burned captions, original voice (loudness-normalised) and
optional background music ducked under the voice. Output verified by FFprobe.
"""
from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path

from .metadata import verify_output

log = logging.getLogger("clipforge.compose")
MUSIC_DIR = Path(__file__).parent / "assets" / "music"
FONTS_DIR = Path(__file__).parent / "assets" / "fonts"

EDIT_STYLES = {
    # No style zooms on a timer any more - a zoom with no reason reads as an editing mistake.
    "raw":         {"label": "Raw (no effects)", "vf": "", "zoom": None},
    "clean":       {"label": "Clean", "vf": "eq=contrast=1.03:saturation=1.05,unsharp=5:5:0.3", "zoom": None},
    "dynamic":     {"label": "Punchy colour", "vf": "eq=contrast=1.06:saturation=1.1,unsharp=5:5:0.4", "zoom": None},
    "cinematic":   {"label": "Cinematic", "vf": "eq=contrast=1.06:saturation=0.92,colorbalance=rs=-0.02:bs=0.04:rh=0.04:bh=-0.03,vignette=PI/6", "zoom": None},
    "high_energy": {"label": "High energy colour", "vf": "eq=contrast=1.1:saturation=1.22,unsharp=5:5:0.5", "zoom": None},
    "warm":        {"label": "Warm (Indian podcast look)", "vf": "eq=contrast=1.05:saturation=1.12,colorbalance=rm=0.03:bm=-0.03,unsharp=5:5:0.35", "zoom": None},
    "mono":        {"label": "Black and white", "vf": "hue=s=0,eq=contrast=1.15", "zoom": None},
    # v0.8 grades (all plain FFmpeg filters - same look in preview frames and export)
    "luxury":      {"label": "Luxury (soft, warm, low saturation)", "vf": "eq=contrast=1.04:saturation=0.82:gamma=1.03,colorbalance=rh=0.03:gh=0.01:bh=-0.03:rs=-0.01:bs=0.02,vignette=PI/5", "zoom": None},
    "moody":       {"label": "Moody (teal shadows, warm skin)", "vf": "eq=contrast=1.12:saturation=0.9:gamma=0.95,colorbalance=rs=-0.06:gs=0.0:bs=0.07:rh=0.05:bh=-0.04,vignette=PI/4", "zoom": None},
    "vintage":     {"label": "Vintage film (faded, warm)", "vf": "curves=all='0/0.06 0.5/0.52 1/0.94',colorbalance=rs=0.04:bs=-0.05:rh=0.05:bh=-0.04,eq=saturation=0.78,noise=alls=7:allf=t,vignette=PI/4", "zoom": None},
    "vhs":         {"label": "Retro VHS", "vf": "rgbashift=rh=3:bh=-3,eq=saturation=1.25:contrast=1.08,gblur=sigma=0.6,noise=alls=10:allf=t", "zoom": None},
    "neon":        {"label": "Neon night (cool, saturated)", "vf": "eq=contrast=1.12:saturation=1.35,colorbalance=bs=0.08:rs=-0.03:bh=0.04", "zoom": None},
    "bright":      {"label": "Bright & clean (UGC / product)", "vf": "eq=brightness=0.03:contrast=1.04:saturation=1.12,unsharp=5:5:0.35", "zoom": None},
}


def list_music(user_dir: Path | None = None) -> list[dict]:
    out = [{"id": f"builtin:{p.stem}", "name": p.stem.replace("_", " ").title(), "builtin": True}
           for p in sorted(MUSIC_DIR.glob("*.m4a"))]
    if user_dir and user_dir.exists():
        import json as _json
        for p in sorted(user_dir.iterdir()):
            if p.suffix.lower() not in (".mp3", ".m4a", ".wav", ".aac", ".ogg", ".flac", ".opus"):
                continue
            item = {"id": f"user:{p.name}", "name": p.stem, "builtin": False}
            side = p.with_suffix(p.suffix + ".json")
            if side.exists():
                try:
                    m = _json.loads(side.read_text(encoding="utf-8"))
                    item.update({"name": m.get("title") or p.stem, "attribution": m.get("attribution"),
                                 "license": m.get("license"), "from": m.get("from")})
                except ValueError:
                    pass
            out.append(item)
    return out


def music_path(music_id: str | None, user_dir: Path) -> Path | None:
    if not music_id:
        return None
    kind, _, name = music_id.partition(":")
    if kind == "builtin":
        p = MUSIC_DIR / f"{Path(name).name}.m4a"
    elif kind == "user":
        p = user_dir / Path(name).name          # no path traversal
    else:
        return None
    return p if p.exists() else None


def _even(v: float) -> int:
    return max(2, int(v) // 2 * 2)


SPLIT_GAP = 8          # px divider between stacked panels
SPLIT_FACE = 0.40      # face height as a share of its panel height
SINGLE_FACE = 0.17     # minimum face height as a share of the frame for single shots
MAX_UPSCALE = 2.0      # never blow a crop up more than this (quality); 2.4 measured soft faces
MAX_TOTAL_UPSCALE = 2.15   # ... including the alternating punch-in zoom


def _place(cx: float, cy: float, cw: float, ch: float, sw: int, sh: int, eye: float = 0.42) -> str:
    """Crop cw x ch with the face centre at (50%, eye) of the crop. The crop always stays
    inside the frame (never black bars); callers zoom in first when a face sits near an edge."""
    cw, ch = _even(min(cw, sw)), _even(min(ch, sh))
    x = min(max(cx - cw / 2, 0), sw - cw)
    y = min(max(cy - ch * eye, 0), sh - ch)
    return f"crop={cw}:{ch}:{int(x)}:{int(y)}"


def _fit_room(cx: float, cw: float, ch: float, sw: int, min_ch: float) -> tuple[float, float]:
    """Zoom in (down to min_ch) so a face near the frame edge can still sit in the centre."""
    room = 2 * min(cx, sw - cx)
    if room < cw:
        ar = cw / ch
        new_ch = max(room / ar, min_ch)
        return new_ch * ar, new_ch
    return cw, ch


def _group(box, others, sw: int, cw: float) -> tuple[float, float] | None:
    """Centre + span of the main face plus everyone of similar size that fits one crop.
    TV / sitcom pages keep two people in one frame instead of splitting the screen."""
    if not others:
        return None
    x0, x1 = box[0] * sw, (box[0] + box[2]) * sw
    for o in others:
        if o[3] < box[3] * 0.55:          # much smaller face = background person
            continue
        nx0, nx1 = min(x0, o[0] * sw), max(x1, (o[0] + o[2]) * sw)
        if nx1 - nx0 <= cw * 0.92:
            x0, x1 = nx0, nx1
    if x1 - x0 <= box[2] * sw * 1.01:
        return None
    return (x0 + x1) / 2, x1 - x0


def _single_crop(box, sw, sh, out_w, out_h, zoom=1.0, others=None, tv=False) -> str:
    cx = (box[0] + box[2] / 2) * sw
    cy = (box[1] + box[3] / 2) * sh
    fh = box[3] * sh
    ar = out_w / out_h
    if sw / sh > ar:
        ch = sh
        cw = sh * ar
    else:
        cw = sw
        ch = sw / ar
    grp = _group(box, others, sw, cw)
    if grp:
        cx = grp[0]
    if tv:
        # TV / film scene: the whole frame height, no face zoom (zooming SD TV looks blurry)
        return f"{_place(cx, cy, cw, ch, sw, sh, 0.40)},scale={out_w}:{out_h}:flags=lanczos"
    # far-away face (wide camera): punch in until the face reads well, within quality limits
    if fh / ch < SINGLE_FACE and not grp:
        ch = max(fh / SINGLE_FACE, out_h / MAX_UPSCALE, ch / 1.8)
        cw = ch * ar
    if grp:                                   # keep both people inside the crop
        ch = min(ch, max(grp[1] / 0.8 / ar, ch / 1.3, out_h / MAX_UPSCALE))
        cw = ch * ar
    else:
        # a face near the edge would force an off-centre crop: zoom in a little first
        cw, ch = _fit_room(cx, cw, ch, sw, max(ch / 1.3, out_h / MAX_UPSCALE))
    cw, ch = cw / zoom, ch / zoom
    if ch < out_h / MAX_TOTAL_UPSCALE:        # zoom never pushes past the source's real detail
        ch = min(sh, out_h / MAX_TOTAL_UPSCALE)
        cw = ch * ar
    return f"{_place(cx, cy, cw, ch, sw, sh, 0.40)},scale={out_w}:{out_h}:flags=lanczos"


def _framed(inner_vf: str, out_w: int, out_h: int, inner_h: int, dark: bool = True) -> str:
    """Podcast 'frame' look (Figuring Out / big Indian podcasts): a 4:5 picture centred on a
    dark, softly blurred copy of itself - clean, premium, room for captions."""
    y = (out_h - inner_h) // 2
    return (f"split=2[bg][fg];[bg]scale={out_w}:{out_h}:force_original_aspect_ratio=increase,"
            f"crop={out_w}:{out_h},gblur=sigma=40,"
            f"{'eq=brightness=-0.32:saturation=0.6' if dark else 'eq=brightness=-0.12:saturation=0.85'},"
            f"noise=alls=3:allf=t[b];"
            f"[fg]{inner_vf}[f];[b][f]overlay=0:{y}")


def _split(boxes, sw, sh, out_w, out_h) -> str:
    n = max(2, min(len(boxes), 3))
    boxes = sorted(boxes[:n], key=lambda b: b[0])          # left person on top
    panel_h = _even((out_h - SPLIT_GAP * (n - 1)) / n)
    ar = out_w / panel_h
    # one common face size for every panel (largest face sets the scale)
    fh = max(b[3] * sh for b in boxes)
    ch = max(fh / SPLIT_FACE, panel_h / MAX_UPSCALE)
    ch = min(ch, sh * 1.0)
    cw = ch * ar
    labels = "".join(f"[s{i}]" for i in range(n))
    parts = [f"split={n}{labels}"]
    for i, box in enumerate(boxes):
        cx = (box[0] + box[2] / 2) * sw
        cy = (box[1] + box[3] / 2) * sh
        pw, ph = _fit_room(cx, cw, ch, sw, max(ch / 1.3, panel_h / MAX_UPSCALE))
        gap = f",pad={out_w}:{panel_h + SPLIT_GAP}:0:0:color=0x0b0b0b" if i < n - 1 else ""
        parts.append(f"[s{i}]{_place(cx, cy, pw, ph, sw, sh, 0.47)},"
                     f"scale={out_w}:{panel_h}:flags=lanczos,setsar=1{gap}[p{i}]")
    stack = "".join(f"[p{i}]" for i in range(n))
    total = panel_h * n + SPLIT_GAP * (n - 1)
    parts.append(f"{stack}vstack=inputs={n},pad={out_w}:{out_h}:0:({out_h}-{total})/2:color=0x0b0b0b")
    return ";".join(parts)


def _fill(sw, sh, out_w, out_h) -> str:
    """No face in shot (B-roll, objects, graphics): fill the frame from the centre -
    no shrunken picture, no blur bars."""
    ar = out_w / out_h
    if sw / sh > ar:
        ch, cw = sh, sh * ar
    else:
        cw, ch = sw, sw / ar
    return f"{_place(sw / 2, sh / 2, cw, ch, sw, sh, 0.5)},scale={out_w}:{out_h}:flags=lanczos"


def _wide(out_w, out_h) -> str:
    return (f"split=2[bg][fg];[bg]scale={out_w}:{out_h}:force_original_aspect_ratio=increase,"
            f"crop={out_w}:{out_h},gblur=sigma=28,eq=brightness=-0.08[b];"
            f"[fg]scale={out_w}:-2:flags=lanczos[f];[b][f]overlay=(W-w)/2:(H-h)/2")


BOX = {"x": 0.04, "y": 0.22, "h": 0.575}    # clip-page video box (share of the frame)
STREAM_TOP = 0.42                               # facecam panel share in the stream layout


def box_rect(out_w: int, out_h: int) -> tuple[int, int, int, int]:
    w = _even(out_w * (1 - 2 * BOX["x"]))
    h = _even(out_h * BOX["h"])
    return (out_w - w) // 2, _even(out_h * BOX["y"]), w, h


def round_mask(out_w: int, out_h: int, rect: tuple[int, int, int, int], path: Path, radius: int = 34,
               colour=(0, 0, 0)) -> Path:
    """PNG the size of the frame: solid outside, transparent rounded hole over the video box."""
    from PIL import Image, ImageDraw
    x, y, w, h = rect
    im = Image.new("RGBA", (out_w, out_h), colour + (255,))
    hole = Image.new("L", (out_w, out_h), 255)
    ImageDraw.Draw(hole).rounded_rectangle([x, y, x + w - 1, y + h - 1], radius=radius, fill=0)
    im.putalpha(hole)
    im.save(path)
    return path


def _boxed(inner_vf: str, out_w: int, out_h: int) -> str:
    x, y, w, h = box_rect(out_w, out_h)
    return f"{inner_vf},pad={out_w}:{out_h}:{x}:{y}:color=black"


def _stream(cam_box, sw: int, sh: int, out_w: int, out_h: int) -> str:
    """Live-stream layout: facecam on top, gameplay / screen below (Speed, Kai Cenat, xQc)."""
    top_h = _even(out_h * STREAM_TOP)
    bot_h = out_h - top_h - 6
    ar_t = out_w / top_h
    if len(cam_box) >= 6:
        # the whole facecam overlay (room + streamer), cut to the panel shape round the face
        px, py, pw, ph = cam_box[0] * sw, cam_box[1] * sh, cam_box[2] * sw, cam_box[3] * sh
        fcx, fcy = cam_box[4] * sw, cam_box[5] * sh
        ins = 0.03                                          # drop the overlay's own border
        px, py, pw, ph = px + pw * ins, py + ph * ins, pw * (1 - 2 * ins), ph * (1 - 2 * ins)
        if pw / ph > ar_t:
            ch, cw = ph, ph * ar_t
            x = min(max(fcx - cw / 2, px), px + pw - cw)
            y = py
        else:
            cw, ch = pw, pw / ar_t
            x = px
            y = min(max(fcy - ch * 0.45, py), py + ph - ch)
        cw, ch = _even(cw), _even(ch)
        top = f"crop={cw}:{ch}:{int(x)}:{int(y)}"
        fx, fw = px, pw
    else:
        top = None
    fx, fy, fw, fh = (cam_box[0] * sw, cam_box[1] * sh, cam_box[2] * sw, cam_box[3] * sh) if top is None else (fx, py, fw, ph)
    ch = max(fh / 0.5, top_h / MAX_UPSCALE)
    ch = min(ch, sh)
    cw = min(ch * ar_t, sw)
    ch = cw / ar_t
    # facecams sit in a corner: zoom in a little so the face can still be centred
    if top is None:
        cw, ch = _fit_room(fx + fw / 2, cw, ch, sw, top_h / MAX_UPSCALE)
        top = _place(fx + fw / 2, fy + fh / 2, cw, ch, sw, sh, 0.45)
    ar_b = out_w / bot_h
    bw = min(sw, sh * ar_b)
    bh = bw / ar_b
    # gameplay: centre of the screen, away from the facecam corner
    bcx = sw / 2 if abs((fx + fw / 2) - sw / 2) > sw * 0.15 else sw / 2
    bot = _place(bcx, sh / 2, bw, bh, sw, sh, 0.5)
    return (f"split=2[sa][sb];[sa]{top},scale={out_w}:{top_h}:flags=lanczos,setsar=1,"
            f"pad={out_w}:{top_h + 6}:0:0:color=0x0b0b0b[t];"
            f"[sb]{bot},scale={out_w}:{bot_h}:flags=lanczos,setsar=1[sg];[t][sg]vstack=inputs=2")


def _letterbox(sw: int, sh: int, out_w: int, out_h: int, mode: str = "letterbox") -> str:
    """Original wide frame on black (studio / Bollywood pages), or a cinemascope band (motivation)."""
    if mode == "cinema":
        band_h = _even(out_w / 1.6)                    # wide cinema band with thick black bars
        cw = min(sw, sh * out_w / band_h)
        ch = cw * band_h / out_w
        return (f"{_place(sw / 2, sh / 2, cw, ch, sw, sh, 0.5)},scale={out_w}:{band_h}:flags=lanczos,"
                f"pad={out_w}:{out_h}:0:({out_h}-{band_h})/2:color=black")
    zoom = 1.3                                          # fills ~45 % of the height, like studio pages
    sc_w = _even(out_w * zoom)
    sc_h = _even(sc_w * sh / sw)
    return (f"scale={sc_w}:{sc_h}:flags=lanczos,crop={out_w}:{sc_h},"
            f"pad={out_w}:{out_h}:0:({out_h}-{sc_h})/2:color=black")


def _white_top(inner_vf: str, out_w: int, out_h: int, inner_h: int) -> str:
    """Meme template: white premise area on top, the clip under it, black below."""
    top = _even(out_h * 0.24)
    return (f"{inner_vf},pad={out_w}:{out_h}:0:{top}:color=black,"
            f"drawbox=x=0:y=0:w={out_w}:h={top}:color=white:t=fill")


PUSH_RATE = 0.005        # slow push-in: +0.5 % per second ...
PUSH_MAX = 1.06          # ... never more than 6 % (a camera move, not a zoom)


def _slow_push(vf: str, out_w: int, out_h: int, offset: float) -> str:
    """Very slow, continuous push-in across a camera shot (premium documentary motion).
    `offset` = seconds since the shot started, so cut pieces continue the same move."""
    z = f"min(1+{PUSH_RATE}*(t+{offset:.3f}),{PUSH_MAX})"
    base = vf.rsplit(",scale=", 1)[0]
    return (f"{base},scale=w='trunc({out_w}*{z}/2)*2':h='trunc({out_h}*{z}/2)*2':eval=frame:flags=bicubic,"
            f"crop={out_w}:{out_h}")


def loop_music(music: Path, total: float, work: Path) -> Path:
    """Make a music bed at least `total` seconds long with 3 s crossfades at the joins
    (no audible jump back to the start of the track)."""
    import json as _json
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", str(music)],
                       capture_output=True, text=True)
    try:
        d = float(_json.loads(r.stdout)["format"]["duration"])
    except (ValueError, KeyError):
        return music
    if d >= total + 1 or d < 8:
        return music
    xf = 3.0
    n = min(12, int((total + 1) // (d - xf)) + 1)
    out = work / "music_bed.m4a"
    ins = []
    for _ in range(n):
        ins += ["-i", str(music)]
    chain, last = [], "[0:a]"
    for k in range(1, n):
        lab = f"[m{k}]"
        chain.append(f"{last}[{k}:a]acrossfade=d={xf}:c1=tri:c2=tri{lab}")
        last = lab
    _run(["ffmpeg", "-y", "-v", "error", *ins, "-filter_complex", ";".join(chain), "-map", last,
          "-c:a", "aac", "-b:a", "160k", str(out)])
    return out


def music_gain_expr(total: float, mode: str) -> str:
    """'bed': under the whole clip. 'sting': only under the hook (first ~10 s) and the
    last ~8 s - how long podcast clips use music without it getting tiring."""
    if mode != "sting":
        return "1"
    end = max(12.0, total - 8.0)
    return (f"if(lt(t,8),1,if(lt(t,11),(11-t)/3,if(gt(t,{end:.2f}),min(1,(t-{end:.2f})/2.5),0)))")


def expand_for_zoom(shots: list[dict], zoom: tuple | None) -> list[dict]:
    """Dynamic styles: alternate punch-in zoom on single-speaker shots."""
    if not zoom:
        return [{**s, "zoom": 1.0} for s in shots]
    every, z = zoom
    out = []
    flip = False
    for s in shots:
        if s["layout"] != "single" or s["end"] - s["start"] < every * 1.5:
            out.append({**s, "zoom": z if (flip and s["layout"] == "single") else 1.0})
            flip = not flip
            continue
        t = s["start"]
        while t < s["end"] - 0.01:
            e = min(s["end"], t + every)
            if s["end"] - e < every * 0.5:
                e = s["end"]
            out.append({**s, "start": t, "end": e, "zoom": z if flip else 1.0})
            flip = not flip
            t = e
    return out


def vt_quality(crf: int) -> int:
    """x264-style CRF -> VideoToolbox -q:v (1-100, higher = better): crf 20 -> 65, 28 -> 51."""
    return max(40, min(90, round(100 - crf * 1.75)))


def _encoder_args(hw: str | None, crf: int, preset: str, final: bool) -> list[str]:
    if hw and hw.endswith("_nvenc"):
        return ["-c:v", hw, "-preset", "p5", "-cq", str(crf if final else 16), "-b:v", "0"]
    if hw and hw.endswith("_qsv"):
        return ["-c:v", hw, "-global_quality", str(crf if final else 16)]
    if hw and hw.endswith("_amf"):             # AMD Radeon / Ryzen graphics
        q = str(crf if final else 16)
        return ["-c:v", hw, "-quality", "quality" if final else "speed", "-rc", "cqp", "-qp_i", q, "-qp_p", q]
    if hw and hw.endswith("_videotoolbox"):    # Mac (Apple chip / Intel Mac)
        return ["-c:v", hw, "-q:v", str(vt_quality(crf) if final else 80), "-allow_sw", "1"]
    return ["-c:v", "libx264", "-preset", preset if final else "veryfast",
            "-crf", str(crf if final else 14)]


LIMITER = "alimiter=limit=0.89:attack=5:release=50:level=disabled"     # ~ -1 dBTP ceiling

CODECS = ("h264", "h265", "vp9", "av1")


def final_encoder_args(hw: str | None, crf: int, preset: str, codec: str = "h264",
                       bitrate_kbps: int | None = None) -> list[str]:
    """Encoder for the delivered file. h264 keeps the old path (NVENC/QSV/x264). h265 uses
    hevc_nvenc when NVENC is there, else libx265. vp9 -> libvpx-vp9. av1 -> av1_nvenc (RTX 40+)
    else SVT-AV1. A bitrate (kbps) replaces constant quality when given."""
    codec = codec if codec in CODECS else "h264"
    nv = bool(hw and hw.endswith("_nvenc"))
    if codec == "h264":
        args = _encoder_args(hw, crf, preset, True)
    elif codec == "h265":
        args = (["-c:v", "hevc_nvenc", "-preset", "p5", "-cq", str(crf + 2), "-b:v", "0"] if nv else
                ["-c:v", "libx265", "-preset", "medium" if preset != "veryfast" else "fast", "-crf", str(crf + 4)])
        args += ["-tag:v", "hvc1"]                 # plays in QuickTime / iOS
    elif codec == "vp9":
        args = ["-c:v", "libvpx-vp9", "-crf", str(crf + 12), "-b:v", "0", "-row-mt", "1",
                "-deadline", "good", "-cpu-used", "4"]
    else:
        args = ["-c:v", "libsvtav1", "-crf", str(crf + 10), "-preset", "8"]
    if bitrate_kbps:
        b = int(bitrate_kbps)
        args = [a for a in args]
        for flag in ("-crf", "-cq", "-global_quality", "-q:v"):
            if flag in args:
                i = args.index(flag)
                del args[i:i + 2]
        if "-rc" in args:                     # AMF constant-QP -> let the bitrate rule
            i = args.index("-rc")
            del args[i:i + 6]
        if "-b:v" in args:
            i = args.index("-b:v")
            del args[i:i + 2]
        args += ["-b:v", f"{b}k", "-maxrate", f"{int(b * 1.5)}k", "-bufsize", f"{b * 2}k"]
    return args


def trim_music(music: Path, start: float, end: float | None, work: Path) -> Path:
    """Cut the chosen section of a song (with 30 ms de-click fades) for the music bed."""
    out = work / "music_hook.m4a"
    cmd = ["ffmpeg", "-y", "-v", "error", "-ss", f"{max(0.0, start):.3f}", "-i", str(music)]
    if end and end > start:
        cmd += ["-t", f"{end - start:.3f}"]
    d = (end - start) if end and end > start else None
    af = "afade=t=in:d=0.03" + (f",afade=t=out:st={max(0.0, d - 0.05):.3f}:d=0.05" if d else "")
    _run(cmd + ["-af", af, "-c:a", "aac", "-b:a", "192k", str(out)])
    return out


def _run(cmd: list[str], cwd: str | None = None) -> None:
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=cwd)
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-900:])


def build_pieces(shots: list[dict], keep: list[tuple[float, float]] | None,
                 jump_zoom: float = 1.0) -> list[dict]:
    """Intersect framing shots with the kept (non-silent) ranges. Consecutive pieces of
    the same shot that are separated by a removed pause are jump cuts; alternating a
    small punch-in on them hides the jump (what editors do by hand)."""
    keep = keep or [(0.0, max(s["end"] for s in shots))]
    pieces = []
    for si, s in enumerate(shots):
        for a, b in keep:
            lo, hi = max(a, s["start"]), min(b, s["end"])
            if hi - lo > 0.04:
                pieces.append({**s, "start": lo, "end": hi, "shot": si, "shot_start": s["start"]})
    zoom_on = False
    for i, p in enumerate(pieces):
        prev = pieces[i - 1] if i else None
        jump = bool(prev and prev["shot"] == p["shot"] and p["start"] - prev["end"] > 0.01)
        if prev is None or prev["shot"] != p["shot"]:
            zoom_on = False
        elif jump and jump_zoom > 1.0:
            zoom_on = not zoom_on
        p["jump"] = jump
        if p["layout"] == "single" and zoom_on:
            p["zoom"] = p.get("zoom", 1.0) * jump_zoom
    return pieces


def render_vertical(video: str | Path, out: str | Path, start: float, end: float,
                    sw: int, sh: int, fps: float, shots: list[dict], out_w: int, out_h: int,
                    work: Path, edit_style: str = "clean", ass_path: Path | None = None,
                    music: Path | None = None, music_volume: float = 0.18, duck: bool = True,
                    hw: str | None = None, crf: int = 20, preset: str = "medium",
                    progress=None, keep: list[tuple[float, float]] | None = None,
                    jump_zoom: float = 1.0, sfx: dict | None = None,
                    graphics_ass: Path | None = None, progress_bar: bool = False,
                    accent: str = "#FF5900", slow_push: bool = False, music_mode: str = "auto",
                    meta: dict | None = None, frame: str = "fill", intro: float = 0.0,
                    outro: float = 0.35, grain: bool = False, cam_box: list | None = None,
                    pre_crop: tuple[int, int] | None = None, punch: list[float] | None = None,
                    music_start: float = 0.0, music_end: float | None = None, voice_enhance: bool = False,
                    music_delay: float = 0.0, orig_volume: float = 1.0, duck_level: str = "light",
                    codec: str = "h264", bitrate_kbps: int | None = None,
                    beats: list[float] | None = None, fx: dict | None = None,
                    watermark: dict | None = None) -> dict:
    work.mkdir(parents=True, exist_ok=True)
    out = Path(out).resolve()
    video = str(Path(video).resolve())
    style = EDIT_STYLES.get(edit_style, EDIT_STYLES["clean"])
    shots = expand_for_zoom(shots, style["zoom"])
    pieces = build_pieces(shots, keep, jump_zoom)
    fps = fps if fps and fps > 1 else 30.0
    seg_dir = work / "shots"
    shutil.rmtree(seg_dir, ignore_errors=True)
    seg_dir.mkdir()
    listing = []
    out_t = 0.0
    changes: list[float] = []                  # output times where the framing changes
    prev_key = None
    for i, s in enumerate(pieces):
        if progress:
            progress(0.88 * i / max(1, len(pieces)),
                     f"Rendering piece {i + 1}/{len(pieces)} ({s['layout']})")
        dur = s["end"] - s["start"]
        key = (s["layout"], len(s.get("boxes", [])))
        if prev_key is not None and key != prev_key:
            changes.append(out_t)
        prev_key = key
        if frame in ("frame45", "frame65", "native", "tv", "boxed", "white_top", "letterbox", "cinema",
                     "stream") and s["layout"] == "split" and s.get("boxes"):
            s = {**s, "layout": "single", "others": s["boxes"][1:] + list(s.get("others") or [])}
        if frame == "native":
            vf = _wide(out_w, out_h)
        elif frame == "stream" and cam_box:
            vf = _stream(cam_box, sw, sh, out_w, out_h)
        elif frame in ("letterbox", "cinema"):
            vf = _letterbox(sw, sh, out_w, out_h, frame)
        elif frame in ("boxed", "white_top"):
            if frame == "boxed":
                _, _, iw, ih = box_rect(out_w, out_h)
            else:
                iw, ih = out_w, out_w          # 1:1 - a 4:3 picture left 34 % of the screen empty
            if s["layout"] == "single" and s.get("boxes"):
                inner = _single_crop(s["boxes"][0], sw, sh, iw, ih, s.get("zoom", 1.0), s.get("others"))
            else:
                inner = _fill(sw, sh, iw, ih)
            vf = _boxed(inner, out_w, out_h) if frame == "boxed" else _white_top(inner, out_w, out_h, ih)
        elif frame in ("frame45", "frame65"):
            inner_h = min(out_h, _even(out_w * (5 / 4 if frame == "frame45" else 5 / 6)))
            if s["layout"] == "single" and s.get("boxes"):
                inner = _single_crop(s["boxes"][0], sw, sh, out_w, inner_h, s.get("zoom", 1.0), s.get("others"))
            else:
                inner = _fill(sw, sh, out_w, inner_h)
            vf = _framed(inner, out_w, out_h, inner_h, dark=(frame == "frame45"))
        elif s["layout"] == "single" and s.get("boxes"):
            vf = _single_crop(s["boxes"][0], sw, sh, out_w, out_h, s.get("zoom", 1.0),
                              s.get("others"), tv=(frame == "tv"))
            if slow_push and frame != "tv" and s.get("shot_start") is not None:
                vf = _slow_push(vf, out_w, out_h, s["start"] - s["shot_start"])
        elif s["layout"] == "split" and len(s.get("boxes", [])) >= 2 and out_h >= out_w:
            vf = _split(s["boxes"], sw, sh, out_w, out_h)
        elif s["layout"] == "wide" and s.get("letterbox"):
            vf = _wide(out_w, out_h)
        else:
            vf = _fill(sw, sh, out_w, out_h)
        if pre_crop:                        # burned-in text band removed before any framing
            vf = f"crop={sw}:{pre_crop[1]}:0:{pre_crop[0]}," + vf
        seg = seg_dir / f"s{i:04d}.mp4"
        # A/V sync: every piece is cut on the frame grid and video + audio get EXACTLY the same
        # length (n frames / n*1/fps seconds of samples). Before, each piece's video was rounded to
        # whole frames while its audio was not, and the concat added that error up piece by piece:
        # ~120 ms drift after 26 pieces (measured), worse on long clips with many pause cuts.
        a_q = round((start + s["start"]) * fps) / fps
        b_q = round((start + s["end"]) * fps) / fps
        n_fr = max(1, round((b_q - a_q) * fps))
        dur = n_fr / fps
        fade = min(0.012, dur / 4)
        cmd = ["ffmpeg", "-y", "-v", "error", "-ss", f"{a_q:.4f}", "-t", f"{dur + 0.25:.3f}",
               "-i", video, "-filter_complex",
               f"[0:v]{vf},setsar=1,fps={fps},trim=end_frame={n_fr},setpts=PTS-STARTPTS[v];"
               f"[0:a]aresample=48000,apad,atrim=end_sample={round(dur * 48000)},asetpts=PTS-STARTPTS,"
               f"afade=t=in:d={fade:.3f},afade=t=out:st={max(0.0, dur - fade):.3f}:d={fade:.3f}[a]",
               "-map", "[v]", "-map", "[a]", *_encoder_args(hw, crf, preset, False), "-pix_fmt", "yuv420p",
               "-c:a", "pcm_s16le", str(seg.with_suffix(".mov"))]
        try:
            _run(cmd)
        except RuntimeError:
            if hw:          # hardware encoder hiccup -> software for this piece
                i0 = cmd.index("-c:v")
                cmd[i0:i0 + len(_encoder_args(hw, crf, preset, False))] = _encoder_args(None, crf, preset, False)
                _run(cmd)
            else:
                raise
        listing.append(f"file '{seg.with_suffix('.mov').name}'")
        out_t += dur
    (seg_dir / "list.txt").write_text("\n".join(listing) + "\n", encoding="utf-8")
    if progress:
        progress(0.9, "Joining pieces")
    _run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", "list.txt",
          "-c", "copy", "joined.mov"], cwd=str(seg_dir))
    joined = seg_dir / "joined.mov"
    total = out_t

    # ---- final pass: grade + motion graphics + captions + voice/music/SFX mix ----
    if progress:
        progress(0.93, "Style, captions, graphics" + (", music" if music else "")
                 + (", sound effects" if sfx else "") + " - final encode")
    vchain = [x for x in [style["vf"]] if x]
    if grain:
        vchain.append("noise=alls=6:allf=t")
    mask = None
    if frame == "boxed":
        mask = round_mask(out_w, out_h, box_rect(out_w, out_h), work / "boxmask.png")
    assv = []
    run_cwd = None
    if ass_path or graphics_ass:
        run_cwd = str(Path(ass_path or graphics_ass).parent)
        fonts_rel = Path(shutil.copytree(FONTS_DIR, Path(run_cwd) / "fonts", dirs_exist_ok=True)).name
        try:                                    # fonts the owner uploaded in the caption studio
            from .captions import user_font_dir
            for f_ in user_font_dir().glob("*.[ot]tf"):
                shutil.copy(f_, Path(run_cwd) / fonts_rel / f_.name)
        except OSError:
            pass
        for a_ in (ass_path, graphics_ass):
            if a_:
                if Path(a_).parent != Path(run_cwd):
                    shutil.copy(a_, Path(run_cwd) / Path(a_).name)
                assv.append(f"ass={Path(a_).name}:fontsdir={fonts_rel}")
    from . import fx as fxmod
    fxc = fxmod.clean(fx)
    vgraph = f"[0:v]{','.join(vchain) if vchain else 'null'}[g00];" + fxmod.graph("g00", "g0", fxc)
    if mask:
        vgraph += ";[g0][MASK]overlay=0:0[g1]"
    else:
        vgraph += ";[g0]null[g1]"
    # opening / ending fades BEFORE the graphics: an end card or last word stays on the black
    fades = []
    if intro > 0:
        fades.append(f"fade=t=in:st=0:d={intro:.2f}")
    if outro >= 0.5 and total > outro + 1:
        fades.append(f"fade=t=out:st={total - outro:.3f}:d={outro:.2f}")
    zoom = []
    if punch and beats:
        # beat sync: a punch-in lands on the nearest music beat (within 0.25 s) - never moves
        # more than that, so a zoom still belongs to the word it emphasises
        bt = [b - music_start + music_delay for b in beats if b >= music_start]
        snapped = []
        for a_ in punch:
            near = min(bt, key=lambda b: abs(b - a_), default=None)
            snapped.append(near if near is not None and abs(near - a_) <= 0.25 else a_)
        punch = snapped
    if punch and frame in ("fill", "stream", "tv"):
        # punch-in on the strongest moments: a quick 10 % zoom held ~0.6 s (stream / meme edits)
        terms = "+".join(f"between(t,{a:.2f},{a + 0.6:.2f})" for a in punch)
        z = f"(1+0.1*({terms}))"
        zoom = [f"scale=w='trunc({out_w}*{z}/2)*2':h='trunc({out_h}*{z}/2)*2':eval=frame:flags=bicubic",
                f"crop={out_w}:{out_h}"]
    vgraph += f";[g1]{','.join(zoom + fades + assv) if (zoom or fades or assv) else 'null'}[v1]"
    wm = fxmod.clean_watermark(watermark) if watermark else None
    if wm and watermark.get("path") and Path(watermark["path"]).exists():
        # logo on top of everything (captions included); the label [v1] keeps meaning "final picture"
        vgraph = vgraph[:vgraph.rindex("[v1]")] + "[v1raw]"
        vgraph += ";" + fxmod.watermark_graph("v1raw", "WMIN", "v1", wm, out_w, out_h)
    else:
        wm = None
    if progress_bar:
        bh = max(6, out_h // 160)
        col = accent.lstrip("#")
        vgraph += (f";color=c=0x{col}:s={out_w}x{bh}:r={fps}:d={total:.3f}[bar];"
                   f"[v1][bar]overlay=x='-w+w*t/{total:.3f}':y=H-h:shortest=1[vout]")
    else:
        vgraph += ";[v1]null[vout]"
    a_out = max(0.35, outro)
    inputs = ["-i", str(joined)]
    idx = 1
    # voice chain: optional clean-up (rumble cut, gentle denoise, levelling, presence), then loudness
    vclean = ("highpass=f=75,afftdn=nr=10:nf=-30:tn=1,"
              "acompressor=threshold=0.125:ratio=2.5:attack=15:release=200:makeup=1.4,"
              "equalizer=f=3200:t=q:w=1.2:g=2.5,equalizer=f=250:t=q:w=1:g=-1.5,") if voice_enhance else ""
    ov = max(0.0, min(2.0, float(orig_volume)))
    agraph = f"[0:a]{vclean}loudnorm=I=-16:TP=-1.5:LRA=11,aresample=48000" + ("" if abs(ov - 1) < 0.01 else f",volume={ov:.2f}")
    mix = []
    if music:
        mmode = music_mode if music_mode in ("bed", "sting") else ("sting" if total > 90 else "bed")
        src_music = Path(music).resolve()
        if music_start > 0.05 or music_end:
            # chosen hook section of the song (waveform selector / auto hook)
            src_music = trim_music(src_music, music_start, music_end, work)
        bed = loop_music(src_music, total, work)
        inputs += ["-stream_loop", "-1", "-i", str(bed)]
        agraph += ",asplit=2[voice][sc];"
        agraph += (f"[{idx}:a]aresample=48000,volume={music_volume:.2f},"
                   f"volume='{music_gain_expr(total, mmode)}':eval=frame,afade=t=in:d=1.5"
                   + (f",adelay={int(music_delay * 1000)}:all=1" if music_delay > 0.05 else "") + "[m0];")
        if duck and ov > 0.01:
            ratio = {"light": 4, "strong": 10}.get(duck_level, 4)      # how far the music dips under speech
            agraph += f"[m0][sc]sidechaincompress=threshold=0.05:ratio={ratio}:attack=60:release=900:makeup=1[m1];"
        else:
            agraph += "[sc]anullsink;[m0]anull[m1];"
        mix.append("[m1]")
        idx += 1
    else:
        agraph += "[voice];"
    if sfx:
        from .edit import sfx_events
        cta_t = total - 2.4 if sfx.get("cta") and total > 8 else None
        sfx = sfx_events(changes, total, sfx.get("level", "off"), bool(sfx.get("hook")))
        if sfx and cta_t:
            sfx.append({"name": "whoosh", "t": max(0.0, cta_t - 0.2), "vol": sfx[0]["vol"] * 0.9})
    sfx = [e for e in (sfx or []) if e["t"] < total - 0.1]
    if sfx:
        from .edit import sfx_path
        names = sorted({e["name"] for e in sfx})
        for n_ in names:
            evs = [e for e in sfx if e["name"] == n_]
            inputs += ["-i", str(sfx_path(n_))]
            labels = "".join(f"[x{n_}{k}]" for k in range(len(evs)))
            agraph += f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo,asplit={len(evs)}{labels};" \
                if len(evs) > 1 else f"[{idx}:a]aresample=48000,aformat=channel_layouts=stereo[x{n_}0];"
            for k, e in enumerate(evs):
                ms = int(e["t"] * 1000)
                agraph += f"[x{n_}{k}]adelay={ms}|{ms},volume={e['vol']:.2f}[f{n_}{k}];"
                mix.append(f"[f{n_}{k}]")
            idx += 1
    if mix:
        agraph += (f"[voice]{''.join(mix)}amix=inputs={1 + len(mix)}:duration=first:normalize=0,"
                   f"afade=t=out:st={max(0.0, total - a_out):.2f}:d={a_out:.2f},{LIMITER}[aout]")
    else:
        agraph += f"[voice]afade=t=out:st={max(0.0, total - a_out):.2f}:d={a_out:.2f},{LIMITER}[aout]"
    if mask:
        vgraph = vgraph.replace("[MASK]", f"[{len([x for x in inputs if x == '-i'])}:v]")
        inputs += ["-loop", "1", "-i", str(mask)]
    if wm:
        vgraph = vgraph.replace("[WMIN]", f"[{len([x for x in inputs if x == '-i'])}:v]")
        inputs += ["-loop", "1", "-i", str(Path(watermark["path"]).resolve())]
    cmd = ["ffmpeg", "-y", "-v", "error", *inputs, "-filter_complex", f"{vgraph};{agraph}",
           "-map", "[vout]", "-map", "[aout]", *final_encoder_args(hw, crf, preset, codec, bitrate_kbps),
           "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-t", f"{total:.3f}",
           *[x for k, v in (meta or {}).items() if v for x in ("-metadata", f"{k}={str(v)[:250]}")],
           "-movflags", "+faststart", str(out)]
    encoder = cmd[cmd.index("-c:v") + 1]
    try:
        _run(cmd, cwd=run_cwd)
    except RuntimeError:
        if encoder.startswith("lib") and encoder not in ("libsvtav1",):
            raise
        # hardware / optional encoder failed -> software encoder of the same codec (CPU fallback)
        i0 = cmd.index("-c:v")
        i1 = cmd.index("-pix_fmt")
        cmd[i0:i1] = final_encoder_args(None, crf, preset, codec if encoder != "libsvtav1" else "h264",
                                        bitrate_kbps)
        encoder = cmd[i0 + 1]
        _run(cmd, cwd=run_cwd)
    shutil.rmtree(seg_dir, ignore_errors=True)
    v = verify_output(out, expected_duration=total)
    if not v["ok"]:
        raise RuntimeError(f"Output failed verification: {v}")
    jumps = sum(1 for p in pieces if p.get("jump"))
    v["output"] = {"width": out_w, "height": out_h, "shots": len(shots), "pieces": len(pieces),
                   "jump_cuts": jumps, "removed_seconds": round((end - start) - total, 2),
                   "duration": round(total, 2), "edit_style": edit_style,
                   "music": Path(music).stem if music else None, "sfx": len(sfx),
                   "graphics": bool(graphics_ass) or progress_bar, "changes": changes,
                   "slow_push": slow_push, "encoder": encoder, "frame": frame, "codec": codec,
                   "bitrate_kbps": bitrate_kbps, "voice_enhance": voice_enhance, "fx": fxc,
                   "watermark": {k: wm[k] for k in ("position", "size", "opacity")} if wm else None,
                   "music_section": [round(music_start, 2), round(music_end, 2) if music_end else None] if music else None,
                   "music_delay": round(music_delay, 2) if music else None,
                   "orig_volume": round(ov, 2), "duck_level": (duck_level if duck else "off") if music else None,
                   "music_mode": (music_mode if music_mode in ("bed", "sting") else ("sting" if total > 90 else "bed")) if music else None}
    return v
